                        ICPSR 27981

Testing a Model of Domestic Abuse Against Elder Women and Barriers
to Help-Seeking in Miami-Dade County, Florida, 2006


This data collection consists of 1 quantitative data file (Part 1), 
8 interview files in a WinZip Archive (Part 2).

Each interview is available in plain text (.txt), and Portable Document 
Format (.pdf).

This data collection consists of 1 quantitative data file (Dataset 1, 
da27981-0001.sav) and 8 qualitative interview files ina WinZip Archive
(Dataset 2, pkg27981-0002_REST.zip).

Downloadable and restricted access version of Dataset 1 (da27981-0001.sav)
are available. Users should refer to the "Codebook Notes" section of the
codebook for details on the differences between th two versions of the data.

Dataset 2 (pkg27981-0002_REST.zip is only available through the restricted
access procedures. All direct indentifiers have been removed from the data.
Replace text can be indentified by enclosure in [square brackets].

Users interested in obtaining restricted data must complete and sign a
Restricted Data Use Agreement, describe the research project and data
protection plan, and obtain IRB approval or notice of exemption for their
research.