
*HSE. 
RENAME VARIABLES (OptimF=OPTIM).
RENAME VARIABLES (Useful=USE).
RENAME VARIABLES (IntPeop=INTREST).
RENAME VARIABLES (Dealprb=DEAL).
RENAME VARIABLES (ThkClr=THINK).
RENAME VARIABLES (Goodme=GOOD).
RENAME VARIABLES (ClsePeop=CLOSE).
RENAME VARIABLES (Confidet=CONFID2).
RENAME VARIABLES (Makemind=MIND).
RENAME VARIABLES (Loved=LOVE).
RENAME VARIABLES (IntThgs=INTRST2).
RENAME VARIABLES (passmkb=bothersm).
RENAME VARIABLES (passmk4=psmkpp) .
RENAME VARIABLES (cigreg=cigregs).
RENAME VARIABLES (smoke1=smokenow).

RENAME VARIABLES (Adults=NOFAd).
RENAME VARIABLES (Children=NOFCh).
RENAME VARIABLES (Infants=NOFInf).
RENAME VARIABLES (Persno=Person).
RENAME VARIABLES (hrpothpd=HOthPaid).
RENAME VARIABLES (hrppayag=HPayAge).
RENAME VARIABLES (hrppylst=HPayLast).
RENAME VARIABLES (hrppaymn=HPayMon).
RENAME VARIABLES (FinOutC=Outcome).
RENAME VARIABLES (IndOut=IOut).
RENAME VARIABLES (Ill12m=longill12).
RENAME VARIABLES (srcin01c=SrcInc1).
RENAME VARIABLES (srcin02c=SrcInc2).
RENAME VARIABLES (srcin03c=SrcInc3).
RENAME VARIABLES (srcin04c=SrcInc4).
RENAME VARIABLES (srcin11c=SrcInc5).
RENAME VARIABLES (srcin05c=SrcInc6).
RENAME VARIABLES (srcin07c=SrcInc7).
RENAME VARIABLES (srcin12c=SrcInc9).
RENAME VARIABLES (srcin14c=SrcInc10).
RENAME VARIABLES (srcin15c=SrcInc12).
RENAME VARIABLES (srcin16c=SrcInc14).
RENAME VARIABLES (srcin17c=SrcInc15).
RENAME VARIABLES (gavehlp=RG15a).
RENAME VARIABLES (Hlthemp3=RG192).
RENAME VARIABLES (Hlthemp4=RG193).
RENAME VARIABLES (Hlthemp5=RG194).
RENAME VARIABLES (Hlthemp6=RG195).
RENAME VARIABLES (Hlthemp2=RG197).
RENAME VARIABLES (Hlthemp1=RG198).
RENAME VARIABLES (Hlthemp7=RG1910).
RENAME VARIABLES (Hlthemp8=RG1911).
RENAME VARIABLES (DocBP=docnurbp).
RENAME VARIABLES (OthBP=nopregbp).
RENAME VARIABLES (MedBP=medcinbp).
RENAME VARIABLES (BPStill=stillbp).
RENAME VARIABLES (EverMed=pastabbp).
RENAME VARIABLES (Diabetes=docinfo1).
RENAME VARIABLES (DiPreg=pregdi).
RENAME VARIABLES (DiOth=nopregdi).
RENAME VARIABLES (DiAge=ageinfo1).
RENAME VARIABLES (DiMed=medcindi).
RENAME VARIABLES (PayAge=PayAge).
RENAME VARIABLES (complst1=compm1).
RENAME VARIABLES (complst2=compm2).
RENAME VARIABLES (complst3=compm3).
RENAME VARIABLES (complst4=compm4).
RENAME VARIABLES (complst5=compm5).
RENAME VARIABLES (complst6=compm6).
RENAME VARIABLES (complst7=compm7).
RENAME VARIABLES (complst8=compm8).
RENAME VARIABLES (complst9=compm9).
RENAME VARIABLES (complst10=compm10).
RENAME VARIABLES (complst11=compm11).
RENAME VARIABLES (complst12=compm12).
RENAME VARIABLES (complst13=compm13).
RENAME VARIABLES (complst14=compm14).
RENAME VARIABLES (complst15=compm15).
RENAME VARIABLES (complst17=compm17).
RENAME VARIABLES (complst18=compm18).
RENAME VARIABLES (complst99=compm99).
RENAME VARIABLES (condlcnt=condcnt).
RENAME VARIABLES (condlcnt2=condcnt2).
RENAME VARIABLES (illmore1=condcnt3).
RENAME VARIABLES (Limlast =limitill).

RENAME VARIABLES (DDrinkAg=DDrkAg08).
RENAME VARIABLES (Totalwu=drating).
RENAME VARIABLES (hrs10hwkg=hrhwkg10).
RENAME VARIABLES (hrs10mang=hrmang10).
RENAME VARIABLES (Walk10no=WalkNo10).
RENAME VARIABLES (hrs10wlka=hrwalk10X).
RENAME VARIABLES (d7unitwg=d7ut08).
RENAME VARIABLES (d7unitwgrp=d7ut08g).
RENAME VARIABLES (Walk10no65=WalkNo10R) .


*-----. 
*HSE. 
RECODE age (0 thru 15=-1) (16 thru 44 =1) (45 thru 64=2) (65 thru hi=3) INTO ag16g3. 
VARIABLE LABELS ag16g3 "(D) Age 16+ in 3 groups". 
VALUE LABELS ag16g3 
	-1 'Item not applicable'
	1 "16-44" 
	2 "45-64" 
	3 "65+".

*HSE. 
RECODE age (0 thru 15=-1) (16 thru 44 =1) (45 thru 64=2) (65 thru 74=3)(75 thru HI=4) (else=-1) INTO ag16g4. 
VARIABLE LABELS ag16g4 "(D) age 16+ - four groups". 
VALUE LABELS ag16g4 
 	-1 'Item not applicable'
	1 "16-44" 
	2 "45-64" 
	3 "65-74"
	4 "75+".

*-----. 
*HSE. 
RECODE marstatc (1=3) (2=1) (3=1) (4=4) (5=5) (6=6) (7=2) (else=copy) into maritalg.
VALUE LABELS maritalg 
	1 "Married / civil partnership"
	2 "Living as married"
	3 "single"
	4 "married / civil partnership separated"
	5 "divorced / disolved civil partnership"
	6 "widowed / surviving civil partner"
	-9 "Refused"
	-8 "Don't know"
	-2 "Schedule not applicable"
	-1 "Item not applicable".

* HSE. 
RECODE couple (3=1).


*SHES. 
RECODE OwnRnt08 (1=1) (2=2) (3=3) (4=4) (5=6) (lo thru -1 = copy) into tenureC.
IF (OwnRnt08=4 and LandLord gt 2) tenureC=5.
VARIABLE LABELS  tenureC "Tenure".
VALUE LABELS tenureC
	1 "Buying with mortage/loan"
	2 "Own it outright"
	3 "Part rent/part mortgage"
	4 "Rent - from a private landlord"
	5 "Rent - from council or housing association "
	6  "Living here rent free"
	-8 "Don't know"
	-9 "Refused".

*HSE. 
RECODE tenureb (1=2) (2=1) (6=5) (else=copy) into OwnRnt08.
VALUE LABELS OwnRnt08 
	-9 "Refused"
	-8 "Don't know"
	-2 "Schedule not applicable"
	-1 "Item not applicable"
	1 "Buying with mortage/loan"
	2 "Own it outright"
	3 "Part rent/part mortgage"
	4 "Rent (including rents paid by housing benefit)"
	5 "Living here rent free".


*HSE. 
RECODE OwnRnt08 (1=1) (2=2) (3=3) (4=4) (5=6) (lo thru -1 = copy) into tenureC.
IF (OwnRnt08=4 and LandLord gt 2) tenureC=5.
VARIABLE LABELS  tenureC "Tenure".
VALUE LABELS tenureC
	1 "Buying with mortage/loan"
	2 "Own it outright"
	3 "Part rent/part mortgage"
	4 "Rent - from a private landlord"
	5 "Rent - from council or housing association "
	6  "Living here rent free"
	-8 "Don't know"
	-9 "Refused".

*-----.
*SHES. 
RECODE car12 (1=1)(2=2)(3 thru hi=3)(else=-1) into numcars.
VARIABLE LABELS numcars "Number of cars in household".
VALUE LABELS numcars 1 "1" 2 "2" 3 "3 or more" -1 "not applicable".

*HSE. 
RECODE SCSEXID (5=-9)(else=copy) into SXORIEN.
VALUE LABELS SXORIEN 
	1 "Heterosexual or Straight"
	2 "Gay or Lesbian"
	3 "Bisexual"
	4 "Other"
	-9 "No answer/refused"
	-1 "Item not applicable".

*-----. 
* SHeS.
RECODE Religi09 (0=1)(1=3)(2=2)(3=3)(4=7)(5=4)(6=8) (7=6) (8=5) (9,10=9)(-1=-9) (else=copy) into Religsc.
VARIABLE LABELS Religsc "Religion".
VALUE LABELS Religsc 
	1 "No religion"
	2 "Christian - Catholic"
	3 "Christian � all other denominations"
	4 "Buddhist"
	5 "Hindu"
	6 "Jewish"
	7 "Muslim"
	8 "Sikh"
	9 "Any other religion"
	-9 "Refused/no answer"
	-8 "Don't know".

*-----. 
*HSE.
RECODE origin (1=1) (2 thru 4=2) (14 thru 16=3) (9 thru 13=4) (5 thru 8=5) (17,18=6) (lo thru -1=copy) into ethnicC.
VARIABLE LABELS ethnicC "Ethnicity".
VALUE LABELS ethnicC 
	1 "White British"
	2 "White other"
	3 "Black/African/Caribbean/Black British"
	4 "Asian/Asian British"
	5 "Mixed/multiple ethnic groups"
	6 "Other ethnic groups".

*SHES. 
RECODE ethnic12 (1,2=1) (3 thru 6=2) (13 thru 17=3) (8 thru 12=4) (7=5) (18,19=6) (lo thru -1=copy) into ethnicC.
VARIABLE LABELS ethnicC "Ethnicity".
VALUE LABELS ethnicC 
	1 "White British"
	2 "White other"
	3 "Black/African/Caribbean/Black British"
	4 "Asian/Asian British"
	5 "Mixed/multiple ethnic groups"
	6 "Other ethnic groups".

*HSE. 
RECODE SrcInc7 (-9,-8,-1=copy) into SrcInc8.
IF (srcin09c =1 or srcin10c=1) SrcInc8=1.
RECODE SrcInc8 (sysmis=0).
VARIABLE LABELS srcinc8 "Income: Working Tax Credit, Child Tax Credit or any other tax credit".
VALUE LABELS srcinc8
 	0 "Not mentioned" 
	1 "Mentioned" 
	-9 "Not answered"
	-8 "Don't know"
	-1 "Not applicable".

*-----. 
*SHES. 
IF any (1, SrcInc11, SrcInc13) SrcInc14=1.

*both.
SELECT IF eqvinc>0.
RANK
  VARIABLES = eqvinc
  /NTILES(3)
  /PRINT = NO
  /TIES = MEAN .
SORT CASES BY neqvinc .

SPLIT FILE
  SEPARATE BY neqvinc .
DESCRIPTIVES
  VARIABLES=eqvinc
  /STATISTICS=MEAN STDDEV MIN MAX .
SPLIT FILE OFF.

RECODE eqvinc (35100 thru hi=1)(17402  thru 35100=2) (0 thru 17402=3)
  (ELSE=-1) INTO eqv3.

VARIABLE LABELS eqv3 "(D) Equivalised Income Teriles".
VALUE LABELS eqv3
	-1 'Item not applicable'
	1 'Top Tertile (>=�35100)'
	2 '2nd Tertile (>=�17402 < 35100)'
	3 'Bottom Tertile (<�17402)'.

*Both. 
SELECT IF eqvinc>0.
RANK
  VARIABLES = eqvinc
  /NTILES(5)
  /PRINT = NO
  /TIES = MEAN .
SORT CASES BY neqvinc .

SPLIT FILE
  SEPARATE BY neqvinc .
DESCRIPTIVES
  VARIABLES=eqvinc
  /STATISTICS=MEAN STDDEV MIN MAX .
SPLIT FILE OFF.

RECODE eqvinc (49400 thru hi=1)(29939 thru 49400=2)
  (19640 thru 29939 =3)(13057 thru 19640 =4)(0 thru 13057=5)
  (ELSE=-1) INTO eqv5.
VARIABLE LABELS eqvinc "(D) Equivalised Income".
VARIABLE LABELS eqv5 "(D) Equivalised Income Quintiles".
VALUE LABELS eqvinc -1 'Item not applicable'.
VALUE LABELS eqv5
 	-1 'Item not applicable'
 	1 'Top Quintile (>=�49400 )'
  	2 '2nd Quintile (>=�29939 < �49400 )'
 	3 '3rd Quintile (>=�19204< �29939)'
 	4 '4th Quintile (>=�13057 < �19204)'
  	5 'Bottom Quintile (<�13057)'.

*SHES. 
COMPUTE Econact_1=neconacb.
VARIABLE LABELS Econact_1 "Economic activity basic".
VALUE LABELS  Econact_1 1"In employment" 2 "ILO unemployed" 3 "Inactive".

RECODE econac12 (1=2) (2=1)(5=3)(3,4,6,7=5)(else=copy) into Econact_2.
IF (neconacb=2) Econact_2=4.
VARIABLE LABELS Econact_2 "Economic activity condensed".
VALUE LABELS Econact_2
	1 "In employment, self emp or govt training"
	2 "In full-time education"
	3 "Retired"
	4 "ILO unemployed"
	5 "Other inactive".

RECODE econac12 (1=6)(2=2)(5=7)(3,4,6,7=9)(else=copy) into Econact_3.
IF (neconacb=2) Econact_3=8.
IF (econac12 =2 and Employe=1 and FtPtime=1)Econact_3=1.
IF (econac12 =2 and Employe=1 and FtPtime=2)Econact_3=2.
IF (econac12 =2 and Employe=2 and FtPtime=1)Econact_3=3.
IF (econac12 =2 and Employe=2 and FtPtime=2)Econact_3=4.
IF (NGvtSchm=1) Econact_3=5.
VARIABLE LABELS Econact_3 "Economic activity full".
VALUE LABELS Econact_3
	1 "In employment -employee - full time"
	2 "In employment - employee - part time"
	3 "In emplyment - self-employed - full time"
	4 "In employment - self-employed - part time"
	5 "On govt training scheme"
	6 "In full-time education"
	7 "Retired"
	8 "ILO unemployed"
	9 "Other inactive".

DO IF econact_3=9 and econac12=7.
RECODE econact_1 (1=3).
END IF.

*HSE. 
RECODE  Econact (1=1) (2=2)(3,4=3) (else=copy) into  Econact_1.
VARIABLE LABELS Econact_1 "Economic activity basic".
VALUE LABELS  Econact_1 1"In employment" 2 "ILO unemployed" 3 "Inactive".

RECODE activb (2,3,4=1)(1=2) (9=3) (5,6,7,8,10,95=5) into Econact_2.
IF any(1,stwork,wkstrt2) Econact_2=4.
IF any(-9,activb,stwork,wkstrt2,wklook4) Econact_2=-9.
IF any(-8,activb,stwork,wkstrt2,wklook4) Econact_2=-8.
VARIABLE LABELS Econact_2 "Economic activity condensed".
VALUE LABELS Econact_2
	1 "In employment, self emp or govt training"
	2 "In full-time education"
	3 "Retired"
	4 "ILO unemployed"
	5 "Other inactive".

RECODE Econact_2 (2=6)(3=7)(4=8)(5=9)(lo thru -1=copy) into Econact_3.
IF (Econact_2=1 and Employe=1 and FtPtime=1)Econact_3=1.
IF (Econact_2=1 and Employe=1 and FtPtime=2)Econact_3=2.
IF (Econact_2=1  and Employe=2 and FtPtime=1)Econact_3=3.
IF (Econact_2=1  and Employe=2 and FtPtime=2)Econact_3=4.
IF (activb=3) Econact_3=5.
VARIABLE LABELS Econact_3 "Economic activity full".
VALUE LABELS Econact_3
	1 "In employment -employee - full time"
	2 "In employment - employee - part time"
	3 "In emplyment - self-employed - full time"
	4 "In employment - self-employed - part time"
	5 "On govt training scheme"
	6 "In full-time education"
	7 "Retired"
	8 "ILO unemployed"
	9 "Other inactive".

* 124 SHeS cases inconsistent because can be in education AND working in SHeS but not HSE.  RECODE them to be consistent with HSE.
DO IF Econact_3=6 and Econact_1=1.
RECODE Econact_1 (1=3).
END IF.


*SHES. 
COMPUTE HighQual=-9.
IF (TopQua12=1)HighQual=6.
IF any (1,TopQua9, TopQua10)HighQual=5.
IF any (1, TopQua1, TopQua2,TopQua3)HighQual=4.
IF any (1,TopQua4,TopQua5)HighQual=3.
IF any (1,TopQua6, TopQua11)HighQual=2.
IF (TopQua7=1 or TopQua8 =1) HighQual=1.

VARIABLE LABELS HighQual "Highest educational qualIFication".
VALUE LABELS HighQual 
	1 "Degree (or equivalent) or higher"
	2 "Higher education below degree"
	3 "A-level / Scottish highers / or equivalent"
	4 "GCSE /Scottish Standard Grades / or equivalent"
	5 "Other"
	6 "No qualIFications"
	-9 'Not answered'.

*HSE. 
COMPUTE HighQual=-9.
IF (Qual=2 or QualA19=1)HighQual=6.
IF (QualA29=1) HighQual=5.
IF any (1, QualA8, QualA12, QualA13,QualA14,QualA15, QualA16, QualA17,
QualA18, QualA20, QualA21, QualA22, QualA26, QualA27,QualA28)HighQual=4.
IF any (1,QualA5, QualA7, QualA9, QualA10, QualA11, QualA25)HighQual=3.
IF any (1,QualA2, QualA3,QualA4,QualA6)HighQual=2.
IF any (1,QualA1,  QualA23,QualA24) HighQual=1.

VARIABLE LABELS HighQual "Highest educational qualIFication".
VALUE LABELS HighQual 
	1 "Degree (or equivalent) or higher"
	2 "Higher education below degree"
	3 "A-level / Scottish highers / or equivalent"
	4 "GCSE /Scottish Standard Grades / or equivalent"
	5 "Other"
	6 "No qualIFications"
	-9 'Not answered'.

*HSE. 
RECODE hpnssec8 hpnssec5 hpnssec3 NSSEC8 NSSEC5 NSSEC3 (8,99=-8).

*SHES. 
RECODE sclass (7=-9).
ADD VALUE LABELS sclass -9 "Refused/not classIFiable".

*HSE. 
RECODE sclass (1=1)(2=2)(3.1=3)(3.2=4)(4=5)(5=6)(0=-9)(else=copy).

*hse. 
RECODE RG15a (0=2).

*HSE. 
COMPUTE condcnt4=condcnt.
IF (longill12 = 2) condcnt4 = -1.
VARIABLE LABELS condcnt4 "(D) Number of grouped conditions (all those with illness)" .
VALUE LABELS condcnt4 -1 "Item not applicable" -9 "Refused/not answered" .

*HSE.
COMPUTE bmivg5=-1.
RECODE bmival (40 thru hi=5) (30 thru 40=4) (25 thru 30=3) (18.5 thru 25=2) (0 thru 18.5=1)(lo thru -1=COPY) INTO bmivg5. 
IF range(age,0,15) bmivg5=-2.
VARIABLE LABELS bmivg5 "(D) Valid BMI (grouped)". 
VALUE LABELS bmivg5 
	1 "Under 18.5" 
	2 "18.5 to less than 25" 
	3 "25 to less than 30" 
	4 "30 to less than 40" 
	5 "40 and over"
	-2 "Schedule not applicable"
	-1 "Item Not Applicable".

*HSE.
COMPUTE bmivg4=-1.
RECODE bmival (30 thru hi=4) (25 thru 30=3) (18.5 thru 25=2) (0 thru 18.5=1)(lo thru -1=COPY) INTO bmivg4. 
IF range(age,0,15) bmivg4=-2.
VARIABLE LABELS bmivg4 "(D) Valid BMI (4 groups)". 
VALUE LABELS bmivg4 
	1 "Under 18.5" 
	2 "18.5 to less than 25" 
	3 "25 to less than 30" 
	4 "30 and over" 
	-2 "Schedule not applicable"
	-1 "Item Not Applicable".


*SHES. 
RECODE GHQg2 (-99 thru -2=-99) (1=0) (2=0) (3=1)(else=copy) into GHQ.
VARIABLE LABELS GHQ "(D) GHQ binary".
VALUE LABELS GHQ
	0 "Score 0-3"
	1 "Score 4"
	-99 "No score available".

*SHES. 
RECODE passmk1 passmk2 passmk3 (-6,-2=-1).
VALUE LABELS passmk1 passmk2 passmk3 
	-9.00 "No answer/refused"
	-8.00 "Don't know"
	-1.00 "Item not applicable"
	0  "No"
	1 "Yes".

*SHES. 
RECODE age (16 thru 34=1)(35 thru 54=2)(55 thru 74=3)(75 thru hi=4)into smkage.
VARIABLE LABELS smkage "(D) Age banded for smoking table (18+)".
VALUE LABELS smkage -1 "Item not applicable" 1 '16-34' 2 '35-54' 3 '55-74' 4'75+'.

*HSE.
RECODE age (16 thru 34=1)(35 thru 54=2)(55 thru 74=3)(75 thru hi=4)into smkage.
VARIABLE LABELS smkage "(D) Age banded for smoking table (18+)".
VALUE LABELS smkage -1 "Item not applicable" 1 '16-34' 2 '35-54' 3 '55-74' 4'75+'.

*SHES. 
FORMATS cigdyal (F8.1).

*HSE.
RECODE cigst1 (4=1)(2,3=2)(1=3) (ELSE=COPY) INTO cigst3.
VARIABLE LABELS cigst3 "(D) Cigarette smoking status - 3 categories".
VALUE LABELS cigst3
 	1 "Current cigarette smoker"
 	2 "Ex-smoker"
 	3 "Never smoked"
	-9 "Refused/not answered"
	-8 "Don't know"
	-6 "Schedule not obtained"
	-2 "Schedule not applicable"
	-1 "Item not applicable".

*HSE.
IF ANY (0,passmk1,passmk3)psmkhm=0.
IF ANY (1,passmk1,passmk3)psmkhm=1.
RECODE passmk1 (lo thru -1=COPY) into psmkhm.
VARIABLE LABELS psmkhm "(D) Ever exposed to passive smoke in own or others home".
VALUE LABELS psmkhm
 	0 "Never exposed"
	1"Exposed"
	-9 "Refused/not answered"
	-8 "Don't know"
	-6 "Schedule not obtained"
	-2 "Schedule not applicable"
	-1 "Item not applicable".

*HSE.
RECODE endsmoke (1=3)(2 thru 4=4)(5 thru 9=5)(10 thru 19=6)(20 thru hi=7) (else=copy) into longstop.
IF (longend=1)longstop=1.
IF (longend=2)longstop=2.
VARIABLE LABELS longstop  "(D) How long since stopped smoking - grouped".
VALUE LABELS longstop 
	 1 "In past 6 months"
	 2 "6 month<1 year"
	 3 "1<2 years"
	4 "2<5 years"
	5 "5<10 years"
	6 "10<20 years"
	7 "20 or more years"
	-9 "Refused/not answered"
	-8 "Don't know"
	-6 "Schedule not obtained"
	-2 "Schedule not applicable"
	-1 "Item not applicable".



*HSE.
COMPUTE whstop = -1.
DO IF cigst1 = 3.
IF (longend = 1) whstop = 1.
IF (longend = 2) whstop = 2.
IF (endsmoke =1) whstop = 3.
IF (endsmoke > 1) and (endsmoke < 5) whstop = 4.
IF (endsmoke > 4) and (endsmoke < 10) whstop = 5.
IF (endsmoke > 9) and (endsmoke < 20) whstop = 6.
IF (endsmoke > 19) whstop = 7.
END IF.
VARIABLE LABELS whstop '(D) Length of time since stopped regular smoking'.
VALUE LABELS whstop
	-1 "Item not applicable"
	1 In past six months
	2 6 months<1 year
	3 1<2 years
	4 2<5 years
	5 5<10 years
	6 10<20 years
	7 20 or more years.


*SHES. 
RECODE Nactygr (-6,-2=-1).
VALUE LABELS Nactygr
	-9	"Refused"
	-8	"Don't know"
	-1	"Item not applicable"
	0	"None"
	1	"One"
	2	"Two"
	3	"Three"
	4	"4 or more".

*HSE.
RECODE Nactygr (4 thru 8=4).
VALUE LABELS Nactygr
	-9	"Refused"
	-8	"Don't know"
	-1	"Item not applicable"
	0	"None"
	1	"One"
	2	"Two"
	3	"Three"
	4	"4 or more". 


*HSE. 
compute notlot=anyacty.
if nactivy=1 & gala=1 notlot = 2.

*Both. 
if any (1, galt, galu, galj) online2=1.
if galt=2 & galu=2 & galj=2 online2=2.
if galt=-9 & galu=-9 & galj=-9 online2=-9.
if galt=-1 online2=-1.
recode online2 (sysmis=-8).

*HSE. 
RECODE drating (-9=COPY)(-8=COPY)(-1=COPY)(-6=COPY)(0 thru hi=0) INTO overlim.
IF sex=1 & drating gt 21 overlim=1.
IF sex=2 & drating gt 14 overlim=1.
IF AGE LT 16 overlim=-2.
VARIABLE LABELS overlim "(D) Drinking in relation to weekly limits (includes non-drinkers)".
VALUE LABELS overlim
	 0 "From 0 up to and including weekly limit M21,F14"	
	 1 "Over weekly limits: M21,F14"	
	-9 "Refused/not answered"	
	-8 "Don't know"	
	-6 "Schedule not obtained"	
	-2 "Schedule not applicable"	
	-1 "Item not applicable".	


*HSE. 
RECODE alcbsmt (1 thru 3 = 1) (4=2) (5=3) (6 thru 8 = 4) (else=copy) into alcbsmt2.
VARIABLE LABELS alcbsmt2 '(D) Alcohol consumption:men ver2'.
VALUE LABELS alcbsmt2
	1 'Never/Ex/Under 1 unit per wk'	
	2 'Over 1-10'	
	3 'Over 10-21'	
	4 'Over 21'	
	-9 "Refused/not answered"	
	-8 "Don't know"	
	-6 "Schedule not obtained"	
	-2 "Schedule not applicable"	
	-1 "Item not applicable".	

*HSE. 
RECODE alcbswt (1 thru 3 = 1) (4=2) (5=3) (6 thru 8 =4) (else=copy) into alcbswt2.
VARIABLE LABELS alcbswt2 '(D) Alcohol consumption:women ver2'.
VALUE LABELS alcbswt2
1 'Never/Ex/Under 1 unit per wk'
2 'Over 1-7'
3 'Over 7-14'
4 'Over 14'
-9 "Refused/not answered"
-8 "Don't know"
-6 "Schedule not obtained"
-2 "Schedule not applicable"
-1 "Item not applicable".

*HSE. 
COMPUTE d7ut08_2=d7ut08.
IF d7day=2 d7ut08_2=0.
IF dnnow = 2 d7ut08_2 = 0.
IF dnnow = 2 and d7day = 1 d7ut08_2=d7ut08.
IF dnnow = 1 and dnoft = 8 d7ut08_2 = 0.
VARIABLE LABELS d7ut08_2 "(D) Units drunk on heaviest day (ALL 16+)".
VALUE LABELS d7ut08_2
-1"Item not applicable"
-2 "Schedule not applicable"
-6 "Schedule not obtained"
-8 "Don't know"
-9 " Refused".

*HSE. 
RECODE d7ut08_2 (0=0)(0 thru 2=1)(2 thru 3=2)(3 thru 4=3)(4 thru 5=4)(5 thru 6=5)(6 thru 8=6)(8 thru hi=7) (else=copy) into d7ut08g_2.
VARIABLE LABELS d7ut08g_2  "(D)  units drunk on heaviest day in last 7 (ALL 16+ grouped) including non-drinkers".
VALUE LABELS d7ut08g_2
  0 "Did not drink in last week"
 1 "Up to and including 2"
 2 "Over 2 and up to (& including) 3"
 3 "Over 3 and up to (& including) 4"
 4 "Over 4 and up to (& including) 5"
 5 "Over 5 and up to (& including) 6"
 6 "Over 6 and up to (& including) 8"
 7 "Over 8"
-1"Item not applicable"
-2 "Schedule not applicable"
-6 "Schedule not obtained"
-8 "Don't know"
-9 " Refused".

*HSE. 
* dlimt4v2.
RECODE d7ut08g_2 (1 thru 3 = 0) (4 thru 8 =1) (else=copy) into dlimt4v2.
IF sex = 2 dlimt4v2 = -1.
VARIABLE LABELS dlimt4v2 '(D) Heaviest day - over daily limit - men - More than 4 units - ALL 16+'.
VALUE LABELS dlimt4v2 
0 '4 or less units'
1 'Over 4 units'.


*HSE. 
* dlimt3v2.
RECODE d7ut08g_2 (1 thru 2 = 0) (3 thru 8 =1) (else=copy) into dlimt3v2.
IF sex = 1 dlimt3v2 = -1.
VARIABLE LABELS dlimt3v2 '(D) Heaviest day - over daily limit - women - More than 3 units - ALL 16+'.
VALUE LABELS dlimt3v2
0 '3 or less units'
1 'Over 3 units'.


*HSE. 
* dlimt6v2.
RECODE d7ut08g_2 (1 thru 5 = 0) (6 thru 8 =1) (else=copy) into dlimt6v2 .
IF sex = 1 dlimt6v2 = -1.
VARIABLE LABELS dlimt6v2  '(D) Heaviest day - over daily limit - women - More than 6 units - ALL 16+'.
VALUE LABELS dlimt6v2  
	0 '6 or less units'
	1 'More than 6 units'.


*HSE. 
* dlimt8v2.
RECODE d7ut08g_2(1 thru 6 = 0) (7 =1) (else=copy) into dlimt8v2.
IF sex = 2 dlimt8v2 = -1.
VARIABLE LABELS dlimt8v2 '(D) Heaviest day - over daily limit - men - More than 8 units - ALL 16+'.
VALUE LABELS dlimt8v2 
	0 '8 or less units'
	1 'Over 8 units'.

ADD VALUE LABELS  d7ut08g_2 dlimt4v2 dlimt3v2 dlimt6v2 dlimt8v2  
	-1 "Item not applicable"
	-2 "Schedule not applicable"
               -6 "Schedule not obtained"
               -8 "Don't know"
               -9 " Refused".

*HSE.
DO IF sex=1.
IF (drating le 21) drkcat=2.
IF (drating gt 21 and drating le 50) drkcat=3.
IF (drating gt 50) drkcat=4.
END IF.

DO IF sex=2.
IF (drating le 14) drkcat=2.
IF (drating gt 14 and drating le 35) drkcat=3.
IF (drating gt 35) drkcat=4.
END IF.
IF (dnnow=2 and dnany=2) drkcat=1.
RECODE drating (lo thru -1=copy) into drkcat.

VARIABLE LABELS drkcat "(D) weekly drinking category".
VALUE LABELS drkcat 1'Non-drinker'
                               2"moderate (men up to and including 21 /women up to and including 14)"
                               3"hazardous (men over 21 up to and including 50/women over 14 up to and including 35)"
                               4"harmful (men over 50/ women over 35)"
                              -1 "Item not applicable"
                              -2 "Schedule not applicable"
                              -6 "Schedule not received"
                              -8 " Don't know"
                              -9 "Refused".

*HSE. 
COMPUTE drkcat_200=drkcat.
IF drating gt 200 drkcat_200=-1.
VARIABLE LABELS drkcat_200 "(D) weekly drinking category - excluding all over 200".
VALUE LABELS drkcat_200 
1'Non-drinker'
2"moderate (men up to and including 21 /women up to and including 14)"
3"hazardous (men over 21 up to and including 50/women over 14 up to and including 35)"
4"harmful (men over 50/ women over 35 - excluding all men/women above 200)"
-1 "Item not applicable"
-2 "Schedule not applicable"
-6 "Schedule not received"
-8 " Don't know"
-9 "Refused".

*HSE. 
DO IF sex=1.
IF (drating le 21) drkcat3=2.
IF (drating gt 21) drkcat3=3.
END IF.
DO IF sex=2.
IF (drating le 14) drkcat3=2.
IF (drating gt 14) drkcat3=3.
END IF.
IF (dnnow=2 and dnany=2) drkcat3=1.
RECODE drating (lo thru -1=copy) into drkcat3.
IF age lt 16 drkcat3=-2.

VARIABLE LABELS drkcat3 "(D) Weekly drinking category - 3 categories (non/moderate/hazardous or harmful)".
VALUE LABELS drkcat3 1'Non-drinker'
                               2"Moderate (men up to and including 21 /women up to and including 14)"
                               3"Hazardous/harmful (men over 21/women over 14)"
                              -9 "Refused"
                              -8 "Don't know"
                              -6 "Schedule obtained"
                              -2 "Schedule not applicable"
                             -1 "Item not applicable".

*HSE. 
COMPUTE alclim=-1.

DO IF SEX=1.
IF (dlimt4v2=1 OR overlim=1)alclim=3.
IF (dlimt4v2=0) AND (overlim=0) alclim=4.
IF d7day=2 AND overlim=0 alclim=4.
IF (alcbsmt=1) alclim=1.
IF (alcbsmt=2) alclim=2.
IF any (-9,alcbsmt,d7day,overlim,dlimt4v2 )alclim=-9.
IF any (-8,alcbsmt,d7day,overlim,dlimt4v2 )alclim=-8.
IF any (-6,alcbsmt,d7day,overlim,dlimt4v2 )alclim=-6.
END IF.

DO IF SEX=2.
IF (dlimt3v2=1 OR overlim=1)alclim=3.
IF (dlimt3v2=0 AND overlim=0) alclim=4.
IF d7day=2 AND overlim=0 alclim=4.
IF (alcbswt=1) alclim=1.
IF (alcbswt=2) alclim=2.
IF any (-9,alcbswt,d7day,overlim,dlimt3v2 )alclim=-9.
IF any (-8,alcbswt,d7day,overlim,dlimt3v2 )alclim=-8.
IF any (-6,alcbsmt,d7day,overlim,dlimt4v2 )alclim=-6.
END IF.

IF age lt 16 alclim=-2.

VARIABLE LABELS alclim "(D) Whether exceeds government recommendations on alcohol consumption".
VALUE LABELS alclim 	
	1 "Never drunk alcohol"
	2 "Ex drinker"
	3 "Drinks outwith government guidelines" 
	4 "Drinks within government guidelines"
	-1 "Item not applicable"
	-2 "Schedule not applicable"
	-6 "Schedule not obtained"
	-8 " Don't know"
	-9 "Refused".

*HSE. 
COMPUTE alclimLW=-5.

DO IF SEX=1.
IF (d7ut08g_2 gt 3)alclimLW=4.
IF (d7ut08g_2 gt 0 and d7ut08g_2 le 3)alclimLW=5.
IF (d7ut08g_2=0) alclimLW=3.
IF (dnevr=1) alclimLW=1.
IF (dnevr=2) alclimLW=2.
IF (d7ut08g_2 lt 0)alclimLW=d7ut08g_2.
IF age lt 16 alclimLW=-2.
END IF.

DO IF SEX=2.
IF (d7ut08g_2 gt 2)alclimLW=4.
IF (d7ut08g_2 gt 0 and d7ut08g_2 le 2)alclimLW=5.
IF (d7ut08g_2=0) alclimLW=3.
IF (dnevr=1) alclimLW=1.
IF (dnevr=2) alclimLW=2.
IF (d7ut08g_2 lt 0)alclimLW=d7ut08g_2.
IF age lt 16 alclimLW=-2.
END IF.

VARIABLE LABELS alclimLW "(D) Whether exceeds daily government recommendations on alcohol consumption".
VALUE LABELS alclimLW 
	1 "Never drunk alcohol"
	2 "Ex drinker"
	3 "Did not drink last week" 
	4 "Drank outwith daily government guidelines last week" 
	5 "Drank within daily government guidelines last week"
	-1 "Item not applicable"
	-2 "Schedule not applicable"
	-6"Schedule not obtained"
	-8 " Don't know"
	-9 "Refused".


*HSE. 
COMPUTE ovlimLW=-1.
IF((sex=1 and  dlimt4v2=0) OR (sex=2 and dlimt3v2=0)) ovlimLW=1.
IF((sex=1 and  dlimt4v2=1) OR (sex=2 and dlimt3v2=1)) ovlimLW=2.
IF(sex=1 and dlimt8v2=1) OR (sex=2 and dlimt6v2=1) ovlimLW=3.
IF (dnnow=2 and dnany=2) ovlimLW=0.
IF age lt 16 ovlimLW=-2.

VARIABLE LABELS ovlimLW "(D) Whether drank over recommended limits in last week".
VALUE LABELS ovlimLW    0"Non-drinker"
                                        1"Drank 3/4units or less"
                                         2 "Drank over 3/4 up to (and including) 6/8"
                                         3 "Drank over 6/8 units". 


*HSE. 
RECODE d7ut08_2 (-9=COPY)(-8=COPY)(-6=copy)(-1=COPY)(0 thru hi=0) INTO olimLWa.
IF sex=1 & d7ut08_2 gt  4 olimLWa=1.
IF sex=2 & d7ut08_2 gt  3 olimLWa=1.
IF AGE LT 16 olimLWa =-2.
VARIABLE LABELS olimLWa "(D) Drinking over (3/4) units in day  (includes non-drinkers)".
VALUE LABELS olimLWa
 0 "From 0 up to and including  M4,F3"
 1 "Over M4,F3"
-9 "Refused/not answered"
-8 "Don't know"
-6 "Schedule not obtained"
-2 "Schedule not applicable"
-1 "Item not applicable".

*HSE. 
RECODE d7ut08_2 (-9=COPY)(-8=COPY)(-6=copy)(-1=COPY)(0 thru hi=0) INTO olimLWb.
IF sex=1 & d7ut08_2 gt 8  olimLWb=1.
IF sex=2 & d7ut08_2 gt 6 olimLWb=1.
IF AGE LT 16 olimLWb=-2.
VARIABLE LABELS olimLWb "(D) Drinking over  (6/8) units in day  (includes non-drinkers)".
VALUE LABELS olimLWb
 0 "From 0 up to and including  M8,F6"
 1 "Over M8,F6"
-9 "Refused/not answered"
-8 "Don't know"
-6 "Schedule not obtained"
-2 "Schedule not applicable"
-1 "Item not applicable".

*HSE. 
RECODE d7many (6 thru 7=1) (1 thru 5=0) (else=copy) into d7_6plus.
VARIABLE LABELS d7_6plus "(D) Drank on 6 or more days a week".
VALUE LABELS d7_6plus
	0 "Drank on fewer than 6 days a week" 
	1 "Drank 6 or more days a week"
               -9 "Refused/not answered"
               -8 "Don't know"
               -6 "Schedule not obtained"
               -2 "Schedule not applicable"
               -1 "Item not applicable".

*HSE. 
COMPUTE drnkoft1=dnoft.
IF (dnnow=2 and dnany=2) drnkoft1=9.
IF age lt 16 drnkoft1=-2.
VARIABLE LABELS drnkoft1 "(D) Frequency of drinking alcohol (ALL 16+)".
VALUE LABELS drnkoft1 
1  'almost every day'
2  '5 or 6 days a week'
3  '3 or 4 days a week'
4 ' once or twice a week'
5  'once or twice a month'
6  'once every couple of months'
7  'once or twice in last 12 months'
8  'not at all in last 12 months'
9 'does not drink'
-9 "Refused/not answered"
-8 "Don't know"
-6 "Schedule not obtained"
-2 "Schedule not applicable"
-1 "Item not applicable".

*HSE. 
COMPUTE WALKPA65=-99.
IF range(AGE,16,64) walkpa65=walkpace.
IF age <16 walkpa65=walkpace.
IF wlk10M=2 walkpa65=walkpace.
IF age ge 65 and ((walkpace=1 | walkpace=2 | walkpace=5) and (walkeff=1)) walkpa65=3.
IF age ge 65 and ((walkpace=1 | walkpace=2 | walkpace=5) and (walkeff=2)) walkpa65=walkpace.
IF age ge 65 and ((walkpace=1 | walkpace=2 | walkpace=5) and (walkeff=-1)) walkpa65=walkpace.
IF age ge 65 and (walkpace=3 | walkpace=4) walkpa65=walkpace.
IF walkpace lt 1 walkpa65=walkpace.

VARIABLE LABELS walkpa65 "(D) Walkpace adjusted - ADJUSTED FOR OVER 65s EXERTION".
VALUE LABELS walkpa65 1 "a slow pace" 2 "a steady average pace" 3 "a fairly brisk pace" 4 "a fast pace - at least 4mph" 5 "none of these" -2 "Schedule not applicable" -1 "Item not applicable".


*BOTH.
DO REPEAT x=whtact01 whtact02 whtact03 whtact04 whtact05 whtact06 whtact07 whtact08 whtact09 whtact10 
	/y=whtac01a whtac02a whtac03a whtac04a whtac05a whtac06a whtac07a whtac08a whtac09a whtac10a .
      COMPUTE y=x.
      DO IF actphy=2.
             RECODE y (-1=0).
      END IF.
END REPEAT.
EXECUTE.

VARIABLE LABELS whtac01a	"(D) Activity: Swimming - ALL 16+"
whtac02a	"(D) Activity: Cycling  ALL 16+"
whtac03a	"(D) Activity: Workout at a gym/Exercise bike/ Weight training ALL 16+"
whtac04a	"(D) Activity: Aerobics/Keep fit/Gymnastics/ Dance for fitness ALL 16+"
whtac05a	"(D) Activity: Any other type of dancing ALL 16+"
whtac06a	"(D) Activity: Running/jogging ALL 16+"
whtac07a	"(D) Activity: Football/rugby ALL 16+"
whtac08a	"(D) Activity: Badminton/tennis ALL 16+"
whtac09a	"(D) Activity: Squash ALL 16+"
whtac10a	"(D) Activity: Exercises (eg press-ups, sit ups) ALL 16+".

VALUE LABELS whtac01a to whtac10a 
	1 "mentioned" 
	0 "not mentioned"
	-1 "item not applicable"
	-2 "Schedule not applicable"
	-8"don't know"
	-9 "refused" .

*SHES. 
RECODE urindsc (1,2=1)(3,4,5=2)(6,7,8=3) into urindC.
VARIABLE LABELS urindC "Urban or rural".
VALUE LABELS urindC 1 "Urban" 2 "Town and fringe" 3 "Rural".

*HSE. 
RECODE Urban (1=1)(2=2)(3=3) into urindC.
VARIABLE LABELS urindC "Urban or rural".
VALUE LABELS urindC 1 "Urban" 2 "Town and fringe" 3 "Rural".

RECODE urindC (sysmis=2).

*Shes. 
IF country=2 GOR1=10.
ADD VALUE LABELS GOR1 10 "Scotland".


