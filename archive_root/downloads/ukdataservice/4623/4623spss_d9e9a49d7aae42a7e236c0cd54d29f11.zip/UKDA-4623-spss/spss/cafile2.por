�����@����@����@����@@@@@@@@@@@@@@@@@@@@ASCII SPSS PORT FILE                    
00000-0000-0000-0000--------------------!3#))0303300/240&),%00000000000000000000
0200002'220'&)3000#0000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrst
uvwxyz .<(+0&[]!$*);^-/|,%_>?`:#@'="000000~000000000000000000000{}\0000000000000
00000000000000000000000000000000000000000000000000000000SPSSPORTA8/200301316/120
430112/SPSS for MS WINDOWS Release 10.041I/5B/70/7/ARTDATE40/8/0/40/8/0/CC/Artic
le Date70/4/IDNO5/5/0/5/5/0/CS/Unique Identification Number70/5/PAPER5/1/0/5/1/0
/C9/Newspaper70/3/DAY5/1/0/5/1/0/CB/Day of Week70/8/PAPERTYP5/1/0/5/1/0/CE/Newsp
aper Type70/7/ARTSIZE5/4/0/5/4/0/CO/Article Size (No. Words)70/7/ARTTYPE5/1/0/5/
1/0/CC/Article Type70/6/PAGENO5/2/0/5/2/0/CB/Page Number70/6/AUTHOR5/2/0/5/2/0/C
E/Type of Author70/7/AUTHGEN5/2/0/5/2/0/CG/Gender of Author72K/7/AUTHNME1/2K/0/1
/2K/0/CB/Author Name70/8/STORYTYP5/2/0/5/2/0/CA/Story Type70/7/SETTING5/1/0/5/1/
0/CD/Story Setting70/8/TREATMNT5/1/0/5/1/0/CF/Tone of Article70/5/CODER5/1/0/5/1
/0/CD/Name of Coder70/8/THEME1ST5/3/0/5/3/0/CA/Main Theme72K/8/THME1OTH1/2K/0/1/
2K/0/CG/Other Main Theme70/8/THME1AGR5/2/0/5/2/0/CL/Aggregated Main Theme70/8/TH
EME2ND5/3/0/5/3/0/CC/Second Theme72K/8/THME2OTH1/2K/0/1/2K/0/CI/Other Second The
me70/8/THME2AGR5/2/0/5/2/0/CN/Aggregated Second Theme70/8/THEME3RD5/3/0/5/3/0/CB
/Third Theme72K/8/THME3OTH1/2K/0/1/2K/0/CH/Other Third Theme70/8/THME3AGR5/2/0/5
/2/0/CM/Aggregated Third Theme70/8/ACTOR1ST5/4/0/5/4/0/CA/Main Actor70/7/ACT1GEN
5/2/0/5/2/0/CK/Gender of Main Actor72K/7/ACT1OTH1/2K/0/1/2K/0/CG/Other Main Acto
r70/8/ACTOR2ND5/4/0/5/4/0/CC/Second Actor70/7/ACT2GEN5/2/0/5/2/0/CM/Gender of Se
cond Actor72K/7/ACT2OTH1/2K/0/1/2K/0/CI/Other Second Actor70/8/ACTOR3RD5/4/0/5/4
/0/CB/Third Actor70/7/ACT3GEN5/2/0/5/2/0/CL/Gender of Third Actor72K/7/ACT3OTH1/
2K/0/1/2K/0/CH/Other Third Actor70/8/ACTOR4TH5/4/0/5/4/0/CC/Fourth Actor70/7/ACT
4GEN5/2/0/5/2/0/CM/Gender of Fourth Actor72K/7/ACT4OTH1/2K/0/1/2K/0/CI/Other Fou
rth Actor70/8/JOURNEV15/1/0/5/1/0/C13/Journalist Evaluation - 1st Actor70/8/JOUR
NEV25/1/0/5/1/0/C13/Journalist Evaluation - 2nd Actor70/8/EVLTING15/4/0/5/4/0/CK
/1st Actor Evaluating70/8/EVLTION15/1/0/5/1/0/CE/1st Evaluation70/7/EVLTED15/4/0
/5/4/0/CJ/1st Actor Evaluated70/8/EVLTING25/4/0/5/4/0/CK/2nd Actor Evaluating70/
8/EVLTION25/1/0/5/1/0/CE/2nd Evaluation70/7/EVLTED25/4/0/5/4/0/CJ/2nd Actor Eval
uated70/7/TONE1ST5/1/0/5/1/0/CR/Favourability to Main Actor70/7/TONE2ND5/1/0/5/1
/0/CT/Favourability to Second Actor70/6/POLICY5/1/0/5/1/0/CI/Policy Information7
0/8/PRSONLTY5/1/0/5/1/0/CN/Personality InformationD1/5/PAPER8/1/8/Guardian2/5/Ti
mes3/9/Telegraph4/B/Independent5/3/Sun6/6/Mirror7/4/Mail8/7/ExpressD1/3/DAY5/1/6
/Monday2/7/Tuesday3/9/Wednesday4/8/Thursday5/6/FridayD1/8/PAPERTYP2/1/7/Tabloid2
/A/BroadsheetD1/7/ARTTYPE2/1/8/Campaign2/C/Non-CampaignD1/6/AUTHOR6/1/K/Politica
l Journalist2/9/Columnist3/9/Not Given4/O/Non Political Journalist5/F/Can't Dete
rmine39/5/OtherD1/7/AUTHGEN3/1/4/Male2/6/Female3/F/Can't DetermineD1/8/STORYTYPA
/1/D/Straight News2/O/News Analysis/Background3/F/Feature/Profile4/G/Editorial/L
eader5/F/Comment/Opinion6/9/Interview7/D/Signed Column8/6/Sketch9/1G/Picture Cap
tion (Page 1 Campaign stories only)39/5/OtherD1/7/SETTING5/1/9/Political2/8/Camp
aign3/5/Media4/5/Other5/N/No Identifiable SettingD1/8/TREATMNT3/1/7/Serious2/C/L
ighthearted3/5/OtherD1/5/CODER2/1/7/Coder 12/7/Coder 2D1/8/THEME1ST3D/3B/E/Campa
ign Trail3C/H/Campaign Strategy3D/M/Announce Election Date3E/J/Controlled Campai
gn3F/K/Negative Campaigning3G/6/Sleaze3H/F/Gaffes/Scandals3I/H/Campaign Gimmicks
3J/15/Political Distrust/Voter Alienation3K/C/Voter Apathy3L/F/Tactical Voting3M
/D/Postal Voting3N/E/Marginal Seats3O/F/Local Elections3P/H/Hecklers/Protests3Q/
M/Risks of a Low Turnout3R/K/Risks of a Landslide3S/4/Spin3T/T/Candidate Selecti
on Procedure40/G/Electoral Reform41/G/Campaign Funding42/9/Women MPs43/R/Proport
ional Representation44/F/Prescotts Punch45/L/Dull/Tedious Campaign46/9/Grey Vote
47/B/Ethnic Vote48/A/Young Vote49/B/Female Vote4A/K/Getting Out the Vote4B/I/Med
ia Manipulation4C/9/Defectors4D/M/Departing/Retiring MPs4E/4/PEBs4F/E/Election F
raud4G/E/Wives/Partners6J/13/Election Campaign/Process - Other6L/J/Opinion Poll 
Result6M/O/Opinion Poll Design etc.6N/G/Reaction to Poll6O/I/Outcome Prediction6
P/I/Turnout Prediction6Q/Q/Media Coverage of Campaign6S/S/Party/Candidate Endors
ements6T/B/Voter Panel70/L/Stats/Facts & Figures71/H/Summary of Events72/H/Spoof
/joke column73/K/Constituency Profile9T/S/Media Coverage/Polls - OtherA1/1A/Qual
ities - Professional and/or PersonalA2/A/Aims/GoalsA3/I/Record/AchievementA4/T/C
ompare Qualities/Aims/RecordA5/H/Manifesto: LabourA6/N/Manifesto: ConservativeA7
/H/Manifesto: LibDemA8/O/Conflict Between PartiesA9/N/Conflict Within PartiesAA/
10/Party/Leader/Candidate ProfileAB/9/The LordsAC/J/Manifesto: BusinessAD/R/Blai
r/Brown Leadership PactAE/16/Post-Election Tory Leadership BattleAF/1G/Post-Elec
tion Cabinet/Whitehall ReorganisationD9/1A/Parties/Party Leaders/Candidates � Ot
herDB/A/NHS/HealthDC/9/EducationDD/H/Crime/Law & OrderDE/8/TaxationDF/H/Europe i
n GeneralDG/8/The EuroDH/8/PensionsDI/7/EconomyDJ/9/TransportDK/A/EmploymentDL/B
/EnvironmentDM/7/WelfareDN/J/Farming/AgricultureDO/B/ImmigrationDP/I/Culture/Art
s/SportDQ/G/Northern IrelandDR/D/Racial IssuesDS/Q/Internet Crime/PornographyDT/
12/National Insurance ContributionsE0/G/Local GovernmentE1/Q/Public Services in 
GeneralE2/13/Social Security inc Benefits, etcE3/10/Rural Affairs inc. Fox-Hunti
ngE4/7/HousingE5/K/Parliamentary ReformE6/M/Information/TechnologyE7/16/Private 
Sector Involvement (PPP/PFI)E9/D/Petrol PricesEA/J/Policies in GeneralEB/F/Publi
c SpendingEC/D/Stealth TaxesED/8/BusinessEE/F/Scottish IssuesEF/K/Care for the E
lderlyEG/7/DefenceEH/7/PovertyGJ/5/OtherD1/8/THME1AGRB/1/E/Policy Stories2/Q/Apa
thy/Low Turnout Stories3/F/Campaign Events4/M/Mechanics of Elections5/F/Types of
 Voters6/K/Poll/Outcome Stories7/E/Media Coverage8/N/Party/Candidate Stories9/P/
Manifesto Content StoriesA/N/Spin/Media Manipulation39/5/OtherD1/8/THEME2ND3D/3B
/E/Campaign Trail3C/H/Campaign Strategy3D/M/Announce Election Date3E/J/Controlle
d Campaign3F/K/Negative Campaigning3G/6/Sleaze3H/F/Gaffes/Scandals3I/H/Campaign 
Gimmicks3J/15/Political Distrust/Voter Alienation3K/C/Voter Apathy3L/F/Tactical 
Voting3M/D/Postal Voting3N/E/Marginal Seats3O/F/Local Elections3P/H/Hecklers/Pro
tests3Q/M/Risks of a Low Turnout3R/K/Risks of a Landslide3S/4/Spin3T/T/Candidate
 Selection Procedure40/G/Electoral Reform41/G/Campaign Funding42/9/Women MPs43/R
/Proportional Representation44/F/Prescotts Punch45/L/Dull/Tedious Campaign46/9/G
rey Vote47/B/Ethnic Vote48/A/Young Vote49/B/Female Vote4A/K/Getting Out the Vote
4B/I/Media Manipulation4C/9/Defectors4D/M/Departing/Retiring MPs4E/4/PEBs4F/E/El
ection Fraud4G/E/Wives/Partners6J/13/Election Campaign/Process - Other6L/J/Opini
on Poll Result6M/O/Opinion Poll Design etc.6N/G/Reaction to Poll6O/I/Outcome Pre
diction6P/I/Turnout Prediction6Q/Q/Media Coverage of Campaign6S/S/Party/Candidat
e Endorsements6T/B/Voter Panel70/L/Stats/Facts & Figures71/H/Summary of Events72
/H/Spoof/joke column73/K/Constituency Profile9T/S/Media Coverage/Polls - OtherA1
/1A/Qualities - Professional and/or PersonalA2/A/Aims/GoalsA3/I/Record/Achieveme
ntA4/T/Compare Qualities/Aims/RecordA5/H/Manifesto: LabourA6/N/Manifesto: Conser
vativeA7/H/Manifesto: LibDemA8/O/Conflict Between PartiesA9/N/Conflict Within Pa
rtiesAA/10/Party/Leader/Candidate ProfileAB/9/The LordsAC/J/Manifesto: BusinessA
D/R/Blair/Brown Leadership PactAE/16/Post-Election Tory Leadership BattleAF/1G/P
ost-Election Cabinet/Whitehall ReorganisationD9/1A/Parties/Party Leaders/Candida
tes � OtherDB/A/NHS/HealthDC/9/EducationDD/H/Crime/Law & OrderDE/8/TaxationDF/H/
Europe in GeneralDG/8/The EuroDH/8/PensionsDI/7/EconomyDJ/9/TransportDK/A/Employ
mentDL/B/EnvironmentDM/7/WelfareDN/J/Farming/AgricultureDO/B/ImmigrationDP/I/Cul
ture/Arts/SportDQ/G/Northern IrelandDR/D/Racial IssuesDS/Q/Internet Crime/Pornog
raphyDT/12/National Insurance ContributionsE0/G/Local GovernmentE1/Q/Public Serv
ices in GeneralE2/13/Social Security inc Benefits, etcE3/10/Rural Affairs inc. F
ox-HuntingE4/7/HousingE5/K/Parliamentary ReformE6/M/Information/TechnologyE7/16/
Private Sector Involvement (PPP/PFI)E9/D/Petrol PricesEA/J/Policies in GeneralEB
/F/Public SpendingEC/D/Stealth TaxesED/8/BusinessEE/F/Scottish IssuesEF/K/Care f
or the ElderlyEG/7/DefenceEH/7/PovertyGJ/5/OtherD1/8/THME2AGRB/1/E/Policy Storie
s2/Q/Apathy/Low Turnout Stories3/F/Campaign Events4/M/Mechanics of Elections5/F/
Types of Voters6/K/Poll/Outcome Stories7/E/Media Coverage8/N/Party/Candidate Sto
ries9/P/Manifesto Content StoriesA/N/Spin/Media Manipulation39/5/OtherD1/8/THEME
3RD3D/3B/E/Campaign Trail3C/H/Campaign Strategy3D/M/Announce Election Date3E/J/C
ontrolled Campaign3F/K/Negative Campaigning3G/6/Sleaze3H/F/Gaffes/Scandals3I/H/C
ampaign Gimmicks3J/15/Political Distrust/Voter Alienation3K/C/Voter Apathy3L/F/T
actical Voting3M/D/Postal Voting3N/E/Marginal Seats3O/F/Local Elections3P/H/Heck
lers/Protests3Q/M/Risks of a Low Turnout3R/K/Risks of a Landslide3S/4/Spin3T/T/C
andidate Selection Procedure40/G/Electoral Reform41/G/Campaign Funding42/9/Women
 MPs43/R/Proportional Representation44/F/Prescotts Punch45/L/Dull/Tedious Campai
gn46/9/Grey Vote47/B/Ethnic Vote48/A/Young Vote49/B/Female Vote4A/K/Getting Out 
the Vote4B/I/Media Manipulation4C/9/Defectors4D/M/Departing/Retiring MPs4E/4/PEB
s4F/E/Election Fraud4G/E/Wives/Partners6J/13/Election Campaign/Process - Other6L
/J/Opinion Poll Result6M/O/Opinion Poll Design etc.6N/G/Reaction to Poll6O/I/Out
come Prediction6P/I/Turnout Prediction6Q/Q/Media Coverage of Campaign6S/S/Party/
Candidate Endorsements6T/B/Voter Panel70/L/Stats/Facts & Figures71/H/Summary of 
Events72/H/Spoof/joke column73/K/Constituency Profile9T/S/Media Coverage/Polls -
 OtherA1/1A/Qualities - Professional and/or PersonalA2/A/Aims/GoalsA3/I/Record/A
chievementA4/T/Compare Qualities/Aims/RecordA5/H/Manifesto: LabourA6/N/Manifesto
: ConservativeA7/H/Manifesto: LibDemA8/O/Conflict Between PartiesA9/N/Conflict W
ithin PartiesAA/10/Party/Leader/Candidate ProfileAB/9/The LordsAC/J/Manifesto: B
usinessAD/R/Blair/Brown Leadership PactAE/16/Post-Election Tory Leadership Battl
eAF/1G/Post-Election Cabinet/Whitehall ReorganisationD9/1A/Parties/Party Leaders
/Candidates � OtherDB/A/NHS/HealthDC/9/EducationDD/H/Crime/Law & OrderDE/8/Taxat
ionDF/H/Europe in GeneralDG/8/The EuroDH/8/PensionsDI/7/EconomyDJ/9/TransportDK/
A/EmploymentDL/B/EnvironmentDM/7/WelfareDN/J/Farming/AgricultureDO/B/Immigration
DP/I/Culture/Arts/SportDQ/G/Northern IrelandDR/D/Racial IssuesDS/Q/Internet Crim
e/PornographyDT/12/National Insurance ContributionsE0/G/Local GovernmentE1/Q/Pub
lic Services in GeneralE2/13/Social Security inc Benefits, etcE3/10/Rural Affair
s inc. Fox-HuntingE4/7/HousingE5/K/Parliamentary ReformE6/M/Information/Technolo
gyE7/16/Private Sector Involvement (PPP/PFI)E9/D/Petrol PricesEA/J/Policies in G
eneralEB/F/Public SpendingEC/D/Stealth TaxesED/8/BusinessEE/F/Scottish IssuesEF/
K/Care for the ElderlyEG/7/DefenceEH/7/PovertyGJ/5/OtherD1/8/THME3AGRB/1/E/Polic
y Stories2/Q/Apathy/Low Turnout Stories3/F/Campaign Events4/M/Mechanics of Elect
ions5/F/Types of Voters6/K/Poll/Outcome Stories7/E/Media Coverage8/N/Party/Candi
date Stories9/P/Manifesto Content StoriesA/N/Spin/Media Manipulation39/5/OtherD1
/8/ACTOR1ST6I/3K/C/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Sco
ttish Nationalist Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Par
ty3R/L/UK Independence Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/
UUP - Ulster Unionist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42
/E/The Government43/B/The Cabinet44/L/Government Department45/E/The Opposition46
/R/Parliament/MPs (in general)47/18/The European Union/European Commission48/8/M
illbank49/K/Electoral Commission4A/F/Scottish Labour4B/F/Scottish Tories6H/10/Ot
her Party - British Mainland6I/10/Other Party - Northern Ireland6J/H/Other Insti
tution70/A/Blair Tony71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry (SF)
74/G/Hume John (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimbl
e David (UUP)78/I/Nick Griffin (BNP)9T/K/Party Leader - OtherAA/J/LAB: Blunkett 
DavidAB/H/LAB: Brown GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: P
rescott JohnAF/G/LAB: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/
LAB: Other Senior Labour PoliticianDK/11/LAB: Baroness Jay of PaddingtonDL/K/LAB
: Becket MargaretDM/F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB: Campbell A
listairDP/L/LAB: Darling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/
K/LAB: Mandelson PeterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Re
id JohnE3/H/LAB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Wo
odward ShaunE7/1A/LAB: Spokesperson or Unamed Party SourceE8/J/LAB: Party Offici
alE9/D/LAB: ActivistEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidat
e/PeerGJ/P/LAB: Other inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2
/I/CON: Maude FrancisH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/L/CON: Porti
llo MichaelH6/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other Senior Polit
icianKA/K/CON: Ainsworth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbuthnot JamesK
D/K/CON: Browning AngelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/
CON: Heathcote Amory DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johnson BorisKJ/J
/CON: Lansley AndrewKK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/J/CON: Plate
ll AmandaKN/K/CON: Rifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: The Lord Henl
eyKQ/P/CON: The Lord StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Spokesperson o
r Unamed Party SourceKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/CON: Council
lorL2/8/CON: MEPL3/J/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/CON: Other MP
/Candidate/PeerN9/P/CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campb
ell MenziesNM/F/LIB: Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers of 
Quarry BankNP/J/LIB: Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/
S/LIB: Other Senior PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable VincentR2/G/L
IB: Harver NickR3/J/LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore
 MichaelR6/F/LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: 
Spokesperson or Unamed Party SourceRA/J/LIB: Party OfficialRB/D/LIB: ActivistRC/
F/LIB: CouncillorRD/8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/LIB: Other i
nc. Supporter10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10E/E/Hattersley
 Roy10F/9/Heath Ted10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13
/Nellist Dave (Socialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party
)10L/1G/Taylor Dr. Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/
19/Titford Jeffrey (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Indi
vidual13K/1B/David Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scot
tish Parliament First Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13
N/1F/Rhodri Morgan (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Pa
rty)13P/13/Ian Paisley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperso
n/Supporter/etc13R/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: M
P/Candidate/Spokesperson/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson
/Supporter/etc140/1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/M/O
ther Party/Politician270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo 
Blair273/I/LAB: Anthony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/
LIB: Sarah Gurling277/P/CON: Nigel Hague (Father)29T/E/Other Relative3AA/Q/Agric
ulture Representative3AB/S/Business/City Representative3AC/1N/Business Organisat
ion eg. CBI, Institute of Directors3AD/D/Civil Servant3AE/M/Celebrity (state who
m)3AF/9/Economist3AG/19/European Leader/Politician (state whom)3AH/H/EU Represen
tative3AI/J/Farmer/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demonst
rator3AL/15/Media Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/Secur
ity3AO/E/Pressure Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollster
/Bookmaker3AS/A/Pensioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scienti
st/Scientific Expert3B2/T/Social Service Representative3B3/13/Trade Union/Repres
entative/Member3B4/P/Unamed Source - Non-Party3B5/J/University Academic3B6/10/Vo
ter/Citizen/Person in Street3B7/1K/World Leader/Politician (not European)(state 
whom)3B8/E/Geri Halliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/
Think Tank3D9/5/OtherD1/7/ACT1GEN3/1/4/Male2/6/Female3/F/Can't DetermineD1/8/ACT
OR2ND6I/3K/C/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Scottish 
Nationalist Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Party3R/L
/UK Independence Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/UUP - 
Ulster Unionist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42/E/The
 Government43/B/The Cabinet44/L/Government Department45/E/The Opposition46/R/Par
liament/MPs (in general)47/18/The European Union/European Commission48/8/Millban
k49/K/Electoral Commission4A/F/Scottish Labour4B/F/Scottish Tories6H/10/Other Pa
rty - British Mainland6I/10/Other Party - Northern Ireland6J/H/Other Institution
70/A/Blair Tony71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry (SF)74/G/H
ume John (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble Davi
d (UUP)78/I/Nick Griffin (BNP)9T/K/Party Leader - OtherAA/J/LAB: Blunkett DavidA
B/H/LAB: Brown GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: Prescot
t JohnAF/G/LAB: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/LAB: O
ther Senior Labour PoliticianDK/11/LAB: Baroness Jay of PaddingtonDL/K/LAB: Beck
et MargaretDM/F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB: Campbell Alistai
rDP/L/LAB: Darling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/K/LAB:
 Mandelson PeterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Reid Joh
nE3/H/LAB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Woodward
 ShaunE7/1A/LAB: Spokesperson or Unamed Party SourceE8/J/LAB: Party OfficialE9/D
/LAB: ActivistEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidate/Peer
GJ/P/LAB: Other inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2/I/CON
: Maude FrancisH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/L/CON: Portillo Mi
chaelH6/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other Senior PoliticianK
A/K/CON: Ainsworth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbuthnot JamesKD/K/CO
N: Browning AngelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/CON: H
eathcote Amory DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johnson BorisKJ/J/CON: 
Lansley AndrewKK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/J/CON: Platell Ama
ndaKN/K/CON: Rifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: The Lord HenleyKQ/P
/CON: The Lord StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Spokesperson or Unam
ed Party SourceKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/CON: CouncillorL2/
8/CON: MEPL3/J/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/CON: Other MP/Candi
date/PeerN9/P/CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campbell Me
nziesNM/F/LIB: Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers of Quarry
 BankNP/J/LIB: Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/S/LIB:
 Other Senior PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable VincentR2/G/LIB: Ha
rver NickR3/J/LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore Micha
elR6/F/LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: Spokes
person or Unamed Party SourceRA/J/LIB: Party OfficialRB/D/LIB: ActivistRC/F/LIB:
 CouncillorRD/8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/LIB: Other inc. Su
pporter10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10E/E/Hattersley Roy10
F/9/Heath Ted10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13/Nelli
st Dave (Socialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party)10L/1
G/Taylor Dr. Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/19/Tit
ford Jeffrey (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Individual
13K/1B/David Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scottish P
arliament First Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13N/1F/R
hodri Morgan (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Party)13
P/13/Ian Paisley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Supp
orter/etc13R/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: MP/Cand
idate/Spokesperson/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson/Suppo
rter/etc140/1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/M/Other P
arty/Politician270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair2
73/I/LAB: Anthony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: S
arah Gurling277/P/CON: Nigel Hague (Father)29T/E/Other Relative3AA/Q/Agriculture
 Representative3AB/S/Business/City Representative3AC/1N/Business Organisation eg
. CBI, Institute of Directors3AD/D/Civil Servant3AE/M/Celebrity (state whom)3AF/
9/Economist3AG/19/European Leader/Politician (state whom)3AH/H/EU Representative
3AI/J/Farmer/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demonstrator3
AL/15/Media Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/Security3AO
/E/Pressure Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollster/Bookm
aker3AS/A/Pensioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scientist/Sci
entific Expert3B2/T/Social Service Representative3B3/13/Trade Union/Representati
ve/Member3B4/P/Unamed Source - Non-Party3B5/J/University Academic3B6/10/Voter/Ci
tizen/Person in Street3B7/1K/World Leader/Politician (not European)(state whom)3
B8/E/Geri Halliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/Think 
Tank3D9/5/OtherD1/7/ACT2GEN3/1/4/Male2/6/Female3/F/Can't DetermineD1/8/ACTOR3RD6
I/3K/C/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Scottish Nation
alist Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Party3R/L/UK In
dependence Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/UUP - Ulster
 Unionist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42/E/The Gover
nment43/B/The Cabinet44/L/Government Department45/E/The Opposition46/R/Parliamen
t/MPs (in general)47/18/The European Union/European Commission48/8/Millbank49/K/
Electoral Commission4A/F/Scottish Labour4B/F/Scottish Tories6H/10/Other Party - 
British Mainland6I/10/Other Party - Northern Ireland6J/H/Other Institution70/A/B
lair Tony71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry (SF)74/G/Hume Jo
hn (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble David (UUP
)78/I/Nick Griffin (BNP)9T/K/Party Leader - OtherAA/J/LAB: Blunkett DavidAB/H/LA
B: Brown GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: Prescott John
AF/G/LAB: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/LAB: Other S
enior Labour PoliticianDK/11/LAB: Baroness Jay of PaddingtonDL/K/LAB: Becket Mar
garetDM/F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB: Campbell AlistairDP/L/
LAB: Darling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/K/LAB: Mande
lson PeterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Reid JohnE3/H/
LAB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Woodward Shaun
E7/1A/LAB: Spokesperson or Unamed Party SourceE8/J/LAB: Party OfficialE9/D/LAB: 
ActivistEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidate/PeerGJ/P/L
AB: Other inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2/I/CON: Maud
e FrancisH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/L/CON: Portillo MichaelH
6/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other Senior PoliticianKA/K/CO
N: Ainsworth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbuthnot JamesKD/K/CON: Bro
wning AngelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/CON: Heathco
te Amory DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johnson BorisKJ/J/CON: Lansle
y AndrewKK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/J/CON: Platell AmandaKN/
K/CON: Rifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: The Lord HenleyKQ/P/CON: 
The Lord StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Spokesperson or Unamed Par
ty SourceKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/CON: CouncillorL2/8/CON:
 MEPL3/J/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/CON: Other MP/Candidate/P
eerN9/P/CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campbell MenziesN
M/F/LIB: Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers of Quarry BankN
P/J/LIB: Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/S/LIB: Other
 Senior PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable VincentR2/G/LIB: Harver N
ickR3/J/LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore MichaelR6/F
/LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: Spokesperson
 or Unamed Party SourceRA/J/LIB: Party OfficialRB/D/LIB: ActivistRC/F/LIB: Counc
illorRD/8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/LIB: Other inc. Supporte
r10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10E/E/Hattersley Roy10F/9/He
ath Ted10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13/Nellist Dav
e (Socialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party)10L/1G/Tayl
or Dr. Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/19/Titford J
effrey (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Individual13K/1B
/David Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scottish Parliam
ent First Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13N/1F/Rhodri 
Morgan (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Party)13P/13/I
an Paisley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Supporter/
etc13R/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: MP/Candidate/
Spokesperson/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson/Supporter/e
tc140/1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/M/Other Party/P
olitician270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair273/I/L
AB: Anthony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: Sarah G
urling277/P/CON: Nigel Hague (Father)29T/E/Other Relative3AA/Q/Agriculture Repre
sentative3AB/S/Business/City Representative3AC/1N/Business Organisation eg. CBI,
 Institute of Directors3AD/D/Civil Servant3AE/M/Celebrity (state whom)3AF/9/Econ
omist3AG/19/European Leader/Politician (state whom)3AH/H/EU Representative3AI/J/
Farmer/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demonstrator3AL/15/
Media Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/Security3AO/E/Pre
ssure Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollster/Bookmaker3A
S/A/Pensioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scientist/Scientifi
c Expert3B2/T/Social Service Representative3B3/13/Trade Union/Representative/Mem
ber3B4/P/Unamed Source - Non-Party3B5/J/University Academic3B6/10/Voter/Citizen/
Person in Street3B7/1K/World Leader/Politician (not European)(state whom)3B8/E/G
eri Halliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/Think Tank3D
9/5/OtherD1/7/ACT3GEN3/1/4/Male2/6/Female3/F/Can't DetermineD1/8/ACTOR4TH6I/3K/C
/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Scottish Nationalist 
Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Party3R/L/UK Independ
ence Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/UUP - Ulster Union
ist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42/E/The Government4
3/B/The Cabinet44/L/Government Department45/E/The Opposition46/R/Parliament/MPs 
(in general)47/18/The European Union/European Commission48/8/Millbank49/K/Electo
ral Commission4A/F/Scottish Labour4B/F/Scottish Tories6H/10/Other Party - Britis
h Mainland6I/10/Other Party - Northern Ireland6J/H/Other Institution70/A/Blair T
ony71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry (SF)74/G/Hume John (SD
LP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble David (UUP)78/I/
Nick Griffin (BNP)9T/K/Party Leader - OtherAA/J/LAB: Blunkett DavidAB/H/LAB: Bro
wn GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: Prescott JohnAF/G/L
AB: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/LAB: Other Senior 
Labour PoliticianDK/11/LAB: Baroness Jay of PaddingtonDL/K/LAB: Becket MargaretD
M/F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB: Campbell AlistairDP/L/LAB: D
arling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/K/LAB: Mandelson P
eterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Reid JohnE3/H/LAB: S
mith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Woodward ShaunE7/1A/
LAB: Spokesperson or Unamed Party SourceE8/J/LAB: Party OfficialE9/D/LAB: Activi
stEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidate/PeerGJ/P/LAB: Ot
her inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2/I/CON: Maude Fran
cisH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/L/CON: Portillo MichaelH6/J/CO
N: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other Senior PoliticianKA/K/CON: Ain
sworth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbuthnot JamesKD/K/CON: Browning 
AngelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/CON: Heathcote Amo
ry DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johnson BorisKJ/J/CON: Lansley Andr
ewKK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/J/CON: Platell AmandaKN/K/CON:
 Rifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: The Lord HenleyKQ/P/CON: The Lo
rd StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Spokesperson or Unamed Party Sou
rceKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/CON: CouncillorL2/8/CON: MEPL3
/J/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/CON: Other MP/Candidate/PeerN9/
P/CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campbell MenziesNM/F/LI
B: Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers of Quarry BankNP/J/LI
B: Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/S/LIB: Other Senio
r PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable VincentR2/G/LIB: Harver NickR3/
J/LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore MichaelR6/F/LIB: 
Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: Spokesperson or Un
amed Party SourceRA/J/LIB: Party OfficialRB/D/LIB: ActivistRC/F/LIB: CouncillorR
D/8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/LIB: Other inc. Supporter10A/D
/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10E/E/Hattersley Roy10F/9/Heath Te
d10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13/Nellist Dave (Soc
ialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party)10L/1G/Taylor Dr.
 Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/19/Titford Jeffrey
 (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Individual13K/1B/David
 Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scottish Parliament Fi
rst Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13N/1F/Rhodri Morgan
 (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Party)13P/13/Ian Pai
sley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Supporter/etc13R
/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: MP/Candidate/Spokes
person/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson/Supporter/etc140/
1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/M/Other Party/Politic
ian270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair273/I/LAB: An
thony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: Sarah Gurling
277/P/CON: Nigel Hague (Father)29T/E/Other Relative3AA/Q/Agriculture Representat
ive3AB/S/Business/City Representative3AC/1N/Business Organisation eg. CBI, Insti
tute of Directors3AD/D/Civil Servant3AE/M/Celebrity (state whom)3AF/9/Economist3
AG/19/European Leader/Politician (state whom)3AH/H/EU Representative3AI/J/Farmer
/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demonstrator3AL/15/Media 
Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/Security3AO/E/Pressure 
Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollster/Bookmaker3AS/A/Pe
nsioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scientist/Scientific Expe
rt3B2/T/Social Service Representative3B3/13/Trade Union/Representative/Member3B4
/P/Unamed Source - Non-Party3B5/J/University Academic3B6/10/Voter/Citizen/Person
 in Street3B7/1K/World Leader/Politician (not European)(state whom)3B8/E/Geri Ha
lliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/Think Tank3D9/5/Ot
herD1/7/ACT4GEN3/1/4/Male2/6/Female3/F/Can't DetermineD1/8/JOURNEV15/0/F/Can't D
etermine1/A/Crticising2/A/Mixed/Both3/A/Supporting4/7/NeutralD1/8/JOURNEV25/0/F/
Can't Determine1/A/Crticising2/A/Mixed/Both3/A/Supporting4/7/NeutralD1/8/EVLTING
167/3K/C/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Scottish Nati
onalist Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Party3R/L/UK 
Independence Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/UUP - Ulst
er Unionist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42/E/The Gov
ernment43/B/The Cabinet44/L/Government Department45/E/The Opposition46/R/Parliam
ent/MPs (in general)47/I/The European Union6H/10/Other Party - British Mainland6
I/10/Other Party - Northern Ireland6J/H/Other Institution70/A/Blair Tony71/D/Hag
ue William72/F/Kennedy Charles73/G/Adams Gerry (SF)74/G/Hume John (SDLP)75/K/Jon
es Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble David (UUP)9T/K/Party Leade
r - OtherAA/E/Blunkett DavidAB/C/Brown GordonAC/A/Cook RobinAD/A/Hoon GeoffAE/D/
Prescott JohnAF/B/Smith ChrisAG/B/Short ClareAH/A/Straw JackD9/T/Other Labour Ca
binet MinisterDK/Q/Baroness Jay of PaddingtonDL/F/Becket MargaretDM/A/Brown Nick
DN/D/Byers StephenDO/H/Campbell AlistairDP/G/Darling AlistairDQ/B/Irvine LordDR/
D/Liddell HelenDS/F/Mandelson PeterDT/C/Milburn AlanE0/9/Mowlam MoE1/B/Murphy Pa
ulE2/9/Reid JohnE3/C/Smith AndrewE4/A/Taylor AnnE5/9/Vaz KeithE6/E/Woodward Shau
nE7/1C/Labour Spokesperson or Unamed Party SourceE8/L/Labour Party OfficialE9/F/
Labour ActivistEA/H/Labour CouncillorEB/A/Labour MEPGI/10/Other Labour MP/Candid
ate/PeerGJ/R/Other Labour inc. SupporterH0/8/Fox LiamH1/E/Jenkin BernardH2/D/Mau
de FrancisH3/B/May TheresaH4/D/Norman ArchieH5/G/Portillo MichaelH6/E/Widdecombe
 AnnH7/7/Yeo TimJT/1C/Other Conservative Shadow Cabinet MinisterKA/F/Ainsworth P
eterKB/E/Ancram MichaelKC/F/Arbuthnot JamesKD/F/Browning AngelaKE/H/Duncan-Smith
 IainKF/E/Garnier EdwardKG/L/Heathcote Amory DavidKH/H/Heseltine MichaelKI/D/Joh
nson BorisKJ/E/Lansley AndrewKK/D/Letwin OliverKL/C/McKay AndrewKM/E/Platell Ama
ndaKN/F/Rifkind MalcolmKO/D/Streeter GaryKP/F/The Lord HenleyKQ/K/The Lord Strat
hclydeKR/L/Willett David WillettKS/1I/Conservative Spokesperson or Unamed Party 
SourceKT/R/Conservative Party OfficialL0/L/Conservative ActivistL1/N/Conservativ
e CouncillorL2/G/Conservative MEPN8/16/Conservative Other MP/Candidate/PeerN9/13
/Other Conservative inc. SupporterNK/A/Beith AlanNL/G/Campbell MenziesNM/A/Foste
r DonNN/C/Hughes SimonNO/R/Lord Rodgers of Quarry BankNP/E/Taylor MatthewNQ/B/To
nge JennyNR/B/Wallace JimQJ/17/Other Lib Dem Shadow Cabinet MinisterR0/B/Breed C
olinR1/D/Cable VincentR2/B/Harver NickR3/E/Livsey RichardR4/G/Maclennan RobertR5
/D/Moore MichaelR6/A/Tyler PaulR7/A/Webb SteveR8/B/Willis PhilR9/1C/LibDem Spoke
sperson or Unamed Party SourceRA/L/LibDem Party OfficialRB/F/LibDem ActivistRC/H
/LibDem CouncillorRD/A/LibDem MEPRE/10/LibDem Other MP/Candidate/PeerTT/R/Other 
LibDem inc. Supporter10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10D/I/Gr
iffin Nick (BNP)10E/E/Hattersley Roy10F/9/Heath Ted10G/C/Kinnock Neil10H/F/Livin
gstone Ken10I/A/Major John10J/13/Nellist Dave (Socialist Alliance)10K/1A/Scargil
l Arthur (Socialist Labour Party)10L/1G/Taylor Dr. Richard (Kidderminster Indepe
ndent)10M/G/Thatcher Magaret10N/19/Titford Jeffrey (UK Independence Party)10O/G/
Hinduja Brothers139/G/Other Individual13K/1B/David Ervine (Progressive Unionist 
Party)13L/1K/Henry McLeish (Scottish Parliament First Minister)13M/1A/Gary McMic
hael (Ulster Democratic Party)13N/1F/Rhodri Morgan (Welsh Assembly First Ministe
r)13O/S/Sean Neeson (Alliance Party)13P/13/Ian Paisley (Democratic Unionist)13Q/
1E/SNP: MP/Candidate/Spokesperson/Supporter/etc13R/1D/PC: MP/Candidate/Spokesper
son/Supporter/etc13S/1G/Green: MP/Candidate/Spokesperson/Supporter/etc13T/1J/NI 
Party: MP/Candidate/Spokesperson/Supporter/etc140/1M/Other Party: MP/Candidate/S
pokesperson/Supporter/etc16J/P/Other Parties/Politicians270/H/LAB: Cherie Blair2
71/F/LAB: Euan Blair272/E/LAB: Leo Blair273/I/LAB: Anthony Booth274/H/LAB: Laure
n Booth275/G/CON: Ffion Hague276/I/LIB: Sarah Gurling29T/F/Other Relatives3AA/Q/
Agriculture Representative3AB/S/Business/City Representative3AC/1N/Business Orga
nisation eg. CBI, Institute of Directors3AD/D/Civil Servant3AE/M/Celebrity (stat
e whom)3AF/9/Economist3AG/19/European Leader/Politician (state whom)3AH/H/EU Rep
resentative3AI/J/Farmer/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/De
monstrator3AL/15/Media Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/
Security3AO/E/Pressure Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pol
lster/Bookmaker3AS/A/Pensioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Sc
ientist/Scientific Expert3B2/T/Social Service Representative3B3/13/Trade Union/R
epresentative/Member3B4/P/Unamed Source - Non-Party3B5/J/University Academic3B6/
10/Voter/Citizen/Person in Street3B7/1K/World Leader/Politician (not European)(s
tate whom)3D9/5/OtherD1/8/EVLTION15/0/F/Can't Determine1/A/Crticising2/A/Mixed/B
oth3/A/Supporting4/7/NeutralD1/7/EVLTED167/3K/C/Labour Party3L/I/Conservative Pa
rty3M/D/Lib Dem Party3N/Q/Scottish Nationalist Party3O/B/Plaid Cymru3P/B/Green P
arty3Q/M/British National Party3R/L/UK Independence Party3S/1B/SDLP - Social Dem
ocratic and Labour Party3T/R/UUP - Ulster Unionist Party40/11/DUP - Democratic U
nionist Party41/9/Sinn Fein42/E/The Government43/B/The Cabinet44/L/Government De
partment45/E/The Opposition46/R/Parliament/MPs (in general)47/I/The European Uni
on6H/10/Other Party - British Mainland6I/10/Other Party - Northern Ireland6J/H/O
ther Institution70/A/Blair Tony71/D/Hague William72/F/Kennedy Charles73/G/Adams 
Gerry (SF)74/G/Hume John (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)7
7/J/Trimble David (UUP)9T/K/Party Leader - OtherAA/E/Blunkett DavidAB/C/Brown Go
rdonAC/A/Cook RobinAD/A/Hoon GeoffAE/D/Prescott JohnAF/B/Smith ChrisAG/B/Short C
lareAH/A/Straw JackD9/T/Other Labour Cabinet MinisterDK/Q/Baroness Jay of Paddin
gtonDL/F/Becket MargaretDM/A/Brown NickDN/D/Byers StephenDO/H/Campbell AlistairD
P/G/Darling AlistairDQ/B/Irvine LordDR/D/Liddell HelenDS/F/Mandelson PeterDT/C/M
ilburn AlanE0/9/Mowlam MoE1/B/Murphy PaulE2/9/Reid JohnE3/C/Smith AndrewE4/A/Tay
lor AnnE5/9/Vaz KeithE6/E/Woodward ShaunE7/1C/Labour Spokesperson or Unamed Part
y SourceE8/L/Labour Party OfficialE9/F/Labour ActivistEA/H/Labour CouncillorEB/A
/Labour MEPGI/10/Other Labour MP/Candidate/PeerGJ/R/Other Labour inc. SupporterH
0/8/Fox LiamH1/E/Jenkin BernardH2/D/Maude FrancisH3/B/May TheresaH4/D/Norman Arc
hieH5/G/Portillo MichaelH6/E/Widdecombe AnnH7/7/Yeo TimJT/1C/Other Conservative 
Shadow Cabinet MinisterKA/F/Ainsworth PeterKB/E/Ancram MichaelKC/F/Arbuthnot Jam
esKD/F/Browning AngelaKE/H/Duncan-Smith IainKF/E/Garnier EdwardKG/L/Heathcote Am
ory DavidKH/H/Heseltine MichaelKI/D/Johnson BorisKJ/E/Lansley AndrewKK/D/Letwin 
OliverKL/C/McKay AndrewKM/E/Platell AmandaKN/F/Rifkind MalcolmKO/D/Streeter Gary
KP/F/The Lord HenleyKQ/K/The Lord StrathclydeKR/L/Willett David WillettKS/1I/Con
servative Spokesperson or Unamed Party SourceKT/R/Conservative Party OfficialL0/
L/Conservative ActivistL1/N/Conservative CouncillorL2/G/Conservative MEPN8/16/Co
nservative Other MP/Candidate/PeerN9/13/Other Conservative inc. SupporterNK/A/Be
ith AlanNL/G/Campbell MenziesNM/A/Foster DonNN/C/Hughes SimonNO/R/Lord Rodgers o
f Quarry BankNP/E/Taylor MatthewNQ/B/Tonge JennyNR/B/Wallace JimQJ/17/Other Lib 
Dem Shadow Cabinet MinisterR0/B/Breed ColinR1/D/Cable VincentR2/B/Harver NickR3/
E/Livsey RichardR4/G/Maclennan RobertR5/D/Moore MichaelR6/A/Tyler PaulR7/A/Webb 
SteveR8/B/Willis PhilR9/1C/LibDem Spokesperson or Unamed Party SourceRA/L/LibDem
 Party OfficialRB/F/LibDem ActivistRC/H/LibDem CouncillorRD/A/LibDem MEPRE/10/Li
bDem Other MP/Candidate/PeerTT/R/Other LibDem inc. Supporter10A/D/Ashdown Paddy1
0B/B/Bell Martin10C/9/Benn Tony10D/I/Griffin Nick (BNP)10E/E/Hattersley Roy10F/9
/Heath Ted10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13/Nellist 
Dave (Socialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party)10L/1G/T
aylor Dr. Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/19/Titfor
d Jeffrey (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Individual13K
/1B/David Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scottish Parl
iament First Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13N/1F/Rhod
ri Morgan (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Party)13P/1
3/Ian Paisley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Support
er/etc13R/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: MP/Candida
te/Spokesperson/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson/Supporte
r/etc140/1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/P/Other Part
ies/Politicians270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair2
73/I/LAB: Anthony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: S
arah Gurling29T/F/Other Relatives3AA/Q/Agriculture Representative3AB/S/Business/
City Representative3AC/1N/Business Organisation eg. CBI, Institute of Directors3
AD/D/Civil Servant3AE/M/Celebrity (state whom)3AF/9/Economist3AG/19/European Lea
der/Politician (state whom)3AH/H/EU Representative3AI/J/Farmer/Rural worker3AJ/M
/Film/Documentary Maker3AK/K/Heckler/Demonstrator3AL/15/Media Commentator/Journa
list/Author3AM/9/The Media3AN/F/Police/Security3AO/E/Pressure Group3AP/8/Prisone
r3AQ/N/Professional Individual3AR/I/Pollster/Bookmaker3AS/A/Pensioners3AT/M/Reli
gious Spokesperson3B0/7/Royalty3B1/R/Scientist/Scientific Expert3B2/T/Social Ser
vice Representative3B3/13/Trade Union/Representative/Member3B4/P/Unamed Source -
 Non-Party3B5/J/University Academic3B6/10/Voter/Citizen/Person in Street3B7/1K/W
orld Leader/Politician (not European)(state whom)3D9/5/OtherD1/8/EVLTING267/3K/C
/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Scottish Nationalist 
Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Party3R/L/UK Independ
ence Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/UUP - Ulster Union
ist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42/E/The Government4
3/B/The Cabinet44/L/Government Department45/E/The Opposition46/R/Parliament/MPs 
(in general)47/I/The European Union6H/10/Other Party - British Mainland6I/10/Oth
er Party - Northern Ireland6J/H/Other Institution70/A/Blair Tony71/D/Hague Willi
am72/F/Kennedy Charles73/G/Adams Gerry (SF)74/G/Hume John (SDLP)75/K/Jones Ieuan
 Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble David (UUP)9T/K/Party Leader - Othe
rAA/E/Blunkett DavidAB/C/Brown GordonAC/A/Cook RobinAD/A/Hoon GeoffAE/D/Prescott
 JohnAF/B/Smith ChrisAG/B/Short ClareAH/A/Straw JackD9/T/Other Labour Cabinet Mi
nisterDK/Q/Baroness Jay of PaddingtonDL/F/Becket MargaretDM/A/Brown NickDN/D/Bye
rs StephenDO/H/Campbell AlistairDP/G/Darling AlistairDQ/B/Irvine LordDR/D/Liddel
l HelenDS/F/Mandelson PeterDT/C/Milburn AlanE0/9/Mowlam MoE1/B/Murphy PaulE2/9/R
eid JohnE3/C/Smith AndrewE4/A/Taylor AnnE5/9/Vaz KeithE6/E/Woodward ShaunE7/1C/L
abour Spokesperson or Unamed Party SourceE8/L/Labour Party OfficialE9/F/Labour A
ctivistEA/H/Labour CouncillorEB/A/Labour MEPGI/10/Other Labour MP/Candidate/Peer
GJ/R/Other Labour inc. SupporterH0/8/Fox LiamH1/E/Jenkin BernardH2/D/Maude Franc
isH3/B/May TheresaH4/D/Norman ArchieH5/G/Portillo MichaelH6/E/Widdecombe AnnH7/7
/Yeo TimJT/1C/Other Conservative Shadow Cabinet MinisterKA/F/Ainsworth PeterKB/E
/Ancram MichaelKC/F/Arbuthnot JamesKD/F/Browning AngelaKE/H/Duncan-Smith IainKF/
E/Garnier EdwardKG/L/Heathcote Amory DavidKH/H/Heseltine MichaelKI/D/Johnson Bor
isKJ/E/Lansley AndrewKK/D/Letwin OliverKL/C/McKay AndrewKM/E/Platell AmandaKN/F/
Rifkind MalcolmKO/D/Streeter GaryKP/F/The Lord HenleyKQ/K/The Lord StrathclydeKR
/L/Willett David WillettKS/1I/Conservative Spokesperson or Unamed Party SourceKT
/R/Conservative Party OfficialL0/L/Conservative ActivistL1/N/Conservative Counci
llorL2/G/Conservative MEPN8/16/Conservative Other MP/Candidate/PeerN9/13/Other C
onservative inc. SupporterNK/A/Beith AlanNL/G/Campbell MenziesNM/A/Foster DonNN/
C/Hughes SimonNO/R/Lord Rodgers of Quarry BankNP/E/Taylor MatthewNQ/B/Tonge Jenn
yNR/B/Wallace JimQJ/17/Other Lib Dem Shadow Cabinet MinisterR0/B/Breed ColinR1/D
/Cable VincentR2/B/Harver NickR3/E/Livsey RichardR4/G/Maclennan RobertR5/D/Moore
 MichaelR6/A/Tyler PaulR7/A/Webb SteveR8/B/Willis PhilR9/1C/LibDem Spokesperson 
or Unamed Party SourceRA/L/LibDem Party OfficialRB/F/LibDem ActivistRC/H/LibDem 
CouncillorRD/A/LibDem MEPRE/10/LibDem Other MP/Candidate/PeerTT/R/Other LibDem i
nc. Supporter10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10D/I/Griffin Ni
ck (BNP)10E/E/Hattersley Roy10F/9/Heath Ted10G/C/Kinnock Neil10H/F/Livingstone K
en10I/A/Major John10J/13/Nellist Dave (Socialist Alliance)10K/1A/Scargill Arthur
 (Socialist Labour Party)10L/1G/Taylor Dr. Richard (Kidderminster Independent)10
M/G/Thatcher Magaret10N/19/Titford Jeffrey (UK Independence Party)10O/G/Hinduja 
Brothers139/G/Other Individual13K/1B/David Ervine (Progressive Unionist Party)13
L/1K/Henry McLeish (Scottish Parliament First Minister)13M/1A/Gary McMichael (Ul
ster Democratic Party)13N/1F/Rhodri Morgan (Welsh Assembly First Minister)13O/S/
Sean Neeson (Alliance Party)13P/13/Ian Paisley (Democratic Unionist)13Q/1E/SNP: 
MP/Candidate/Spokesperson/Supporter/etc13R/1D/PC: MP/Candidate/Spokesperson/Supp
orter/etc13S/1G/Green: MP/Candidate/Spokesperson/Supporter/etc13T/1J/NI Party: M
P/Candidate/Spokesperson/Supporter/etc140/1M/Other Party: MP/Candidate/Spokesper
son/Supporter/etc16J/O/Other Parties/Polticians270/H/LAB: Cherie Blair271/F/LAB:
 Euan Blair272/E/LAB: Leo Blair273/I/LAB: Anthony Booth274/H/LAB: Lauren Booth27
5/G/CON: Ffion Hague276/I/LIB: Sarah Gurling29T/F/Other Relatives3AA/Q/Agricultu
re Representative3AB/S/Business/City Representative3AC/1N/Business Organisation 
eg. CBI, Institute of Directors3AD/D/Civil Servant3AE/M/Celebrity (state whom)3A
F/9/Economist3AG/19/European Leader/Politician (state whom)3AH/H/EU Representati
ve3AI/J/Farmer/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demonstrato
r3AL/15/Media Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/Security3
AO/E/Pressure Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollster/Boo
kmaker3AS/A/Pensioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scientist/S
cientific Expert3B2/T/Social Service Representative3B3/13/Trade Union/Representa
tive/Member3B4/P/Unamed Source - Non-Party3B5/J/University Academic3B6/10/Voter/
Citizen/Person in Street3B7/1K/World Leader/Politician (not European)(state whom
)3D9/5/OtherD1/8/EVLTION25/0/F/Can't Determine1/A/Crticising2/A/Mixed/Both3/A/Su
pporting4/7/NeutralD1/7/EVLTED267/3K/C/Labour Party3L/I/Conservative Party3M/D/L
ib Dem Party3N/Q/Scottish Nationalist Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/
British National Party3R/L/UK Independence Party3S/1B/SDLP - Social Democratic a
nd Labour Party3T/R/UUP - Ulster Unionist Party40/11/DUP - Democratic Unionist P
arty41/9/Sinn Fein42/E/The Government43/B/The Cabinet44/L/Government Department4
5/E/The Opposition46/R/Parliament/MPs (in general)47/I/The European Union6H/10/O
ther Party - British Mainland6I/10/Other Party - Northern Ireland6J/H/Other Inst
itution70/A/Blair Tony71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry (SF
)74/G/Hume John (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimb
le David (UUP)9T/K/Party Leader - OtherAA/E/Blunkett DavidAB/C/Brown GordonAC/A/
Cook RobinAD/A/Hoon GeoffAE/D/Prescott JohnAF/B/Smith ChrisAG/B/Short ClareAH/A/
Straw JackD9/T/Other Labour Cabinet MinisterDK/Q/Baroness Jay of PaddingtonDL/F/
Becket MargaretDM/A/Brown NickDN/D/Byers StephenDO/H/Campbell AlistairDP/G/Darli
ng AlistairDQ/B/Irvine LordDR/D/Liddell HelenDS/F/Mandelson PeterDT/C/Milburn Al
anE0/9/Mowlam MoE1/B/Murphy PaulE2/9/Reid JohnE3/C/Smith AndrewE4/A/Taylor AnnE5
/9/Vaz KeithE6/E/Woodward ShaunE7/1C/Labour Spokesperson or Unamed Party SourceE
8/L/Labour Party OfficialE9/F/Labour ActivistEA/H/Labour CouncillorEB/A/Labour M
EPGI/10/Other Labour MP/Candidate/PeerGJ/R/Other Labour inc. SupporterH0/8/Fox L
iamH1/E/Jenkin BernardH2/D/Maude FrancisH3/B/May TheresaH4/D/Norman ArchieH5/G/P
ortillo MichaelH6/E/Widdecombe AnnH7/7/Yeo TimJT/1C/Other Conservative Shadow Ca
binet MinisterKA/F/Ainsworth PeterKB/E/Ancram MichaelKC/F/Arbuthnot JamesKD/F/Br
owning AngelaKE/H/Duncan-Smith IainKF/E/Garnier EdwardKG/L/Heathcote Amory David
KH/H/Heseltine MichaelKI/D/Johnson BorisKJ/E/Lansley AndrewKK/D/Letwin OliverKL/
C/McKay AndrewKM/E/Platell AmandaKN/F/Rifkind MalcolmKO/D/Streeter GaryKP/F/The 
Lord HenleyKQ/K/The Lord StrathclydeKR/L/Willett David WillettKS/1I/Conservative
 Spokesperson or Unamed Party SourceKT/R/Conservative Party OfficialL0/L/Conserv
ative ActivistL1/N/Conservative CouncillorL2/G/Conservative MEPN8/16/Conservativ
e Other MP/Candidate/PeerN9/13/Other Conservative inc. SupporterNK/A/Beith AlanN
L/G/Campbell MenziesNM/A/Foster DonNN/C/Hughes SimonNO/R/Lord Rodgers of Quarry 
BankNP/E/Taylor MatthewNQ/B/Tonge JennyNR/B/Wallace JimQJ/17/Other Lib Dem Shado
w Cabinet MinisterR0/B/Breed ColinR1/D/Cable VincentR2/B/Harver NickR3/E/Livsey 
RichardR4/G/Maclennan RobertR5/D/Moore MichaelR6/A/Tyler PaulR7/A/Webb SteveR8/B
/Willis PhilR9/1C/LibDem Spokesperson or Unamed Party SourceRA/L/LibDem Party Of
ficialRB/F/LibDem ActivistRC/H/LibDem CouncillorRD/A/LibDem MEPRE/10/LibDem Othe
r MP/Candidate/PeerTT/R/Other LibDem inc. Supporter10A/D/Ashdown Paddy10B/B/Bell
 Martin10C/9/Benn Tony10D/I/Griffin Nick (BNP)10E/E/Hattersley Roy10F/9/Heath Te
d10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13/Nellist Dave (Soc
ialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party)10L/1G/Taylor Dr.
 Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/19/Titford Jeffrey
 (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Individual13K/1B/David
 Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scottish Parliament Fi
rst Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13N/1F/Rhodri Morgan
 (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Party)13P/13/Ian Pai
sley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Supporter/etc13R
/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: MP/Candidate/Spokes
person/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson/Supporter/etc140/
1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/P/Other Parties/Polit
icians270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair273/I/LAB:
 Anthony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: Sarah Gurl
ing29T/F/Other Relatives3AA/Q/Agriculture Representative3AB/S/Business/City Repr
esentative3AC/1N/Business Organisation eg. CBI, Institute of Directors3AD/D/Civi
l Servant3AE/M/Celebrity (state whom)3AF/9/Economist3AG/19/European Leader/Polit
ician (state whom)3AH/H/EU Representative3AI/J/Farmer/Rural worker3AJ/M/Film/Doc
umentary Maker3AK/K/Heckler/Demonstrator3AL/15/Media Commentator/Journalist/Auth
or3AM/9/The Media3AN/F/Police/Security3AO/E/Pressure Group3AP/8/Prisoner3AQ/N/Pr
ofessional Individual3AR/I/Pollster/Bookmaker3AS/A/Pensioners3AT/M/Religious Spo
kesperson3B0/7/Royalty3B1/R/Scientist/Scientific Expert3B2/T/Social Service Repr
esentative3B3/13/Trade Union/Representative/Member3B4/P/Unamed Source - Non-Part
y3B5/J/University Academic3B6/10/Voter/Citizen/Person in Street3B7/1K/World Lead
er/Politician (not European)(state whom)3D9/5/OtherD1/7/TONE1ST5/0/F/Can't Deter
mine1/8/Negative2/A/Mixed/Both3/8/Positive4/7/NeutralD1/7/TONE2ND5/0/F/Can't Det
ermine1/8/Negative2/A/Mixed/Both3/8/Positive4/7/NeutralD1/6/POLICY4/0/4/None1/3/
Low2/6/medium3/4/HighD1/8/PRSONLTY4/0/4/None1/3/Low2/6/Medium3/4/HighFDNL2O+2/B8
A/1/3/2/7J/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *
.*.*.*.*.*.*.*.*.*.*.*.DNL2O+2/B8B/1/3/2/5P/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1
/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL6+3/BBK/1/4/2/173/2/1
/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*
.*.*.*.*.DNL96+2/BF0/1/5/2/BK/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*
.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL96+2/BF1/1/5/2/C0/2/1/*.*.1/ *.*.*.
*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLIO
+2/BIA/1/1/2/II/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*
.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLIO+2/BIB/1/1/2/188/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/
 *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLIO+2/BIC/1/1/2/
5N/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*
.*.*.*.*.*.*.*.DNLM+3/BLK/1/2/2/EK/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1
/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLM+3/BLL/1/2/2/JM/2/1/*.*.1/ *.
*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.D
NLP6+2/BP0/1/3/2/GF/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/
 *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLSC+2/BSA/1/4/2/9G/2/1/*.*.1/ *.*.*.*.*.1/ *.*
.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNM1I+2/C1K/1/5
/2/KL/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.
*.*.*.*.*.*.*.*.*.DNMB6+2/C50/1/1/2/MT/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*
.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMB6+2/C51/1/1/2/1BE/2/1/*.*
.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*
.*.*.DNMEC+2/C8A/1/2/2/LG/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ 
*.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMHI+2/CBK/1/3/2/135/2/1/*.*.1/ *.*.*.*.*
.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMKO+2/
CF0/1/4/2/PB/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/
 *.*.*.*.*.*.*.*.*.*.*.*.DNMKO+2/CF1/1/4/2/7Q/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*
.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMO+3/CIA/1/5/2/OS/2/
1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.
*.*.*.*.*.DNMO+3/CIB/1/5/2/8I/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*
.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN3I+2/CLK/1/1/2/OS/2/1/*.*.1/ *.*.*.
*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN3I
+2/CLL/1/1/2/DM/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*
.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN6O+2/CP0/1/2/2/11B/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/
 *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN6O+2/CP1/1/2/2/
O1/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*
.*.*.*.*.*.*.*.DNNA+3/CSA/1/3/2/HS/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1
/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNND6+2/D1K/1/4/2/GS/2/1/*.*.1/ *
.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.
DNND6+2/D1L/1/4/2/PN/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1
/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNND6+2/D1M/1/4/2/JF/2/1/*.*.1/ *.*.*.*.*.1/ *.
*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNND6+2/D1N/1/
4/2/CO/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*
.*.*.*.*.*.*.*.*.*.DNNGC+2/D51/1/5/2/HD/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.
*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNQ+3/D8A/1/1/2/TP/2/1/*.*.
1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.
*.*.DNNQ+3/D8B/1/1/2/KJ/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.
*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNQ+3/D8C/1/1/2/9P/2/1/*.*.1/ *.*.*.*.*.1/ 
*.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNT6+2/DBK/
1/2/2/R5/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*
.*.*.*.*.*.*.*.*.*.*.DNNT6+2/DBL/1/2/2/AN/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ 
*.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO2C+2/DF0/1/3/2/MC/2/1/*
.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*
.*.*.*.DNO5I+2/DIA/1/4/2/BR/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1
/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL2O+2/MBK/2/3/2/86/2/1/*.*.1/ *.*.*.*.
*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL6+3/
MF0/2/4/2/82/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/
 *.*.*.*.*.*.*.*.*.*.*.*.DNL6+3/MF1/2/4/2/CA/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.
1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL96+2/MIA/2/5/2/CA/2/
1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.
*.*.*.*.*.DNL96+2/MIB/2/5/2/IC/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.
*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLIO+2/MLK/2/1/2/85/2/1/*.*.1/ *.*.*
.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLI
O+2/MLL/2/1/2/AG/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.
*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLIO+2/MLM/2/1/2/2F/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/
 *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLIO+2/MLN/2/1/2/
9K/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*
.*.*.*.*.*.*.*.DNLM+3/MP0/2/2/2/9A/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1
/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLM+3/MP1/2/2/2/KK/2/1/*.*.1/ *.
*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.D
NLM+3/MP2/2/2/2/5B/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ 
*.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLP6+2/MSA/2/3/2/IF/2/1/*.*.1/ *.*.*.*.*.1/ *.*.
1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLP6+2/MSB/2/3/
2/7E/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*
.*.*.*.*.*.*.*.*.DNLSC+2/N1K/2/4/2/DD/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.
*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNM1I+2/N50/2/5/2/84/2/1/*.*.1
/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*
.*.DNM1I+2/N51/2/5/2/DS/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.
*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNM1I+2/N52/2/5/2/3C/2/1/*.*.1/ *.*.*.*.*.1/
 *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMB6+2/N8A
/2/1/2/54/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.
*.*.*.*.*.*.*.*.*.*.*.DNMB6+2/N8B/2/1/2/G0/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/
 *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMB6+2/N8C/2/1/2/F2/2/1/
*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.
*.*.*.*.DNMEC+2/NBK/2/2/2/84/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.
1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMEC+2/NBL/2/2/2/B0/2/1/*.*.1/ *.*.*.*
.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMHI+
2/NF0/2/3/2/8O/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.
1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMHI+2/NF1/2/3/2/6E/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *
.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMKO+2/NIA/2/4/2/G4
/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*
.*.*.*.*.*.*.DNMKO+2/NIB/2/4/2/BC/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/
 *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMKO+2/NIC/2/4/2/DO/2/1/*.*.1/ *.
*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.D
NMO+3/NLK/2/5/2/IF/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ 
*.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMO+3/NLL/2/5/2/A4/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1
/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMO+3/NLM/2/5/2/
DG/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*
.*.*.*.*.*.*.*.DNN3I+2/NP0/2/1/2/KN/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.
1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN3I+2/NP1/2/1/2/7A/2/1/*.*.1/ 
*.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*
.DNN3I+2/NP2/2/1/2/8I/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.
1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN3I+2/NP3/2/1/2/8P/2/1/*.*.1/ *.*.*.*.*.1/ *
.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN6O+2/NSA/2
/2/2/8E/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.
*.*.*.*.*.*.*.*.*.*.DNN6O+2/NSB/2/2/2/BR/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *
.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNA+3/O1K/2/3/2/8A/2/1/*.*
.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*
.*.*.DNNA+3/O1L/2/3/2/8F/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *
.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNA+3/O1M/2/3/2/I2/2/1/*.*.1/ *.*.*.*.*.1/
 *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNND6+2/O50
/2/4/2/QB/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.
*.*.*.*.*.*.*.*.*.*.*.DNND6+2/O51/2/4/2/G8/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/
 *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNND6+2/O52/2/4/2/7G/2/1/
*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.
*.*.*.*.DNND6+2/O53/2/4/2/L3/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.
1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNGC+2/O8A/2/5/2/IF/2/1/*.*.1/ *.*.*.*
.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNGC+
2/O8B/2/5/2/4I/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.
1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNQ+3/OBK/2/1/2/82/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.
*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNQ+3/OBL/2/1/2/OS/2
/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*
.*.*.*.*.*.DNNQ+3/OBM/2/1/2/RF/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.
*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNQ+3/OBN/2/1/2/1P/2/1/*.*.1/ *.*.*.
*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNT6
+2/OF0/2/2/2/AF/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*
.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNT6+2/OF1/2/2/2/8G/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ 
*.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO2C+2/OIA/2/3/2/S
I/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.
*.*.*.*.*.*.*.DNO2C+2/OIB/2/3/2/JI/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1
/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO2C+2/OIC/2/3/2/9N/2/1/*.*.1/ *
.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.
DNO2C+2/OID/2/3/2/15/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1
/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO5I+2/OLK/2/4/2/78/2/1/*.*.1/ *.*.*.*.*.1/ *.
*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO5I+2/OLM/2/
4/2/BS/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*
.*.*.*.*.*.*.*.*.*.DNO5I+2/OLN/2/4/2/2J/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.
*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO5I+2/OLO/2/4/2/D7/2/1/*.*
.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*
.*.*.DNL2O+2/13F0/3/3/2/8R/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/
 *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL2O+2/13F1/3/3/2/HL/2/1/*.*.1/ *.*.*.*.
*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL6+3/
13IA/3/4/2/H8/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1
/ *.*.*.*.*.*.*.*.*.*.*.*.DNL6+3/13IB/3/4/2/96/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.
*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL6+3/13IC/3/4/2/9D/
2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.
*.*.*.*.*.*.DNL96+2/13LK/3/5/2/HA/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/
 *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL96+2/13LL/3/5/2/73/2/1/*.*.1/ *
.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.
DNL96+2/13LM/3/5/2/HE/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.
1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL96+2/13LN/3/5/2/AL/2/1/*.*.1/ *.*.*.*.*.1/ 
*.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLIO+2/13P0
/3/1/2/EK/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.
*.*.*.*.*.*.*.*.*.*.*.DNLIO+2/13P1/3/1/2/9M/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1
/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLIO+2/13P2/3/1/2/74/2/
1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.
*.*.*.*.*.DNLM+3/13SA/3/2/2/8K/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.
*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLM+3/13SB/3/2/2/F7/2/1/*.*.1/ *.*.*
.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLM
+3/13SC/3/2/2/GK/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.
*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLM+3/13SD/3/2/2/4S/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/
 *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLP6+2/141K/3/3/2
/N4/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.
*.*.*.*.*.*.*.*.DNLP6+2/141L/3/3/2/AO/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.
*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLP6+2/141M/3/3/2/8G/2/1/*.*.
1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.
*.*.DNLSC+2/1450/3/4/2/PD/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ 
*.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNM1I+2/148A/3/5/2/7S/2/1/*.*.1/ *.*.*.*.*
.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNM1I+2/
148B/3/5/2/85/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1
/ *.*.*.*.*.*.*.*.*.*.*.*.DNMB6+2/14BK/3/1/2/L8/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *
.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMB6+2/14BL/3/1/2/8
Q/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.
*.*.*.*.*.*.*.DNMB6+2/14BM/3/1/2/AM/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.
1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMEC+2/14F0/3/2/2/GM/2/1/*.*.1/
 *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.
*.DNMEC+2/14F1/3/2/2/8R/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.
*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMEC+2/14F2/3/2/2/9T/2/1/*.*.1/ *.*.*.*.*.1
/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMHI+2/14
IA/3/3/2/KH/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ 
*.*.*.*.*.*.*.*.*.*.*.*.DNMHI+2/14IB/3/3/2/BF/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*
.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMKO+2/14LK/3/4/2/HC/
2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.
*.*.*.*.*.*.DNMKO+2/14LL/3/4/2/I7/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/
 *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMKO+2/14LM/3/4/2/FM/2/1/*.*.1/ *
.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.
DNMO+3/14P0/3/5/2/NH/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1
/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMO+3/14P1/3/5/2/BK/2/1/*.*.1/ *.*.*.*.*.1/ *.
*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMO+3/14P2/3/
5/2/FT/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*
.*.*.*.*.*.*.*.*.*.DNMO+3/14P4/3/5/2/9N/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.
*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN3I+2/14SA/3/1/2/SH/2/1/*.
*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.
*.*.*.DNN3I+2/14SB/3/1/2/92/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1
/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN3I+2/14SC/3/1/2/A4/2/1/*.*.1/ *.*.*.*
.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN6O+
2/151K/3/2/2/5K/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*
.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN6O+2/151L/3/2/2/E6/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/
 *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNA+3/1550/3/3/2/
R6/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*
.*.*.*.*.*.*.*.DNNA+3/1551/3/3/2/CF/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.
1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNA+3/1552/3/3/2/95/2/1/*.*.1/ 
*.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*
.DNND6+2/158A/3/4/2/KO/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*
.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNND6+2/158B/3/4/2/AA/2/1/*.*.1/ *.*.*.*.*.1/
 *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNND6+2/158
C/3/4/2/9G/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *
.*.*.*.*.*.*.*.*.*.*.*.DNNGC+2/15BK/3/5/2/TN/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.
1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNGC+2/15BL/3/5/2/KO/2
/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*
.*.*.*.*.*.DNNGC+2/15BM/3/5/2/9M/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ 
*.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNQ+3/15F0/3/1/2/D2/2/1/*.*.1/ *.*
.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DN
NQ+3/15F1/3/1/2/98/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ 
*.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNQ+3/15F2/3/1/2/AI/2/1/*.*.1/ *.*.*.*.*.1/ *.*.
1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNT6+2/15IA/3/2
/2/MK/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.
*.*.*.*.*.*.*.*.*.DNNT6+2/15IB/3/2/2/CP/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.
*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNT6+2/15IC/3/2/2/DC/2/1/*.
*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.
*.*.*.DNNT6+2/15ID/3/2/2/9Q/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1
/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO2C+2/15LK/3/3/2/GC/2/1/*.*.1/ *.*.*.*
.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO2C+
2/15LL/3/3/2/IE/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*
.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO5I+2/15P0/3/4/2/80/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/
 *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO5I+2/15P1/3/4/2
/2H/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.
*.*.*.*.*.*.*.*.DNL6+3/1ELK/4/4/2/C9/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*
.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL96+2/1EP0/4/5/2/HK/2/1/*.*.1
/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*
.*.DNL96+2/1EP1/4/5/2/72/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *
.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL96+2/1EP2/4/5/2/7B/2/1/*.*.1/ *.*.*.*.*.
1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLIO+2/1
ESA/4/1/2/F2/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/
 *.*.*.*.*.*.*.*.*.*.*.*.DNLIO+2/1ESB/4/1/2/B9/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.
*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLM+3/1F1K/4/2/2/CD/
2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.
*.*.*.*.*.*.DNLP6+2/1F50/4/3/2/AR/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/
 *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLP6+2/1F51/4/3/2/8F/2/1/*.*.1/ *
.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.
DNLSC+2/1F8A/4/4/2/DQ/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.
1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLSC+2/1F8B/4/4/2/5T/2/1/*.*.1/ *.*.*.*.*.1/ 
*.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLSC+2/1F8C
/4/4/2/7I/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.
*.*.*.*.*.*.*.*.*.*.*.DNM1I+2/1FBK/4/5/2/A3/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1
/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNM1I+2/1FBL/4/5/2/8P/2/
1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.
*.*.*.*.*.DNMB6+2/1FF0/4/1/2/7T/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *
.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMB6+2/1FF2/4/1/2/II/2/1/*.*.1/ *.*
.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DN
MEC+2/1FIA/4/2/2/IK/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/
 *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMEC+2/1FIC/4/2/2/E4/2/1/*.*.1/ *.*.*.*.*.1/ *.
*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMHI+2/1FLK/4
/3/2/D4/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.
*.*.*.*.*.*.*.*.*.*.DNMHI+2/1FLL/4/3/2/AH/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ 
*.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMKO+2/1FP0/4/4/2/FF/2/1/
*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.
*.*.*.*.DNMKO+2/1FP1/4/4/2/A9/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*
.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMO+3/1FSA/4/5/2/C9/2/1/*.*.1/ *.*.*.
*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMO+
3/1FSB/4/5/2/F2/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*
.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMO+3/1FSC/4/5/2/8K/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ 
*.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN3I+2/1G1K/4/1/2/
L1/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*
.*.*.*.*.*.*.*.DNN3I+2/1G1L/4/1/2/BJ/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*
.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN3I+2/1G1M/4/1/2/9N/2/1/*.*.1
/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*
.*.DNMEC+2/1G3B/4/2/2/9H/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *
.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN6O+2/1G50/4/2/2/FS/2/1/*.*.1/ *.*.*.*.*.
1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN6O+2/1
G51/4/2/2/63/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/
 *.*.*.*.*.*.*.*.*.*.*.*.DNNA+3/1G8A/4/3/2/9B/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*
.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNA+3/1G8B/4/3/2/9E/2
/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*
.*.*.*.*.*.DNND6+2/1GBK/4/4/2/S3/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ 
*.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNND6+2/1GBL/4/4/2/8P/2/1/*.*.1/ *.
*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.D
NNGC+2/1GF0/4/5/2/98/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1
/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNGC+2/1GF1/4/5/2/7S/2/1/*.*.1/ *.*.*.*.*.1/ *
.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNQ+3/1GIA/4
/1/2/59/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.
*.*.*.*.*.*.*.*.*.*.DNNQ+3/1GIB/4/1/2/CD/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *
.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNQ+3/1GIC/4/1/2/AN/2/1/*.
*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.
*.*.*.DNNT6+2/1GLK/4/2/2/J0/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1
/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNT6+2/1GLL/4/2/2/AI/2/1/*.*.1/ *.*.*.*
.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO2C+
2/1GP1/4/3/2/H6/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*
.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO2C+2/1GP2/4/3/2/I6/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/
 *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO5I+2/1GSA/4/4/2
/AM/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.
*.*.*.*.*.*.*.*.DNO5I+2/1GSB/4/4/2/9H/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.
*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL6+3/1PP0/5/4/1/E4/2/1/*.*.1
/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*
.*.DNL96+2/1PSA/5/5/1/10E/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ 
*.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL96+2/1PSB/5/5/1/1S/2/1/*.*.1/ *.*.*.*.*
.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLIO+2/
1Q1K/5/1/1/6T/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1
/ *.*.*.*.*.*.*.*.*.*.*.*.DNLM+3/1Q50/5/2/1/6E/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.
*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMB6+2/1QIA/5/1/1/CM
/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*
.*.*.*.*.*.*.DNMEC+2/1QLK/5/2/1/26/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1
/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMEC+2/1QLL/5/2/1/3P/2/1/*.*.1/ 
*.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*
.DNMHI+2/1QP0/5/3/1/L5/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*
.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMKO+2/1QSA/5/4/1/CG/2/1/*.*.1/ *.*.*.*.*.1/
 *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMO+3/1R1K
/5/5/1/23/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.
*.*.*.*.*.*.*.*.*.*.*.DNN3I+2/1R50/5/1/1/3T/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1
/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN6O+2/1R8A/5/2/1/1P/2/
1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.
*.*.*.*.*.DNNA+3/1RBK/5/3/1/3G/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.
*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNND6+2/1RF0/5/4/1/4A/2/1/*.*.1/ *.*.
*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN
GC+2/1RIA/5/5/1/3D/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ 
*.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO5I+2/1S1K/5/4/1/2B/2/1/*.*.1/ *.*.*.*.*.1/ *.*
.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL96+2/271K/6/
5/1/BO/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*
.*.*.*.*.*.*.*.*.*.DNLIO+2/2750/6/1/1/3C/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *
.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLM+3/278A/6/2/1/32/2/1/*.
*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.
*.*.*.DNLP6+2/27BK/6/3/1/83/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1
/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLP6+2/27BL/6/3/1/2R/2/1/*.*.1/ *.*.*.*
.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMB6+
2/27LK/6/1/1/5A/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*
.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMEC+2/27P0/6/2/1/6D/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/
 *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMEC+2/27P1/6/2/1
/EJ/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.
*.*.*.*.*.*.*.*.DNMHI+2/27SA/6/3/1/73/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.
*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMKO+2/281K/6/4/1/17/2/1/*.*.
1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.
*.*.DNMO+3/2850/6/5/1/CB/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *
.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNND6+2/28IA/6/4/1/GL/2/1/*.*.1/ *.*.*.*.*.
1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNND6+2/2
8IB/6/4/1/5N/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/
 *.*.*.*.*.*.*.*.*.*.*.*.DNNQ+3/28P0/6/1/1/AA/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*
.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNT6+2/28SA/6/2/1/34/
2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.
*.*.*.*.*.*.DNL2O+2/2HSA/7/3/1/1AO/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1
/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLIO+2/2I8A/7/1/1/SI/2/1/*.*.1/ 
*.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*
.DNLM+3/2IBK/7/2/1/17O/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*
.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNM1I+2/2ILK/7/5/1/KC/2/1/*.*.1/ *.*.*.*.*.1/
 *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMB6+2/2IP
0/7/1/1/QN/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *
.*.*.*.*.*.*.*.*.*.*.*.DNMHI+2/2J1K/7/3/1/11T/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*
.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMKO+2/2J50/7/4/1/112
/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*
.*.*.*.*.*.*.DNMO+3/2J8A/7/5/1/R0/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/
 *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNND6+2/2JLK/7/4/1/O1/2/1/*.*.1/ *
.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.
DNNT6+2/2K1K/7/2/1/11L/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*
.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO2C+2/2K50/7/3/1/S2/2/1/*.*.1/ *.*.*.*.*.1/
 *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO5I+2/2K8
A/7/4/1/135/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ 
*.*.*.*.*.*.*.*.*.*.*.*.DNL6+3/2T50/8/4/1/M1/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.
1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNL96+2/2T8A/8/5/1/KQ/2
/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*
.*.*.*.*.*.DNLIO+2/2TBK/8/1/1/N0/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ 
*.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLM+3/2TF0/8/2/1/MC/2/1/*.*.1/ *.*
.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DN
LP6+2/2TIA/8/3/1/IM/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/
 *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNLSC+2/2TLK/8/4/1/1FS/2/1/*.*.1/ *.*.*.*.*.1/ *
.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMB6+2/2TSA/
8/1/1/F5/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*
.*.*.*.*.*.*.*.*.*.*.DNMEC+2/301K/8/2/1/MG/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/
 *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMHI+2/3050/8/3/1/M6/2/1
/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*
.*.*.*.*.DNMKO+2/308A/8/4/1/RI/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.
*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNMO+3/30BK/8/5/1/RS/2/1/*.*.1/ *.*.*
.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNN6
O+2/30IA/8/2/1/SO/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *
.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNA+3/30LK/8/3/1/MA/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1
/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNND6+2/30P0/8/4/
1/1CH/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.
*.*.*.*.*.*.*.*.*.DNNGC+2/30SA/8/5/1/1B6/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *
.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNNQ+3/311K/8/1/1/L9/2/1/*.
*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.
*.*.*.DNNT6+2/3150/8/2/1/KO/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1
/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO2C+2/318A/8/3/1/KE/2/1/*.*.1/ *.*.*.*
.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.*.1/ *.*.*.*.*.*.*.*.*.*.*.*.DNO5I+
2/31BK/8/4/1/11A/2/1/*.*.1/ *.*.*.*.*.1/ *.*.1/ *.*.1/ *.*.*.1/ *.*.1/ *.*.1/ *.
*.1/ *.*.*.*.*.*.*.*.*.*.*.*.ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
