�����@����@����@����@@@@@@@@@@@@@@@@@@@@ASCII SPSS PORT FILE                    
00000-0000-0000-0000--------------------!3#))0303300/240&),%00000000000000000000
0200002'220'&)3000#0000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrst
uvwxyz .<(+0&[]!$*);^-/|,%_>?`:#@'="000000~000000000000000000000{}\0000000000000
00000000000000000000000000000000000000000000000000000000SPSSPORTA8/200301316/115
541112/SPSS for MS WINDOWS Release 10.041I/5B/70/7/ARTDATE40/8/0/40/8/0/CC/Artic
le Date70/4/IDNO5/5/0/5/5/0/CS/Unique Identification Number70/5/PAPER5/1/0/5/1/0
/C9/Newspaper70/3/DAY5/1/0/5/1/0/CB/Day of Week70/8/PAPERTYP5/1/0/5/1/0/CE/Newsp
aper Type70/7/ARTSIZE5/4/0/5/4/0/CO/Article Size (No. Words)70/7/ARTTYPE5/1/0/5/
1/0/CC/Article Type70/6/PAGENO5/2/0/5/2/0/CB/Page Number70/6/AUTHOR5/2/0/5/2/0/C
E/Type of Author70/7/AUTHGEN5/2/0/5/2/0/CG/Gender of Author72K/7/AUTHNME1/2K/0/1
/2K/0/CB/Author Name70/8/STORYTYP5/2/0/5/2/0/CA/Story Type70/7/SETTING5/1/0/5/1/
0/CD/Story Setting70/8/TREATMNT5/1/0/5/1/0/CF/Tone of Article70/5/CODER5/1/0/5/1
/0/CD/Name of Coder70/8/THEME1ST5/3/0/5/3/0/CA/Main Theme72K/8/THME1OTH1/2K/0/1/
2K/0/CG/Other Main Theme70/8/THME1AGR5/2/0/5/2/0/CL/Aggregated Main Theme70/8/TH
EME2ND5/3/0/5/3/0/CC/Second Theme72K/8/THME2OTH1/2K/0/1/2K/0/CI/Other Second The
me70/8/THME2AGR5/2/0/5/2/0/CN/Aggregated Second Theme70/8/THEME3RD5/3/0/5/3/0/CB
/Third Theme72K/8/THME3OTH1/2K/0/1/2K/0/CH/Other Third Theme70/8/THME3AGR5/2/0/5
/2/0/CM/Aggregated Third Theme70/8/ACTOR1ST5/4/0/5/4/0/CA/Main Actor70/7/ACT1GEN
5/2/0/5/2/0/CK/Gender of Main Actor72K/7/ACT1OTH1/2K/0/1/2K/0/CG/Other Main Acto
r70/8/ACTOR2ND5/4/0/5/4/0/CC/Second Actor70/7/ACT2GEN5/2/0/5/2/0/CM/Gender of Se
cond Actor72K/7/ACT2OTH1/2K/0/1/2K/0/CI/Other Second Actor70/8/ACTOR3RD5/4/0/5/4
/0/CB/Third Actor70/7/ACT3GEN5/2/0/5/2/0/CL/Gender of Third Actor72K/7/ACT3OTH1/
2K/0/1/2K/0/CH/Other Third Actor70/8/ACTOR4TH5/4/0/5/4/0/CC/Fourth Actor70/7/ACT
4GEN5/2/0/5/2/0/CM/Gender of Fourth Actor72K/7/ACT4OTH1/2K/0/1/2K/0/CI/Other Fou
rth Actor70/8/JOURNEV15/1/0/5/1/0/C13/Journalist Evaluation - 1st Actor70/8/JOUR
NEV25/1/0/5/1/0/C13/Journalist Evaluation - 2nd Actor70/8/EVLTING15/4/0/5/4/0/CK
/1st Actor Evaluating70/8/EVLTION15/1/0/5/1/0/CE/1st Evaluation70/7/EVLTED15/4/0
/5/4/0/CJ/1st Actor Evaluated70/8/EVLTING25/4/0/5/4/0/CK/2nd Actor Evaluating70/
8/EVLTION25/1/0/5/1/0/CE/2nd Evaluation70/7/EVLTED25/4/0/5/4/0/CJ/2nd Actor Eval
uated70/7/TONE1ST5/1/0/5/1/0/CR/Favourability to Main Actor70/7/TONE2ND5/1/0/5/1
/0/CT/Favourability to Second Actor70/6/POLICY5/1/0/5/1/0/CI/Policy Information7
0/8/PRSONLTY5/1/0/5/1/0/CN/Personality InformationD1/5/PAPER8/1/8/Guardian2/5/Ti
mes3/9/Telegraph4/B/Independent5/3/Sun6/6/Mirror7/4/Mail8/7/ExpressD1/3/DAY5/1/6
/Monday2/7/Tuesday3/9/Wednesday4/8/Thursday5/6/FridayD1/8/PAPERTYP2/1/7/Tabloid2
/A/BroadsheetD1/7/ARTTYPE2/1/8/Campaign2/C/Non-CampaignD1/6/AUTHOR6/1/K/Politica
l Journalist2/9/Columnist3/9/Not Given4/O/Non Political Journalist5/F/Can't Dete
rmine39/5/OtherD1/7/AUTHGEN3/1/4/Male2/6/Female3/F/Can't DetermineD1/8/STORYTYPA
/1/D/Straight News2/O/News Analysis/Background3/F/Feature/Profile4/G/Editorial/L
eader5/F/Comment/Opinion6/9/Interview7/D/Signed Column8/6/Sketch9/1G/Picture Cap
tion (Page 1 Campaign stories only)39/5/OtherD1/7/SETTING5/1/9/Political2/8/Camp
aign3/5/Media4/5/Other5/N/No Identifiable SettingD1/8/TREATMNT3/1/7/Serious2/C/L
ighthearted3/5/OtherD1/5/CODER2/1/7/Coder 12/7/Coder 2D1/8/THEME1ST3D/3B/E/Campa
ign Trail3C/H/Campaign Strategy3D/M/Announce Election Date3E/J/Controlled Campai
gn3F/K/Negative Campaigning3G/6/Sleaze3H/F/Gaffes/Scandals3I/H/Campaign Gimmicks
3J/15/Political Distrust/Voter Alienation3K/C/Voter Apathy3L/F/Tactical Voting3M
/D/Postal Voting3N/E/Marginal Seats3O/F/Local Elections3P/H/Hecklers/Protests3Q/
M/Risks of a Low Turnout3R/K/Risks of a Landslide3S/4/Spin3T/T/Candidate Selecti
on Procedure40/G/Electoral Reform41/G/Campaign Funding42/9/Women MPs43/R/Proport
ional Representation44/F/Prescotts Punch45/L/Dull/Tedious Campaign46/9/Grey Vote
47/B/Ethnic Vote48/A/Young Vote49/B/Female Vote4A/K/Getting Out the Vote4B/I/Med
ia Manipulation4C/9/Defectors4D/M/Departing/Retiring MPs4E/4/PEBs4F/E/Election F
raud4G/E/Wives/Partners6J/13/Election Campaign/Process - Other6L/J/Opinion Poll 
Result6M/O/Opinion Poll Design etc.6N/G/Reaction to Poll6O/I/Outcome Prediction6
P/I/Turnout Prediction6Q/Q/Media Coverage of Campaign6S/S/Party/Candidate Endors
ements6T/B/Voter Panel70/L/Stats/Facts & Figures71/H/Summary of Events72/H/Spoof
/joke column73/K/Constituency Profile9T/S/Media Coverage/Polls - OtherA1/1A/Qual
ities - Professional and/or PersonalA2/A/Aims/GoalsA3/I/Record/AchievementA4/T/C
ompare Qualities/Aims/RecordA5/H/Manifesto: LabourA6/N/Manifesto: ConservativeA7
/H/Manifesto: LibDemA8/O/Conflict Between PartiesA9/N/Conflict Within PartiesAA/
10/Party/Leader/Candidate ProfileAB/9/The LordsAC/J/Manifesto: BusinessAD/R/Blai
r/Brown Leadership PactAE/16/Post-Election Tory Leadership BattleAF/1G/Post-Elec
tion Cabinet/Whitehall ReorganisationD9/1A/Parties/Party Leaders/Candidates � Ot
herDB/A/NHS/HealthDC/9/EducationDD/H/Crime/Law & OrderDE/8/TaxationDF/H/Europe i
n GeneralDG/8/The EuroDH/8/PensionsDI/7/EconomyDJ/9/TransportDK/A/EmploymentDL/B
/EnvironmentDM/7/WelfareDN/J/Farming/AgricultureDO/B/ImmigrationDP/I/Culture/Art
s/SportDQ/G/Northern IrelandDR/D/Racial IssuesDS/Q/Internet Crime/PornographyDT/
12/National Insurance ContributionsE0/G/Local GovernmentE1/Q/Public Services in 
GeneralE2/13/Social Security inc Benefits, etcE3/10/Rural Affairs inc. Fox-Hunti
ngE4/7/HousingE5/K/Parliamentary ReformE6/M/Information/TechnologyE7/16/Private 
Sector Involvement (PPP/PFI)E9/D/Petrol PricesEA/J/Policies in GeneralEB/F/Publi
c SpendingEC/D/Stealth TaxesED/8/BusinessEE/F/Scottish IssuesEF/K/Care for the E
lderlyEG/7/DefenceEH/7/PovertyGJ/5/OtherD1/8/THME1AGRB/1/E/Policy Stories2/Q/Apa
thy/Low Turnout Stories3/F/Campaign Events4/M/Mechanics of Elections5/F/Types of
 Voters6/K/Poll/Outcome Stories7/E/Media Coverage8/N/Party/Candidate Stories9/P/
Manifesto Content StoriesA/N/Spin/Media Manipulation39/5/OtherD1/8/THEME2ND3D/3B
/E/Campaign Trail3C/H/Campaign Strategy3D/M/Announce Election Date3E/J/Controlle
d Campaign3F/K/Negative Campaigning3G/6/Sleaze3H/F/Gaffes/Scandals3I/H/Campaign 
Gimmicks3J/15/Political Distrust/Voter Alienation3K/C/Voter Apathy3L/F/Tactical 
Voting3M/D/Postal Voting3N/E/Marginal Seats3O/F/Local Elections3P/H/Hecklers/Pro
tests3Q/M/Risks of a Low Turnout3R/K/Risks of a Landslide3S/4/Spin3T/T/Candidate
 Selection Procedure40/G/Electoral Reform41/G/Campaign Funding42/9/Women MPs43/R
/Proportional Representation44/F/Prescotts Punch45/L/Dull/Tedious Campaign46/9/G
rey Vote47/B/Ethnic Vote48/A/Young Vote49/B/Female Vote4A/K/Getting Out the Vote
4B/I/Media Manipulation4C/9/Defectors4D/M/Departing/Retiring MPs4E/4/PEBs4F/E/El
ection Fraud4G/E/Wives/Partners6J/13/Election Campaign/Process - Other6L/J/Opini
on Poll Result6M/O/Opinion Poll Design etc.6N/G/Reaction to Poll6O/I/Outcome Pre
diction6P/I/Turnout Prediction6Q/Q/Media Coverage of Campaign6S/S/Party/Candidat
e Endorsements6T/B/Voter Panel70/L/Stats/Facts & Figures71/H/Summary of Events72
/H/Spoof/joke column73/K/Constituency Profile9T/S/Media Coverage/Polls - OtherA1
/1A/Qualities - Professional and/or PersonalA2/A/Aims/GoalsA3/I/Record/Achieveme
ntA4/T/Compare Qualities/Aims/RecordA5/H/Manifesto: LabourA6/N/Manifesto: Conser
vativeA7/H/Manifesto: LibDemA8/O/Conflict Between PartiesA9/N/Conflict Within Pa
rtiesAA/10/Party/Leader/Candidate ProfileAB/9/The LordsAC/J/Manifesto: BusinessA
D/R/Blair/Brown Leadership PactAE/16/Post-Election Tory Leadership BattleAF/1G/P
ost-Election Cabinet/Whitehall ReorganisationD9/1A/Parties/Party Leaders/Candida
tes � OtherDB/A/NHS/HealthDC/9/EducationDD/H/Crime/Law & OrderDE/8/TaxationDF/H/
Europe in GeneralDG/8/The EuroDH/8/PensionsDI/7/EconomyDJ/9/TransportDK/A/Employ
mentDL/B/EnvironmentDM/7/WelfareDN/J/Farming/AgricultureDO/B/ImmigrationDP/I/Cul
ture/Arts/SportDQ/G/Northern IrelandDR/D/Racial IssuesDS/Q/Internet Crime/Pornog
raphyDT/12/National Insurance ContributionsE0/G/Local GovernmentE1/Q/Public Serv
ices in GeneralE2/13/Social Security inc Benefits, etcE3/10/Rural Affairs inc. F
ox-HuntingE4/7/HousingE5/K/Parliamentary ReformE6/M/Information/TechnologyE7/16/
Private Sector Involvement (PPP/PFI)E9/D/Petrol PricesEA/J/Policies in GeneralEB
/F/Public SpendingEC/D/Stealth TaxesED/8/BusinessEE/F/Scottish IssuesEF/K/Care f
or the ElderlyEG/7/DefenceEH/7/PovertyGJ/5/OtherD1/8/THME2AGRB/1/E/Policy Storie
s2/Q/Apathy/Low Turnout Stories3/F/Campaign Events4/M/Mechanics of Elections5/F/
Types of Voters6/K/Poll/Outcome Stories7/E/Media Coverage8/N/Party/Candidate Sto
ries9/P/Manifesto Content StoriesA/N/Spin/Media Manipulation39/5/OtherD1/8/THEME
3RD3D/3B/E/Campaign Trail3C/H/Campaign Strategy3D/M/Announce Election Date3E/J/C
ontrolled Campaign3F/K/Negative Campaigning3G/6/Sleaze3H/F/Gaffes/Scandals3I/H/C
ampaign Gimmicks3J/15/Political Distrust/Voter Alienation3K/C/Voter Apathy3L/F/T
actical Voting3M/D/Postal Voting3N/E/Marginal Seats3O/F/Local Elections3P/H/Heck
lers/Protests3Q/M/Risks of a Low Turnout3R/K/Risks of a Landslide3S/4/Spin3T/T/C
andidate Selection Procedure40/G/Electoral Reform41/G/Campaign Funding42/9/Women
 MPs43/R/Proportional Representation44/F/Prescotts Punch45/L/Dull/Tedious Campai
gn46/9/Grey Vote47/B/Ethnic Vote48/A/Young Vote49/B/Female Vote4A/K/Getting Out 
the Vote4B/I/Media Manipulation4C/9/Defectors4D/M/Departing/Retiring MPs4E/4/PEB
s4F/E/Election Fraud4G/E/Wives/Partners6J/13/Election Campaign/Process - Other6L
/J/Opinion Poll Result6M/O/Opinion Poll Design etc.6N/G/Reaction to Poll6O/I/Out
come Prediction6P/I/Turnout Prediction6Q/Q/Media Coverage of Campaign6S/S/Party/
Candidate Endorsements6T/B/Voter Panel70/L/Stats/Facts & Figures71/H/Summary of 
Events72/H/Spoof/joke column73/K/Constituency Profile9T/S/Media Coverage/Polls -
 OtherA1/1A/Qualities - Professional and/or PersonalA2/A/Aims/GoalsA3/I/Record/A
chievementA4/T/Compare Qualities/Aims/RecordA5/H/Manifesto: LabourA6/N/Manifesto
: ConservativeA7/H/Manifesto: LibDemA8/O/Conflict Between PartiesA9/N/Conflict W
ithin PartiesAA/10/Party/Leader/Candidate ProfileAB/9/The LordsAC/J/Manifesto: B
usinessAD/R/Blair/Brown Leadership PactAE/16/Post-Election Tory Leadership Battl
eAF/1G/Post-Election Cabinet/Whitehall ReorganisationD9/1A/Parties/Party Leaders
/Candidates � OtherDB/A/NHS/HealthDC/9/EducationDD/H/Crime/Law & OrderDE/8/Taxat
ionDF/H/Europe in GeneralDG/8/The EuroDH/8/PensionsDI/7/EconomyDJ/9/TransportDK/
A/EmploymentDL/B/EnvironmentDM/7/WelfareDN/J/Farming/AgricultureDO/B/Immigration
DP/I/Culture/Arts/SportDQ/G/Northern IrelandDR/D/Racial IssuesDS/Q/Internet Crim
e/PornographyDT/12/National Insurance ContributionsE0/G/Local GovernmentE1/Q/Pub
lic Services in GeneralE2/13/Social Security inc Benefits, etcE3/10/Rural Affair
s inc. Fox-HuntingE4/7/HousingE5/K/Parliamentary ReformE6/M/Information/Technolo
gyE7/16/Private Sector Involvement (PPP/PFI)E9/D/Petrol PricesEA/J/Policies in G
eneralEB/F/Public SpendingEC/D/Stealth TaxesED/8/BusinessEE/F/Scottish IssuesEF/
K/Care for the ElderlyEG/7/DefenceEH/7/PovertyGJ/5/OtherD1/8/THME3AGRB/1/E/Polic
y Stories2/Q/Apathy/Low Turnout Stories3/F/Campaign Events4/M/Mechanics of Elect
ions5/F/Types of Voters6/K/Poll/Outcome Stories7/E/Media Coverage8/N/Party/Candi
date Stories9/P/Manifesto Content StoriesA/N/Spin/Media Manipulation39/5/OtherD1
/8/ACTOR1ST6I/3K/C/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Sco
ttish Nationalist Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Par
ty3R/L/UK Independence Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/
UUP - Ulster Unionist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42
/E/The Government43/B/The Cabinet44/L/Government Department45/E/The Opposition46
/R/Parliament/MPs (in general)47/18/The European Union/European Commission48/8/M
illbank49/K/Electoral Commission4A/F/Scottish Labour4B/F/Scottish Tories6H/10/Ot
her Party - British Mainland6I/10/Other Party - Northern Ireland6J/H/Other Insti
tution70/A/Blair Tony71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry (SF)
74/G/Hume John (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimbl
e David (UUP)78/I/Nick Griffin (BNP)9T/K/Party Leader - OtherAA/J/LAB: Blunkett 
DavidAB/H/LAB: Brown GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: P
rescott JohnAF/G/LAB: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/
LAB: Other Senior Labour PoliticianDK/11/LAB: Baroness Jay of PaddingtonDL/K/LAB
: Becket MargaretDM/F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB: Campbell A
listairDP/L/LAB: Darling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/
K/LAB: Mandelson PeterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Re
id JohnE3/H/LAB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Wo
odward ShaunE7/1A/LAB: Spokesperson or Unamed Party SourceE8/J/LAB: Party Offici
alE9/D/LAB: ActivistEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidat
e/PeerGJ/P/LAB: Other inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2
/I/CON: Maude FrancisH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/L/CON: Porti
llo MichaelH6/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other Senior Polit
icianKA/K/CON: Ainsworth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbuthnot JamesK
D/K/CON: Browning AngelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/
CON: Heathcote Amory DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johnson BorisKJ/J
/CON: Lansley AndrewKK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/J/CON: Plate
ll AmandaKN/K/CON: Rifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: The Lord Henl
eyKQ/P/CON: The Lord StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Spokesperson o
r Unamed Party SourceKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/CON: Council
lorL2/8/CON: MEPL3/J/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/CON: Other MP
/Candidate/PeerN9/P/CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campb
ell MenziesNM/F/LIB: Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers of 
Quarry BankNP/J/LIB: Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/
S/LIB: Other Senior PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable VincentR2/G/L
IB: Harver NickR3/J/LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore
 MichaelR6/F/LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: 
Spokesperson or Unamed Party SourceRA/J/LIB: Party OfficialRB/D/LIB: ActivistRC/
F/LIB: CouncillorRD/8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/LIB: Other i
nc. Supporter10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10E/E/Hattersley
 Roy10F/9/Heath Ted10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13
/Nellist Dave (Socialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party
)10L/1G/Taylor Dr. Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/
19/Titford Jeffrey (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Indi
vidual13K/1B/David Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scot
tish Parliament First Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13
N/1F/Rhodri Morgan (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Pa
rty)13P/13/Ian Paisley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperso
n/Supporter/etc13R/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: M
P/Candidate/Spokesperson/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson
/Supporter/etc140/1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/M/O
ther Party/Politician270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo 
Blair273/I/LAB: Anthony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/
LIB: Sarah Gurling277/P/CON: Nigel Hague (Father)29T/E/Other Relative3AA/Q/Agric
ulture Representative3AB/S/Business/City Representative3AC/1N/Business Organisat
ion eg. CBI, Institute of Directors3AD/D/Civil Servant3AE/M/Celebrity (state who
m)3AF/9/Economist3AG/19/European Leader/Politician (state whom)3AH/H/EU Represen
tative3AI/J/Farmer/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demonst
rator3AL/15/Media Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/Secur
ity3AO/E/Pressure Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollster
/Bookmaker3AS/A/Pensioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scienti
st/Scientific Expert3B2/T/Social Service Representative3B3/13/Trade Union/Repres
entative/Member3B4/P/Unamed Source - Non-Party3B5/J/University Academic3B6/10/Vo
ter/Citizen/Person in Street3B7/1K/World Leader/Politician (not European)(state 
whom)3B8/E/Geri Halliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/
Think Tank3D9/5/OtherD1/7/ACT1GEN3/1/4/Male2/6/Female3/F/Can't DetermineD1/8/ACT
OR2ND6I/3K/C/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Scottish 
Nationalist Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Party3R/L
/UK Independence Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/UUP - 
Ulster Unionist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42/E/The
 Government43/B/The Cabinet44/L/Government Department45/E/The Opposition46/R/Par
liament/MPs (in general)47/18/The European Union/European Commission48/8/Millban
k49/K/Electoral Commission4A/F/Scottish Labour4B/F/Scottish Tories6H/10/Other Pa
rty - British Mainland6I/10/Other Party - Northern Ireland6J/H/Other Institution
70/A/Blair Tony71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry (SF)74/G/H
ume John (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble Davi
d (UUP)78/I/Nick Griffin (BNP)9T/K/Party Leader - OtherAA/J/LAB: Blunkett DavidA
B/H/LAB: Brown GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: Prescot
t JohnAF/G/LAB: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/LAB: O
ther Senior Labour PoliticianDK/11/LAB: Baroness Jay of PaddingtonDL/K/LAB: Beck
et MargaretDM/F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB: Campbell Alistai
rDP/L/LAB: Darling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/K/LAB:
 Mandelson PeterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Reid Joh
nE3/H/LAB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Woodward
 ShaunE7/1A/LAB: Spokesperson or Unamed Party SourceE8/J/LAB: Party OfficialE9/D
/LAB: ActivistEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidate/Peer
GJ/P/LAB: Other inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2/I/CON
: Maude FrancisH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/L/CON: Portillo Mi
chaelH6/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other Senior PoliticianK
A/K/CON: Ainsworth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbuthnot JamesKD/K/CO
N: Browning AngelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/CON: H
eathcote Amory DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johnson BorisKJ/J/CON: 
Lansley AndrewKK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/J/CON: Platell Ama
ndaKN/K/CON: Rifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: The Lord HenleyKQ/P
/CON: The Lord StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Spokesperson or Unam
ed Party SourceKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/CON: CouncillorL2/
8/CON: MEPL3/J/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/CON: Other MP/Candi
date/PeerN9/P/CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campbell Me
nziesNM/F/LIB: Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers of Quarry
 BankNP/J/LIB: Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/S/LIB:
 Other Senior PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable VincentR2/G/LIB: Ha
rver NickR3/J/LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore Micha
elR6/F/LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: Spokes
person or Unamed Party SourceRA/J/LIB: Party OfficialRB/D/LIB: ActivistRC/F/LIB:
 CouncillorRD/8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/LIB: Other inc. Su
pporter10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10E/E/Hattersley Roy10
F/9/Heath Ted10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13/Nelli
st Dave (Socialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party)10L/1
G/Taylor Dr. Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/19/Tit
ford Jeffrey (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Individual
13K/1B/David Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scottish P
arliament First Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13N/1F/R
hodri Morgan (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Party)13
P/13/Ian Paisley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Supp
orter/etc13R/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: MP/Cand
idate/Spokesperson/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson/Suppo
rter/etc140/1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/M/Other P
arty/Politician270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair2
73/I/LAB: Anthony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: S
arah Gurling277/P/CON: Nigel Hague (Father)29T/E/Other Relative3AA/Q/Agriculture
 Representative3AB/S/Business/City Representative3AC/1N/Business Organisation eg
. CBI, Institute of Directors3AD/D/Civil Servant3AE/M/Celebrity (state whom)3AF/
9/Economist3AG/19/European Leader/Politician (state whom)3AH/H/EU Representative
3AI/J/Farmer/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demonstrator3
AL/15/Media Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/Security3AO
/E/Pressure Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollster/Bookm
aker3AS/A/Pensioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scientist/Sci
entific Expert3B2/T/Social Service Representative3B3/13/Trade Union/Representati
ve/Member3B4/P/Unamed Source - Non-Party3B5/J/University Academic3B6/10/Voter/Ci
tizen/Person in Street3B7/1K/World Leader/Politician (not European)(state whom)3
B8/E/Geri Halliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/Think 
Tank3D9/5/OtherD1/7/ACT2GEN3/1/4/Male2/6/Female3/F/Can't DetermineD1/8/ACTOR3RD6
I/3K/C/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Scottish Nation
alist Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Party3R/L/UK In
dependence Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/UUP - Ulster
 Unionist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42/E/The Gover
nment43/B/The Cabinet44/L/Government Department45/E/The Opposition46/R/Parliamen
t/MPs (in general)47/18/The European Union/European Commission48/8/Millbank49/K/
Electoral Commission4A/F/Scottish Labour4B/F/Scottish Tories6H/10/Other Party - 
British Mainland6I/10/Other Party - Northern Ireland6J/H/Other Institution70/A/B
lair Tony71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry (SF)74/G/Hume Jo
hn (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble David (UUP
)78/I/Nick Griffin (BNP)9T/K/Party Leader - OtherAA/J/LAB: Blunkett DavidAB/H/LA
B: Brown GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: Prescott John
AF/G/LAB: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/LAB: Other S
enior Labour PoliticianDK/11/LAB: Baroness Jay of PaddingtonDL/K/LAB: Becket Mar
garetDM/F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB: Campbell AlistairDP/L/
LAB: Darling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/K/LAB: Mande
lson PeterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Reid JohnE3/H/
LAB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Woodward Shaun
E7/1A/LAB: Spokesperson or Unamed Party SourceE8/J/LAB: Party OfficialE9/D/LAB: 
ActivistEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidate/PeerGJ/P/L
AB: Other inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2/I/CON: Maud
e FrancisH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/L/CON: Portillo MichaelH
6/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other Senior PoliticianKA/K/CO
N: Ainsworth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbuthnot JamesKD/K/CON: Bro
wning AngelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/CON: Heathco
te Amory DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johnson BorisKJ/J/CON: Lansle
y AndrewKK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/J/CON: Platell AmandaKN/
K/CON: Rifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: The Lord HenleyKQ/P/CON: 
The Lord StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Spokesperson or Unamed Par
ty SourceKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/CON: CouncillorL2/8/CON:
 MEPL3/J/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/CON: Other MP/Candidate/P
eerN9/P/CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campbell MenziesN
M/F/LIB: Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers of Quarry BankN
P/J/LIB: Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/S/LIB: Other
 Senior PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable VincentR2/G/LIB: Harver N
ickR3/J/LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore MichaelR6/F
/LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: Spokesperson
 or Unamed Party SourceRA/J/LIB: Party OfficialRB/D/LIB: ActivistRC/F/LIB: Counc
illorRD/8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/LIB: Other inc. Supporte
r10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10E/E/Hattersley Roy10F/9/He
ath Ted10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13/Nellist Dav
e (Socialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party)10L/1G/Tayl
or Dr. Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/19/Titford J
effrey (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Individual13K/1B
/David Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scottish Parliam
ent First Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13N/1F/Rhodri 
Morgan (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Party)13P/13/I
an Paisley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Supporter/
etc13R/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: MP/Candidate/
Spokesperson/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson/Supporter/e
tc140/1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/M/Other Party/P
olitician270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair273/I/L
AB: Anthony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: Sarah G
urling277/P/CON: Nigel Hague (Father)29T/E/Other Relative3AA/Q/Agriculture Repre
sentative3AB/S/Business/City Representative3AC/1N/Business Organisation eg. CBI,
 Institute of Directors3AD/D/Civil Servant3AE/M/Celebrity (state whom)3AF/9/Econ
omist3AG/19/European Leader/Politician (state whom)3AH/H/EU Representative3AI/J/
Farmer/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demonstrator3AL/15/
Media Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/Security3AO/E/Pre
ssure Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollster/Bookmaker3A
S/A/Pensioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scientist/Scientifi
c Expert3B2/T/Social Service Representative3B3/13/Trade Union/Representative/Mem
ber3B4/P/Unamed Source - Non-Party3B5/J/University Academic3B6/10/Voter/Citizen/
Person in Street3B7/1K/World Leader/Politician (not European)(state whom)3B8/E/G
eri Halliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/Think Tank3D
9/5/OtherD1/7/ACT3GEN3/1/4/Male2/6/Female3/F/Can't DetermineD1/8/ACTOR4TH6I/3K/C
/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Scottish Nationalist 
Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Party3R/L/UK Independ
ence Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/UUP - Ulster Union
ist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42/E/The Government4
3/B/The Cabinet44/L/Government Department45/E/The Opposition46/R/Parliament/MPs 
(in general)47/18/The European Union/European Commission48/8/Millbank49/K/Electo
ral Commission4A/F/Scottish Labour4B/F/Scottish Tories6H/10/Other Party - Britis
h Mainland6I/10/Other Party - Northern Ireland6J/H/Other Institution70/A/Blair T
ony71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry (SF)74/G/Hume John (SD
LP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble David (UUP)78/I/
Nick Griffin (BNP)9T/K/Party Leader - OtherAA/J/LAB: Blunkett DavidAB/H/LAB: Bro
wn GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: Prescott JohnAF/G/L
AB: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/LAB: Other Senior 
Labour PoliticianDK/11/LAB: Baroness Jay of PaddingtonDL/K/LAB: Becket MargaretD
M/F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB: Campbell AlistairDP/L/LAB: D
arling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/K/LAB: Mandelson P
eterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Reid JohnE3/H/LAB: S
mith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Woodward ShaunE7/1A/
LAB: Spokesperson or Unamed Party SourceE8/J/LAB: Party OfficialE9/D/LAB: Activi
stEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidate/PeerGJ/P/LAB: Ot
her inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2/I/CON: Maude Fran
cisH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/L/CON: Portillo MichaelH6/J/CO
N: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other Senior PoliticianKA/K/CON: Ain
sworth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbuthnot JamesKD/K/CON: Browning 
AngelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/CON: Heathcote Amo
ry DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johnson BorisKJ/J/CON: Lansley Andr
ewKK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/J/CON: Platell AmandaKN/K/CON:
 Rifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: The Lord HenleyKQ/P/CON: The Lo
rd StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Spokesperson or Unamed Party Sou
rceKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/CON: CouncillorL2/8/CON: MEPL3
/J/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/CON: Other MP/Candidate/PeerN9/
P/CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campbell MenziesNM/F/LI
B: Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers of Quarry BankNP/J/LI
B: Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/S/LIB: Other Senio
r PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable VincentR2/G/LIB: Harver NickR3/
J/LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore MichaelR6/F/LIB: 
Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: Spokesperson or Un
amed Party SourceRA/J/LIB: Party OfficialRB/D/LIB: ActivistRC/F/LIB: CouncillorR
D/8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/LIB: Other inc. Supporter10A/D
/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10E/E/Hattersley Roy10F/9/Heath Te
d10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13/Nellist Dave (Soc
ialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party)10L/1G/Taylor Dr.
 Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/19/Titford Jeffrey
 (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Individual13K/1B/David
 Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scottish Parliament Fi
rst Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13N/1F/Rhodri Morgan
 (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Party)13P/13/Ian Pai
sley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Supporter/etc13R
/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: MP/Candidate/Spokes
person/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson/Supporter/etc140/
1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/M/Other Party/Politic
ian270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair273/I/LAB: An
thony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: Sarah Gurling
277/P/CON: Nigel Hague (Father)29T/E/Other Relative3AA/Q/Agriculture Representat
ive3AB/S/Business/City Representative3AC/1N/Business Organisation eg. CBI, Insti
tute of Directors3AD/D/Civil Servant3AE/M/Celebrity (state whom)3AF/9/Economist3
AG/19/European Leader/Politician (state whom)3AH/H/EU Representative3AI/J/Farmer
/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demonstrator3AL/15/Media 
Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/Security3AO/E/Pressure 
Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollster/Bookmaker3AS/A/Pe
nsioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scientist/Scientific Expe
rt3B2/T/Social Service Representative3B3/13/Trade Union/Representative/Member3B4
/P/Unamed Source - Non-Party3B5/J/University Academic3B6/10/Voter/Citizen/Person
 in Street3B7/1K/World Leader/Politician (not European)(state whom)3B8/E/Geri Ha
lliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/Think Tank3D9/5/Ot
herD1/7/ACT4GEN3/1/4/Male2/6/Female3/F/Can't DetermineD1/8/JOURNEV15/0/F/Can't D
etermine1/A/Crticising2/A/Mixed/Both3/A/Supporting4/7/NeutralD1/8/JOURNEV25/0/F/
Can't Determine1/A/Crticising2/A/Mixed/Both3/A/Supporting4/7/NeutralD1/8/EVLTING
16J/3K/C/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Scottish Nati
onalist Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Party3R/L/UK 
Independence Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/UUP - Ulst
er Unionist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42/E/The Gov
ernment43/B/The Cabinet44/L/Government Department45/E/The Opposition46/R/Parliam
ent/MPs (in general)47/18/The European Union/European Commission48/8/Millbank49/
K/Electoral Commission4A/F/Scottish Labour4B/F/Scottish Tories6H/10/Other Party 
- British Mainland6I/10/Other Party - Northern Ireland6J/H/Other Institution70/A
/Blair Tony71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry (SF)74/G/Hume 
John (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble David (U
UP)78/I/Nick Griffin (BNP)9T/K/Party Leader - OtherAA/J/LAB: Blunkett DavidAB/H/
LAB: Brown GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: Prescott Jo
hnAF/G/LAB: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/LAB: Other
 Senior Labour PoliticianDK/11/LAB: Baroness Jay of PaddingtonDL/K/LAB: Becket M
argaretDM/F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB: Campbell AlistairDP/
L/LAB: Darling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/K/LAB: Man
delson PeterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Reid JohnE3/
H/LAB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Woodward Sha
unE7/1A/LAB: Spokesperson or Unamed Party SourceE8/J/LAB: Party OfficialE9/D/LAB
: ActivistEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidate/PeerGJ/P
/LAB: Other inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2/I/CON: Ma
ude FrancisH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/L/CON: Portillo Michae
lH6/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other Senior PoliticianKA/K/
CON: Ainsworth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbuthnot JamesKD/K/CON: B
rowning AngelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/CON: Heath
cote Amory DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johnson BorisKJ/J/CON: Lans
ley AndrewKK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/J/CON: Platell AmandaK
N/K/CON: Rifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: The Lord HenleyKQ/P/CON
: The Lord StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Spokesperson or Unamed P
arty SourceKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/CON: CouncillorL2/8/CO
N: MEPL3/J/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/CON: Other MP/Candidate
/PeerN9/P/CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campbell Menzie
sNM/F/LIB: Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers of Quarry Ban
kNP/J/LIB: Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/S/LIB: Oth
er Senior PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable VincentR2/G/LIB: Harver
 NickR3/J/LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore MichaelR6
/F/LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: Spokespers
on or Unamed Party SourceRA/J/LIB: Party OfficialRB/D/LIB: ActivistRC/F/LIB: Cou
ncillorRD/8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/LIB: Other inc. Suppor
ter10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10D/I/Griffin Nick (BNP)10
E/E/Hattersley Roy10F/9/Heath Ted10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Ma
jor John10J/13/Nellist Dave (Socialist Alliance)10K/1A/Scargill Arthur (Socialis
t Labour Party)10L/1G/Taylor Dr. Richard (Kidderminster Independent)10M/G/Thatch
er Magaret10N/19/Titford Jeffrey (UK Independence Party)10O/G/Hinduja Brothers13
9/G/Other Individual13K/1B/David Ervine (Progressive Unionist Party)13L/1K/Henry
 McLeish (Scottish Parliament First Minister)13M/1A/Gary McMichael (Ulster Democ
ratic Party)13N/1F/Rhodri Morgan (Welsh Assembly First Minister)13O/S/Sean Neeso
n (Alliance Party)13P/13/Ian Paisley (Democratic Unionist)13Q/1E/SNP: MP/Candida
te/Spokesperson/Supporter/etc13R/1D/PC: MP/Candidate/Spokesperson/Supporter/etc1
3S/1G/Green: MP/Candidate/Spokesperson/Supporter/etc13T/1J/NI Party: MP/Candidat
e/Spokesperson/Supporter/etc140/1M/Other Party: MP/Candidate/Spokesperson/Suppor
ter/etc16J/M/Other Party/Politician270/H/LAB: Cherie Blair271/F/LAB: Euan Blair2
72/E/LAB: Leo Blair273/I/LAB: Anthony Booth274/H/LAB: Lauren Booth275/G/CON: Ffi
on Hague276/I/LIB: Sarah Gurling277/P/CON: Nigel Hague (Father)29T/E/Other Relat
ive3AA/Q/Agriculture Representative3AB/S/Business/City Representative3AC/1N/Busi
ness Organisation eg. CBI, Institute of Directors3AD/D/Civil Servant3AE/9/Celebr
ity3AF/9/Economist3AG/Q/European Leader/Politician3AH/H/EU Representative3AI/J/F
armer/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demonstrator3AL/15/M
edia Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/Security3AO/E/Pres
sure Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollster/Bookmaker3AS
/A/Pensioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scientist/Scientific
 Expert3B2/T/Social Service Representative3B3/13/Trade Union/Representative/Memb
er3B4/P/Unamed Source - Non-Party3B5/J/University Academic3B6/10/Voter/Citizen/P
erson in Street3B7/18/World Leader/Politician (not European)3B8/E/Geri Halliwell
3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/Think Tank3D9/5/OtherD1/8
/EVLTION15/0/F/Can't Determine1/A/Crticising2/A/Mixed/Both3/A/Supporting4/7/Neut
ralD1/7/EVLTED16J/3K/C/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q
/Scottish Nationalist Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National
 Party3R/L/UK Independence Party3S/1B/SDLP - Social Democratic and Labour Party3
T/R/UUP - Ulster Unionist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fe
in42/E/The Government43/B/The Cabinet44/L/Government Department45/E/The Oppositi
on46/R/Parliament/MPs (in general)47/18/The European Union/European Commission48
/8/Millbank49/K/Electoral Commission4A/F/Scottish Labour4B/F/Scottish Tories6H/1
0/Other Party - British Mainland6I/10/Other Party - Northern Ireland6J/H/Other I
nstitution70/A/Blair Tony71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry 
(SF)74/G/Hume John (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Tr
imble David (UUP)78/I/Nick Griffin (BNP)9T/K/Party Leader - OtherAA/J/LAB: Blunk
ett DavidAB/H/LAB: Brown GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn AlanAE/I/LA
B: Prescott JohnAF/G/LAB: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Straw JackD9
/15/LAB: Other Senior Labour PoliticianDK/11/LAB: Baroness Jay of PaddingtonDL/K
/LAB: Becket MargaretDM/F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB: Campbe
ll AlistairDP/L/LAB: Darling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Liddell Hele
nDS/K/LAB: Mandelson PeterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB
: Reid JohnE3/H/LAB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB
: Woodward ShaunE7/1A/LAB: Spokesperson or Unamed Party SourceE8/J/LAB: Party Of
ficialE9/D/LAB: ActivistEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other MP/Cand
idate/PeerGJ/P/LAB: Other inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenkin Berna
rdH2/I/CON: Maude FrancisH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/L/CON: P
ortillo MichaelH6/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other Senior P
oliticianKA/K/CON: Ainsworth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbuthnot Ja
mesKD/K/CON: Browning AngelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier EdwardK
G/Q/CON: Heathcote Amory DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johnson Boris
KJ/J/CON: Lansley AndrewKK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/J/CON: P
latell AmandaKN/K/CON: Rifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: The Lord 
HenleyKQ/P/CON: The Lord StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Spokespers
on or Unamed Party SourceKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/CON: Cou
ncillorL2/8/CON: MEPL3/J/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/CON: Othe
r MP/Candidate/PeerN9/P/CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/L/LIB: C
ampbell MenziesNM/F/LIB: Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers
 of Quarry BankNP/J/LIB: Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace Ji
mQJ/S/LIB: Other Senior PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable VincentR2
/G/LIB: Harver NickR3/J/LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/I/LIB: M
oore MichaelR6/F/LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis PhilR9/1A/L
IB: Spokesperson or Unamed Party SourceRA/J/LIB: Party OfficialRB/D/LIB: Activis
tRC/F/LIB: CouncillorRD/8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/LIB: Oth
er inc. Supporter10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10D/I/Griffi
n Nick (BNP)10E/E/Hattersley Roy10F/9/Heath Ted10G/C/Kinnock Neil10H/F/Livingsto
ne Ken10I/A/Major John10J/13/Nellist Dave (Socialist Alliance)10K/1A/Scargill Ar
thur (Socialist Labour Party)10L/1G/Taylor Dr. Richard (Kidderminster Independen
t)10M/G/Thatcher Magaret10N/19/Titford Jeffrey (UK Independence Party)10O/G/Hind
uja Brothers139/G/Other Individual13K/1B/David Ervine (Progressive Unionist Part
y)13L/1K/Henry McLeish (Scottish Parliament First Minister)13M/1A/Gary McMichael
 (Ulster Democratic Party)13N/1F/Rhodri Morgan (Welsh Assembly First Minister)13
O/S/Sean Neeson (Alliance Party)13P/13/Ian Paisley (Democratic Unionist)13Q/1E/S
NP: MP/Candidate/Spokesperson/Supporter/etc13R/1D/PC: MP/Candidate/Spokesperson/
Supporter/etc13S/1G/Green: MP/Candidate/Spokesperson/Supporter/etc13T/1J/NI Part
y: MP/Candidate/Spokesperson/Supporter/etc140/1M/Other Party: MP/Candidate/Spoke
sperson/Supporter/etc16J/M/Other Party/Politician270/H/LAB: Cherie Blair271/F/LA
B: Euan Blair272/E/LAB: Leo Blair273/I/LAB: Anthony Booth274/H/LAB: Lauren Booth
275/G/CON: Ffion Hague276/I/LIB: Sarah Gurling277/P/CON: Nigel Hague (Father)29T
/E/Other Relative3AA/Q/Agriculture Representative3AB/S/Business/City Representat
ive3AC/1N/Business Organisation eg. CBI, Institute of Directors3AD/D/Civil Serva
nt3AE/9/Celebrity3AF/9/Economist3AG/Q/European Leader/Politician3AH/H/EU Represe
ntative3AI/J/Farmer/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demons
trator3AL/15/Media Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/Secu
rity3AO/E/Pressure Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollste
r/Bookmaker3AS/A/Pensioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scient
ist/Scientific Expert3B2/T/Social Service Representative3B3/13/Trade Union/Repre
sentative/Member3B4/P/Unamed Source - Non-Party3B5/J/University Academic3B6/10/V
oter/Citizen/Person in Street3B7/18/World Leader/Politician (not European)3B8/E/
Geri Halliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/Think Tank3
D9/5/OtherD1/8/EVLTING26J/3K/C/Labour Party3L/I/Conservative Party3M/D/Lib Dem P
arty3N/Q/Scottish Nationalist Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British 
National Party3R/L/UK Independence Party3S/1B/SDLP - Social Democratic and Labou
r Party3T/R/UUP - Ulster Unionist Party40/11/DUP - Democratic Unionist Party41/9
/Sinn Fein42/E/The Government43/B/The Cabinet44/L/Government Department45/E/The 
Opposition46/R/Parliament/MPs (in general)47/18/The European Union/European Comm
ission48/8/Millbank49/K/Electoral Commission4A/F/Scottish Labour4B/F/Scottish To
ries6H/10/Other Party - British Mainland6I/10/Other Party - Northern Ireland6J/H
/Other Institution70/A/Blair Tony71/D/Hague William72/F/Kennedy Charles73/G/Adam
s Gerry (SF)74/G/Hume John (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP
)77/J/Trimble David (UUP)78/I/Nick Griffin (BNP)9T/K/Party Leader - OtherAA/J/LA
B: Blunkett DavidAB/H/LAB: Brown GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn Ala
nAE/I/LAB: Prescott JohnAF/G/LAB: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Stra
w JackD9/15/LAB: Other Senior Labour PoliticianDK/11/LAB: Baroness Jay of Paddin
gtonDL/K/LAB: Becket MargaretDM/F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB
: Campbell AlistairDP/L/LAB: Darling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Lidd
ell HelenDS/K/LAB: Mandelson PeterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh Margaret
E2/E/LAB: Reid JohnE3/H/LAB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz Keith
E6/J/LAB: Woodward ShaunE7/1A/LAB: Spokesperson or Unamed Party SourceE8/J/LAB: 
Party OfficialE9/D/LAB: ActivistEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other
 MP/Candidate/PeerGJ/P/LAB: Other inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenk
in BernardH2/I/CON: Maude FrancisH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/
L/CON: Portillo MichaelH6/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other 
Senior PoliticianKA/K/CON: Ainsworth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbu
thnot JamesKD/K/CON: Browning AngelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier
 EdwardKG/Q/CON: Heathcote Amory DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johns
on BorisKJ/J/CON: Lansley AndrewKK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/
J/CON: Platell AmandaKN/K/CON: Rifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: T
he Lord HenleyKQ/P/CON: The Lord StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Sp
okesperson or Unamed Party SourceKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/
CON: CouncillorL2/8/CON: MEPL3/J/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/C
ON: Other MP/Candidate/PeerN9/P/CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/
L/LIB: Campbell MenziesNM/F/LIB: Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord
 Rodgers of Quarry BankNP/J/LIB: Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wa
llace JimQJ/S/LIB: Other Senior PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable V
incentR2/G/LIB: Harver NickR3/J/LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/
I/LIB: Moore MichaelR6/F/LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis Phi
lR9/1A/LIB: Spokesperson or Unamed Party SourceRA/J/LIB: Party OfficialRB/D/LIB:
 ActivistRC/F/LIB: CouncillorRD/8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/
LIB: Other inc. Supporter10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10D/
I/Griffin Nick (BNP)10E/E/Hattersley Roy10F/9/Heath Ted10G/C/Kinnock Neil10H/F/L
ivingstone Ken10I/A/Major John10J/13/Nellist Dave (Socialist Alliance)10K/1A/Sca
rgill Arthur (Socialist Labour Party)10L/1G/Taylor Dr. Richard (Kidderminster In
dependent)10M/G/Thatcher Magaret10N/19/Titford Jeffrey (UK Independence Party)10
O/G/Hinduja Brothers139/G/Other Individual13K/1B/David Ervine (Progressive Union
ist Party)13L/1K/Henry McLeish (Scottish Parliament First Minister)13M/1A/Gary M
cMichael (Ulster Democratic Party)13N/1F/Rhodri Morgan (Welsh Assembly First Min
ister)13O/S/Sean Neeson (Alliance Party)13P/13/Ian Paisley (Democratic Unionist)
13Q/1E/SNP: MP/Candidate/Spokesperson/Supporter/etc13R/1D/PC: MP/Candidate/Spoke
sperson/Supporter/etc13S/1G/Green: MP/Candidate/Spokesperson/Supporter/etc13T/1J
/NI Party: MP/Candidate/Spokesperson/Supporter/etc140/1M/Other Party: MP/Candida
te/Spokesperson/Supporter/etc16J/M/Other Party/Politician270/H/LAB: Cherie Blair
271/F/LAB: Euan Blair272/E/LAB: Leo Blair273/I/LAB: Anthony Booth274/H/LAB: Laur
en Booth275/G/CON: Ffion Hague276/I/LIB: Sarah Gurling277/P/CON: Nigel Hague (Fa
ther)29T/E/Other Relative3AA/Q/Agriculture Representative3AB/S/Business/City Rep
resentative3AC/1N/Business Organisation eg. CBI, Institute of Directors3AD/D/Civ
il Servant3AE/9/Celebrity3AF/9/Economist3AG/Q/European Leader/Politician3AH/H/EU
 Representative3AI/J/Farmer/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckle
r/Demonstrator3AL/15/Media Commentator/Journalist/Author3AM/9/The Media3AN/F/Pol
ice/Security3AO/E/Pressure Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I
/Pollster/Bookmaker3AS/A/Pensioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/
R/Scientist/Scientific Expert3B2/T/Social Service Representative3B3/13/Trade Uni
on/Representative/Member3B4/P/Unamed Source - Non-Party3B5/J/University Academic
3B6/10/Voter/Citizen/Person in Street3B7/18/World Leader/Politician (not Europea
n)3B8/E/Geri Halliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/Thi
nk Tank3D9/5/OtherD1/8/EVLTION25/0/F/Can't Determine1/A/Crticising2/A/Mixed/Both
3/A/Supporting4/7/NeutralD1/7/EVLTED26J/3K/C/Labour Party3L/I/Conservative Party
3M/D/Lib Dem Party3N/Q/Scottish Nationalist Party3O/B/Plaid Cymru3P/B/Green Part
y3Q/M/British National Party3R/L/UK Independence Party3S/1B/SDLP - Social Democr
atic and Labour Party3T/R/UUP - Ulster Unionist Party40/11/DUP - Democratic Unio
nist Party41/9/Sinn Fein42/E/The Government43/B/The Cabinet44/L/Government Depar
tment45/E/The Opposition46/R/Parliament/MPs (in general)47/18/The European Union
/European Commission48/8/Millbank49/K/Electoral Commission4A/F/Scottish Labour4B
/F/Scottish Tories6H/10/Other Party - British Mainland6I/10/Other Party - Northe
rn Ireland6J/H/Other Institution70/A/Blair Tony71/D/Hague William72/F/Kennedy Ch
arles73/G/Adams Gerry (SF)74/G/Hume John (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swi
nney John (SNP)77/J/Trimble David (UUP)78/I/Nick Griffin (BNP)9T/K/Party Leader 
- OtherAA/J/LAB: Blunkett DavidAB/H/LAB: Brown GordonAC/F/LAB: Cook RobinAD/H/LA
B: Milburn AlanAE/I/LAB: Prescott JohnAF/G/LAB: Smith ChrisAG/G/LAB: Short Clare
AH/F/LAB: Straw JackD9/15/LAB: Other Senior Labour PoliticianDK/11/LAB: Baroness
 Jay of PaddingtonDL/K/LAB: Becket MargaretDM/F/LAB: Brown NickDN/I/LAB: Byers S
tephenDO/M/LAB: Campbell AlistairDP/L/LAB: Darling AlistairDQ/G/LAB: Irvine Lord
DR/I/LAB: Liddell HelenDS/K/LAB: Mandelson PeterE0/E/LAB: Mowlam MoE1/M/LAB: McD
onagh MargaretE2/E/LAB: Reid JohnE3/H/LAB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/
LAB: Vaz KeithE6/J/LAB: Woodward ShaunE7/1A/LAB: Spokesperson or Unamed Party So
urceE8/J/LAB: Party OfficialE9/D/LAB: ActivistEA/F/LAB: CouncillorEB/8/LAB: MEPG
I/S/LAB: Other MP/Candidate/PeerGJ/P/LAB: Other inc. SupporterH0/D/CON: Fox Liam
H1/J/CON: Jenkin BernardH2/I/CON: Maude FrancisH3/G/CON: May TheresaH4/I/CON: No
rman ArchieH5/L/CON: Portillo MichaelH6/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT
/S/CON: Other Senior PoliticianKA/K/CON: Ainsworth PeterKB/J/CON: Ancram Michael
KC/K/CON: Arbuthnot JamesKD/K/CON: Browning AngelaKE/M/CON: Duncan-Smith IainKF/
J/CON: Garnier EdwardKG/Q/CON: Heathcote Amory DavidKH/M/CON: Heseltine MichaelK
I/I/CON: Johnson BorisKJ/J/CON: Lansley AndrewKK/I/CON: Letwin OliverKL/H/CON: M
cKay AndrewKM/J/CON: Platell AmandaKN/K/CON: Rifkind MalcolmKO/I/CON: Streeter G
aryKP/K/CON: The Lord HenleyKQ/P/CON: The Lord StrathclydeKR/I/CON: Willett Davi
dKS/1A/CON: Spokesperson or Unamed Party SourceKT/J/CON: Party OfficialL0/D/CON:
 ActivistL1/F/CON: CouncillorL2/8/CON: MEPL3/J/CON: Clarke KennethL4/H/CON: Pick
les EricN8/S/CON: Other MP/Candidate/PeerN9/P/CON: Other inc. SupporterNK/F/LIB:
 Beith AlanNL/L/LIB: Campbell MenziesNM/F/LIB: Foster DonNN/H/LIB: Hughes SimonN
O/12/LIB: Lord Rodgers of Quarry BankNP/J/LIB: Taylor MatthewNQ/G/LIB: Tonge Jen
nyNR/G/LIB: Wallace JimQJ/S/LIB: Other Senior PoliticianR0/G/LIB: Breed ColinR1/
I/LIB: Cable VincentR2/G/LIB: Harver NickR3/J/LIB: Livsey RichardR4/L/LIB: Macle
nnan RobertR5/I/LIB: Moore MichaelR6/F/LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/L
IB: Willis PhilR9/1A/LIB: Spokesperson or Unamed Party SourceRA/J/LIB: Party Off
icialRB/D/LIB: ActivistRC/F/LIB: CouncillorRD/8/LIB: MEPRE/S/LIB: Other MP/Candi
date/PeerTT/P/LIB: Other inc. Supporter10A/D/Ashdown Paddy10B/B/Bell Martin10C/9
/Benn Tony10D/I/Griffin Nick (BNP)10E/E/Hattersley Roy10F/9/Heath Ted10G/C/Kinno
ck Neil10H/F/Livingstone Ken10I/A/Major John10J/13/Nellist Dave (Socialist Allia
nce)10K/1A/Scargill Arthur (Socialist Labour Party)10L/1G/Taylor Dr. Richard (Ki
dderminster Independent)10M/G/Thatcher Magaret10N/19/Titford Jeffrey (UK Indepen
dence Party)10O/G/Hinduja Brothers139/G/Other Individual13K/1B/David Ervine (Pro
gressive Unionist Party)13L/1K/Henry McLeish (Scottish Parliament First Minister
)13M/1A/Gary McMichael (Ulster Democratic Party)13N/1F/Rhodri Morgan (Welsh Asse
mbly First Minister)13O/S/Sean Neeson (Alliance Party)13P/13/Ian Paisley (Democr
atic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Supporter/etc13R/1D/PC: MP/C
andidate/Spokesperson/Supporter/etc13S/1G/Green: MP/Candidate/Spokesperson/Suppo
rter/etc13T/1J/NI Party: MP/Candidate/Spokesperson/Supporter/etc140/1M/Other Par
ty: MP/Candidate/Spokesperson/Supporter/etc16J/M/Other Party/Politician270/H/LAB
: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair273/I/LAB: Anthony Booth2
74/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: Sarah Gurling277/P/CON: N
igel Hague (Father)29T/E/Other Relative3AA/Q/Agriculture Representative3AB/S/Bus
iness/City Representative3AC/1N/Business Organisation eg. CBI, Institute of Dire
ctors3AD/D/Civil Servant3AE/9/Celebrity3AF/9/Economist3AG/Q/European Leader/Poli
tician3AH/H/EU Representative3AI/J/Farmer/Rural worker3AJ/M/Film/Documentary Mak
er3AK/K/Heckler/Demonstrator3AL/15/Media Commentator/Journalist/Author3AM/9/The 
Media3AN/F/Police/Security3AO/E/Pressure Group3AP/8/Prisoner3AQ/N/Professional I
ndividual3AR/I/Pollster/Bookmaker3AS/A/Pensioners3AT/M/Religious Spokesperson3B0
/7/Royalty3B1/R/Scientist/Scientific Expert3B2/T/Social Service Representative3B
3/13/Trade Union/Representative/Member3B4/P/Unamed Source - Non-Party3B5/J/Unive
rsity Academic3B6/10/Voter/Citizen/Person in Street3B7/18/World Leader/Politicia
n (not European)3B8/E/Geri Halliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/
3/ITV3BC/A/Think Tank3D9/5/OtherD1/7/TONE1ST5/0/F/Can't Determine1/8/Negative2/A
/Mixed/Both3/8/Positive4/7/NeutralD1/7/TONE2ND5/0/F/Can't Determine1/8/Negative2
/A/Mixed/Both3/8/Positive4/7/NeutralD1/6/POLICY4/0/4/None1/3/Low2/6/Medium3/4/Hi
ghD1/8/PRSONLTY4/0/4/None1/3/Low2/6/Medium3/4/HighFDNL2O+2/B6L/1/3/2/BQ/1/2/1/2/
1/ 2/3/1/2/42/1/ 39/49/1/ 5/*.1/ *.GI/2/9/Women MPs3K/3/1/ E7/3/1/ *.*.1/ 4/4/*.
*.*.*.*.*.4/4/1/0/DNL2O+2/B6P/1/3/2/H7/1/1/1/1/1/ 8/2/1/1/3D/1/ 3/*.1/ *.*.1/ *.
70/1/1/ AA/1/1/ 3D9/3/F/School Children*.*.1/ 1/4/*.*.*.*.*.*.1/4/0/0/DNL2O+2/B6
Q/1/3/2/LH/1/1/1/1/1/ 1/2/1/1/3D/1/ 3/3B/1/ 3/*.1/ *.70/1/1/ 71/1/1/ 72/1/1/ *.*
.1/ 4/4/71/1/70/*.*.*.4/4/1/0/DNL2O+2/B6T/1/3/2/QP/1/4/5/2/A/sarah hall1/2/1/1/3
D/1/ 3/A2/1/ 8/EA/1/ 1/70/1/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.2/0/DNL2
O+2/B71/1/3/2/RA/1/5/4/1/1/ 2/3/1/1/6L/1/ 6/9T/14/Analysis of previous opinion p
olls6/*.1/ *.71/1/1/ 3K/3/1/ 3L/3/1/ 3M/3/1/ 1/3/*.*.*.*.*.*.1/3/0/0/DNL2O+2/B73
/1/3/2/R7/1/6/1/2/1/ 1/3/1/1/4G/1/ 39/EA/1/ 1/*.1/ *.72/1/1/ 3M/3/1/ *.*.1/ *.*.
1/ 4/4/*.*.*.*.*.*.4/4/2/1/DNL2O+2/B74/1/3/2/5S/1/6/1/1/1/ 2/3/1/2/A1/1/ 8/6O/1/
 6/*.1/ *.70/1/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.0/0/DNL2O+2/B76/1/3/2
/6O/1/7/1/1/1/ 5/3/1/1/D9/1D/Analysis of Hague's position after election8/A9/1/ 
8/*.1/ *.71/1/1/ H5/1/1/ 70/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/1/DNL2O+2/B78/1/3/
2/16I/1/J/2/1/1/ 5/3/1/1/6Q/18/Analysis of different election outcome7/3R/1/ 2/*
.1/ *.3K/3/1/ 70/1/1/ 3L/3/1/ 71/1/1/ 2/2/*.*.*.*.*.*.2/2/1/0/DNL2O+2/B79/1/3/2/
19B/1/J/2/2/1/ 5/3/1/2/6J/11/Can Blair secure a second term?8/EA/1/ 1/*.1/ *.70/
1/1/ 71/1/1/ AB/1/1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/1/0/DNL2O+2/B7A/1/3/2/QT/1/K/1/1
/1/ 5/3/1/1/A3/1/ 8/A1/1/ 8/DI/1/ 1/AB/1/1/ 70/1/1/ *.*.1/ *.*.1/ 2/4/*.*.*.*.*.
*.2/4/2/0/DNL2O+2/B7B/1/3/2/Q2/1/5/1/1/1/ 1/2/1/1/3B/1/ 3/3C/1/ 4/A2/1/ 8/71/1/1
/ 3B6/3/1/ N8/1/F/Michael McManus*.*.1/ 4/4/3B6/2/71/*.*.*.4/4/1/0/DNL6+3/BA1/1/
4/2/14S/1/H/39/1/1D/george osbourne - tory candidate for tatton5/3/1/2/3C/1/ 4/6
J/1J/Optimistic mood at tory hq and amongst supporters8/*.1/ *.3L/3/1/ 3K/3/1/ 7
0/1/1/ 71/1/1/ 3/1/*.*.*.*.*.*.3/1/1/0/DNL6+3/BA3/1/4/2/BD/1/5/5/1/C/jamie wilso
n1/2/1/2/3B/1/ 3/A3/1/ 8/*.1/ *.AE/1/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*
.0/0/DNL6+3/BA5/1/4/2/LR/1/5/1/1/1/ 1/3/1/1/3T/1/ 4/3T/1N/Speculation on mp bein
g offered peerage to stand down4/A1/1/ 8/E6/1/1/ 70/1/1/ GI/1/J/Gerry Bermingham
 MPE9/3/1/ 4/4/70/3/E6/E9/1/70/4/4/0/0/DNL6+3/BA6/1/4/2/FB/1/5/1/2/1/ 1/2/1/1/3L
/1/ 4/6J/1G/Lib Dems admit they won't form next government8/6J/11/Lib Dems could
 become 2nd party8/3M/3/1/ 72/1/1/ NN/1/1/ 3B6/3/1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNL6
+3/BA8/1/4/2/Q7/1/1/1/1/1/ 1/3/1/1/DE/1/ 1/EB/1/ 1/A2/1/ 8/3K/3/1/ AB/1/1/ 3BC/1
/S/Institute for Fiscal StudiesH5/1/1/ 4/4/3BC/2/3K/H5/1/AB/4/4/2/0/DNL6+3/BA9/1
/4/2/GC/1/1/1/1/1/ 1/2/1/1/A6/1/ 9/EA/1/ 1/*.1/ *.71/1/1/ 3K/3/1/ D9/3/G/Labour 
Ministers*.*.1/ 4/4/71/1/3K/D9/1/71/4/4/2/0/DNL6+3/BAA/1/4/2/K1/1/2/1/1/1/ 8/3/2
/1/6J/10/Summary of last day in Commons39/*.1/ *.*.1/ *.70/1/1/ 71/1/1/ 72/1/1/ 
10F/1/1/ 2/1/10F/1/70/*.*.*.2/1/0/0/DNL6+3/BAB/1/4/2/FO/1/4/1/1/1/ 1/1/1/1/DF/1/
 1/DG/1/ 1/A9/1/ 8/10F/1/1/ 71/1/1/ 70/1/1/ *.*.1/ 4/4/10F/1/71/71/1/70/4/4/1/0/
DNL6+3/BAC/1/4/2/10E/1/6/1/1/1/ 1/3/1/1/DE/1/ 1/GJ/O/Redistribution of wealth1/E
H/1/ 1/3K/3/1/ AB/1/1/ 3BC/3/R/Institute of Fiscal Studies*.*.1/ 4/4/3BC/2/3K/*.
*.*.4/4/2/0/DNL6+3/BAF/1/4/2/DH/1/J/3/3/1/ 4/3/1/1/DI/1/ 1/DE/1/ 1/*.1/ *.AB/1/1
/ 3BC/3/S/Institute for Fiscal Studies*.*.1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/1/0/DNL9
6+2/BDB/1/5/2/AM/1/6/1/1/1/ 1/3/1/2/6J/S/Election/candidate blackmail8/DQ/1/ 1/*
.1/ *.13T/1/H/Leslie Cree (UUP)16J/2/O/Lady Sylvia Hermon (UUP)29T/2/B/Cree's Wi
fe*.*.1/ 4/4/29T/3/13T/13T/3/16J/4/4/0/0/DNL96+2/BDC/1/5/2/K0/1/J/3/3/1/ 4/3/1/2
/A6/1/ 9/EA/1/ 1/*.1/ *.71/1/1/ 3K/3/1/ H5/1/1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/2/0/D
NL96+2/BDD/1/5/2/J5/1/5/1/1/1/ 8/2/2/2/A6/1/ 9/EA/1/ 1/*.1/ *.3L/3/1/ 71/1/1/ H5
/1/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/1/DNL96+2/BDE/1/5/2/GP/1/6/1/2/1/ 1/3/1/1/3H/
1/ 39/*.1/ *.*.1/ *.E5/1/1/ 29T/2/S/Maria Fernandes - Vaz'z wife6J/3/13/Standard
s & Privelidges Committee*.*.1/ 4/4/6J/1/29T/6J/2/E5/1/1/0/0/DNL96+2/BDF/1/5/2/F
O/1/6/4/1/1/ 1/2/1/1/DB/1/ 1/6J/1H/Rush to get legislation through before electi
on39/*.1/ *.AD/1/1/ 3D9/3/L/Patient's AssociationH0/1/1/ *.*.1/ 4/4/3D9/2/AD/H0/
1/AD/4/4/1/0/DNL96+2/BDG/1/5/2/GB/1/7/1/2/1/ 3/3/1/1/3L/1/ 4/3N/1/ 4/*.1/ *.3M/3
/1/ RE/1/K/Norman Baker (Lewes)3L/3/1/ 3M/3/1/ 4/4/*.*.*.*.*.*.4/4/1/1/DNL96+2/B
DH/1/5/2/DS/1/1/4/1/1/ 1/3/1/1/3T/1/ 4/3T/H/Offering peerages4/*.1/ *.GI/1/10/Ma
rk Fisher (MP Stoke Central)70/1/1/ GJ/1/J/Gerry Berringham MP48/3/1/ 4/1/GI/1/4
8/GJ/1/48/4/1/0/0/DNL96+2/BDI/1/5/2/2C7/1/4/1/1/1/ 1/3/1/1/A6/1/ 9/EA/1/ 1/A2/1/
 8/3L/3/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.3/0/DNL96+2/BDJ/1/5/2/M6/1/5
/1/1/1/ 1/2/1/1/A6/1/ 9/DE/1/ 1/A8/L/Claims/counter claims8/71/1/1/ 3L/3/1/ 3K/3
/1/ AB/1/1/ 4/4/AB/1/3L/3L/1/AB/1/1/2/0/DNL96+2/BDN/1/5/2/19S/1/H/1/2/1/ 5/3/1/1
/DE/1/ 1/EB/1/ 1/6J/1K/Labour must persuade electorate that tax must rise39/3K/3
/1/ 3L/3/1/ *.*.1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/2/0/DNL96+2/BDO/1/5/2/117/1/H/1/1/
1/ 5/3/1/1/6J/15/How politicians persuade electorate39/A1/1/ 8/6J/A/Vote share39
/3K/3/1/ 10M/2/1/ 70/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNL96+2/BDP/1/5/2/TL/1/
1/1/1/1/ 1/2/1/1/A5/1/ 9/DE/1/ 1/EA/1/ 1/3K/3/1/ 70/1/1/ D9/3/D/Senior Labour*.*
.1/ 4/4/*.*.*.*.*.*.4/4/3/0/DNLIO+2/BGL/1/1/2/GG/1/A/1/1/1/ 1/3/1/2/DF/1/ 1/6J/1
F/Some Tories say they will never vote for euro8/*.1/ *.71/1/1/ N8/3/E/Several T
ories3AQ/1/J/University Lecturer*.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNLIO+2/BGM/1/1/2
/72/1/E/5/1/R/jamie wilson - shop steward39/3/1/2/6S/1/ 39/EA/1/ 1/*.1/ *.3K/3/1
/ 71/1/1/ AB/1/1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/1/0/DNLIO+2/BGN/1/1/2/F1/1/C/1/1/1/
 1/2/1/2/A7/1/ 9/DB/1/ 1/EA/1/ 1/72/1/1/ 3M/3/1/ 70/1/1/ *.*.1/ 4/4/72/1/70/*.*.
*.4/4/2/0/DNLIO+2/BGT/1/1/2/104/1/1/1/1/1/ 1/3/1/1/3T/1/ 4/A9/1/ 8/*.1/ *.E6/1/1
/ 48/3/1/ KT/3/1/ GJ/3/D/Party Members2/1/GJ/2/E6/*.*.*.2/1/0/0/DNLIO+2/BH1/1/1/
2/T0/1/E/2/1/1/ 5/3/1/1/A2/1A/Labour concentrating on the wrong issues8/A3/S/Lab
our promises same as 19978/DJ/1/ 1/70/1/1/ 3K/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*
.1/1/2/0/DNLIO+2/BH3/1/1/2/242/1/E/3/3/1/ 39/3/1/1/6T/14/Description of voter pa
nel members39/6S/1/ 39/*.1/ *.3B6/3/D/Panel Members3K/3/1/ 3L/3/1/ 3M/3/1/ 0/0/3
D9/2/3K/3D9/2/3L/4/2/1/0/DNLIO+2/BH6/1/1/2/RE/1/K/1/1/1/ 5/3/1/1/6J/S/Quality of
 campaign speeches39/DE/1/ 1/DO/1/ 1/3K/3/1/ 3L/3/1/ AB/1/1/ H5/1/1/ 2/1/*.*.*.*
.*.*.2/1/2/0/DNLIO+2/BH8/1/1/2/FS/1/C/1/1/1/ 1/2/1/2/DD/1/ 1/A2/1/ 8/*.1/ *.AH/1
/1/ 3AN/1/1G/Fred Broughton (chairman of police federation)H6/2/1/ 42/3/1/ 4/4/3
AN/2/42/*.*.*.4/4/1/0/DNLM+3/BK2/1/2/2/RK/1/1/1/1/1/ 1/3/1/2/DE/1/ 1/3H/1/ 39/A9
/1/ 8/3K/3/1/ 71/1/1/ KK/1/1/ H5/1/1/ 4/1/3K/1/71/*.*.*.4/1/1/0/DNLM+3/BK3/1/2/2
/EP/1/H/1/1/1/ 2/3/1/2/3C/1/ 4/4A/1/ 4/41/1/ 4/3L/3/1/ 3B6/3/1/ KS/3/1/ N9/1/G/M
ichael Ashcroft4/4/*.*.*.*.*.*.4/4/0/0/DNLM+3/BK4/1/2/2/87/1/H/3/3/1/ 2/3/1/2/6Q
/R/Analysis of types of voters7/3C/1/ 4/*.1/ *.3B6/3/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/
4/*.*.*.*.*.*.4/4/0/0/DNLM+3/BK6/1/2/2/K3/1/N/3/3/1/ 4/3/1/1/6J/M/Public trust i
n Labour8/EH/1/ 1/*.1/ *.3K/3/1/ 70/1/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/1/0/D
NLM+3/BKD/1/2/2/1G3/1/F/5/1/B/vikram dodd1/2/1/1/3B/1/ 3/DD/1/ 1/DO/1/ 1/AH/1/1/
 3AN/3/1/ N8/1/B/John Cotton3D9/3/F/Asian Community2/4/3AN/3/AH/3D9/2/AH/2/4/1/1
/DNLM+3/BKE/1/2/2/GO/1/G/1/2/1/ 1/3/1/1/GJ/1B/New Department of the Working Age 
planned1/GJ/E/Women's issues1/*.1/ *.3K/3/1/ DK/2/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*
.*.4/4/2/0/DNLM+3/BKF/1/2/2/N3/1/G/5/1/C/owen bowcott1/2/1/1/3B/1/ 3/6J/I/Party 
infiltration39/*.1/ *.10B/1/1/ L4/1/1/ 3D9/3/P/Peniel Pentecostal Church*.*.1/ 4
/4/10B/1/3D9/N8/1/10B/4/4/0/0/DNLM+3/BKG/1/2/2/DF/1/G/4/2/1/ 2/3/1/1/AA/1/ 8/DQ/
1/ 1/D9/D/DUP manifesto9/40/3/1/ 13T/3/K/Peter Robinson (DUP)13P/1/1/ 77/1/1/ 4/
4/13T/1/77/*.*.*.4/4/2/0/DNLM+3/BKL/1/2/2/1DO/1/J/1/2/1/ 6/3/1/1/A1/1/ 8/43/1/ 4
/A2/1/ 8/72/1/1/ 70/1/1/ 71/1/1/ *.*.1/ 3/4/72/2/70/72/1/71/4/3/1/2/DNLM+3/BKN/1
/2/2/198/1/L/2/1/1/ 5/3/1/1/GJ/F/Corporate Power1/DL/1/ 1/E1/1/ 1/AB/1/1/ 3AC/3/
1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNLM+3/BKQ/1/2/2/BG/1/I/39/1/C/russell 
sage39/3/1/1/9T/L/Why author won't vote39/3K/1/ 2/A3/1/ 8/3K/3/1/ 3M/3/1/ 3L/3/1
/ *.*.1/ 1/2/*.*.*.*.*.*.1/2/1/0/DNLP6+2/BND/1/3/2/DD/1/G/4/1/1/ 1/2/1/2/A7/1/ 9
/*.1/ *.*.1/ *.3M/3/1/ 72/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNLP6+2/BNG
/1/3/2/CF/1/1/4/1/1/ 1/3/1/1/6L/1/ 6/DE/1/ 1/*.1/ *.3K/3/1/ 3L/3/1/ 70/1/1/ 71/1
/1/ 2/2/*.*.*.*.*.*.2/2/0/0/DNLP6+2/BNH/1/3/2/9R/1/1/1/1/1/ 1/2/1/1/3B/1/ 3/3E/1
/ 2/*.1/ *.70/1/1/ 3B6/3/1/ 3D9/3/J/Unspecified Critics*.*.1/ 1/4/3D9/1/70/*.*.*
.1/4/0/0/DNLP6+2/BNJ/1/3/2/12H/1/1/1/1/1/ 2/3/1/1/E7/1/ 1/DB/1/ 1/E1/1/ 1/3BC/1/
11/Martin Taylor (IPPR) think tank3D9/3/I/The Private Sector70/1/1/ 3K/3/1/ 4/4/
*.*.*.*.*.*.4/4/3/0/DNLP6+2/BNK/1/3/2/KD/1/D/1/1/1/ 1/2/1/1/4E/1/ 4/DD/10/Prison
ers early release scheme1/3F/1/ 2/3L/3/1/ 3D9/2/16/Juliet Lyon - Prisoners refor
m trustD9/1/C/Paul Boateng*.*.1/ 1/4/3D9/1/3L/D9/1/3L/1/4/1/0/DNLP6+2/BNL/1/3/2/
D3/1/D/4/1/1/ 2/3/1/1/DD/10/Prisoners early release scheme1/3F/1/ 2/*.1/ *.3K/3/
1/ 3L/3/1/ 3AP/3/1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/1/0/DNLP6+2/BNN/1/3/2/LI/1/D/4/1/
1/ 1/3/1/2/3H/1/ 39/*.1/ *.*.1/ *.3BC/3/S/Institute for Fiscal StudiesH5/1/1/ DO
/1/1/ NP/1/1/ 4/4/*.*.*.*.*.*.4/1/1/0/DNLP6+2/BNO/1/3/2/JM/1/E/1/1/1/ 8/2/2/2/A7
/1/ 9/3B/1/ 3/*.1/ *.72/1/1/ 3M/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/1/DNLP6
+2/BNP/1/3/2/MJ/1/E/4/1/1/ 1/3/1/1/6L/1/ 6/DE/1/ 1/D9/N/Popularity of 3 leaders8
/71/1/1/ 3K/3/1/ 3L/3/1/ 70/1/1/ 4/4/*.*.*.*.*.*.2/2/1/1/DNLP6+2/BNR/1/3/2/18E/1
/F/2/1/1/ 2/3/1/1/73/1/ 39/3B/1/ 3/A1/1/ 8/N8/1/P/Shailesh Vara (Kettering)GI/3/
1/ *.*.1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/0/1/DNLP6+2/BNS/1/3/2/QM/1/G/1/2/1/ 1/2/1/1
/A7/1/ 9/EA/1/ 1/A2/1/ 8/3M/3/1/ 72/1/1/ 3L/3/1/ 3K/3/1/ 3/4/3L/1/3M/3K/1/3M/3/4
/2/0/DNLP6+2/BNT/1/3/2/KD/1/H/1/1/1/ 1/2/1/2/A5/1/ 9/EA/1/ 1/*.1/ *.70/1/1/ AB/1
/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNLP6+2/BO1/1/3/2/SC/1/I/1/1/1/ 2/3/1/
1/E7/1/ 1/6J/D/Leaked report39/E1/1/ 1/3BC/3/15/Institute of Public Policy Resea
rch70/1/1/ 3K/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNLP6+2/BO3/1/3/2/GK/1/I/4/1/1
/ 5/3/1/1/DJ/10/Renationalisation of railtrack1/DJ/1/ 1/*.1/ *.3D9/3/9/Railtrack
3K/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNLP6+2/BO6/1/3/2/12B/1/K/5/1/D/St
uart Millar1/2/1/2/3B/1/ 3/*.1/ *.*.1/ *.70/1/1/ 72/1/1/ 71/1/1/ *.*.1/ 2/2/*.*.
*.*.*.*.2/2/0/0/DNLP6+2/BO8/1/3/2/QG/1/L/1/1/1/ 5/3/1/2/6J/18/Is Labour leaning 
too far to the right8/A1/1/ 8/*.1/ *.3K/3/1/ 3L/3/1/ 70/1/1/ AB/1/1/ 2/1/*.*.*.*
.*.*.2/1/1/0/DNLP6+2/BO9/1/3/2/TA/1/L/39/2/A/al kennedy5/3/2/1/D9/1B/Characteris
tics of politicians in general8/*.1/ *.*.1/ *.46/3/1/ 3L/3/1/ 3K/3/1/ *.*.1/ 1/1
/*.*.*.*.*.*.1/1/0/1/DNLP6+2/BOA/1/3/2/BT/1/J/1/1/1/ 1/3/1/1/6J/T/Comments by Le
ader's families39/DH/1/ 1/*.1/ *.273/1/1/ 70/1/1/ 277/1/1/ 71/1/1/ 4/4/273/1/70/
277/1/71/4/4/1/0/DNLP6+2/BOB/1/3/2/AN/1/I/39/1/1/ 39/3/1/1/6S/1/ 39/DP/1/ 1/*.1/
 *.3K/3/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.1/0/DNLP6+2/BOC/1/3/2/1FJ/1/
G/1/2/1/ 1/2/1/1/A7/1/ 9/EA/1/ 1/*.1/ *.72/1/1/ 3M/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.
*.*.*.4/4/3/0/DNLSC+2/BQL/1/4/2/C8/1/J/1/2/1/ 1/2/1/2/D9/14/Socialist Alliance p
arty manifesto9/*.1/ *.*.1/ *.6H/3/I/Socialist Alliance10J/1/1/ 70/1/1/ 3AE/3/J/
Various Celebrities4/4/10J/1/70/3AE/3/6H/4/4/1/0/DNLSC+2/BQM/1/4/2/PL/1/E/1/1/1/
 1/3/1/2/3H/1/ 39/DE/1/ 1/*.1/ *.KK/1/1/ 71/1/1/ 3K/3/1/ 3L/3/1/ 4/4/3K/1/71/3K/
1/3L/1/1/1/0/DNLSC+2/BQO/1/4/2/KK/1/J/1/1/1/ 1/3/1/2/DF/1/ 1/A9/1/ 8/*.1/ *.71/1
/1/ L3/1/1/ N9/1/A/Ian Taylor*.*.1/ 4/4/L3/1/71/*.*.*.1/4/1/0/DNLSC+2/BQR/1/4/2/
I9/1/1/4/1/1/ 1/3/1/1/DD/1/ 1/6J/D/Leaked report39/*.1/ *.3K/3/1/ AH/1/1/ AA/1/1
/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNLSC+2/BQS/1/4/2/G7/1/D/5/1/B/john carvel1/3/1
/1/DB/1/ 1/E7/1/ 1/A2/1/ 8/3K/3/1/ 70/1/1/ 3D9/3/15/Independent Health Care Asso
ciation3B3/3/1/ 4/4/3D9/1/3K/3B3/1/3K/1/1/1/0/DNLSC+2/BQT/1/4/2/NP/1/1/1/1/1/ 1/
2/1/1/3H/1/ 39/*.1/ *.*.1/ *.AE/1/1/ 3AN/3/1/ 3B9/1/1/ 3AI/3/1/ 4/4/3AI/1/AE/*.*
.*.1/4/0/1/DNLSC+2/BR0/1/4/2/5M/1/D/1/1/1/ 1/2/1/1/3P/1/ 3/DB/1/ 1/3E/1/ 2/70/1/
1/ 3AK/2/D/Sharon Storer*.*.1/ *.*.1/ 4/4/3AK/1/70/*.*.*.1/4/1/0/DNLSC+2/BR1/1/4
/2/MB/1/D/1/1/1/ 1/2/1/1/A5/1/ 9/E7/1/ 1/E1/1/ 1/70/1/1/ 72/1/1/ 3B3/3/K/Public 
Sector Unions*.*.1/ 4/4/72/1/70/3B3/1/70/2/2/2/0/DNLSC+2/BR3/1/4/2/EH/1/E/1/2/1/
 1/2/1/1/DD/1/ 1/3C/1/ 4/A2/1/ 8/71/1/1/ 3K/3/1/ 3L/3/1/ H6/2/1/ 4/4/71/1/3K/*.*
.*.4/4/2/1/DNLSC+2/BR4/1/4/2/9B/1/E/1/1/1/ 5/3/1/1/DD/1/ 1/*.1/ *.*.1/ *.3AN/3/1
/ 3L/3/1/ 3K/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNLSC+2/BR5/1/4/2/1AF/1/F/2/1/1
/ 5/3/1/1/A1/1/ 8/3B/1/ 3/3C/1/ 4/71/1/1/ 3L/3/1/ 3B6/3/1/ *.*.1/ 2/1/3B6/1/71/*
.*.*.2/1/0/1/DNLSC+2/BR6/1/4/2/1IN/1/G/1/1/1/ 1/3/1/1/A5/1/ 9/EA/1/ 1/*.1/ *.3K/
3/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.3/0/DNLSC+2/BR8/1/4/2/JS/1/H/1/1/1
/ 8/2/2/1/3B/1/ 3/3E/1/ 2/6J/M/Blair-centred campaign2/70/1/1/ 43/3/1/ *.*.1/ *.
*.1/ 1/4/*.*.*.*.*.*.1/4/1/1/DNLSC+2/BR9/1/4/2/LC/1/H/4/1/1/ 1/3/1/2/A5/1/ 9/DI/
1/ 1/EA/1/ 1/3K/3/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.3/0/DNLSC+2/BRA/1/
4/2/AH/1/H/1/1/1/ 1/2/1/1/3C/1/ 4/9T/1G/Media asked to field 'soft' questions to
 Blair39/*.1/ *.70/1/1/ E8/3/C/Spin Doctors3AM/3/1/ DO/1/1/ 4/4/*.*.*.*.*.*.4/1/
0/0/DNLSC+2/BRB/1/4/2/SQ/1/I/2/1/1/ 1/3/1/2/6J/F/Blair vs Labour8/A5/1/ 9/E1/1/ 
1/70/1/1/ AB/1/1/ 3K/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.2/4/1/0/DNLSC+2/BRD/1/4/2/AB/1/
I/39/1/F/celebrity voter39/3/1/1/6S/1/ 39/EA/1/ 1/*.1/ *.3M/3/1/ 3L/3/1/ 3K/3/1/
 *.*.1/ 3/2/*.*.*.*.*.*.3/2/1/0/DNLSC+2/BRF/1/4/2/PH/1/J/5/2/C/Kirsty scott2/2/1
/2/6J/L/The threat of the SSP39/6L/1/ 6/*.1/ *.6H/3/O/Scottish Socialist Party9T
/1/K/Tommy Sheridan (SSP)3K/3/1/ *.*.1/ 3/3/9T/1/3K/*.*.*.3/3/1/0/DNLSC+2/BRG/1/
4/2/FT/1/J/5/3/E/jeevan vasager1/3/1/1/6J/1C/Lib Dems back Independent in Kidder
minster8/DB/1/ 1/*.1/ *.GI/1/A/David Lock3M/3/1/ 10L/1/1/ *.*.1/ 4/4/GI/1/3M/3M/
3/10L/4/4/1/0/DNLSC+2/BRH/1/4/2/TK/1/K/4/1/1/ 1/2/2/1/3B/1/ 3/6Q/1/ 7/3E/1/ 2/70
/1/1/ 3L/3/1/ 6H/3/I/Socialist Alliance6H/3/G/Socialist Labour2/2/*.*.*.*.*.*.2/
2/0/0/DNLSC+2/BRI/1/4/2/1BO/1/L/4/2/1/ 5/3/1/1/E7/1/ 1/DJ/1/ 1/GJ/G/Public utili
ties1/3D9/3/9/Railtrack3D9/3/7/Transco*.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/2/0/DNLS
C+2/BRJ/1/4/2/RT/1/M/2/1/1/ 5/3/1/2/A5/1/ 9/A1/1/ 8/E1/1/ 1/70/1/1/ *.*.1/ *.*.1
/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.2/0/DNLSC+2/BRK/1/4/2/NB/1/N/3/3/1/ 4/3/1/2/A5/1/ 9
/E1/1/ 1/DF/1/ 1/70/1/1/ 3K/3/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/2/0/DNM1I+2/C
04/1/5/2/10L/1/H/1/2/1/ 1/3/1/2/44/1/ 3/3C/1A/How Millbank dealt with Prescott's
 gaffe4/*.1/ *.AE/1/1/ 48/3/1/ 70/1/1/ GI/3/J/Labour Club Members4/4/70/3/AE/GI/
3/AE/4/4/0/0/DNM1I+2/C08/1/5/2/6S/1/H/5/1/D/steven morris1/3/1/1/6J/16/Handling 
rage (in response to punch)39/*.1/ *.*.1/ *.3AQ/1/R/Anger Management Consultant3
AQ/1/C/PsychologistAE/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNM1I+2/C09/1/5/2/NJ/1
/1/1/1/1/ 1/3/1/1/44/1/ 3/3C/1/ 4/3C/1/ 4/AE/1/1/ 70/1/1/ 3B6/3/1/ 3B9/1/1/ 4/4/
70/3/AE/3B6/2/AE/2/4/0/1/DNM1I+2/C0B/1/5/2/MS/1/G/1/1/1/ 2/3/1/1/A1/1/ 8/3H/1/ 3
9/*.1/ *.AE/1/1/ *.*.1/ *.*.1/ *.*.1/ 3/*.*.*.*.*.*.*.3/*.0/3/DNM1I+2/C0C/1/5/2/
7J/1/G/5/1/B/vikram dodd1/3/1/1/44/R/Did Prescott break the law?3/3P/1/ 3/*.1/ *
.AE/1/1/ 3AQ/3/A/Solicitors3AN/3/1/ *.*.1/ 4/4/3AN/3/AE/*.*.*.4/4/0/0/DNM1I+2/C0
D/1/5/2/QB/1/H/3/3/1/ 39/3/1/1/6T/1/ 39/44/1/ 3/*.1/ *.AE/1/1/ 3B6/3/D/Panel Mem
bers*.*.1/ *.*.1/ 0/0/3D9/2/AE/*.*.*.2/4/0/1/DNM1I+2/C0E/1/5/2/GF/1/J/5/2/J/ange
lique chrisafis1/3/1/1/3T/1/ 4/A9/12/Labour members resign in protest8/*.1/ *.E6
/1/1/ 140/1/D/Neil ThompsonGJ/2/A/Helen Shaw*.*.1/ 4/4/140/1/E6/GJ/1/E6/1/4/0/0/
DNM1I+2/C0G/1/5/2/DR/1/J/4/2/1/ 1/3/1/1/D9/16/Sinn Fein aim to get Commons offic
es8/DQ/1/ 1/*.1/ *.73/1/1/ 77/1/1/ *.*.1/ *.*.1/ 4/4/77/1/73/*.*.*.4/4/0/0/DNM1I
+2/C0J/1/5/2/SP/1/K/1/1/1/ 2/3/1/2/DD/1/ 1/*.1/ *.*.1/ *.3K/3/1/ 3B3/3/H/Police 
FederationAH/1/1/ *.*.1/ 2/4/3B3/1/AH/*.*.*.2/4/1/0/DNM1I+2/C0O/1/5/2/E4/1/L/4/1
/1/ 6/3/1/1/DQ/1/ 1/A3/1/ 8/*.1/ *.77/1/1/ 3T/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*
.4/4/1/0/DNM1I+2/C0R/1/5/2/C1/1/L/3/3/1/ 1/2/1/1/D9/L/Green Party Manifesto9/DG/
1/ 1/EA/1/ 1/3P/3/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.3/0/DNM1I+2/C0T/1/
5/2/S4/1/Q/2/1/1/ 5/3/1/1/6J/Q/Question & answer sessions39/A1/1/ 8/3P/1/ 3/70/1
/1/ 3B6/3/1/ *.*.1/ *.*.1/ 3/4/3B6/2/70/*.*.*.3/4/0/1/DNM1I+2/C11/1/5/2/K3/1/1/5
/2/C/helen carter3/3/1/1/9T/10/Profile of Craig Evans/heckler39/*.1/ *.*.1/ *.3B
9/1/1/ 3D9/3/L/Craig Evans's Friends*.*.1/ *.*.1/ 4/4/3D9/3/3B9/*.*.*.3/4/0/2/DN
MB6+2/C3E/1/1/2/SE/1/G/2/1/1/ 2/3/1/2/6J/1N/Conflict between Tories and their ad
vertising company8/3C/1/ 4/6Q/1/ 7/71/1/1/ 3D9/3/15/Yellow M (Tories' advertisin
g team)3L/3/1/ *.*.1/ 2/4/3D9/1/71/*.*.*.2/4/1/0/DNMB6+2/C3H/1/1/2/8L/1/E/5/1/1/
 6/3/1/1/3B/1/ 3/3K/1/ 2/3C/1/ 4/GI/1/D/Mike O' Brien*.*.1/ *.*.1/ *.*.1/ 4/*.*.
*.*.*.*.*.4/*.1/0/DNMB6+2/C3J/1/1/2/NQ/1/1/4/1/1/ 1/3/1/1/DO/1/ 1/6L/1/ 6/*.1/ *
.3L/3/1/ 3K/3/1/ 71/1/1/ N8/1/M/Lord Taylor of Warwick4/4/N8/1/71/*.*.*.1/4/1/0/
DNMB6+2/C3K/1/1/2/1DI/1/B/2/1/1/ 3/3/2/1/A1/1/ 8/3B/1/ 3/*.1/ *.DS/1/1/ N8/1/Q/G
us Robertson (Hartlepool)3B6/3/1/ *.*.1/ 2/2/3B6/2/DS/*.*.*.2/2/0/2/DNMB6+2/C3L/
1/1/2/K1/1/B/5/2/C/sophie lomax1/3/1/1/DB/1/ 1/E7/1/ 1/*.1/ *.3AQ/3/E/Birmingham
 GPs42/3/1/ 3AK/2/E/Sharron Storer3B3/2/N/Christine Hancock - RCN4/4/3AQ/1/42/3B
3/1/42/4/1/1/0/DNMB6+2/C3M/1/1/2/L0/1/C/1/1/1/ 8/2/2/1/A1/1/ 8/3B/1/ 3/*.1/ *.GI
/1/T/Bob Marshall-Andrews (Medway)3B6/1/1/ *.*.1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/1/3
/DNMB6+2/C3R/1/1/2/AC/1/F/1/1/1/ 1/3/1/1/AF/1/ 39/AF/1/ 39/*.1/ *.GI/1/C/Frank D
obson70/1/1/ AB/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNMB6+2/C3S/1/1/2/94/1/F/1/1
/1/ 1/3/1/2/EE/1/ 1/*.1/ *.*.1/ *.3N/3/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.
4/4/0/1/DNMB6+2/C40/1/1/1/14H/1/H/4/2/1/ 2/3/1/1/DQ/1/ 1/3B/1/ 3/6J/17/SDLP/Sinn
 Fein Contest in West Tyrone8/3S/3/1/ 41/3/1/ 13T/2/C/Brid Rodgers73/1/1/ 4/4/*.
*.*.*.*.*.4/4/1/1/DNMB6+2/C43/1/1/2/S5/1/J/1/1/1/ 5/3/1/1/6Q/1/ 7/*.1/ *.*.1/ *.
3BA/3/1/ 3AL/1/G/BBC Interviewers70/1/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNMB6+2/
C44/1/1/2/QN/1/K/1/1/1/ 5/3/2/1/A1/1/ 8/3B/1/ 3/*.1/ *.10F/1/1/ N9/2/1/ 3K/3/1/ 
3L/3/1/ 2/4/*.*.*.*.*.*.2/4/0/0/DNMEC+2/C6L/1/2/2/RF/1/I/5/1/B/Mark Milner1/3/1/
2/6S/1/ 39/3C/1/ 4/*.1/ *.3AB/3/1/ 3L/3/1/ 3K/3/1/ *.*.1/ 4/4/3AB/3/3K/3AB/3/3L/
4/2/1/0/DNMEC+2/C6O/1/2/2/AG/1/G/1/1/1/ 1/3/1/2/GJ/8/Red tape1/*.1/ *.*.1/ *.3AB
/3/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNMEC+2/C6P/1/2/2/PB/1/L/39
/1/E/Richard Taylor5/3/1/1/DB/1/ 1/6J/1F/Independent MP opposed to Kidderministe
r cuts8/E7/1/ 1/42/3/1/ GI/1/C/Frank Dobson3D9/3/O/People of Kidderminister*.*.1
/ 1/1/*.*.*.*.*.*.1/1/1/0/DNMEC+2/C6R/1/2/2/FH/1/E/5/1/C/jamie wilson1/2/1/1/GJ/
8/New Deal1/3P/1/ 3/*.1/ *.3B6/2/D/Single Mother70/1/1/ *.*.1/ *.*.1/ 4/4/3B6/2/
70/*.*.*.3/2/1/0/DNMEC+2/C6S/1/2/2/SG/1/1/1/1/1/ 1/3/1/1/6Q/1/ 7/*.1/ *.*.1/ *.E
1/2/1/ 3AM/3/1/ 3K/3/1/ KB/1/1/ 4/4/3K/1/3AM/KB/1/3K/4/4/0/0/DNMEC+2/C6T/1/2/2/N
3/1/1/1/1/1/ 1/2/1/1/DG/1/ 1/A2/1/ 8/*.1/ *.71/1/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/4/71
/1/3K/*.*.*.4/4/1/0/DNMEC+2/C71/1/2/2/L0/1/D/1/1/1/ 8/3/2/1/9T/L/Looking for Kei
th Vaz39/*.1/ *.*.1/ *.E5/1/1/ E8/3/1/ *.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/0/0/DNM
EC+2/C73/1/2/2/12P/1/F/4/1/D/stephen bates1/2/1/1/3B/1/ 3/A1/1/ 8/A2/1/ 8/72/1/1
/ 3M/3/1/ 3B6/3/1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/0/1/DNMEC+2/C74/3/2/2/N2/1/G/1/2/1
/ 1/3/1/1/DT/1/ 1/DE/1/ 1/*.1/ *.71/1/1/ DP/1/1/ 3L/3/1/ 3K/3/1/ 4/4/71/1/3K/DP/
1/3L/4/4/2/1/DNMEC+2/C75/1/2/2/125/1/H/5/2/J/angelique chrisafis2/3/1/1/6J/H/Fir
st-time voters5/3K/1/ 2/3J/1/ 2/3D9/3/8/Students3L/3/1/ 3K/3/1/ 3M/3/1/ 4/4/3D9/
2/3L/3D9/2/3K/4/4/0/0/DNMEC+2/C77/1/2/2/FC/1/I/39/1/R/rowan williams (archbishop
)3/1/1/1/6J/E/Floating voter5/EA/1/ 1/*.1/ *.6J/3/I/Parties in General*.*.1/ *.*
.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.1/0/DNMEC+2/C79/1/2/2/1N1/1/J/1/1/1/ 6/3/1/1/A1/1
/ 8/A2/1/ 8/D9/N/Disprove his stereotype39/71/1/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.
*.*.*.*.2/*.1/2/DNMEC+2/C7C/1/2/2/SB/1/L/39/2/F/minnette marrin5/3/1/1/DR/1/ 1/D
O/1/ 1/*.1/ *.GJ/3/8/The LeftN9/3/9/The Right*.*.1/ *.*.1/ 1/3/*.*.*.*.*.*.1/3/1
/0/DNMEC+2/C7D/1/2/2/JQ/1/N/3/3/1/ 4/3/1/1/A2/1/ 8/E7/1/ 1/E1/1/ 1/70/1/1/ 3K/3/
1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNMHI+2/CA1/1/3/2/196/1/L/2/1/1/ 2/3/1/
2/6J/2I/Questioning why Martin Bell is standing as independent for Brentwood and
 Ongar8/A1/1/ 8/*.1/ *.10B/1/1/ L4/1/1/ 3D9/3/P/Penial Pentecostal Church*.*.1/ 
2/2/*.*.*.*.*.*.2/2/0/0/DNMHI+2/CA3/1/3/2/QI/1/1/1/1/1/ 1/4/1/1/DF/1/ 1/3C/1/ 4/
6J/17/Labour wants to delay Jospin's speech39/3K/3/1/ 3AG/1/D/Lionel Jospin3L/3/
1/ 70/1/1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNMHI+2/CA4/1/3/2/FF/1/1/1/1/1/ 1/2/1/1/DG/1/
 1/A9/1/ 8/*.1/ *.10M/2/1/ 71/1/1/ N8/3/J/Pro-European ToriesAE/1/1/ 4/4/N8/1/10
M/AE/1/71/4/4/1/0/DNMHI+2/CA5/1/3/2/89/1/J/4/2/1/ 1/2/1/1/AA/1/ 8/DQ/1/ 1/EA/1/ 
1/3S/3/1/ 13T/1/D/Seamus Mallon74/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNMHI+2/CA
B/1/3/2/9I/1/F/5/2/J/angelique chrisafis1/3/1/1/3T/1/ 4/A9/1J/Lab party members 
leave to stand against Woodward8/*.1/ *.140/1/12/Michael Murphy (ind, St Helen's
)E6/1/1/ 16J/3/K/Left-Wing Candidates*.*.1/ 4/4/140/1/E6/16J/1/E6/4/1/0/0/DNMHI+
2/CAD/1/3/2/GK/1/G/1/2/1/ 1/3/1/1/42/1/ 39/6J/A/Ethnic MPs8/*.1/ *.3D9/3/F/Fawce
tt Society3K/3/1/ 3L/3/1/ 3M/3/1/ 4/4/3D9/1/3K/3D9/1/3L/4/4/0/0/DNMHI+2/CAF/1/3/
2/G9/1/H/4/1/1/ 1/3/1/2/DB/1/ 1/*.1/ *.*.1/ *.70/1/1/ 3B3/3/1B/Delegates of the 
royal college of nursingD9/1/B/John DenhamAD/1/1/ 4/4/3B3/1/70/*.*.*.1/4/1/3/DNM
HI+2/CAH/1/3/2/QB/1/K/5/1/C/kirsty scott1/2/1/1/EE/1/ 1/GJ/1M/Devolved vs Reserv
ed matters/Holyrood vs Westminster1/*.1/ *.3B6/2/1/ 3K/3/1/ 3N/3/1/ 4B/3/1/ 4/4/
3B6/2/3K/*.*.*.4/4/1/0/DNMHI+2/CAI/1/3/2/J4/1/K/2/1/1/ 1/2/1/1/4E/1/ 4/3F/1/ 2/D
I/1/ 1/3K/3/1/ 3L/3/1/ 3AE/1/9/Ken Loach6H/3/I/Socialist Alliance4/4/3K/1/3L/*.*
.*.4/4/0/1/DNMHI+2/CAJ/1/3/2/CS/1/K/39/2/1/ 39/3/1/1/GJ/9/Childcare1/6J/O/Labour
's broken promises8/6S/1/ 39/70/1/1/ 3L/3/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/1
/0/DNMHI+2/CAL/1/3/2/QA/1/N/1/1/1/ 5/3/1/1/E7/1/ 1/DB/1/ 1/E1/1/ 1/3K/3/1/ 70/1/
1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNMHI+2/CAM/1/3/2/RT/1/O/2/1/1/ 5/3/1/1
/6J/H/Role of the State39/DE/1/ 1/A9/1/ 8/3L/3/1/ 71/1/1/ H5/1/1/ KK/1/1/ 1/1/*.
*.*.*.*.*.1/1/1/0/DNMKO+2/CDC/1/4/2/N8/1/1/4/1/1/ 1/3/1/2/DE/1/ 1/DF/1/ 1/6L/1/ 
6/71/1/1/ 3AH/1/1/ 3L/3/1/ AB/1/1/ 1/4/3AH/1/3L/*.*.*.1/4/1/0/DNMKO+2/CDD/1/4/2/
53/1/D/3/3/1/ 1/3/1/2/DC/1/ 1/A2/1/ 8/*.1/ *.3K/3/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.
*.*.*.*.*.4/*.3/0/DNMKO+2/CDF/1/4/1/LP/1/E/1/1/1/ 8/3/2/1/9T/T/Trying to find Sh
aun Woodward39/3T/1/ 4/A1/1/ 8/E6/1/1/ 140/1/12/Neil Thompson Socialist Alliance
*.*.1/ *.*.1/ 2/4/140/1/E6/*.*.*.2/4/0/1/DNMKO+2/CDH/1/4/2/K1/1/F/1/2/1/ 1/3/1/1
/A1/1/ 8/3J/1/ 2/*.1/ *.10A/1/1/ 70/1/1/ 72/1/1/ 71/1/1/ 4/4/10A/1/70/10A/3/72/4
/4/0/1/DNMKO+2/CDK/1/4/2/JD/1/D/5/1/D/will woodward1/2/1/1/DC/1/ 1/A2/1/ 8/*.1/ 
*.70/1/1/ 3D9/3/R/Secondary Heads Association*.*.1/ *.*.1/ 4/4/3D9/1/70/*.*.*.2/
4/3/0/DNMKO+2/CDN/1/4/2/194/1/D/2/1/1/ 5/3/1/1/3C/1/ 4/3E/1/ 2/45/1/ 2/70/1/1/ 4
8/3/1/ 3B6/3/1/ *.*.1/ 4/1/3B6/1/70/*.*.*.4/1/0/1/DNMKO+2/CDO/1/4/2/CC/1/G/1/2/1
/ 1/3/1/1/40/1/ 4/D9/F/Broken promises39/*.1/ *.70/1/1/ 3D9/3/A/Charter 883K/3/1
/ 3M/3/1/ 4/4/3D9/1/70/3D9/1/3K/1/4/1/1/DNMKO+2/CDP/1/4/2/J1/1/K/4/1/1/ 1/3/1/1/
E7/1/ 1/DC/1/ 1/*.1/ *.6J/3/L/Surrey County Council3D9/3/1F/Nord Anglia (private
 company managing school)3D9/3/H/Abbeylands School*.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0
/DNMKO+2/CDQ/1/4/2/IR/1/L/5/1/B/john carvel1/3/1/1/6J/15/Unions' decision not to
 back Labour8/DB/1/ 1/E7/1/ 1/3L/3/1/ 3B3/2/N/Christine Hancock (RCN)3D9/3/J/Fir
e Brigades Union*.*.1/ 4/4/3B3/1/3L/3D9/1/3L/4/1/1/0/DNMKO+2/CDR/1/4/2/LT/1/L/1/
1/1/ 1/3/1/1/4B/1/ A/6Q/1/ 7/*.1/ *.3AL/3/M/Undercover Journalists3AM/3/9/Channe
l 43M/3/1/ 3L/3/1/ 4/4/3M/1/3AM/3L/1/3AM/4/4/0/0/DNMKO+2/CDS/1/4/2/S7/1/L/3/3/1/
 39/3/1/1/6T/1/ 39/6J/1J/Margaret Thatcher's intervention in Tory campaign39/DG/
1/ 1/10M/2/1/ 3B6/3/D/Panel Members*.*.1/ *.*.1/ 0/0/3B6/1/10M/*.*.*.1/4/0/1/DNM
KO+2/CE3/1/4/2/13S/1/N/5/1/F/Oliver Burkeman1/2/1/2/A1/1/ 8/3B/1/ 3/*.1/ *.KR/1/
1/ 3B6/1/1/ *.*.1/ *.*.1/ 2/4/3B6/3/KR/*.*.*.2/4/0/0/DNMKO+2/CE6/1/4/2/RH/1/P/1/
1/1/ 5/3/2/1/72/15/Songs to uplift the labour campaign7/45/1/ 2/*.1/ *.3K/3/1/ 7
0/1/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/0/0/DNMKO+2/CE7/1/5/2/Q7/1/P/1/1/1/ 5/3
/1/1/3E/1/ 2/3C/1/ 4/*.1/ *.139/3/M/Previous Party Leaders*.*.1/ *.*.1/ *.*.1/ 3
/*.*.*.*.*.*.*.3/*.0/0/DNMKO+2/CE9/1/4/2/K1/1/R/3/3/1/ 4/3/1/2/6J/L/Labour's ins
ecurities8/3C/1/ 4/*.1/ *.70/1/1/ AB/1/1/ 10A/1/1/ 3K/3/1/ 1/4/10A/1/70/*.*.*.1/
4/0/0/DNMKO+2/CEA/1/4/2/F3/1/1/1/1/1/ 1/4/1/1/E7/1/ 1/E1/1/ 1/3S/1/ A/70/1/1/ 3B
3/3/1/ *.*.1/ *.*.1/ 4/4/3B3/1/70/*.*.*.1/4/2/0/DNMKO+2/CEB/1/4/2/19J/1/Q/2/1/1/
 5/2/1/1/A9/1/ 8/DG/1/ 1/A3/1/ 8/3L/3/1/ 71/1/1/ 10M/2/1/ H5/1/1/ 1/1/*.*.*.*.*.
*.1/1/1/0/DNMO+3/CGL/1/5/2/N8/1/1/1/1/1/ 8/2/1/1/GJ/C/Foot & mouth1/3B/1/ 3/*.1/
 *.DM/1/1/ 3B6/3/1/ 3AI/3/1/ 70/1/1/ 1/4/3B6/1/DM/3AI/1/70/1/4/0/1/DNMO+3/CGM/1/
5/2/FL/1/1/1/1/1/ 1/2/1/1/DG/1/ 1/DF/1/ 1/A9/1/ 8/70/1/1/ H2/1/1/ 71/1/1/ 10M/2/
1/ 4/4/70/1/71/*.*.*.4/4/1/0/DNMO+3/CGN/1/5/2/M1/1/F/1/1/1/ 1/2/1/1/4E/1/ 4/DD/1
/ 1/DC/1/ 1/3L/3/1/ 3B3/1/B/Doug McEvoyAA/1/1/ 3K/3/1/ 4/4/3B3/1/3L/AA/1/3L/4/4/
1/0/DNMO+3/CGO/1/5/2/MB/1/F/1/1/1/ 1/3/1/1/AF/1/ 39/GJ/5/Drugs1/A2/1/ 8/AA/1/1/ 
3D9/1/F/Keith Hellawell3K/3/1/ E7/1/1/ 4/4/3D9/1/3K/E7/1/3K/4/4/1/0/DNMO+3/CGS/1
/5/2/FI/1/G/1/1/1/ 1/3/1/1/DB/1/ 1/E7/1/ 1/*.1/ *.AD/1/1/ 3K/3/1/ 3D9/3/13/Anti-
Privatisation Health Experts3L/3/1/ 4/4/3D9/1/3K/3K/1/3L/4/4/1/0/DNMO+3/CH2/1/5/
2/N1/1/J/1/2/1/ 1/3/1/1/6J/L/Silent women syndrome39/3C/1/ 4/42/1/ 39/AB/1/1/ 6J
/2/K/Women MPs/Candidates3L/3/1/ 3M/3/1/ 4/4/6J/1/AB/6J/1/3L/4/4/0/0/DNMO+3/CH3/
1/5/2/H4/1/J/1/2/1/ 1/3/1/1/3M/1/ 4/6J/13/Local postal strikes cause delays39/*.
1/ *.6J/3/R/Party Political Strategists3D9/3/19/Association of Electoral Adminis
trators*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNMO+3/CHB/1/5/2/QQ/1/M/4/1/1/ 1/2/
1/2/3B/1/ 3/*.1/ *.*.1/ *.70/1/1/ 3M/3/1/ 71/1/1/ H5/1/1/ 2/2/*.*.*.*.*.*.2/2/0/
0/DNMO+3/CHC/1/5/2/189/1/N/1/2/1/ 5/3/1/1/43/1/ 4/3L/1/ 4/*.1/ *.3K/3/1/ 3L/3/1/
 3M/3/1/ 3D9/1/1I/Jason Buckley - tactical voting website designer2/2/*.*.*.*.*.
*.2/2/1/0/DNMO+3/CHE/1/5/2/SC/1/O/2/1/1/ 5/3/1/1/3J/1/ 2/3K/1/ 2/6J/N/Politics l
acks idealism2/70/1/1/ 71/1/1/ 3B6/3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNMO+3/CH
F/1/5/2/K1/1/P/3/3/1/ 4/3/1/1/6J/L/Lack of public debate39/3C/1/ 4/6Q/1/ 7/70/1/
1/ 3AM/3/1/ 46/3/1/ *.*.1/ 1/2/70/1/3AM/*.*.*.1/2/0/0/DNN3I+2/CK1/3/1/2/GD/1/1/1
/2/1/ 1/3/1/1/3N/1/ 4/6L/1/ 6/*.1/ *.72/1/1/ 3M/3/1/ 3K/3/1/ NN/1/1/ 4/4/72/1/3K
/NN/1/3K/4/4/0/0/DNN3I+2/CK4/1/1/2/6N/1/4/4/2/1/ 1/3/1/1/6J/18/Votes not secret/
violates human rights39/*.1/ *.*.1/ *.3D9/1/10/Liberty Director - John Wadham*.*
.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.0/0/DNN3I+2/CK5/1/1/2/153/1/5/2/1/1/ 1/2/2
/2/3B/1/ 3/*.1/ *.*.1/ *.H5/1/1/ 3B6/3/1/ *.*.1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/0/0/
DNN3I+2/CK7/1/1/2/44/1/6/1/2/1/ 1/3/1/2/49/1/ 5/6L/1/ 6/*.1/ *.3B6/3/D/Female Vo
ters3K/3/1/ GI/2/F/Patricia Hewitt*.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNN3I+2/CKA/1/1
/2/84/1/6/1/2/1/ 1/2/1/1/6L/1/ 6/6J/17/Share of vote vs support for policies39/*
.1/ *.3P/3/1/ 13S/1/B/Mike Woodin3AM/3/1/ *.*.1/ 4/4/3P/1/3AM/*.*.*.4/4/1/0/DNN3
I+2/CKC/1/1/2/183/1/D/2/1/1/ 5/3/1/1/DG/1/ 1/DF/1/ 1/*.1/ *.3AL/1/1/ 3L/3/1/ *.*
.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/2/0/DNN3I+2/CKE/1/1/2/R3/1/D/1/1/1/ 5/3/1/1/DG/1/
 1/3C/1/ 4/DF/1/ 1/71/1/1/ 70/1/1/ 3L/3/1/ 3K/3/1/ 1/3/*.*.*.*.*.*.1/3/1/0/DNN3I
+2/CKG/1/1/2/SN/1/E/39/1/J/geoffrey wheatcroft5/3/1/1/6J/O/Religious fundamental
ism39/47/1/ 5/*.1/ *.3D9/3/C/Muslim Lobby3AL/1/11/Faisal Bodi - muslim journalis
t6J/3/F/Pro-Israeli MPs*.*.1/ 1/1/3D9/1/6J/*.*.*.1/1/0/0/DNN6O+2/CND/1/2/2/MJ/1/
1/4/1/1/ 1/4/1/1/DF/1/ 1/*.1/ *.*.1/ *.3B9/1/1/ 70/1/1/ 71/1/1/ *.*.1/ 4/4/70/2/
3B9/71/1/3B9/4/4/1/0/DNN6O+2/CNE/1/2/2/9P/1/G/1/2/1/ 6/3/1/1/E1/1/ 1/DP/1/ 1/*.1
/ *.AF/1/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.1/0/DNN6O+2/CNF/1/2/2/SI/1/
G/2/1/1/ 2/3/1/1/4E/1/ 4/A1/1/ 8/6J/1F/Personality over policies/cult of persona
lity39/70/1/1/ E7/3/1/ 71/1/1/ *.*.1/ 1/1/E7/2/3K/*.*.*.1/1/0/0/DNN6O+2/CNH/1/2/
2/MA/1/B/1/1/1/ 8/2/2/1/3B/1/ 3/*.1/ *.*.1/ *.70/1/1/ E0/2/1/ 270/2/1/ *.*.1/ 2/
4/*.*.*.*.*.*.2/4/0/1/DNN6O+2/CNJ/1/2/1/NE/1/C/1/1/1/ 1/3/1/1/DG/1/ 1/3C/1/ 4/*.
1/ *.3L/3/1/ 3K/3/1/ H2/1/1/ 3AC/3/1F/Chantrey Vellacott - accountancy organisat
ion4/4/H2/1/3K/*.*.*.2/4/1/0/DNN6O+2/CNK/1/2/2/A7/1/C/4/1/1/ 5/3/1/1/DG/1/ 1/*.1
/ *.*.1/ *.70/1/1/ 3L/3/1/ H5/1/1/ 3K/3/1/ 4/4/H5/1/3K/3L/1/70/4/4/1/0/DNN6O+2/C
NL/1/2/2/13G/1/D/5/2/C/kirsty scott2/2/1/1/6L/1/ 6/3B/1/ 3/6J/S/Lib Dems aim to 
be 2nd party8/72/1/1/ RA/3/1/ 3B6/3/1/ 10A/1/1/ 3/4/3B6/3/10A/3B6/2/72/3/4/1/2/D
NN6O+2/CNM/1/2/2/1CO/1/E/5/2/D/audret gillan2/3/1/1/E7/1/ 1/E1/1/ 1/*.1/ *.3K/3/
1/ 3BC/3/15/Institute of Public Policy Research*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4
/2/0/DNN6O+2/CNP/1/2/2/F9/1/F/4/1/1/ 2/3/1/2/DO/1/ 1/E4/1/ 1/*.1/ *.GJ/1/P/Fred 
Chaplin (Sedgefield)70/1/1/ 3D9/3/8/Refugees*.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNN6O
+2/CNQ/1/2/2/C0/1/F/5/2/E/tania branigan1/3/1/1/3C/1/ 4/3O/S/BNP aiming for coun
cil seats39/*.1/ *.3Q/3/1/ 78/1/1/ 3D9/3/P/Anti-Fascist Organisation*.*.1/ 4/4/3
D9/1/3Q/*.*.*.4/4/0/0/DNN6O+2/CNR/1/2/2/HK/1/G/4/1/1/ 5/3/1/2/6Q/1/ 7/*.1/ *.*.1
/ *.3AM/3/H/Sunday Newspapers*.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.0/0/DNN6O+
2/CNT/1/2/2/AI/1/G/39/1/C/ua fanthorpe39/3/1/1/6S/1/ 39/6J/14/No Green candidate
 in constituency8/*.1/ *.3P/3/1/ 3M/3/1/ *.*.1/ *.*.1/ 3/2/*.*.*.*.*.*.3/2/1/0/D
NN6O+2/CO3/1/2/2/QK/1/I/5/1/D/stuart millar1/2/1/1/3B/1/ 3/72/P/Hague/Blair fash
ion sense7/*.1/ *.71/1/1/ 275/2/1/ 70/1/1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/0/2/DNNA+3
/CQL/1/3/2/SN/1/1/4/1/1/ 1/3/1/1/6L/1/ 6/3C/1/ 4/DG/1/ 1/71/1/1/ 3K/3/1/ 70/1/1/
 10I/1/1/ 1/3/70/1/71/10I/3/71/1/3/1/1/DNNA+3/CQM/1/3/2/R9/1/1/1/1/1/ 8/2/2/1/3C
/1/ 4/*.1/ *.*.1/ *.10M/2/1/ 3B6/3/1/ *.*.1/ *.*.1/ 1/4/3B6/2/10M/*.*.*.1/4/0/1/
DNNA+3/CQN/1/3/2/H6/1/D/1/1/1/ 1/2/1/1/3C/1/ 4/A1/1/ 8/A3/1/ 8/70/1/1/ AG/2/1/ 7
1/1/1/ DO/1/1/ 4/4/AG/3/70/AG/1/71/4/4/1/1/DNNA+3/CQR/1/3/2/K5/1/E/1/1/1/ 1/3/1/
1/3C/1/ 4/6O/1/ 6/*.1/ *.71/1/1/ KS/3/1/ *.*.1/ *.*.1/ 4/4/KS/3/71/*.*.*.2/4/0/0
/DNNA+3/CR0/1/3/2/16B/1/F/2/1/1/ 2/2/1/1/73/1/ 39/A1/1/ 8/*.1/ *.N8/1/E/Michael 
HowardRE/1/C/Peter CarollGI/1/F/Albert Caterall*.*.1/ 2/4/*.*.*.*.*.*.2/4/1/1/DN
NA+3/CR1/1/3/2/L5/1/G/1/1/1/ 1/2/1/2/A5/1/ 9/E7/1/ 1/*.1/ *.70/1/1/ 3B3/3/D/Unio
n LeadersAE/1/1/ H5/1/1/ 4/4/3B3/2/70/*.*.*.2/4/1/0/DNNA+3/CR3/1/3/2/7R/1/G/4/1/
1/ 1/3/1/1/DG/1/ 1/6J/O/Campaigning on one issue39/*.1/ *.3AB/1/L/Chris Gent (Vo
dafone)3L/3/1/ *.*.1/ *.*.1/ 4/4/3AB/1/3L/*.*.*.4/1/1/0/DNNA+3/CR5/1/3/2/RQ/1/I/
4/1/B/paul murphy2/3/1/1/AC/1/ 9/ED/1/ 1/*.1/ *.3L/3/1/ 3AB/3/1/ *.*.1/ *.*.1/ 4
/4/*.*.*.*.*.*.4/4/2/0/DNNA+3/CR6/1/3/2/HP/1/I/2/1/1/ 5/3/1/1/6Q/R/Analysis of '
election call'7/A1/1/ 8/*.1/ *.H5/3/1/ 3AM/3/F/'election call'*.*.1/ *.*.1/ 1/3/
*.*.*.*.*.*.1/3/0/0/DNNA+3/CRA/1/3/2/D8/1/J/1/1/1/ 1/2/1/2/EF/1/ 1/*.1/ *.*.1/ *
.139/1/C/Paul Burstow3M/3/1/ 3AS/3/1/ 70/1/1/ 4/4/139/1/70/*.*.*.4/4/1/0/DNNA+3/
CRC/1/3/2/KR/1/J/5/1/D/Stuart Millar1/2/1/1/3B/1/ 3/3H/1/ 39/6O/1/ 6/3L/3/1/ 3M/
3/1/ 3K/3/1/ 3AR/3/1/ 1/4/3L/1/3K/3AR/3/3M/1/4/0/0/DNNA+3/CRD/1/3/2/17C/1/L/2/2/
1/ 5/3/1/2/A1/1/ 8/*.1/ *.*.1/ *.70/1/1/ AG/2/1/ *.*.1/ *.*.1/ 3/4/AG/3/70/*.*.*
.3/4/1/1/DNNA+3/CRF/1/3/2/RG/1/M/2/1/1/ 5/3/1/1/DG/1/ 1/3C/1/ 4/6J/12/Predicting
 outcome of Referendum39/71/1/1/ 70/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/0/D
NND6+2/D01/1/4/2/MH/1/F/1/1/1/ 1/2/1/1/DD/18/Crackdown on attacks on public work
ers1/GJ/N/Skills tests (literacy)1/DB/1/ 1/70/1/1/ 3B6/3/1/ *.*.1/ *.*.1/ 4/4/3B
6/1/70/*.*.*.4/4/2/0/DNND6+2/D03/1/4/2/M5/1/F/1/1/1/ 1/2/1/1/3B/1/ 3/6L/1/ 6/6M/
1/ 6/71/1/1/ 3K/3/1/ N9/3/G/Party Supporters*.*.1/ 1/4/N9/1/71/71/1/3K/1/4/0/1/D
NND6+2/D07/1/4/2/AM/1/G/1/1/1/ 1/2/1/2/DK/1/ 1/*.1/ *.*.1/ *.AB/1/1/ AE/1/1/ *.*
.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNND6+2/D08/1/4/2/1B8/1/H/4/1/1/ 2/2/1/1/3B/1
/ 3/A1/1/ 8/*.1/ *.71/1/1/ 3B6/3/1/ 10I/1/1/ *.*.1/ 2/4/3B6/1/71/3B6/3/10I/2/4/0
/2/DNND6+2/D0A/1/4/2/TM/1/I/4/2/1/ 1/3/1/1/GJ/14/Drug costs in the developing wo
rld1/GJ/14/Contribution to global health fund1/48/1/ 5/AB/1/1/ 3B7/1/D/Kofi Anna
n/UN3D9/3/E/Drug Companies*.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNND6+2/D0B/1/4/2/14G/1
/J/1/2/1/ 1/2/1/2/3B/1/ 3/D9/N/Green Party's manifesto9/DB/1/ 1/3P/3/1/ 3B6/2/1/
 N9/3/1/ *.*.1/ 2/4/3B6/1/3P/N9/3/3P/2/4/2/0/DNND6+2/D0D/1/4/2/JC/1/J/1/1/1/ 1/2
/1/1/46/1/ 5/DH/1/ 1/EF/1/ 1/3M/3/1/ 3L/3/1/ 3K/3/1/ KR/1/1/ 4/4/KR/1/3K/*.*.*.4
/4/2/0/DNND6+2/D0N/1/4/2/RP/1/O/2/1/1/ 5/3/1/1/3C/1/ 4/6J/N/Ideology vs Personal
ity39/A1/1/ 8/70/1/1/ 71/1/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNNGC+2/D3B/
1/5/2/SK/1/1/1/1/1/ 1/3/1/1/A9/1/ 8/DF/1/ 1/3R/1/ 2/139/1/C/Chris PattenN8/3/J/P
ro-European Tories3L/3/1/ 71/1/1/ 4/4/139/1/71/N8/1/3L/4/4/0/0/DNNGC+2/D3C/1/5/2
/HI/1/1/4/1/1/ 1/2/1/1/3C/1/ 4/E1/1/ 1/4A/1/ 4/AB/1/1/ 3L/3/1/ 3K/3/1/ *.*.1/ 4/
4/AB/1/3L/*.*.*.4/4/1/0/DNNGC+2/D3D/1/5/2/8O/1/F/1/2/1/ 1/2/1/1/3C/1/ 4/DC/1/ 1/
DB/1/ 1/70/1/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNNGC+2/D3E/1/5/2
/LK/1/F/4/1/1/ 1/3/1/1/DB/1/ 1/6J/H/Mutiny by doctors39/*.1/ *.3D9/3/3/BMA3AQ/3/
7/Doctors3K/3/1/ 70/1/1/ 4/4/3D9/1/3K/3AQ/1/3K/4/4/2/0/DNNGC+2/D3J/1/5/2/AC/1/G/
1/1/1/ 1/3/1/2/6J/14/Row over special advisor contracts39/*.1/ *.*.1/ *.E8/3/G/S
pecial Advisors49/3/1/ 3K/3/1/ N8/1/C/Andrew Tyrie4/4/49/1/3K/*.*.*.1/4/0/0/DNNG
C+2/D3M/1/5/2/BE/1/I/4/1/1/ 2/3/1/1/49/1/ 5/3K/1/ 2/48/1/ 5/3K/3/1/ 3B6/2/C/Wome
n Voters6J/3/Q/Conservatives and Lib Dems*.*.1/ 4/4/3B6/1/3K/3B6/1/6J/4/4/0/0/DN
NGC+2/D3O/1/5/2/AL/1/I/1/2/1/ 1/2/1/2/E2/1/ 1/*.1/ *.*.1/ *.AE/1/1/ KR/1/1/ 3K/3
/1/ 3L/3/1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNNGC+2/D3P/1/5/2/12D/1/J/2/1/1/ 2/3/1/1/73/
1/ 39/3B/1/ 3/4A/1/ 4/GI/1/R/Kevin Hopkins (Luton North)GI/2/S/Margaret Moran - 
Luton South3B6/3/1/ 42/3/1/ 3/3/3B6/1/42/*.*.*.3/3/1/0/DNNGC+2/D3R/1/5/2/70/1/J/
1/1/1/ 1/2/1/2/4E/1/ 4/*.1/ *.*.1/ *.3K/3/1/ DO/1/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*
.*.4/4/0/0/DNNGC+2/D3S/1/5/2/S2/1/K/4/2/1/ 2/3/1/1/DQ/1/ 1/A8/1/ 8/*.1/ *.77/1/1
/ 13P/1/1/ 3T/3/1/ 40/3/1/ 4/4/3T/1/40/40/1/3T/4/4/1/0/DNNGC+2/D3T/1/5/2/RA/1/K/
2/1/1/ 5/3/1/1/6Q/1/ 7/9T/Q/Leader's performance on TV39/A1/1/ 8/70/1/1/ 71/1/1/
 *.*.1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/0/1/DNNGC+2/D40/1/5/2/C5/1/K/5/1/C/james meik
le5/3/1/1/GJ/B/Food safety1/*.1/ *.*.1/ *.3K/3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 1/1/*.*
.*.*.*.*.1/1/1/0/DNNGC+2/D45/1/5/2/18C/1/N/2/2/1/ 5/3/1/2/3L/1/ 4/6L/1/ 6/*.1/ *
.3K/3/1/ 3M/3/1/ 3L/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.1/3/0/0/DNNGC+2/D46/1/5/2/S4/1/O
/2/1/1/ 5/3/1/1/6Q/1/ 7/9T/1J/Misleading readers into thinking Tories might win3
9/*.1/ *.3AM/3/9/The PressH5/1/1/ 3L/3/1/ *.*.1/ 1/3/*.*.*.*.*.*.1/3/0/0/DNNGC+2
/D47/1/5/2/K0/1/P/3/3/1/ 4/3/1/1/DQ/1/ 1/A8/1/ 8/*.1/ *.77/1/1/ 3T/3/1/ 40/3/1/ 
41/3/1/ 2/4/3T/1/40/40/1/3T/2/4/1/0/DNNGC+2/D49/1/5/2/27/1/1/3/3/1/ 1/3/1/1/3T/P
/Peerages for retiring mps4/*.1/ *.*.1/ *.10A/1/1/ KH/1/1/ GI/3/1/ *.*.1/ 4/4/*.
*.*.*.*.*.4/4/0/0/DNNQ+3/D6L/1/1/2/N6/1/1/1/1/1/ 1/3/1/1/AF/1/ 39/DP/1/ 1/AF/1/ 
39/70/1/1/ 44/3/4/DCMSAF/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNNQ+3/D6M/1/1/2/M3
/1/B/1/2/1/ 1/2/1/1/3R/1/ 2/3S/1/ A/DG/1/ 1/71/1/1/ 3K/3/1/ KB/1/1/ *.*.1/ 4/4/7
1/1/3K/KB/1/3K/4/1/1/2/DNNQ+3/D6N/1/1/2/14G/1/B/2/1/1/ 3/2/1/2/A1/1/ 8/*.1/ *.*.
1/ *.AB/1/1/ 3B6/3/1/ *.*.1/ *.*.1/ 3/4/*.*.*.*.*.*.3/4/0/2/DNNQ+3/D6Q/1/1/2/II/
1/C/1/2/1/ 1/3/1/2/9T/10/Panorama change 'their claims'39/*.1/ *.*.1/ *.3AL/3/C/
Panorama BBC3K/3/1/ D9/1/B/John Denham70/1/1/ 4/4/*.*.*.*.*.*.1/4/0/0/DNNQ+3/D6T
/1/1/2/ER/1/E/1/1/1/ 1/2/1/1/EC/1/ 1/*.1/ *.*.1/ *.H5/1/1/ AB/1/1/ 3L/3/1/ *.*.1
/ 4/4/H5/1/AB/H5/1/3L/4/4/1/0/DNNQ+3/D70/1/1/2/85/1/E/3/3/1/ 1/2/1/1/46/1/ 5/DH/
1/ 1/EF/1/ 1/76/1/1/ 3N/3/1/ 3K/3/1/ AB/1/1/ 4/4/76/1/3K/76/1/AB/4/4/1/0/DNNQ+3/
D71/1/1/2/GC/1/E/5/1/D/gerard seenan1/3/1/1/D9/12/Scottish Tories prepare to spl
it8/A9/1/ 8/*.1/ *.4B/3/1/ 3L/3/1/ KN/1/1/ *.*.1/ 4/4/4B/1/3L/*.*.*.4/4/0/0/DNNQ
+3/D72/1/1/2/LE/1/F/1/1/1/ 8/2/1/2/3B/1/ 3/A1/1/ 8/*.1/ *.N8/1/F/Nicholas Soames
3B6/3/C/Older Voters71/1/1/ GI/1/D/Paul Mitchell2/4/N8/3/GI/*.*.*.2/4/0/0/DNNQ+3
/D74/1/1/2/IC/1/G/4/1/1/ 1/3/1/2/3I/1/ 3/*.1/ *.*.1/ *.3D9/3/B/Advertisers3K/3/1
/ 3L/3/1/ 3M/3/1/ 4/2/*.*.*.*.*.*.4/2/0/0/DNNQ+3/D75/1/1/2/G5/1/G/1/2/1/ 2/3/1/2
/GJ/8/The Dome1/*.1/ *.*.1/ *.70/1/1/ 3L/3/1/ KB/1/1/ *.*.1/ 4/1/KB/1/70/*.*.*.4
/1/1/0/DNNQ+3/D77/1/1/2/KT/1/H/1/1/1/ 1/3/1/2/6Q/1/ 7/EA/1/ 1/*.1/ *.3AM/3/1/ 3K
/3/1/ 3L/3/1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/0/0/DNNQ+3/D7A/1/1/2/EG/1/H/3/3/1/ 2/3/
1/1/6S/1/ 39/*.1/ *.*.1/ *.3AM/3/H/Sunday Newspapers3K/3/1/ 3L/3/1/ 3M/3/1/ 4/4/
3AM/2/3K/3AM/1/3L/4/4/1/1/DNNQ+3/D7B/1/1/1/117/1/I/4/1/1/ 1/2/2/1/3B/1/ 3/3R/1/ 
2/*.1/ *.3K/3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNNQ+3/D7E/1/1/2
/18P/1/M/2/1/1/ 5/3/1/1/A1/1/ 8/D9/15/Brown should be moved from treasury8/A9/1/
 8/AB/1/1/ 70/1/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/1/1/DNNQ+3/D7F/1/1/2/R7/1/M
/2/1/1/ 5/3/1/2/A1/1/ 8/EH/1/ 1/*.1/ *.70/1/1/ GI/2/D/Yvette Cooper*.*.1/ *.*.1/
 1/3/*.*.*.*.*.*.1/3/0/0/DNNQ+3/D7G/1/1/2/Q7/1/M/1/1/1/ 5/3/1/1/6J/L/Pre-electio
n progress39/3T/1/ 4/6Q/1/ 7/70/1/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/
0/DNNT6+2/DA1/1/2/1/PT/1/1/1/1/1/ 1/3/1/1/GJ/G/Decentralisation1/GJ/P/Traditiona
l labour values1/*.1/ *.70/1/1/ GI/3/9/BlairitesD9/3/L/Centre-Left Ministers3D9/
3/E/Fabian Society4/4/GI/1/70/*.*.*.1/4/2/0/DNNT6+2/DA2/1/2/2/74/1/1/1/1/1/ 1/2/
1/1/6J/A/Rural vote5/6J/2B/Claims of politically motivated delay in culling foot
 & mouth livestock39/*.1/ *.71/1/1/ 70/1/1/ E7/3/1/ *.*.1/ 4/4/71/1/70/E7/1/71/4
/4/0/0/DNNT6+2/DA4/3/2/2/KT/1/D/1/1/1/ 1/2/1/1/3B/1/ 3/3R/1/ 2/6Q/1/ 7/70/1/1/ 3
AM/3/1/ 3L/3/1/ *.*.1/ 4/4/70/1/3AM/70/1/3L/4/4/0/0/DNNT6+2/DA5/1/2/2/10E/1/D/2/
1/1/ 1/2/1/2/3B/1/ 3/*.1/ *.*.1/ *.72/1/1/ 3M/3/1/ *.*.1/ *.*.1/ 2/4/*.*.*.*.*.*
.2/4/0/0/DNNT6+2/DA8/1/2/2/F3/1/E/1/1/1/ 1/2/1/1/3R/1/ 2/A2/1/ 8/*.1/ *.71/1/1/ 
3K/3/1/ *.*.1/ *.*.1/ 4/4/71/1/3K/*.*.*.4/4/1/0/DNNT6+2/DA9/1/2/2/E4/1/E/1/2/1/ 
1/3/1/1/4C/1/ 39/DF/1/ 1/*.1/ *.3D9/1/17/Anthony Nelson - former Tory Minister3K
/3/1/ 3L/3/1/ 71/1/1/ 4/4/3D9/3/3K/3D9/1/3L/4/1/1/0/DNNT6+2/DAB/1/2/2/1AI/1/F/1/
1/1/ 5/3/1/1/DD/1/ 1/DD/N/Criminal justice reform1/A2/1/ 8/3K/3/1/ *.*.1/ *.*.1/
 *.*.1/ 2/*.*.*.*.*.*.*.2/*.3/1/DNNT6+2/DAC/1/2/2/CT/1/G/1/1/1/ 1/3/1/1/GJ/C/Min
imum wage1/48/1/ 5/A9/1/ 8/AB/1/1/ 3D9/3/I/Low Pay CommissionDN/1/1/ 3K/3/1/ 4/4
/*.*.*.*.*.*.4/4/1/0/DNNT6+2/DAD/1/2/2/D8/1/G/4/2/1/ 1/2/1/2/DQ/1G/Trimble threa
tens to quit over ira disarmament1/DQ/1/ 1/*.1/ *.77/1/1/ 40/3/1/ 41/3/1/ *.*.1/
 4/4/77/1/40/77/1/41/4/4/0/0/DNNT6+2/DAG/1/2/2/SM/1/I/4/1/1/ 2/3/1/1/3O/1/ 39/6J
/1Q/Voting for different parties in local & general election39/*.1/ *.3B6/3/1/ 3
K/3/1/ 3L/3/1/ 6J/3/E/Local Councils4/4/*.*.*.*.*.*.4/4/0/0/DNNT6+2/DAM/1/2/1/84
/1/J/5/1/D/gerard seenan1/2/1/1/E5/1/ 1/GJ/H/Act of Settlement1/*.1/ *.70/1/1/ *
.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.1/0/DNNT6+2/DAP/1/2/2/QO/1/L/2/2/1/ 5/3/
1/1/6J/15/Lack of emotion/passion in politics39/*.1/ *.*.1/ *.3K/3/1/ 3P/3/1/ 46
/3/1/ *.*.1/ 1/3/*.*.*.*.*.*.1/3/1/1/DNNT6+2/DAR/1/2/2/T9/1/M/39/2/E/minnette ma
rin5/3/1/1/3C/1/ 4/A1/1/ 8/*.1/ *.71/1/1/ 3L/3/1/ 10M/2/1/ *.*.1/ 1/1/*.*.*.*.*.
*.1/1/1/0/DNO2C+2/DDB/1/3/2/PP/1/1/1/1/1/ 1/3/1/1/3C/1/ 4/AE/1/ 39/*.1/ *.71/1/1
/ N8/1/D/Sebastian CoeN9/3/J/Pro-European ToriesJT/3/D/Senior Tories4/4/N9/1/71/
JT/1/N8/1/1/0/0/DNO2C+2/DDC/1/3/2/L6/1/1/4/1/1/ 1/3/1/1/6L/1/ 6/6P/1/ 6/*.1/ *.3
L/3/1/ 3K/3/1/ 71/1/1/ 70/1/1/ 2/2/*.*.*.*.*.*.2/2/1/0/DNO2C+2/DDG/1/3/2/I9/1/E/
1/1/1/ 1/2/1/2/A8/1H/Hague attacks Blairs school choice for his boys8/DC/1/ 1/*.
1/ *.71/1/1/ 70/1/1/ E5/1/1/ 3B6/3/B/Tory voters4/4/71/1/70/3B6/3/71/4/1/1/0/DNO
2C+2/DDI/1/3/2/207/1/F/1/1/1/ 2/3/1/1/3L/1/ 4/6J/F/Use of internet4/*.1/ *.3M/3/
1/ 3K/3/1/ 3L/3/1/ 3B5/3/1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNO2C+2/DDJ/1/3/2/IT/1/G/1/2
/1/ 1/2/1/1/EA/1/ 1/A2/1/ 8/*.1/ *.72/1/1/ 3M/3/1/ 3K/3/1/ 3L/3/1/ 4/4/72/1/3K/7
2/1/3L/4/4/2/0/DNO2C+2/DDL/1/3/2/R2/1/H/2/1/1/ 3/3/1/2/A1/1/ 8/*.1/ *.*.1/ *.AA/
1/1/ *.*.1/ *.*.1/ *.*.1/ 3/*.*.*.*.*.*.*.3/*.0/2/DNO2C+2/DDM/1/3/2/6R/1/G/4/1/1
/ 1/3/1/1/6J/1A/Labour-held seats have worse death rates8/EH/1/ 1/*.1/ *.70/1/1/
 3B5/1/O/Prof. George Davey Smith3L/3/1/ *.*.1/ 4/4/3B5/1/70/*.*.*.4/4/0/0/DNO2C
+2/DDN/1/3/2/92/1/H/1/1/1/ 2/3/1/2/3R/1/ 2/*.1/ *.*.1/ *.71/1/1/ 3K/3/1/ 3L/3/1/
 10M/2/1/ 4/4/71/1/3K/*.*.*.4/4/0/0/DNO2C+2/DDQ/1/3/2/BL/1/I/4/1/1/ 5/3/1/1/DP/1
/ 1/D9/T/Culture ignored in manifestos9/*.1/ *.3K/3/1/ AF/1/1/ 3L/3/1/ *.*.1/ 2/
3/*.*.*.*.*.*.2/3/1/0/DNO2C+2/DDS/1/3/2/J4/1/J/1/1/1/ 1/3/1/2/3G/1/ 39/*.1/ *.*.
1/ *.E5/1/1/ 70/1/1/ H2/1/1/ R9/1/C/Norman Baker4/4/H2/1/E5/*.*.*.1/1/0/0/DNO2C+
2/DDT/1/3/2/A2/1/J/1/1/1/ 1/4/1/1/GJ/N/EU unlocks funds for UK1/DE/1/ 1/*.1/ *.D
N/1/1/ AB/1/1/ 47/3/1/ *.*.1/ 4/4/DN/2/47/AB/2/47/4/4/1/0/DNO2C+2/DE1/1/3/1/195/
1/L/2/2/1/ 5/3/1/1/6J/C/Protest vote39/EH/1/ 1/3L/1/ 4/3K/3/1/ 3D9/3/E/Protest v
oters*.*.1/ *.*.1/ 3/1/3D9/1/3K/*.*.*.3/1/2/0/DNO2C+2/DE6/1/3/2/D1/1/J/1/1/1/ 1/
3/1/1/6J/L/Party membership down39/*.1/ *.*.1/ *.3K/3/1/ GJ/3/E/Labour Members3L
/3/1/ *.*.1/ 1/4/GJ/1/3K/*.*.*.1/4/0/0/DNO5I+2/DGL/1/4/2/OE/1/1/1/1/1/ 1/2/1/1/3
B/1/ 3/3Q/1/ 2/45/1/ 2/70/1/1/ 71/1/1/ 72/1/1/ 3K/3/1/ 4/4/70/1/3K/*.*.*.4/1/1/0
/DNO5I+2/DGM/1/4/2/10L/1/1/2/1/1/ 5/2/2/1/3B/1/ 3/3C/1/ 4/*.1/ *.71/1/1/ 3B6/3/1
/ JT/3/D/Senior Tories*.*.1/ 2/4/3B6/2/71/*.*.*.2/4/0/1/DNO5I+2/DGN/1/4/2/MP/1/F
/1/1/1/ 1/2/1/1/3B/1/ 3/3K/1/ 2/6J/Q/Return to socialist ideals39/70/1/1/ GJ/3/A
/Supporters*.*.1/ *.*.1/ 3/4/GJ/3/70/*.*.*.3/4/0/1/DNO5I+2/DGO/1/4/2/EI/1/F/1/1/
1/ 1/3/1/2/3I/1/ 3/*.1/ *.*.1/ *.3K/3/1/ E7/1/1/ 70/1/1/ 3AL/3/1/ 4/4/*.*.*.*.*.
*.2/4/0/0/DNNT6+2/DGS/1/4/2/J3/1/H/1/1/1/ 1/2/1/1/3B/1/ 3/9T/T/Appeal to voters 
to vote tory39/*.1/ *.71/1/1/ 3K/3/1/ JT/3/D/Senior ToriesL0/3/1/ 4/4/71/1/3K/L0
/3/71/4/4/1/0/DNO5I+2/DGT/1/4/2/BF/1/H/1/1/1/ 1/4/1/1/DG/1/ 1/6J/14/Anti-euros a
ttack Hague's campaign39/*.1/ *.3D9/3/1/ 71/1/1/ 3L/3/1/ *.*.1/ 4/4/3D9/1/71/3D9
/1/3L/4/1/0/0/DNO5I+2/DH0/1/4/2/E7/1/H/1/1/1/ 1/3/1/2/6L/1/ 6/*.1/ *.*.1/ *.3K/3
/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.3/1/0/0/DNO5I+2/DH2/1/4/1/QS/1/K/2/1/
1/ 5/3/1/1/6Q/1/ 7/3C/17/Willingness of MPs to be interrogated39/*.1/ *.70/1/1/ 
3AM/3/1/ 3B6/3/1/ *.*.1/ 3/2/*.*.*.*.*.*.3/2/0/0/DNO5I+2/DH3/1/4/2/H9/1/K/3/3/1/
 1/3/1/2/6Q/10/Summary of what the papers say7/6L/1/ 6/*.1/ *.70/1/1/ 3L/3/1/ 3K
/3/1/ 3M/3/1/ 4/4/*.*.*.*.*.*.3/1/0/0/DNO5I+2/DH5/1/4/2/CB/1/K/1/1/1/ 1/3/1/1/3Q
/1/ 2/3J/1/ 2/6J/J/Share of votes cast39/70/1/1/ 3K/3/1/ 6J/3/A/Charter 88*.*.1/
 4/4/6J/1/3K/*.*.*.4/4/1/0/DNO5I+2/DH7/1/4/2/Q3/1/M/5/1/D/stuart millar1/2/2/1/3
B/1/ 3/3E/1/ 2/*.1/ *.3K/3/1/ 3L/3/1/ 3P/3/1/ 76/1/1/ 4/4/*.*.*.*.*.*.4/4/0/0/DN
O5I+2/DH8/1/4/2/184/1/C/2/1/1/ 5/3/1/1/45/1/ 2/3C/1/ 4/6Q/1/ 7/46/3/1/ 3AM/3/1/ 
3B6/3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/1/DNO5I+2/DHA/1/4/2/14S/1/O/2/1/1/ 5/3/1/2
/DR/1/ 1/A1/N/Qualities of New Labour8/*.1/ *.3K/3/1/ AB/1/1/ AH/1/1/ 70/1/1/ 2/
2/*.*.*.*.*.*.2/2/1/0/DNO5I+2/DHB/1/4/2/JN/1/P/3/3/1/ 4/3/1/1/3S/1/ A/3J/1/ 2/*.
1/ *.70/1/1/ DP/1/1/ 3AM/3/1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/0/0/DNO5I+2/DHC/1/4/2/A
L/1/P/3/3/1/ 4/3/1/1/3N/1/ 4/3L/1/ 4/9T/1B/Marginal MPs who author wants to win/
lose7/46/3/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.0/0/DNL2O+2/MA0/2/3/2/I9/
1/D/1/2/1/ 1/3/1/2/4G/1/ 39/3B/1/ 3/*.1/ *.270/2/1/ 275/2/1/ 70/1/1/ 71/1/1/ 4/4
/*.*.*.*.*.*.1/3/0/0/DNL2O+2/MA1/2/3/2/DK/1/C/4/1/1/ 1/3/1/2/DQ/1G/Trimble threa
tens to quit over ira disarmament1/DQ/1/ 1/*.1/ *.77/1/1/ 13T/1/H/Martin McGuinn
ess16J/1/D/Seamus MallonE7/3/1/ 4/4/13T/1/77/*.*.*.4/4/0/0/DNL2O+2/MA3/2/3/2/Q5/
1/1/1/1/1/ 1/2/1/1/DF/1/ 1/DG/1/ 1/3C/1/ 4/70/1/1/ 71/1/1/ 72/1/1/ AC/1/1/ 4/4/*
.*.*.*.*.*.4/4/1/0/DNL2O+2/MA4/2/3/2/IP/1/1/1/1/1/ 1/2/2/1/3D/1/ 3/*.1/ *.*.1/ *
.70/1/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/1/DNL2O+2/MA6/2/3/2/JE/1/9/1
/1/1/ 1/2/1/1/3D/1/ 3/3I/1/ 3/A3/1/ 8/70/1/1/ 71/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.
*.*.1/1/0/1/DNL2O+2/MA8/2/3/2/1M0/1/A/5/1/9/tim hames2/3/1/2/3C/1/ 4/6J/P/Import
ance of the regions39/*.1/ *.3K/3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/
1/0/DNL2O+2/MAB/2/3/2/60/1/C/1/1/1/ 1/2/1/1/DF/1/ 1/A2/1/ 8/*.1/ *.AC/1/1/ *.*.1
/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.1/0/DNL2O+2/MAD/2/3/2/JT/1/D/1/2/1/ 1/2/1/1/
3B/1/ 3/3P/1/ 3/*.1/ *.71/1/1/ 3B6/3/1/ N9/3/1/ *.*.1/ 1/4/3B6/1/71/*.*.*.1/4/1/
0/DNL2O+2/MAF/2/3/2/12H/1/I/5/2/B/alice miles5/3/1/1/6J/1M/Politics (as opposed 
to campaign) no longer exciting39/A3/1/ 8/A2/1/ 8/3K/3/1/ 70/1/1/ *.*.1/ *.*.1/ 
2/2/*.*.*.*.*.*.2/2/1/0/DNL2O+2/MAG/2/3/2/1GP/1/I/5/1/D/simon jenkins5/3/1/1/3K/
1/ 2/6J/I/Premature election39/*.1/ *.70/1/1/ 3B6/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*
.*.*.1/1/0/0/DNL2O+2/MAH/2/3/2/DN/1/9/1/1/1/ 1/3/1/1/6J/1A/Queen will miss Ascot
 to open Parliament39/*.1/ *.*.1/ *.3B0/2/9/The Queen3D9/3/H/Buckingham Palace6J
/3/B/Westminster*.*.1/ 4/4/3D9/1/6J/*.*.*.4/4/0/0/DNL6+3/MDB/2/4/2/O8/1/9/1/1/1/
 1/1/2/2/6J/L/Last PM question time39/*.1/ *.*.1/ *.70/1/1/ 71/1/1/ N8/1/F/Phill
ip Hammond72/1/1/ 1/2/*.*.*.*.*.*.1/2/1/0/DNL6+3/MDD/2/4/2/N4/1/1/1/1/1/ 1/3/1/1
/6L/1/ 6/*.1/ *.*.1/ *.70/1/1/ 3L/3/1/ 3K/3/1/ 3M/3/1/ 4/4/*.*.*.*.*.*.3/4/0/0/D
NL6+3/MDE/2/4/2/PI/1/1/1/1/1/ 1/2/1/1/3I/1/ 3/A6/1/ 9/EA/1/ 1/3K/3/1/ 70/1/1/ N8
/1/B/Tim Collins71/1/1/ 4/4/N8/1/3K/71/1/3K/4/4/2/0/DNL6+3/MDI/2/4/2/H9/1/A/5/1/
F/dominic kennedy1/3/1/1/3H/1/ 39/*.1/ *.*.1/ *.70/1/1/ 10O/1/1/ N8/1/C/Andrew T
yrie*.*.1/ 4/4/N8/1/70/*.*.*.4/4/0/0/DNL6+3/MDJ/2/4/2/HO/1/A/5/2/B/alice miles2/
3/1/1/3I/1/ 3/EA/1/ 1/A3/1/ 8/3K/3/1/ E8/3/Q/Strategists/Policy Advisor3L/3/1/ *
.*.1/ 2/4/3L/1/3K/*.*.*.2/4/2/0/DNL6+3/MDK/2/4/2/BS/1/A/1/1/1/ 1/2/1/1/AD/1/ 39/
AC/1/ 9/*.1/ *.70/1/1/ AB/1/1/ 3L/3/1/ *.*.1/ 4/4/AB/1/3L/*.*.*.4/4/1/0/DNL6+3/M
DL/2/4/2/8B/1/B/5/1/8/tim reid1/2/1/1/3B/1/ 3/A1/1/ 8/3C/1/ 4/13S/2/R/Glamourous
 Green Candidates3P/3/1/ *.*.1/ *.*.1/ 3/4/*.*.*.*.*.*.3/4/0/0/DNL6+3/MDM/2/4/2/
D8/1/B/5/1/F/Brian MacArthur1/3/1/2/6Q/1/ 7/*.1/ *.*.1/ *.3AM/3/1/ 71/1/1/ *.*.1
/ *.*.1/ 4/2/*.*.*.*.*.*.4/2/0/1/DNL6+3/MDP/2/4/2/J0/1/B/1/1/1/ 1/3/1/1/3T/1/ 4/
3T/1/ 4/*.1/ *.E6/1/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/4/3K/3/E6/*.*.*.4/4/0/0/DNL96+2/M
GL/2/5/2/62/1/B/3/3/1/ 1/2/1/2/A6/1/ 9/DI/1/ 1/*.1/ *.H5/1/1/ 3K/3/1/ *.*.1/ *.*
.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNL96+2/MGN/2/5/2/1K/1/D/3/3/1/ 1/3/1/1/DB/1/ 1/D9/1
G/Lib Dem research show waiting lists have risen39/*.1/ *.3M/3/1/ *.*.1/ *.*.1/ 
*.*.1/ 4/*.*.*.*.*.*.*.4/*.0/0/DNL96+2/MGO/2/5/2/KO/1/E/5/2/H/mary ann seighert2
/3/1/1/6J/Q/Student politics at Oxford39/*.1/ *.*.1/ *.N8/3/1J/Oxford University
 Conservative Association (OUCA)N9/1/11/Marcus Walker (president, OUCA)N9/2/11/A
lex da Costa (soc. sec., OUCA)*.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNL96+2/MGP/2/5/2/7
K/1/1/5/1/D/andrew pierce1/3/1/1/3H/19/Tory manifesto not available in Bengali39
/3C/1/ 4/*.1/ *.71/1/1/ 6J/3/R/Conservative Central Office*.*.1/ *.*.1/ 4/1/*.*.
*.*.*.*.4/1/0/0/DNL96+2/MGQ/2/5/2/PO/1/1/1/1/1/ 2/2/1/2/A6/1/ 9/DH/1/ 1/*.1/ *.3
L/3/1/ 3K/3/1/ AB/1/1/ DP/1/1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNL96+2/MGR/2/5/2/O0/1/9/
2/1/1/ 5/3/1/1/A6/1/ 9/A2/1/ 8/EA/1/ 1/3L/3/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.
*.*.2/*.3/0/DNL96+2/MGS/2/5/2/KC/1/9/5/1/D/ben macintyre5/3/1/1/A6/1/ 9/3C/1/ 4/
*.1/ *.71/1/1/ 3L/3/1/ KR/1/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNL96+2/MH1/2/5/2/
4G/1/A/5/2/E/valerie elliot1/3/1/1/E9/1/ 1/*.1/ *.*.1/ *.3D9/3/F/Fuel Protestors
AB/1/1/ *.*.1/ *.*.1/ 4/4/3D9/2/AB/*.*.*.4/4/1/0/DNL96+2/MH2/2/5/2/4E/1/A/5/2/F/
alexandra frean5/3/1/1/E0/R/Rerendums in local councils1/4A/1/ 4/6J/L/Single iss
ue politics39/3B6/3/1/ 6J/3/E/Local Councils*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/
0/DNL96+2/MH6/2/5/2/LD/1/D/5/1/G/damain whitworth1/3/1/1/3T/1/ 4/*.1/ *.*.1/ *.G
J/3/J/Labour Club MembersE6/1/1/ GI/1/J/Gerry Bermingham MP*.*.1/ 4/4/GJ/1/E6/*.
*.*.4/1/0/0/DNL96+2/MH8/2/5/2/1K/1/D/3/3/1/ 1/3/1/2/6J/G/Anti-capitalists39/*.1/
 *.*.1/ *.3AK/3/G/Anti-Capitalists70/1/1/ 71/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.1/4/0/0
/DNL96+2/MH9/2/5/2/JL/1/9/1/1/1/ 5/2/2/1/3B/1/ 3/A6/1/ 9/*.1/ *.71/1/1/ JT/3/I/T
he Shadow Cabinet*.*.1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/0/1/DNLIO+2/MK5/2/1/2/M1/1/1/
1/1/1/ 1/2/1/1/ED/1/ 1/6S/1J/Letter printed from business in support of labour39
/*.1/ *.3K/3/1/ 3AB/3/1/ AB/1/1/ 3L/3/1/ 4/4/3AB/3/3K/3L/1/3K/4/4/1/0/DNLIO+2/MK
6/2/1/2/ES/1/1/1/1/1/ 1/2/1/1/DM/1/ 1/DD/1/ 1/A2/1/ 8/3K/3/1/ 70/1/1/ *.*.1/ *.*
.1/ 4/4/*.*.*.*.*.*.4/4/2/1/DNLIO+2/MK9/2/1/2/8R/1/7/5/1/H/nicholas wapshott1/3/
1/1/4C/1/ 39/3C/1/ 4/6S/1/ 39/3B8/2/1/ 3K/3/1/ 3AE/2/B/Spice Girls*.*.1/ 1/4/3B8
/3/3K/*.*.*.1/4/0/0/DNLM+3/MNB/2/2/2/4Q/1/1/1/1/1/ 1/3/1/2/DE/1/ 1/A9/1/ 8/*.1/ 
*.KK/1/1/ 3K/3/1/ 3L/3/1/ AB/1/1/ 4/4/3L/1/3K/AB/1/3L/4/4/1/0/DNLM+3/MNC/2/2/2/H
P/1/D/5/1/G/damian whitworth1/2/1/2/3B/1/ 3/*.1/ *.*.1/ *.DS/1/1/ H6/2/1/ N8/1/C
/Gus Robinson*.*.1/ 2/1/*.*.*.*.*.*.2/1/0/1/DNLM+3/MND/2/2/2/E7/1/H/3/3/1/ 4/3/1
/1/3C/1/ 4/6S/M/Celebrity Endorsements39/*.1/ *.3B8/2/1/ 70/1/1/ 3AE/3/J/Various
 Celebrities*.*.1/ 1/4/*.*.*.*.*.*.1/4/0/0/DNLM+3/MNF/2/2/2/NP/1/1/4/1/1/ 1/3/1/
1/DB/1/ 1/E7/1/ 1/A2/1/ 8/3K/3/1/ 3D9/3/P/Independent Health SectorAD/1/1/ *.*.1
/ 4/4/3D9/3/3K/*.*.*.4/4/2/0/DNLM+3/MNG/2/2/2/12A/1/G/5/1/C/michael gove5/3/1/1/
A1/1/ 8/A7/1/ 9/EA/1/ 1/72/1/1/ 3M/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/2/1/DN
LM+3/MNH/2/2/2/IB/1/E/1/1/D/peter riddell2/3/1/1/DE/1/ 1/DI/1/ 1/*.1/ *.3K/3/1/ 
3L/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNLM+3/MNI/2/2/2/IA/1/1/1/1/1/ 1/2
/1/1/GJ/L/House of Lords reform1/A2/1/ 8/*.1/ *.DK/2/1/ 70/1/1/ 6J/3/E/House of 
Lords*.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNLM+3/MNJ/2/2/2/78/1/4/4/1/1/ 1/3/1/1/3G/1/
 39/3H/24/Hindujas to stay in India to avoid controversy prior to election39/*.1
/ *.10O/1/1/ 3D9/3/P/Sources close to Hindujas*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/
0/0/DNLM+3/MNK/2/2/2/L7/1/D/5/1/D/andrew pierce1/2/1/1/3B/1/ 3/A1/1/ 8/*.1/ *.10
M/2/1/ 71/1/1/ E9/3/1/ *.*.1/ 4/4/10M/3/71/E9/3/10M/4/4/0/1/DNLM+3/MNM/2/2/2/BG/
1/D/1/2/1/ 1/2/1/1/3H/14/Welsh manifesto wrongly translated39/A6/5/Welsh9/3B/1/ 
3/71/1/1/ 3AM/3/1/ *.*.1/ *.*.1/ 1/4/3AM/1/71/*.*.*.1/4/0/0/DNLM+3/MNN/2/2/2/3H/
1/E/5/3/C/lea paterson1/3/1/1/EB/1/ 1/A2/1/ 8/*.1/ *.3L/3/1/ 3AB/3/1/ *.*.1/ *.*
.1/ 4/4/3AB/1/3L/*.*.*.4/4/1/0/DNLM+3/MNP/2/2/2/8T/1/E/5/1/H/nicholas wapshott1/
3/1/1/3B/S/John Humphreys berates Blair3/3G/1/ 39/*.1/ *.70/1/1/ 3AL/1/E/John Hu
mphreys3AM/3/1/ *.*.1/ 1/4/3AL/1/70/*.*.*.1/4/0/0/DNLM+3/MNQ/2/2/2/4R/1/E/1/1/1/
 1/3/1/2/3T/1/ 4/*.1/ *.*.1/ *.70/1/1/ E6/1/1/ *.*.1/ *.*.1/ 4/4/70/3/E6/*.*.*.4
/4/0/0/DNLM+3/MNS/2/2/2/HH/1/F/1/1/1/ 1/3/1/1/AF/1/ 39/A9/K/Blair/Brown conflict
8/*.1/ *.70/1/1/ DO/1/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNLM+3/MO0/2/2/2/
9M/1/F/5/1/A/Greg Hurst1/2/1/2/3B/1/ 3/4G/K/Kennedy's girlfriend39/*.1/ *.72/1/1
/ 276/2/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNLM+3/MO2/2/2/2/40/1/F/3/3/1/ 
1/3/1/2/6J/11/Martin Bell's hopes in election8/*.1/ *.*.1/ *.10B/1/1/ L4/1/1/ *.
*.1/ *.*.1/ 4/4/L4/1/10B/*.*.*.2/4/0/0/DNLM+3/MO3/2/2/2/Q7/1/G/5/2/J/patience wh
eatcroft5/3/1/1/ED/1/ 1/6S/1J/Letter printed from business in support of labour3
9/*.1/ *.3AB/3/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/1/3AB/2/3K/*.*.*.4/1/1/0/DNLM+3/MO4/2/
2/2/LH/1/E/1/1/1/ 1/3/1/1/DE/1/ 1/A9/1/ 8/*.1/ *.3L/3/1/ 3K/3/1/ 71/1/1/ KK/1/1/
 4/4/3K/1/3L/*.*.*.1/4/1/0/DNLP6+2/MQL/2/3/2/53/1/1/1/1/1/ 1/2/1/2/3C/1/ 4/DG/1/
 1/*.1/ *.72/1/1/ N9/3/1/ 3K/3/1/ *.*.1/ 4/4/72/1/3K/*.*.*.4/4/1/0/DNLP6+2/MQO/2
/3/2/MH/1/1/1/1/1/ 1/2/1/1/A5/1/ 9/A2/1/ 8/E1/1/ 1/70/1/1/ *.*.1/ *.*.1/ *.*.1/ 
4/*.*.*.*.*.*.*.4/*.3/0/DNLP6+2/MQP/2/3/2/HB/1/1/5/1/D/andrew pierce1/3/1/1/72/1
6/Odds on Ffion Hague remaining silent7/A1/1/ 8/3C/1/ 4/275/2/1/ 3AR/3/1/ 71/1/1
/ N9/3/1/ 4/4/N9/3/275/*.*.*.4/4/0/1/DNLP6+2/MQT/2/3/2/K2/1/C/1/1/1/ 5/2/2/1/3B/
1/ 3/*.1/ *.*.1/ *.72/1/1/ 3B6/3/1/ N9/3/A/SupportersTT/3/A/Supporters2/2/3B6/1/
72/*.*.*.2/2/0/0/DNLP6+2/MR0/2/3/2/2II/1/D/3/3/1/ 39/2/1/1/A7/1/ 9/A2/1/ 8/EA/1/
 1/3M/3/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.3/0/DNLP6+2/MR1/2/3/2/8P/1/D
/5/1/A/Sam Coates1/3/1/2/A7/1/ 9/EA/1/ 1/*.1/ *.3M/3/1/ *.*.1/ *.*.1/ *.*.1/ 2/*
.*.*.*.*.*.*.2/*.2/0/DNLP6+2/MR2/2/3/2/LD/1/E/1/1/1/ 1/2/1/1/DE/1/ 1/3H/1/ 39/A2
/1/ 8/H5/1/1/ AB/1/1/ KK/1/1/ 3L/3/1/ 4/4/AB/1/3L/AB/1/KK/4/4/2/0/DNLP6+2/MR3/2/
3/2/49/1/E/1/1/1/ 1/3/1/1/6J/S/Ed Balls joins election team8/6J/T/Strengthens Br
own's influence8/*.1/ *.AB/1/1/ E8/1/8/Ed Balls48/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/
4/0/0/DNLP6+2/MR4/2/3/2/K2/1/E/1/1/1/ 1/3/1/1/3H/1/ 39/A9/1/ 8/DE/1/ 1/KK/1/1/ H
5/1/1/ 3K/3/1/ 71/1/1/ 1/4/3K/1/71/*.*.*.1/4/1/0/DNLP6+2/MR6/2/3/2/K0/1/F/1/2/1/
 1/2/1/1/3C/1/ 4/3F/1/ 2/DD/K/Early release scheme1/3L/3/1/ 3K/3/1/ 3D9/3/J/Pris
on Reform Trust3AO/3/E/Victim Support1/4/3K/1/3L/3D9/1/3L/1/4/1/0/DNLP6+2/MRD/2/
3/2/HP/1/B/1/1/1/ 1/3/1/1/A7/1/ 9/EA/1/ 1/A1/1/ 8/3M/3/1/ 72/1/1/ *.*.1/ *.*.1/ 
4/3/*.*.*.*.*.*.4/3/1/1/DNLSC+2/N02/2/4/2/HE/1/E/1/1/D/peter riddell2/3/1/2/A5/1
/ 9/EA/1/ 1/*.1/ *.70/1/1/ D9/3/9/Ministers*.*.1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/1/0
/DNLSC+2/N03/2/4/2/TK/1/H/1/1/1/ 2/2/2/1/3B/1/ 3/3E/1/ 2/*.1/ *.70/1/1/ AB/1/1/ 
E9/3/1/ 3AM/3/B/Journalists1/1/*.*.*.*.*.*.1/1/0/1/DNLSC+2/N05/2/4/2/KP/1/1/1/1/
1/ 1/2/1/1/3H/1/ 39/3P/1/ 3/*.1/ *.AE/1/1/ 3B9/1/1/ N8/1/E/Brendan Murphy3AI/1/1
/ 4/4/N8/1/AE/3AI/1/AE/1/4/0/1/DNLSC+2/N06/2/4/2/NK/1/1/1/1/1/ 1/2/1/1/A5/1/ 9/E
B/1/ 1/E7/1/ 1/70/1/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/2/*.*.*.*.*.*.4/2/3/0/DNLSC+2/N07
/2/4/2/G0/1/1/1/1/1/ 1/3/1/1/6L/1/ 6/*.1/ *.*.1/ *.3L/3/1/ 3D9/3/M/Professionals
/Managers70/1/1/ 3K/3/1/ 4/4/3D9/1/3L/3D9/3/70/1/4/0/0/DNLSC+2/N08/2/4/2/A3/1/2/
5/1/G/stewart trendler1/3/1/1/3C/1/ 4/*.1/ *.*.1/ *.3AN/3/1/ 6J/3/7/VIP MPs*.*.1
/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNLSC+2/N0C/2/4/2/1R6/1/F/3/3/10/extract from l
abour manifesto)39/2/1/1/A5/1/ 9/A2/1/ 8/EA/1/ 1/3K/3/1/ *.*.1/ *.*.1/ *.*.1/ 3/
*.*.*.*.*.*.*.3/*.3/0/DNLSC+2/N0E/2/4/2/FA/1/F/1/1/1/ 2/3/1/1/A5/1/ 9/EA/1/ 1/*.
1/ *.3K/3/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.3/0/DNLSC+2/N0H/2/4/2/BP/1
/I/5/1/H/nicholas wapshott1/2/2/1/4E/1/ 4/*.1/ *.*.1/ *.72/1/1/ *.*.1/ *.*.1/ *.
*.1/ 2/*.*.*.*.*.*.*.2/*.0/1/DNLSC+2/N0N/2/4/2/DS/1/J/5/1/D/andrew pierce1/3/1/1
/DG/1/ 1/A9/1/ 8/*.1/ *.QJ/1/1N/David Heath (Agriculture Spokesman, Somerset & F
rome)RE/1/11/Mike Hancock (Portsmouth South)3D9/3/I/Democracy Movement3M/3/1/ 4/
4/QJ/1/3D9/RE/1/3D9/4/4/0/0/DNM1I+2/N3B/2/5/2/78/1/A/1/1/1/ 1/3/1/2/3C/1/ 4/3B/1
/ 3/*.1/ *.70/1/1/ E7/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNM1I+2/N3C/2/5
/2/L6/1/J/3/3/1/ 4/3/1/2/3C/1/ 4/3P/1/ 3/3E/1/ 2/AE/1/1/ 3AK/3/1/ 3AM/3/1/ *.*.1
/ 2/1/*.*.*.*.*.*.2/1/0/0/DNM1I+2/N3E/2/5/2/12H/1/I/5/2/H/mary ann sieghart5/3/1
/1/6J/16/Prospect of a public sector backlash39/DI/1/ 1/EG/1/ 1/70/1/1/ 3K/3/1/ 
3D9/1/L/Public Sector Workers*.*.1/ 2/2/*.*.*.*.*.*.2/2/2/0/DNM1I+2/N3F/2/5/2/J5
/1/1/1/1/1/ 1/2/1/1/3H/1/ 39/*.1/ *.*.1/ *.AE/1/1/ 70/1/1/ 71/1/1/ 3K/3/1/ 4/4/7
0/3/AE/71/1/AE/2/4/0/1/DNM1I+2/N3G/2/5/2/KP/1/1/5/1/G/magnus linklater5/2/2/1/3B
/1/ 3/6Q/1/ 7/A1/1/ 8/AE/1/1/ GJ/3/1/ GI/1/12/John Home Robertson/East Lothian*.
*.1/ 4/4/GJ/3/AE/GI/3/AE/3/4/0/0/DNM1I+2/N3H/2/5/2/1EA/1/9/1/1/1/ 1/3/1/2/3H/1/ 
39/6L/1/ 6/*.1/ *.AE/1/1/ 70/1/1/ 71/1/1/ N8/1/L/Brendan Murphy (Rhyl)4/4/*.*.*.
*.*.*.4/4/0/0/DNM1I+2/N3K/2/5/2/BE/1/A/5/1/G/nicholas wapshot1/3/1/1/3P/1/ 3/44/
1/ 3/6Q/T/Phone-ins re Prescott's punch7/AE/1/1/ 3AL/1/1/ 3D9/3/1/ *.*.1/ 4/4/3D
9/2/AE/*.*.*.4/4/0/0/DNM1I+2/N3M/2/5/2/99/1/B/4/1/1/ 1/2/1/1/3P/1/ 3/DD/1/ 1/*.1
/ *.AH/1/1/ 3AN/3/1/ H6/2/1/ *.*.1/ 4/4/3AN/1/AH/H6/1/AH/1/4/0/1/DNM1I+2/N3N/2/5
/2/LD/1/C/1/1/1/ 5/2/1/1/3B/1/ 3/A1/1/ 8/*.1/ *.71/1/1/ 275/2/1/ N9/3/A/Supporte
rs3AK/3/1/ 2/3/N9/3/3L/3AK/1/3L/2/3/0/1/DNM1I+2/N3P/2/5/2/H0/1/C/5/1/D/andrew pi
erce1/3/1/1/AA/1/ 8/73/1/ 39/A1/1/ 8/N8/1/M/John Horam (Orpington)71/1/1/ N9/3/1
/ RE/1/1/ 4/4/N8/2/71/3B6/2/71/4/4/0/1/DNM1I+2/N3Q/2/5/2/IS/1/E/5/1/D/david char
ter1/3/1/1/DB/1/ 1/3P/1/ 3/*.1/ *.3D9/3/13/Staff at Queen Elizabeth Hospital3AK/
2/D/Sharon Storer*.*.1/ *.*.1/ 4/4/3D9/1/3AK/*.*.*.4/1/1/0/DNM1I+2/N40/2/5/2/8J/
1/E/5/1/D/david charter1/2/1/1/DB/1/ 1/3P/1/ 3/3C/1/ 4/70/1/1/ 3D9/2/L/Health Wo
rker (nurse)*.*.1/ *.*.1/ 1/4/3D9/1/70/*.*.*.1/4/1/0/DNMB6+2/N6L/2/1/2/9H/1/8/1/
1/1/ 1/3/1/2/3C/1/ 4/A9/1/ 8/DG/1/ 1/71/1/1/ N9/3/P/Tory Ad Agency & PollsterJT/
3/D/Senior Tories*.*.1/ 4/4/N9/1/71/JT/2/71/4/4/0/0/DNMB6+2/N6O/2/1/2/A8/1/A/5/1
/A/Greg Hurst1/3/1/1/AD/1/ 39/A9/1/ 8/*.1/ *.GJ/1/C/Derek Draper70/1/1/ AB/1/1/ 
*.*.1/ 4/4/GJ/1/70/AB/1/GJ/4/1/0/0/DNMB6+2/N6P/2/1/2/QH/1/9/5/1/G/damian whitwor
th2/2/1/1/3B/1/ 3/A1/1/ 8/3G/1/ 39/10B/1/1/ L4/1/1/ 3L/3/1/ *.*.1/ 2/4/L4/1/10B/
*.*.*.2/4/0/1/DNMB6+2/N6Q/2/1/2/KJ/1/1/1/1/1/ 1/3/1/1/A9/1/ 8/DF/1/ 1/3C/1/ 4/71
/1/1/ N8/1/C/Lord BrittanKS/1/1/ 10F/1/1/ 4/4/N8/1/71/KS/1/N8/1/4/1/0/DNMB6+2/N6
R/2/1/2/6Q/1/1/1/1/1/ 1/3/1/1/DT/1/ 1/EC/1/ 1/DE/1/ 1/AB/1/1/ H5/1/1/ 70/1/1/ 3L
/3/1/ 4/4/H5/1/AB/70/1/3L/1/4/1/0/DNMB6+2/N6S/2/1/2/114/1/7/5/1/D/ben macintyre2
/3/1/1/47/1/ 5/DO/1/ 1/DR/1/ 1/3D9/3/A/Pakistanis3L/3/1/ N8/1/C/John Townend*.*.
1/ 4/4/3D9/1/3L/3D9/1/N8/4/4/1/0/DNMB6+2/N73/2/1/2/J2/1/A/1/1/1/ 1/2/1/1/DE/1/ 1
/DT/1/ 1/*.1/ *.AB/1/1/ H5/1/1/ KK/1/1/ E3/1/1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNMB6+2/
N75/2/1/2/N0/1/8/1/1/1/ 1/3/1/1/DF/1/ 1/A9/1/ 8/*.1/ *.N8/1/S/Lord Brittan of Sp
ennithorne71/1/1/ 3L/3/1/ *.*.1/ 4/4/N8/1/71/N8/1/3L/4/1/1/0/DNMEC+2/NA1/2/2/2/A
M/1/C/5/2/C/helen nugent1/3/1/2/DT/1/ 1/*.1/ *.*.1/ *.AB/1/1/ 3AF/3/1/ 3L/3/1/ *
.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNMEC+2/NA2/2/2/2/50/1/D/1/1/1/ 1/3/1/2/D9/D/UUP m
anifesto9/EA/1/ 1/3F/C/Dirty tricks2/77/1/1/ 3T/3/1/ 40/3/1/ 13T/1/1/ 4/4/40/1/7
7/13T/1/3T/4/4/1/0/DNMEC+2/NA3/2/2/2/B3/1/1/5/1/C/Nigel Hawkes1/3/1/1/DB/1/ 1/DB
/I/University for NHS1/*.1/ *.3D9/3/B/NHS Workers70/1/1/ 3K/3/1/ *.*.1/ 4/4/*.*.
*.*.*.*.4/4/1/0/DNMEC+2/NA4/2/2/2/Q4/1/1/1/1/1/ 1/2/2/1/3E/1/ 2/3B/1/ 3/*.1/ *.A
B/1/1/ 3B6/3/1/ *.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/0/1/DNMEC+2/NA5/2/2/2/KJ/1/1/1
/1/1/ 1/3/1/1/6Q/1/ 7/3P/1/ 3/3E/1/ 2/3K/3/1/ E1/2/1/ 3AM/3/11/News Broadcasters
 (ITN,BBC,SKY)*.*.1/ 4/4/E1/1/3AM/3AM/1/3K/4/4/0/0/DNMEC+2/NA6/2/2/2/JD/1/B/5/1/
D/ben macintyre1/2/1/1/3B/1/ 3/DG/1/ 1/A9/1/ 8/L3/1/1/ 71/1/1/ N8/1/J/Lord Britt
anbrittan3B6/1/1/ 4/4/N8/1/71/3B6/2/L3/4/4/1/1/DNMEC+2/NA7/2/2/2/IC/1/B/5/1/D/Ol
iver Wright6/3/1/1/A1/1/ 8/A3/1/ 8/*.1/ *.E5/1/1/ 3B6/3/1/ *.*.1/ *.*.1/ 1/4/3B6
/3/E5/*.*.*.1/4/0/1/DNMEC+2/NAB/2/2/2/JL/1/D/5/1/G/damian whitworth2/2/1/1/DD/1/
 1/3B/1/ 3/3K/1/ 2/N8/2/G/Angela WatkinsonGI/1/C/Keith Darvil3B6/3/1/ *.*.1/ 4/4
/GI/3/N8/*.*.*.4/4/1/0/DNMEC+2/NAC/2/2/2/1EK/1/E/2/2/1/ 5/3/1/1/9T/16/Describes 
'perferct' political party39/A2/1/ 8/3C/1/ 4/140/3/G/The Boring Party3K/3/1/ 3L/
3/1/ AB/1/1/ 4/1/*.*.*.*.*.*.4/1/1/1/DNMEC+2/NAD/2/2/2/8K/1/D/1/1/1/ 1/3/1/1/6S/
1/ 39/*.1/ *.*.1/ *.10F/1/1/ 71/1/1/ 70/1/1/ 10M/2/1/ 4/4/10F/1/71/10M/1/70/4/4/
0/0/DNMEC+2/NAG/2/2/2/KS/1/F/3/3/1/ 4/3/1/1/E1/1/ 1/DE/1/ 1/A2/1/ 8/3L/3/1/ 3K/3
/1/ 3D9/3/1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/1/0/DNMEC+2/NAH/2/2/2/4O/1/D/1/2/1/ 1/2/
1/1/DO/1/ 1/3B/1/ 3/3P/1/ 3/3D9/1/F/Kosovan Refugee71/1/1/ 70/1/1/ *.*.1/ 4/4/3D
9/1/71/3D9/3/70/4/1/1/0/DNMHI+2/NDB/2/3/2/E1/1/2/5/1/D/andrew pierce1/3/1/2/3C/1
/ 4/3B/1/ 3/*.1/ *.10M/2/1/ 71/1/1/ JT/3/N/Senior Tory Strategists*.*.1/ 4/4/71/
3/10M/JT/3/10B/2/4/0/0/DNMHI+2/NDD/2/3/2/MK/1/1/1/1/1/ 1/2/1/1/DG/1/ 1/6S/1/ 39/
*.1/ *.10M/2/1/ 71/1/1/ 3K/3/1/ *.*.1/ 4/4/10M/3/71/10M/1/3K/4/4/1/0/DNMHI+2/NDE
/2/3/2/L1/1/1/5/1/D/andrew pierce1/3/1/1/3M/1/ 4/4F/1/ 4/3N/1/ 4/3K/3/1/ 49/3/1/
 3L/3/1/ 3M/3/1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNMHI+2/NDF/2/3/2/G9/1/1/5/1/D/Ben Maci
ntyre1/2/1/1/6J/H/Thatcher's speech39/A9/1/ 8/*.1/ *.10M/2/1/ 71/1/1/ 3L/3/1/ *.
*.1/ 2/2/3B6/3/10M/3B6/2/71/2/2/1/1/DNMHI+2/NDG/2/3/2/RB/1/2/39/2/H/margaret tha
tcher39/2/1/1/A1/1/ 8/DG/1/ 1/DF/1/ 1/3K/3/1/ 3L/3/1/ 70/1/1/ AB/1/1/ 1/3/*.*.*.
*.*.*.1/3/1/1/DNMHI+2/NDH/2/3/2/I8/1/F/1/1/1/ 1/3/1/1/EE/1/ 1/GJ/1A/Difference b
etween Scottish & London MPs1/GJ/H/Devolved politics1/KN/1/1/ 3K/3/1/ 140/3/N/Sc
ottish MPs in General*.*.1/ 4/4/KN/1/3K/*.*.*.4/4/2/0/DNMHI+2/NDK/2/3/2/IH/1/G/1
/1/1/ 1/2/1/1/6Q/1/ 7/3P/1/ 3/6J/15/Labour's "control freak" tendencies2/70/1/1/
 AB/1/1/ E1/2/1/ 3AM/3/1/ 4/4/70/1/3AM/*.*.*.4/4/0/0/DNMHI+2/NDN/2/3/2/80/1/H/5/
1/H/nicholas wapshott1/2/1/1/4E/1/ 4/*.1/ *.*.1/ *.3K/3/1/ 6H/3/M/Socialist Labo
ur Party*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.1/1/0/0/DNMHI+2/NDO/2/3/2/IS/1/H/1/1/1/ 1/
2/2/1/3B/1/ 3/*.1/ *.*.1/ *.H6/2/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.0/1
/DNMHI+2/NDP/2/3/2/12C/1/I/5/2/B/alice miles5/3/1/1/6Q/1/ 7/*.1/ *.*.1/ *.3K/3/1
/ 3AM/3/1/ 70/1/1/ *.*.1/ 4/4/3K/1/3AM/*.*.*.4/4/0/0/DNMHI+2/NDR/2/3/2/HO/1/J/3/
3/1/ 4/3/1/1/3M/1/ 4/*.1/ *.*.1/ *.3K/3/1/ 3L/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*
.4/4/1/0/DNMKO+2/NGL/2/4/2/SQ/1/E/5/1/H/William Rees-Mogg1/3/1/2/3N/1/ 4/*.1/ *.
*.1/ *.3L/3/1/ 3K/3/1/ N8/3/7/VariousGI/3/7/Various4/4/*.*.*.*.*.*.4/4/1/0/DNMKO
+2/NGN/2/4/2/T8/1/1/1/1/1/ 1/3/1/1/6L/1/ 6/*.1/ *.*.1/ *.3K/3/1/ 3L/3/1/ 3M/3/1/
 *.*.1/ 4/4/*.*.*.*.*.*.3/1/0/0/DNMKO+2/NGO/2/4/2/7G/1/1/1/1/1/ 1/4/1/1/DF/1/ 1/
DG/1/ 1/ED/1/ 1/AB/1/1/ 3AC/3/3/CBIN8/3/J/Pro-European Tories*.*.1/ 4/4/*.*.*.*.
*.*.4/4/1/0/DNMKO+2/NGQ/2/4/2/FI/1/D/5/3/N/Jill Sherman GReg Hurst1/3/1/2/42/1/ 
39/6L/1/ 6/*.1/ *.3K/3/1/ GI/3/9/Women MPs3D9/3/J/The Fawcett Society*.*.1/ 4/4/
*.*.*.*.*.*.4/4/0/0/DNMKO+2/NGT/2/4/2/O1/1/F/1/1/1/ 5/2/1/1/GJ/8/The Dome1/3B/1/
 3/3C/1/ 4/KA/1/1/ 3L/3/1/ 3K/3/1/ 70/1/1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNMKO+2/NH0/2
/4/2/KQ/1/F/5/1/G/damian whitworth2/2/1/1/3Q/1/ 2/A1/1/ 8/73/1/ 39/GI/1/G/Andrew
 MackinlayN8/1/C/Mike Penning3B6/3/1/ *.*.1/ 3/4/N8/1/GI/*.*.*.3/4/0/1/DNMKO+2/N
H1/2/4/2/IR/1/G/1/1/1/ 1/4/1/1/DF/1/ 1/GJ/H/Tax harmonisation1/*.1/ *.3L/3/1/ H2
/1/1/ 47/3/1/ 3AG/1/G/Frits Bolkestein4/4/H2/1/47/3AG/1/3L/4/4/1/0/DNMKO+2/NH4/2
/4/2/1H7/1/I/2/1/1/ 5/3/1/1/6Q/1/ 7/DE/1/ 1/*.1/ *.3AM/3/1/ 3K/3/1/ 3L/3/1/ AB/1
/1/ 1/4/*.*.*.*.*.*.1/4/2/0/DNMKO+2/NH5/2/4/2/AF/1/G/1/1/1/ 1/3/1/1/DE/3/VAT1/DT
/1/ 1/*.1/ *.H5/1/1/ 71/1/1/ DP/1/1/ AB/1/1/ 4/4/DP/1/71/H5/1/AB/1/1/1/0/DNMKO+2
/NH6/2/4/2/AO/1/H/5/1/D/ben macintyre1/3/1/1/3N/1/ 4/D9/10/Performance of Lib De
ms in S/W8/*.1/ *.3M/3/1/ KG/1/1/ RE/1/C/Graham Oakes*.*.1/ 4/4/*.*.*.*.*.*.4/4/
0/0/DNMO+3/NK1/2/5/2/M8/1/1/1/1/1/ 1/3/1/1/3C/1/ 4/3F/1/ 2/3F/19/Can negative ca
mpaigning damage society2/3AT/1/12/Archbishops of Canterbury & York3L/3/1/ 3K/3/
1/ AA/1/1/ 4/4/AA/1/3L/3K/1/3L/4/1/1/0/DNMO+3/NK3/2/5/2/E5/1/F/5/1/K/Benedict Ni
ghtingale1/2/1/2/3B/1/ 3/*.1/ *.*.1/ *.70/1/1/ 3B6/3/1/ 3AE/2/G/Charlotte Church
*.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNMO+3/NK6/2/5/2/BQ/1/G/5/1/G/damian whitworth1/2
/1/1/AA/1/ 8/DG/1/ 1/A9/1/ 8/N8/1/A/Ian TaylorN9/3/F/Tory Europhiles3B6/3/1/ *.*
.1/ 4/4/*.*.*.*.*.*.4/4/0/1/DNMO+3/NK8/2/5/2/NO/1/H/1/1/1/ 5/2/1/1/3B/1/ 3/A1/1/
 8/*.1/ *.10I/1/1/ N8/1/H/Jonathan Djanogly3B6/3/1/ *.*.1/ 3/4/3B6/3/10I/*.*.*.3
/4/0/2/DNMO+3/NKA/2/5/2/BD/1/H/5/1/H/nicholas wapshott1/2/1/1/4E/1/ 4/DC/1/ 1/DD
/1/ 1/3L/3/1/ 139/1/13/Lord Bell - Tory advertising guru*.*.1/ *.*.1/ 4/4/*.*.*.
*.*.*.4/4/1/0/DNMO+3/NKB/2/5/2/4G/1/H/1/1/1/ 1/3/1/1/A9/1/ 8/3T/1/ 4/*.1/ *.GJ/1
/O/Lord Stoddart of SwindonE6/1/1/ 140/1/12/Neil Thompson/Socialist allianceE7/1
/1/ 4/4/E7/1/GJ/*.*.*.1/4/0/0/DNMO+3/NKD/2/5/2/FA/1/I/5/1/E/andrew norfolk2/3/1/
1/DD/B/Rural crime1/3B/1/ 3/*.1/ *.N8/2/G/Gillian Shepherd3D9/1/B/Tony Martin3K/
3/1/ 3L/3/1/ 4/4/N8/2/3D9/3K/1/3L/4/4/0/0/DNMO+3/NKG/2/5/2/H1/1/J/5/1/G/magnus l
inklater1/2/1/1/6J/13/Charles Kennedy may lose his seat8/3B/1/ 3/73/1/ 39/72/1/1
/ GI/1/F/Donald Crichton*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNMO+3/NKI/2/5/2/1
E4/1/K/5/1/D/simon jenkins5/3/1/1/A1/12/Sense of humour of party leaders8/A1/1/ 
8/3C/1/ 4/71/1/1/ 70/1/1/ *.*.1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/1/2/DNMO+3/NKJ/2/5/2
/QA/1/K/5/1/D/philip howard5/3/1/1/45/1/ 2/*.1/ *.*.1/ *.3D9/3/17/People who are
 interested in politics3D9/3/1A/People who aren't interested in politics*.*.1/ *
.*.1/ 1/3/*.*.*.*.*.*.1/3/0/0/DNN3I+2/NNB/2/1/2/KN/1/1/5/1/F/russell jenkins1/3/
1/1/DR/1/ 1/DO/1/ 1/6J/L/Playing the race card39/71/1/1/ NN/1/1/ 3N/3/1/ 139/1/B
/Lord Tebbit4/4/NN/1/71/71/1/3M/2/4/0/0/DNN3I+2/NNC/2/1/2/G2/1/1/1/1/1/ 1/3/1/1/
DG/1/ 1/3C/1/ 4/*.1/ *.3AB/3/1/ 71/1/1/ 140/1/E/Alan Sken/UKIPH5/1/1/ 4/4/*.*.*.
*.*.*.4/4/1/0/DNN3I+2/NNE/2/1/2/F6/1/B/5/1/H/nicholas wapshott1/3/1/1/4E/1/ 4/*.
1/ *.*.1/ *.70/1/1/ 3K/3/1/ 272/1/1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/0/1/DNN3I+2/NNG/
2/1/2/GN/1/C/1/1/1/ 1/2/1/1/6J/10/Lib Dems will become 2nd party8/A3/1/ 8/*.1/ *
.72/1/1/ 3K/3/1/ 3L/3/1/ 3M/3/1/ 4/4/72/1/3K/72/1/3L/4/4/1/0/DNN3I+2/NNH/2/1/2/9
G/1/C/5/2/C/frances gibb1/3/1/1/6J/T/Numbering of election ballots4/*.1/ *.*.1/ 
*.3D9/3/7/Liberty42/3/1/ *.*.1/ *.*.1/ 4/4/3D9/1/42/*.*.*.4/4/0/0/DNN3I+2/NNM/2/
1/2/F4/1/D/5/1/G/damian whitworth1/3/1/1/73/1/ 39/3L/1/ 4/3B/1/ 3/GI/1/F/Simon C
harletonN8/1/G/Crispin Blunt MPRE/2/A/Jane Kulka*.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/D
NN3I+2/NNN/2/1/2/D8/1/D/5/1/E/mark henderson2/3/1/1/D9/16/Facial features indica
te personality8/*.1/ *.*.1/ *.70/1/1/ 71/1/1/ 3D9/1/10/Evan Fotis - character an
alyst*.*.1/ 4/4/3D9/2/70/3D9/2/71/2/2/0/2/DNN3I+2/NNO/2/1/2/5P/1/D/1/1/1/ 1/3/1/
1/3C/1/ 4/D9/T/Focus on leader's personality8/A1/1/ 8/3K/3/1/ 71/1/1/ DO/1/1/ KS
/3/1/ 4/4/3K/1/71/KS/1/3K/4/4/0/1/DNN3I+2/NNP/2/1/2/1FO/1/E/5/1/H/William Rees-M
ogg5/3/1/2/DG/1/ 1/*.1/ *.*.1/ *.70/1/1/ 3L/3/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.*.*.2
/2/1/0/DNN6O+2/NQL/2/2/2/MJ/1/D/3/3/1/ 4/3/1/1/DF/1/ 1/*.1/ *.*.1/ *.3B9/1/1/ 3A
G/1/8/Schroder70/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNN6O+2/NQN/2/2/2/QG/1/1/1/
1/1/ 1/4/1/1/6J/F/Jospin's speech39/DF/1/ 1/3C/1/ 4/70/1/1/ 3AG/1/D/Lionel Jospi
nH2/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNN6O+2/NQO/2/2/2/I3/1/1/5/1/D/andrew pi
erce1/3/1/1/DR/1/ 1/3C/1/ 4/*.1/ *.10M/2/1/ 3Q/3/1/ N8/1/1D/Shailesh Vara (candi
date Northampton South)*.*.1/ 4/4/10M/3/N8/*.*.*.4/4/0/0/DNN6O+2/NQP/2/2/2/HR/1/
2/1/1/1/ 1/1/1/1/DF/1/ 1/6J/17/Divisions in Europe - Jospin's speech39/*.1/ *.3A
G/1/D/Lionel Jospin*.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.2/0/DNN6O+2/NQR/2/2/
2/IE/1/6/4/1/1/ 2/3/1/1/DQ/1/ 1/A1/1/ 8/*.1/ *.13T/1/D/David Simpson77/1/1/ 3T/3
/1/ 40/3/1/ 4/4/13T/1/77/*.*.*.4/4/1/0/DNN6O+2/NQS/2/2/2/N3/1/7/1/1/1/ 5/2/2/1/A
A/1/ 8/*.1/ *.*.1/ *.N8/1/H/Michael Fabricant3B6/3/1/ *.*.1/ *.*.1/ 3/4/3B6/3/N8
/*.*.*.3/4/0/2/DNN6O+2/NQT/2/2/2/HT/1/7/5/1/G/damian whitworth1/2/1/1/3B/1/ 3/E4
/1/ 1/DJ/1/ 1/N8/1/E/Philip Hammond3B6/3/1/ 42/3/1/ *.*.1/ 4/4/3B6/3/N8/N8/1/42/
3/4/1/0/DNN6O+2/NR1/2/2/2/RO/1/8/5/1/D/Ben MacIntyre2/3/1/1/DR/1/ 1/73/1/ 39/DO/
1/ 1/3B6/3/1/ 3D9/3/M/Constituency Residents*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/
0/DNNA+3/O01/2/3/2/O7/1/1/1/1/1/ 1/3/1/1/DG/1/ 1/3C/1/ 4/*.1/ *.71/1/1/ 70/1/1/ 
AG/2/1/ 10I/1/1/ 4/4/AG/3/70/10I/1/70/2/2/1/1/DNNA+3/O03/2/3/2/I5/1/8/1/1/1/ 1/3
/1/1/DR/1/ 1/DO/1/ 1/A9/1/ 8/N9/3/H/Tory Reform Group71/1/1/ *.*.1/ *.*.1/ 4/4/N
9/1/71/*.*.*.4/1/1/0/DNNA+3/O06/2/3/2/MM/1/9/5/1/D/Ben MacIntyre2/3/1/1/AA/1/ 8/
73/1/ 39/*.1/ *.13R/1/A/Adam Price3O/3/1/ 3K/3/1/ 6J/3/A/Old Labour4/4/6J/1/3K/*
.*.*.4/4/1/1/DNNA+3/O09/2/3/2/I0/1/A/5/2/J/patience wheatcroft1/3/1/1/AC/1/ 9/ED
/1/ 1/*.1/ *.3K/3/1/ AB/1/1/ *.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/2/0/DNNA+3/O0B/2/
3/2/133/1/E/5/1/9/tim hames5/3/1/1/DG/1/ 1/*.1/ *.*.1/ *.70/1/1/ 71/1/1/ 3B6/3/1
/ 42/3/1/ 4/4/71/1/42/*.*.*.4/4/1/0/DNND6+2/O3B/2/4/2/72/1/1/1/1/1/ 1/3/1/2/6L/1
/ 6/*.1/ *.*.1/ *.72/1/1/ 3M/3/1/ 3K/3/1/ 3L/3/1/ 4/4/*.*.*.*.*.*.3/3/0/0/DNND6+
2/O3C/2/4/2/K5/1/2/4/1/1/ 1/3/1/1/A2/1/ 8/EF/1/ 1/E7/1/ 1/D9/1/T/John Hutton (He
alth Minister)AD/1/1/ 3M/3/1/ *.*.1/ 4/4/3M/1/3K/*.*.*.4/4/2/0/DNND6+2/O3F/2/4/2
/D8/1/D/5/1/9/tim hames2/3/1/1/3L/1/ 4/*.1/ *.*.1/ *.3K/3/1/ 3M/3/1/ 3L/3/1/ 70/
1/1/ 4/1/*.*.*.*.*.*.4/1/0/0/DNND6+2/O3G/2/4/2/EP/1/E/1/1/1/ 1/3/2/2/6L/1/ 6/*.1
/ *.*.1/ *.3K/3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNND6+2/O3H/2/
4/2/AE/1/E/5/1/A/greg hurst1/2/1/1/3B/1/ 3/4C/1/ 39/6L/1/ 6/72/1/1/ 3M/3/1/ 3AE/
2/E/Honor BlackmanN9/1/O/John Lee (tory defector)4/4/3AE/3/72/*.*.*.4/4/0/0/DNND
6+2/O3I/2/4/2/BC/1/E/1/1/1/ 1/3/1/2/6L/1/ 6/6M/1/ 6/*.1/ *.3AR/3/1/ 3K/3/1/ 3L/3
/1/ 3M/3/1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNND6+2/O3L/2/4/2/79/1/F/5/1/D/oliver wright
1/3/1/1/GJ/T/Violence against health staff1/*.1/ *.*.1/ *.3AQ/1/5/Nurse70/1/1/ *
.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNND6+2/O3M/2/4/2/J7/1/F/5/1/D/Ben MacIntyr
e39/3/2/2/72/18/Blair's hand movements (body language)7/*.1/ *.*.1/ *.70/1/1/ *.
*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.0/0/DNND6+2/O3N/2/4/2/K1/1/G/1/1/1/ 1/2/1
/1/3C/1/ 4/AE/1/ 39/A9/1/ 8/H5/1/1/ N8/3/J/Pro-European Tories3L/3/1/ *.*.1/ 3/4
/*.*.*.*.*.*.3/4/0/0/DNND6+2/O3O/2/4/2/A3/1/G/1/1/1/ 1/2/1/1/3B/1/ 3/6O/P/Tories
 predict late swing6/AE/1/ 39/KE/1/1/ 3AR/3/D/Opinion Polls3B6/3/1/ *.*.1/ 4/4/K
E/1/3AR/KE/3/3B6/4/4/0/0/DNND6+2/O3P/2/4/2/DH/1/G/1/1/1/ 1/2/1/1/AE/1/ 39/73/1/ 
39/3B/1/ 3/GI/1/B/David Davis71/1/1/ *.*.1/ *.*.1/ 2/4/GI/2/71/*.*.*.2/4/0/0/DNN
D6+2/O3S/2/4/2/DR/1/H/1/1/1/ 1/2/1/2/DG/1/ 1/DE/1/ 1/*.1/ *.70/1/1/ 71/1/1/ *.*.
1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNND6+2/O40/2/4/2/126/1/I/5/2/B/alice miles5/3
/1/1/3B/1/ 3/3C/1/ 4/3J/1/ 2/3K/3/1/ 3L/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1
/1/DNND6+2/O41/2/4/2/1ET/1/I/2/1/1/ 5/3/1/1/DG/1/ 1/GJ/12/Issues resulting from 
referendum1/*.1/ *.70/1/1/ AB/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNNGC+2
/O6L/2/5/2/K3/1/1/1/1/1/ 1/3/1/1/4D/1/ 39/3T/K/Dishing out peerages4/3T/1/ 4/6J/
3/D/Departing MPs3K/3/1/ 3L/3/1/ 3M/3/1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNNGC+2/O6M/2/5
/2/PL/1/1/1/1/1/ 1/2/1/1/AE/1/ 39/A2/1/ 8/DG/1/ 1/70/1/1/ *.*.1/ *.*.1/ *.*.1/ 4
/*.*.*.*.*.*.*.4/*.2/0/DNNGC+2/O6N/2/5/2/285/1/9/5/1/E/peter stothard6/3/1/1/A1/
1/ 8/DG/1/ 1/EA/1/ 1/70/1/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.3/2/DNNGC+
2/O6P/2/5/2/DS/1/A/1/1/1/ 1/3/1/2/6L/1/ 6/DI/1/ 1/*.1/ *.3K/3/1/ 3B6/3/1/ *.*.1/
 *.*.1/ 2/4/*.*.*.*.*.*.2/4/1/0/DNNGC+2/O6R/2/5/2/N1/1/C/1/1/1/ 5/2/2/1/6J/1F/Te
d Heath lunches with successor (in private)39/A1/1/ 8/*.1/ *.10F/1/1/ 3D9/1/C/Pu
b LandlordN8/1/C/Derek Conway*.*.1/ 2/4/N8/3/10F/3D9/2/10F/2/4/0/1/DNNGC+2/O6T/2
/5/2/4Q/1/B/1/2/1/ 1/2/1/1/3P/1/ 3/DB/1/ 1/*.1/ *.3D9/3/7/Parents70/1/1/ D9/2/D/
Yvette Cooper*.*.1/ 4/4/3D9/1/70/3D9/1/D9/4/1/1/0/DNNGC+2/O70/2/5/2/I0/1/C/1/1/1
/ 2/3/1/1/6J/1L/Cabinet ministers 'missing' from the campaign trail8/*.1/ *.*.1/
 *.DM/1/1/ DP/1/1/ E2/1/1/ D9/3/P/Various Cabinet Ministers1/1/*.*.*.*.*.*.1/1/0
/0/DNNGC+2/O73/2/5/2/HR/1/D/1/1/1/ 1/2/1/2/3R/1/ 2/6L/1/ 6/*.1/ *.71/1/1/ 3K/3/1
/ 10M/2/1/ *.*.1/ 4/4/71/1/3K/10M/1/3K/4/4/1/0/DNNGC+2/O76/2/5/2/KG/1/J/3/3/1/ 4
/3/1/1/DB/1/ 1/E7/1/ 1/*.1/ *.3K/3/1/ 70/1/1/ 3AQ/3/7/Doctors*.*.1/ 2/2/*.*.*.*.
*.*.2/2/2/0/DNNQ+3/OA1/2/1/2/J2/1/1/1/1/1/ 1/3/1/1/3R/1/ 2/4A/1/ 4/A1/F/arrogant
 labour8/70/1/1/ 3L/3/1/ 71/1/1/ 3K/3/1/ 4/4/70/1/3L/71/1/3K/4/4/0/1/DNNQ+3/OA2/
2/1/2/H9/1/2/5/1/C/nigel hawkes1/3/1/1/9T/S/Panorama programme incorrect39/DB/1/
 1/*.1/ *.3K/3/1/ 3AM/3/8/PanoramaD9/1/T/John Denham - health minister3D9/1/K/Ch
arity - Kings Fund4/4/3K/1/3AM/3D9/2/3K/4/4/0/0/DNNQ+3/OA4/2/1/2/8B/1/7/5/3/A/Sa
m Lister39/3/1/1/6J/R/Will weather affect turnout39/3Q/1/ 2/*.1/ *.3D9/1/L/Met O
ffice Forecaster3K/3/1/ 10M/2/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNNQ+3/OA8/2/1/2
/C8/1/8/1/1/1/ 1/3/1/1/DG/1/ 1/3M/1/ 4/*.1/ *.49/3/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*
.*.*.*.*.*.4/*.0/0/DNNQ+3/OA9/2/1/2/HH/1/9/5/1/C/Adam Sherwin2/3/1/2/3L/1/ 4/*.1
/ *.*.1/ *.GI/1/B/Mark EreiraN8/1/D/David Ruffley70/1/1/ *.*.1/ 4/4/N8/1/70/*.*.
*.4/4/1/0/DNNQ+3/OAA/2/1/2/5J/1/9/1/1/1/ 1/2/1/2/48/1/ 5/6S/1/ 39/*.1/ *.70/1/1/
 3B6/3/C/Young Voters3AE/3/J/Various Celebreties*.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/D
NNT6+2/ODB/2/2/2/L0/1/1/1/1/1/ 1/3/1/1/GJ/Q/Minimum wage for under 21s1/A9/1/ 8/
4C/1/ 39/AB/1/1/ 70/1/1/ N8/1/1A/Anthony Nelson (Tory) defected to Labour3D9/3/I
/Low Pay Commission4/4/*.*.*.*.*.*.4/4/1/0/DNNT6+2/ODC/2/2/2/9B/1/1/1/1/1/ 1/2/1
/1/6J/E/Text messaging4/48/1/ 5/3C/1/ 4/3K/3/1/ E7/3/1/ 3D9/3/C/Young Voters*.*.
1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNNT6+2/ODD/2/2/2/SB/1/7/5/2/B/Alice Miles2/3/1/2/3Q/
1/ 2/3K/1/ 2/*.1/ *.3K/3/1/ 3B6/3/1/ 70/1/1/ GI/1/E/Peter Kilfoyle4/4/3B6/1/3K/3
B6/1/70/1/4/0/0/DNNT6+2/ODG/2/2/2/9O/1/8/5/1/H/nicholas wapshott1/2/1/1/3B/M/Bla
ir/Paxman interview3/9T/G/Paxman not tough39/*.1/ *.70/1/1/ 3AL/1/D/Jeremy Paxma
n*.*.1/ *.*.1/ 4/1/*.*.*.*.*.*.4/1/0/0/DNNT6+2/ODI/2/2/2/HC/1/9/1/1/1/ 5/2/1/1/D
9/1E/Women candidates in Lincoln (3 main parties)8/3B/1/ 3/*.1/ *.GI/2/E/Gillian
 MarronN8/2/G/Christine TalbotRE/2/C/Lisa Gabriel*.*.1/ 4/4/N9/1/GI/*.*.*.4/4/0/
1/DNNT6+2/ODJ/2/2/2/7N/1/9/1/1/1/ 1/2/1/1/43/1/ 4/A2/1/ 8/*.1/ *.70/1/1/ 3K/3/1/
 72/1/1/ 3M/3/1/ 4/1/72/1/70/*.*.*.4/1/1/0/DNNT6+2/ODM/2/2/2/LL/1/A/5/1/H/willia
m rees-mogg5/3/1/1/EE/1/ 1/EA/1/ 1/*.1/ *.13Q/1/C/Alex SalmondKN/1/1/ GI/1/B/Tam
 DalyellNL/1/1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNNT6+2/ODN/2/2/2/BG/1/A/5/1/G/Damian Wh
itworth1/2/1/1/3B/1/ 3/4A/1/ 4/*.1/ *.13Q/1/C/Pete Wishart4B/3/1/ 3N/3/1/ *.*.1/
 4/4/13Q/1/4B/*.*.*.4/4/0/0/DNNT6+2/ODO/2/2/2/125/1/E/5/1/C/michael gore5/3/1/1/
6J/2B/Tendency for voters to want to be on the winning side & kick the losers39/
3R/1/ 2/*.1/ *.3K/3/1/ 3L/3/1/ *.*.1/ *.*.1/ 1/2/*.*.*.*.*.*.1/2/1/0/DNO2C+2/OGL
/2/3/2/II/1/1/1/1/1/ 1/3/1/1/A2/1/ 8/EA/1/ 1/*.1/ *.AB/1/1/ 70/1/1/ 71/1/1/ *.*.
1/ 4/4/71/1/70/*.*.*.4/4/2/0/DNO2C+2/OGM/2/3/2/73/1/1/4/1/1/ 1/3/1/1/DI/1/ 1/*.1
/ *.*.1/ *.3K/3/1/ 3AB/3/8/The City70/1/1/ 3AF/3/1/ 4/4/3AB/3/70/*.*.*.3/4/1/0/D
NO2C+2/OGP/2/3/2/DJ/1/9/5/2/E/Helen Rumbelow1/3/1/2/6S/1/ 39/*.1/ *.*.1/ *.3K/3/
1/ 3AE/2/G/Michelle Collins3AE/1/11/Peter Reid (Sunderland Manager)3L/3/1/ 4/4/3
AE/3/3K/3AE/3/3K/3/4/0/0/DNO2C+2/OGQ/2/3/2/HM/1/A/5/1/D/ben macintyre1/3/1/1/73/
1/ 39/A3/1/ 8/EH/1/ 1/RE/1/B/Keith SharpAF/1/1/ 3K/3/1/ *.*.1/ 4/4/RE/1/3K/RE/2/
AF/4/2/0/0/DNO2C+2/OH2/2/3/2/FH/1/C/1/1/1/ 1/3/1/2/3G/1/ 39/*.1/ *.*.1/ *.E5/1/1
/ 70/1/1/ DL/2/1/ H2/1/1/ 4/4/*.*.*.*.*.*.1/1/0/0/DNO2C+2/OH5/2/3/2/N6/1/C/3/3/1
/ 39/3/2/2/6Q/1F/Assessing performance of key election players7/*.1/ *.*.1/ *.GI
/3/R/Key Labour Campaign PlayersN8/3/13/Key Conservative Campaign PlayersRE/1/S/
Key Lib Dem campaign players140/1/Q/Other Key Campaign Players2/2/*.*.*.*.*.*.2/
2/0/0/DNO2C+2/OH6/2/3/2/126/1/G/5/2/B/alice miles5/3/2/1/6J/13/Tories out of tou
ch with electors8/D9/T/Tories forget core principles8/*.1/ *.3L/3/1/ 71/1/1/ 3K/
3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNO2C+2/OH7/2/3/2/1HA/1/G/5/1/D/simon jenkin
s5/3/1/1/6J/10/The state of British democracy39/6J/1I/Controlling government vs 
empowered institutions39/*.1/ *.42/3/1/ 70/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/
1/1/0/DNO2C+2/OH8/2/3/2/Q8/1/G/2/1/1/ 5/3/2/1/3C/1/ 4/3C/1D/Why Tony holds a mug
 & not a cup and saucer4/3S/1/ A/GJ/3/J/Labour Spin Doctors70/1/1/ *.*.1/ *.*.1/
 1/1/*.*.*.*.*.*.1/1/0/0/DNO2C+2/OH9/2/3/2/9K/1/B/1/1/1/ 1/2/1/1/3B/1/ 3/6J/20/E
lection gives opportunity to leave Thatcherism & 80s behind39/*.1/ *.70/1/1/ 10M
/2/1/ *.*.1/ *.*.1/ 4/4/70/1/10M/*.*.*.4/4/0/0/DNO5I+2/OK1/2/4/2/NC/1/1/1/1/1/ 1
/3/1/1/6L/1/ 6/3R/1/ 2/*.1/ *.3K/3/1/ 71/1/1/ 3M/3/1/ 70/1/1/ 4/1/*.*.*.*.*.*.4/
1/0/0/DNO5I+2/OK4/2/4/2/GM/1/A/1/1/1/ 1/2/1/1/3Q/1/ 2/3B/1/ 3/4A/1/ 4/70/1/1/ GJ
/3/A/Supporters3L/3/1/ *.*.1/ 4/4/70/1/3L/*.*.*.4/4/0/0/DNO5I+2/OK7/2/4/2/127/1/
B/1/1/1/ 2/3/1/1/AE/1/ 39/*.1/ *.*.1/ *.71/1/1/ 6J/3/I/The Shadow CabinetH5/1/1/
 *.*.1/ 4/4/6J/1/71/*.*.*.4/1/0/0/DNO5I+2/OK9/2/4/2/FD/1/C/5/1/B/greg watson1/3/
1/1/3C/1/ 4/6J/18/Lib Dems policies largely unchallenged8/*.3/4301/72/1/1/ 3M/3/
1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNO5I+2/OKA/2/4/2/MI/1/C/5/1/D/ben maci
ntyre1/2/1/1/3B/1/ 3/6J/13/Increased polularity for Lib Dems8/*.1/ *.N8/1/C/Anto
ny SteenRE/2/D/Rachel Oliver72/1/1/ *.*.1/ 1/2/N8/1/RE/RE/1/N8/1/2/0/1/DNO5I+2/O
KD/2/4/2/DN/1/E/1/1/1/ 1/3/1/2/6L/1/ 6/EA/1/ 1/*.1/ *.3B6/3/1/ 71/1/1/ 72/1/1/ 7
0/1/1/ 4/4/*.*.*.*.*.*.4/1/1/0/DNO5I+2/OKG/2/4/2/CD/1/E/5/2/E/helen rumbelow1/3/
1/1/6O/1/ 6/*.1/ *.*.1/ *.3AR/3/1/ 6J/3/I/Three Main Parties*.*.1/ *.*.1/ 4/4/3A
R/2/6J/*.*.*.4/4/0/0/DNO5I+2/OKK/2/4/2/Q8/1/I/5/2/G/maryann sieghart5/3/1/1/9T/N
/Why author loves voting39/*.1/ *.*.1/ *.46/3/1/ 3D9/3/6/Cynics*.*.1/ *.*.1/ 2/1
/*.*.*.*.*.*.2/1/0/0/DNO5I+2/OKL/2/4/2/L5/1/J/3/3/1/ 4/3/1/1/9T/K/Urge readers t
o vote39/3Q/1/ 2/6J/O/British election process4/3K/3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 4
/4/*.*.*.*.*.*.4/4/1/0/DNO5I+2/OKM/2/4/2/7L/1/1/1/1/1/ 1/3/1/1/3Q/1/ 2/6J/S/Effe
ct of weather on turnout39/*.1/ *.3AE/1/D/David Beckham3K/3/1/ *.*.1/ *.*.1/ 4/4
/*.*.*.*.*.*.4/4/0/0/DNL2O+2/13DB/3/3/2/52/1/5/1/2/1/ 1/3/1/2/3C/1/ 4/3E/1/ 2/*.
1/ *.270/2/1/ 70/1/1/ E8/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNL2O+2/13DC/3/3/2/
HD/1/5/1/1/1/ 1/2/1/2/3B/1/ 3/*.1/ *.*.1/ *.71/1/1/ 70/1/1/ 3B6/3/1/ *.*.1/ 1/4/
71/1/70/*.*.*.1/4/1/0/DNL2O+2/13DF/3/3/2/EM/1/6/4/1/1/ 1/2/1/1/DF/1/ 1/DG/1/ 1/*
.1/ *.AC/1/1/ 6J/3/S/Party of European SocialistsH2/1/1/ *.*.1/ 4/4/H2/1/AC/*.*.
*.4/4/1/0/DNL2O+2/13DH/3/3/2/H6/1/4/5/2/G/rachel sylvester1/3/1/1/A5/1/ 9/E3/1/ 
1/*.1/ *.70/1/1/ 3K/3/1/ 6J/3/C/Backbenchers*.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNL2O
+2/13DJ/3/3/2/S2/1/4/1/1/1/ 1/2/1/2/3D/1/ 3/3C/1/ 4/A2/1/ 8/70/1/1/ 71/1/1/ 3K/3
/1/ 3L/3/1/ 2/2/*.*.*.*.*.*.2/1/1/1/DNL2O+2/13DN/3/3/2/RJ/1/N/3/3/1/ 4/3/1/1/3K/
1/ 2/A1/J/Arrogance of Labour8/E1/1/ 1/70/1/1/ 3K/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*
.*.*.1/1/1/0/DNL2O+2/13DO/3/3/2/IL/1/1/1/1/1/ 8/3/2/1/9T/E/Election fever39/3D/1
/ 3/*.1/ *.3D9/3/D/Election Fans70/1/1/ *.*.1/ *.*.1/ 4/1/*.*.*.*.*.*.4/1/0/0/DN
L2O+2/13DP/3/3/2/TJ/1/1/1/1/1/ 1/2/1/1/3D/1/ 3/3B/1/ 3/6L/1/ 6/70/1/1/ 71/1/1/ 7
2/1/1/ 3K/3/1/ 4/4/71/1/3K/*.*.*.4/4/1/0/DNL6+3/13GL/3/4/2/MC/1/5/1/1/1/ 1/3/1/2
/3C/1/ 4/6J/1E/Reaction to Blair's opening speech at school39/*.1/ *.70/1/1/ GI/
3/A/Labour MPs71/1/1/ DO/1/1/ 4/4/GI/1/70/71/1/70/1/4/1/0/DNL6+3/13GM/3/4/2/BP/1
/4/1/1/1/ 1/2/1/2/3B/1/ 3/DE/1/ 1/DG/1/ 1/70/1/1/ 3B6/2/1/ 71/1/1/ *.*.1/ 4/4/70
/1/71/*.*.*.4/4/1/0/DNL6+3/13GP/3/4/2/124/1/N/39/1/D/Boris Johnson5/3/1/1/A3/1/ 
8/EA/1/ 1/*.1/ *.3K/3/1/ 3L/3/1/ *.*.1/ *.*.1/ 1/3/*.*.*.*.*.*.1/3/2/1/DNL6+3/13
GQ/3/4/2/74/1/5/5/2/H/Rachael Sylvester1/2/1/1/DD/1/ 1/A6/1/ 9/*.1/ *.3L/3/1/ H6
/2/1/ 6J/3/N/Criminal Justice System*.*.1/ 4/4/H6/1/6J/*.*.*.4/4/2/0/DNL6+3/13GR
/3/4/2/OR/1/1/1/1/1/ 1/3/1/1/A6/1/ 9/E9/1/ 1/DE/1/ 1/71/1/1/ 3L/3/1/ 70/1/1/ 3K/
3/1/ 4/4/3K/1/3L/71/1/70/4/4/2/0/DNL6+3/13GS/3/4/2/NM/1/4/1/1/1/ 1/3/1/1/6L/1/ 6
/*.1/ *.*.1/ *.3K/3/1/ 3L/3/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/0/0/DNL6+3/13H0
/3/4/2/150/1/M/5/1/E/daniel johnson5/3/1/1/3D/1/ 3/*.1/ *.*.1/ *.70/1/1/ 3K/3/1/
 3AQ/2/R/Irene Bishop (Head teacher)*.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNL6+3/13H1/3
/4/2/7A/1/4/4/2/1/ 2/3/1/1/DB/1/ 1/6J/T/Doctors turn away from labour39/6L/1/ 6/
3D9/3/7/Doctors3K/3/1/ H0/1/1/ 70/1/1/ 4/1/3D9/1/3K/H0/1/70/4/1/0/0/DNL96+2/13K1
/3/5/2/95/1/5/5/1/E/david millward1/3/1/2/40/1/ 4/43/1/ 4/A2/1/ 8/3M/3/1/ 72/1/1
/ 3K/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNL96+2/13K2/3/5/2/F0/1/7/1/1/1/ 1/3/1/
2/3T/1/ 4/*.1/ *.*.1/ *.GI/1/F/David MillibandE6/1/1/ 70/1/1/ *.*.1/ 4/4/*.*.*.*
.*.*.4/4/0/0/DNL96+2/13K3/3/5/2/I4/1/6/1/2/1/ 1/3/1/2/3C/1/ 4/6J/18/Gender balan
ced campaign, use of women4/49/1/ 5/3K/3/1/ 29T/2/E/Leader's WivesGI/2/9/Women M
Ps*.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNL96+2/13K4/3/5/2/IG/1/C/5/1/I/michael kallenb
ach1/1/1/2/6J/11/Government accused of climbdown8/GJ/P/Community health councils
1/*.1/ *.42/3/1/ 45/3/1/ D9/1/1/ *.*.1/ 4/4/45/1/42/*.*.*.1/4/1/0/DNL96+2/13K6/3
/5/2/1O0/1/5/1/1/1/ 5/3/1/1/A6/1/ 9/EA/1/ 1/*.1/ *.3L/3/1/ *.*.1/ *.*.1/ *.*.1/ 
2/*.*.*.*.*.*.*.2/*.3/0/DNL96+2/13K7/3/5/2/O1/1/1/1/1/1/ 1/3/1/2/DE/1/ 1/E1/1/ 1
/*.1/ *.AB/1/1/ 71/1/1/ 3K/3/1/ 3L/3/1/ 4/4/AB/1/3L/3L/1/3K/1/4/3/0/DNL96+2/13K8
/3/5/2/M4/1/2/1/1/1/ 8/1/2/1/6J/N/Last days of Parliament39/4D/1/ 39/DR/1/ 1/10F
/1/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 1/4/3K/2/10F/*.*.*.1/4/0/1/DNL96+2/13KC/3/5/2/KA/1/
D/1/1/1/ 1/1/1/1/DH/1/ 1/46/1/ 5/DE/1/ 1/AB/1/1/ H5/1/1/ 3L/3/1/ 3K/3/1/ 4/4/H5/
1/AB/AB/1/3L/4/4/1/0/DNL96+2/13KD/3/5/2/14N/1/Q/2/1/1/ 5/3/1/1/3Q/1/ 2/3E/1/ 2/3
K/1/ 2/46/3/1/ 6J/3/E/Party Managers3AM/3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNL9
6+2/13KE/3/5/2/12L/1/R/5/2/D/Alice Thomson5/3/1/1/6S/1/ 39/A1/1/ 8/A1/10/Compare
 Hague to Bridget Jones8/71/1/1/ 72/1/1/ *.*.1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/1/2/D
NLIO+2/13NB/3/1/2/ON/1/1/1/1/1/ 1/2/1/2/3T/1/ 4/GJ/1/ 1/*.1/ *.70/1/1/ E6/1/1/ 1
0B/1/1/ 71/1/1/ 4/4/10B/1/70/71/1/70/2/4/1/0/DNLIO+2/13NC/3/1/2/CC/1/6/1/2/1/ 1/
3/1/2/A1/1/ 8/6L/1/ 6/A9/1/ 8/72/1/1/ QJ/3/F/Senior Lib DemsRA/3/1/ 3M/3/1/ 4/4/
RE/1/72/TT/3/72/1/4/0/1/DNLIO+2/13NG/3/1/2/6O/1/5/1/1/1/ 1/3/1/1/AD/1/ 39/A9/1/ 
8/*.1/ *.70/1/1/ AB/1/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNLIO+2/13NH/3/1/
2/KC/1/1/4/1/1/ 1/3/1/1/DD/1/ 1/*.1/ *.*.1/ *.3AN/3/I/Police FederationsAH/1/1/ 
3L/3/1/ 3K/3/1/ 4/4/3AN/1/3K/*.*.*.4/4/1/0/DNLIO+2/13NI/3/1/2/D2/1/5/1/1/1/ 1/3/
1/1/6J/1A/Bremner not allowed on Labour battle bus3/3C/1/ 4/*.1/ *.3AE/1/C/Rory 
Bremner3K/3/1/ 3L/3/1/ *.*.1/ 4/1/3AE/1/3K/3L/1/3K/4/1/0/0/DNLIO+2/13NJ/3/1/2/CE
/1/5/1/1/1/ 1/3/1/1/3I/1/ 3/*.1/ *.*.1/ *.3L/3/1/ 70/1/1/ 3AM/3/1/ *.*.1/ 4/4/*.
*.*.*.*.*.3/4/0/0/DNLIO+2/13NK/3/1/2/D8/1/6/4/2/1/ 1/4/1/1/DG/1/ 1/6J/P/Joining 
Euro un-christian39/*.1/ *.3AB/1/I/Graeme Leach (IOD)47/3/1/ *.*.1/ *.*.1/ 4/4/3
AB/1/47/*.*.*.4/4/0/0/DNLIO+2/13NN/3/1/2/IG/1/L/3/3/1/ 4/3/1/1/3T/1/ 4/A1/1/ 8/*
.1/ *.E6/1/1/ 70/1/1/ 71/1/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/2/DNLIO+2/13NO/3/1/2/
HD/1/7/4/1/1/ 1/3/1/1/DQ/L/Good Friday agreement1/A9/1/ 8/A1/1/ 8/13T/1/B/Lady H
ermon140/3/O/Anti-Agreement Unionists*.*.1/ *.*.1/ 4/4/140/1/13T/*.*.*.4/4/0/1/D
NLIO+2/13NP/3/1/2/N9/1/5/1/1/1/ 1/2/1/1/3B/1/ 3/A2/1/ 8/D9/L/New Labour's Big Id
ea8/70/1/1/ GJ/3/D/Party Members*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/1/DNLM+3/13Q
L/3/2/2/72/1/4/1/1/1/ 1/3/1/2/4C/1/ 39/*.1/ *.*.1/ *.GJ/1/A/Alan Sugar3B8/2/1/ E
6/1/1/ AB/1/1/ 1/4/*.*.*.*.*.*.1/4/0/0/DNLM+3/13QO/3/2/2/PE/1/6/5/1/C/sean o'nei
ll1/2/1/2/73/1/ 39/3H/2H/Supposed takeover of cons association by members of pen
ial pentecostal church39/A9/1/ 8/10B/1/1/ 3B6/3/M/Brentwood ConstituentsL4/1/1/ 
*.*.1/ 4/4/3B6/2/10B/3B6/2/L4/4/4/0/1/DNLM+3/13QS/3/2/2/PN/1/1/1/1/1/ 1/3/1/1/3C
/1/ 4/3E/1/ 2/3G/1/ 39/70/1/1/ DS/1/1/ 3K/3/1/ 3L/3/1/ 1/4/DS/1/3K/70/1/3L/1/4/1
/0/DNLM+3/13R1/3/2/2/JA/1/4/1/1/1/ 1/2/1/2/3B/1/ 3/3E/1/ 2/*.1/ *.70/1/1/ *.*.1/
 *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/0/DNLM+3/13R3/3/2/2/AB/1/7/5/2/G/rachel syl
vester1/1/1/1/3T/12/MPs offered bribes to stand down4/*.1/ *.*.1/ *.139/3/18/Hou
se of Lords Appointments Commission3K/3/1/ GI/3/I/Various Labour MPs*.*.1/ 4/4/1
39/1/3K/*.*.*.4/1/0/0/DNLM+3/13RA/3/2/2/KI/1/N/3/3/1/ 4/3/1/1/3G/1/ 39/*.1/ *.*.
1/ *.70/1/1/ 3AL/1/E/John HumphreysE5/1/1/ GI/1/H/Geoffrey Robinson1/4/3AL/1/70/
*.*.*.1/4/0/0/DNLM+3/13RC/3/2/2/CH/1/5/1/2/1/ 1/2/1/1/3B/1/ 3/A1/1/ 8/*.1/ *.H6/
2/1/ 3B6/1/1/ *.*.1/ *.*.1/ 3/4/3B6/3/H6/*.*.*.3/4/0/1/DNLP6+2/1401/3/3/2/CE/1/9
/1/1/1/ 1/3/1/2/6J/M/Call for EU referendum39/A9/1/ 8/*.1/ *.3D9/1/17/Paul Sykes
 - Euro Sceptic Millionaire3L/3/1/ 6J/3/1C/MPs in favour of eu memebership refer
endum71/1/1/ 4/4/3D9/1/3L/*.*.*.4/4/1/0/DNLP6+2/1402/3/3/2/J9/1/N/3/3/1/ 4/3/1/2
/DE/1/ 1/A9/1/ 8/EB/1/ 1/3L/3/1/ 3K/3/1/ KK/1/1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/1/0/
DNLP6+2/1404/3/3/2/LQ/1/8/5/2/G/rachel sylvester2/3/1/2/6J/15/Party analysis of 
manifesto content9/EA/1/ 1/*.1/ *.3K/3/1/ GI/3/C/Left-Wingers70/1/1/ *.*.1/ 4/4/
*.*.*.*.*.*.4/4/2/0/DNLP6+2/1406/3/3/2/AB/1/6/1/1/1/ 1/2/1/1/A5/1/ 9/6J/1G/Conse
rvatives held nation back in 21st century8/A2/1/ 8/70/1/1/ 3L/3/1/ 3K/3/1/ *.*.1
/ 4/4/70/1/3L/*.*.*.4/4/1/0/DNLP6+2/1407/3/3/2/O6/1/1/5/2/G/rachel sylvester1/3/
1/1/DD/1/ 1/A5/1/ 9/EA/1/ 1/3K/3/1/ 70/1/1/ 3AN/3/1/ AH/1/1/ 4/4/*.*.*.*.*.*.4/4
/2/0/DNLP6+2/1409/3/3/2/AC/1/6/1/1/1/ 1/2/1/1/DC/1/ 1/E0/1/ 1/A3/1/ 8/AA/1/1/ 3L
/3/1/ *.*.1/ *.*.1/ 4/4/AA/1/3L/*.*.*.4/1/2/1/DNLP6+2/140C/3/3/2/6T/1/7/1/2/1/ 1
/2/1/1/3B/1/ 3/3G/1/ 39/*.1/ *.E5/1/1/ 70/1/1/ *.*.1/ *.*.1/ 1/4/70/2/E5/*.*.*.1
/4/0/0/DNLP6+2/140D/3/3/2/129/1/7/5/1/8/Amit Roy2/3/1/2/DO/1/ 1/6J/Q/Should BNP 
be in politics?8/*.1/ *.3Q/3/1/ GI/1/F/Michael MeacherN8/1/O/Duncan Reed Craig H
eeley3B6/3/1/ 4/4/GI/1/3Q/N8/1/3Q/1/4/1/0/DNLP6+2/140F/3/3/2/A2/1/8/5/1/E/David 
Millward1/3/1/1/DE/1/ 1/A7/1/ 9/*.1/ *.3M/3/1/ H2/1/1/ E3/1/1/ 72/1/1/ 4/4/H2/1/
3M/E3/1/H2/4/4/1/0/DNLP6+2/140G/3/3/2/J8/1/9/1/1/1/ 1/2/1/1/3B/1/ 3/6J/15/Hague 
copied Blair's speech formula8/3I/1/ 3/71/1/1/ 3L/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*
.*.*.1/1/0/1/DNLP6+2/140I/3/3/2/N8/1/M/5/1/A/david Hare5/3/1/2/A7/1/ 9/48/1/ 5/*
.1/ *.3M/3/1/ NP/1/1/ *.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/1/0/DNLP6+2/140K/3/3/2/1
2D/1/N/5/1/9/tom utley2/3/1/1/A1/1/ 8/3T/1/ 4/*.1/ *.E6/1/1/ 70/1/1/ *.*.1/ *.*.
1/ 1/1/*.*.*.*.*.*.1/1/0/2/DNLP6+2/140M/3/3/2/GM/1/6/5/1/G/george trefgarne2/3/1
/1/DE/1/ 1/A9/1/ 8/*.1/ *.KK/1/1/ 3L/3/1/ 3K/3/1/ AB/1/1/ 1/1/*.*.*.*.*.*.1/1/1/
0/DNLSC+2/143C/3/4/2/Q7/1/A/5/2/E/sandra barwick2/3/1/2/73/1/ 39/3N/1/ 4/6S/1/ 3
9/3B6/3/1/ N8/1/E/Peter Atkinson3L/3/1/ 3K/3/1/ 4/4/3B6/2/N8/3B6/2/3K/4/4/0/1/DN
LSC+2/143D/3/4/2/9G/1/1/1/1/1/ 2/3/1/2/6M/1/ 6/3Q/1/ 2/*.1/ *.3B4/3/1/ 3K/3/1/ 3
L/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNLSC+2/143E/3/4/2/EO/1/2/1/1/1/ 2/3/1/2/4
4/1/ 3/A1/1/ 8/*.1/ *.AE/1/1/ 3K/3/1/ 3D9/3/10/People who annoy John Prescott*.*
.1/ 1/4/AE/1/3D9/*.*.*.1/4/0/1/DNLSC+2/143H/3/4/2/RC/1/1/1/1/1/ 1/2/1/1/3B/1/ 3/
3P/1/ 3/A5/1/ 9/AE/1/1/ 70/1/1/ 3AK/2/D/Sharon Storer3B9/1/1/ 1/1/3AK/1/70/3AK/1
/AE/1/1/2/0/DNLSC+2/143J/3/4/2/4A/1/3/5/1/B/paul stokes1/3/1/1/6J/Q/Lib Dem cand
idate arrested8/*.1/ *.*.1/ *.RE/1/D/Trefor Morgan3B6/3/1/ *.*.1/ *.*.1/ 4/4/3B6
/1/RE/*.*.*.4/4/0/0/DNLSC+2/143K/3/4/2/PJ/1/6/1/1/1/ 1/3/1/1/A5/1/ 9/EB/1/ 1/E7/
1/ 1/70/1/1/ 3K/3/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/1/0/DNLSC+2/143O/3/4/2/11
O/1/R/5/1/H/james bartholomew5/3/1/1/6J/J/Ignorant electorate5/3S/1/ A/*.1/ *.3B
6/3/1/ 46/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNLSC+2/143Q/3/4/2/I5/1/R/3
/3/1/ 4/3/1/1/A5/1/ 9/DE/1/ 1/E7/1/ 1/3K/3/1/ 70/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.
*.*.1/1/2/0/DNLSC+2/143R/3/4/2/DI/1/A/1/1/1/ 1/3/1/1/6J/15/Lib Dems back indepen
dent candidate8/DB/1/ 1/*.1/ *.GI/1/A/David Lock10L/1/1/ RE/1/C/Lord Razzall3M/3
/1/ 4/4/RE/3/10L/*.*.*.1/4/0/0/DNLSC+2/143S/3/4/2/9Q/1/7/5/1/D/stewart payne1/3/
1/1/3H/1/ 39/DE/1/ 1/*.1/ *.KK/1/1/ 71/1/1/ H5/1/1/ 3AR/3/1/ 4/3/3AR/3/71/*.*.*.
4/3/1/0/DNM1I+2/146L/3/5/2/FB/1/4/1/1/1/ 1/2/1/2/44/1/ 3/A1/1/ 8/3C/1/ 4/70/1/1/
 AE/1/1/ AA/1/1/ AB/1/1/ 4/4/70/3/AE/*.*.*.4/4/0/1/DNM1I+2/146N/3/5/2/130/1/5/5/
1/C/nigel bunyan2/3/1/2/44/1/ 3/*.1/ *.*.1/ *.3B9/1/1/ AE/1/1/ 3B6/3/1/ *.*.1/ 4
/4/3B6/1/AE/3B6/3/3B9/4/4/0/1/DNM1I+2/146P/3/5/2/13M/1/1/1/1/1/ 1/2/1/1/3H/1/ 39
/3C/1/ 4/A1/1/ 8/AE/1/1/ 70/1/1/ 71/1/1/ 3B9/1/1/ 4/4/70/3/AE/71/1/AE/2/4/0/1/DN
M1I+2/146Q/3/5/2/4S/1/6/5/2/A/erin baker2/3/1/1/6P/1/ 6/70/1/ 39/*.1/ *.3B6/3/1/
 *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.0/0/DNM1I+2/146R/3/5/2/FN/1/1/1/1/1/ 1
/2/1/1/DO/1/ 1/3C/1/ 4/*.1/ *.71/1/1/ 3K/3/1/ 3L/3/1/ N8/1/F/John Townend MP4/4/
71/1/3K/*.*.*.4/1/1/0/DNM1I+2/146S/3/5/2/MR/1/2/1/1/1/ 8/2/1/2/3B/1/ 3/44/1/ 3/*
.1/ *.71/1/1/ AE/1/1/ 70/1/1/ 275/2/1/ 2/3/*.*.*.*.*.*.2/3/0/0/DNM1I+2/146T/3/5/
2/GG/1/4/1/2/1/ 1/3/1/2/3P/18/Hired hecklers paid for by the parties3/*.1/ *.*.1
/ *.71/1/1/ 3AK/3/O/Hired/Organised Hecklers70/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0
/0/DNM1I+2/1473/3/5/2/9T/1/6/1/2/1/ 1/2/1/1/4G/1/ 39/3B/1/ 3/*.1/ *.275/2/1/ 71/
1/1/ *.*.1/ *.*.1/ 3/4/*.*.*.*.*.*.3/4/0/1/DNM1I+2/1474/3/5/2/KN/1/6/1/1/1/ 1/3/
1/1/3T/1/ 4/*.1/ *.*.1/ *.E6/1/1/ GJ/1/C/Harry Rimmer140/1/1B/Neil Thompson (to 
stand against Woodward)3K/3/1/ 1/4/GJ/1/E6/140/1/3K/1/4/0/0/DNM1I+2/1478/3/5/2/1
33/1/R/5/2/D/alice thomson5/3/1/1/45/1/ 2/3Q/1/ 2/3J/1/ 2/3K/3/1/ 46/3/1/ 3B6/3/
1/ 70/1/1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNM1I+2/147A/3/5/2/I4/1/R/3/3/1/ 4/3/1/1/44/1
/ 3/3E/1/ 2/A1/1/ 8/AE/1/1/ 70/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/2/DNM1I+
2/147C/3/5/2/M5/1/6/4/1/1/ 1/2/1/2/DD/1/ 1/A2/1/ 8/*.1/ *.H6/2/1/ 3B3/3/H/Police
 FederationAH/1/1/ *.*.1/ 4/4/3B3/1/AH/3B3/3/H6/3/4/1/0/DNM1I+2/147D/3/5/2/8P/1/
7/1/1/1/ 1/3/1/1/41/1/ 4/DF/1/ 1/*.1/ *.3D9/1/17/Paul Sykes - Euro Sceptic Milli
onaire3R/3/1/ 3L/3/1/ *.*.1/ 4/4/3D9/3/3R/3D9/1/3L/4/4/0/0/DNM1I+2/147F/3/5/2/D9
/1/8/5/1/E/thomas harding1/3/1/1/6Q/1/ 7/6J/18/Methods of monitoring broadcast o
utput39/*.1/ *.6J/3/S/Party Media Monitoring Units3AM/3/3/ITN3BA/3/1/ *.*.1/ 4/4
/*.*.*.*.*.*.4/4/0/0/DNMB6+2/14A1/3/1/2/37/1/4/1/1/1/ 1/3/1/2/DF/1/ 1/A9/1/ 8/*.
1/ *.N8/1/C/Lord Brittan71/1/1/ *.*.1/ *.*.1/ 4/4/GI/1/71/*.*.*.4/4/1/0/DNMB6+2/
14A2/3/1/2/15G/1/N/5/1/C/Peter Oborne5/3/2/2/A1/1/ 8/6O/1/ 6/*.1/ *.71/1/1/ 3K/3
/1/ 70/1/1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/1/2/DNMB6+2/14A4/3/1/2/AB/1/6/1/1/1/ 1/3/
1/2/AD/1/ 39/*.1/ *.*.1/ *.GJ/1/C/Derek DraperDS/1/1/ 70/1/1/ AB/1/1/ 4/4/*.*.*.
*.*.*.4/4/0/0/DNMB6+2/14A6/3/1/2/SE/1/6/5/1/E/david sharrock2/3/1/1/DQ/1/ 1/73/1
/ 39/3L/1/ 4/13T/1/G/David Taylor UUP13T/2/H/Iris Robinson DUP13T/3/I/N. Ireland
 Parties3B6/3/1/ 4/4/3B6/1/13T/*.*.*.4/4/0/0/DNMB6+2/14A7/3/1/2/T2/1/1/1/1/1/ 1/
3/1/1/ED/1/ 1/6S/1/ 39/*.1/ *.3AB/3/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 4/1/3AB/1/3K/3AB/3
/3L/4/1/1/0/DNMB6+2/14A8/3/1/2/H2/1/4/5/1/B/tom leonard2/3/1/1/4B/1/ A/6Q/1/ 7/3
S/1/ A/3K/3/1/ 3AM/3/1/ 3D9/1/1A/Nick Jones - BBC political correspondent*.*.1/ 
1/4/3AM/1/3K/3D9/1/3K/1/4/0/0/DNMB6+2/14A9/3/1/2/M9/1/4/5/2/A/Celia Hall2/3/1/2/
DB/1/ 1/*.1/ *.*.1/ *.3K/3/1/ 3AQ/3/7/Doctors3L/3/1/ 3M/3/1/ 4/4/3AQ/1/3K/3AQ/1/
3L/1/1/1/0/DNMB6+2/14AA/3/1/2/F1/1/4/5/1/G/george trefgarne1/3/1/1/6S/1/ 39/ED/1
/ 1/*.1/ *.N9/3/12/Tory-Supporting Business Leaders3L/3/1/ 3K/3/1/ GJ/3/14/Labou
r supporting business leaders4/4/N9/3/3L/*.*.*.4/4/0/0/DNMB6+2/14AB/3/1/2/CH/1/7
/5/1/A/Erin Baker1/3/1/1/9T/17/Instructions on how to cast your vote39/*.1/ *.*.
1/ *.3B6/3/D/You the voter*.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.0/0/DNMB6+2/1
4AC/3/1/2/T5/1/7/1/1/1/ 5/3/1/1/3Q/1/ 2/6J/15/Narrower gap between left and righ
t39/6J/S/Less conflict within society39/3D9/3/7/Society6J/3/S/Political Parties 
in General*.*.1/ *.*.1/ 3/2/*.*.*.*.*.*.3/2/0/0/DNMB6+2/14AD/3/1/2/P5/1/7/1/2/1/
 1/3/1/2/DG/1/ 1/3C/1/ 4/*.1/ *.71/1/1/ 70/1/1/ H2/1/1/ AC/1/1/ 4/4/H2/1/70/*.*.
*.4/4/1/0/DNMB6+2/14AE/3/1/2/FD/1/N/3/3/1/ 4/3/1/1/DD/1/ 1/GJ/I/Effect on busine
ss1/*.1/ *.3K/3/1/ 70/1/1/ 3L/3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNMB6+2/14AF/3
/1/2/B1/1/1/1/1/1/ 1/2/1/1/DT/1/ 1/EC/1/ 1/*.1/ *.AB/1/1/ 3L/3/1/ H5/1/1/ 3K/3/1
/ 4/4/3M/1/AB/H5/1/3K/1/4/2/0/DNMB6+2/14AG/3/1/2/FN/1/2/5/2/D/Nicole Martin1/3/1
/2/DB/1/ 1/A5/1/ 9/6L/1/ 6/3AQ/2/L/Christine Hancock RCNAD/1/1/ 42/3/1/ *.*.1/ 4
/4/3AQ/1/42/*.*.*.4/4/1/0/DNMB6+2/14AI/3/1/2/KN/1/7/5/1/C/nigel bunyan1/2/1/1/3B
/1/ 3/*.1/ *.*.1/ *.E6/1/1/ 3B6/3/1/ *.*.1/ *.*.1/ 1/4/3B6/2/E6/*.*.*.1/4/0/0/DN
MEC+2/14DC/3/2/2/AI/1/7/1/2/1/ 1/2/1/2/48/1/ 5/A1/1/ 8/3C/1/ 4/70/1/1/ 3AL/3/1/ 
71/1/1/ 139/1/A/John Smith4/4/*.*.*.*.*.*.4/4/0/0/DNMEC+2/14DD/3/2/2/DG/1/8/1/1/
1/ 1/2/1/2/AD/1/ 39/A9/1/ 8/*.1/ *.70/1/1/ AB/1/1/ DS/1/1/ GJ/1/C/Derek Draper4/
4/AB/3/DS/*.*.*.4/4/0/0/DNMEC+2/14DE/3/2/2/JR/1/8/5/2/G/rachel sylvester1/3/1/1/
6S/1/ 39/9T/10/Profile of celebrity supporter39/*.1/ *.3AE/1/11/Matthew Vaughan 
(film producer)3L/3/1/ 3K/3/1/ H5/1/1/ 4/4/3AE/3/3L/3AE/1/3K/4/4/0/1/DNMEC+2/14D
G/3/2/2/Q9/1/1/1/1/1/ 1/3/1/1/6Q/1/ 7/4B/1/ A/*.1/ *.3K/3/1/ 3AM/3/H/News Broadc
astersE1/2/1/ KB/1/1/ 4/4/E1/1/3AM/KB/1/3K/1/4/1/0/DNMEC+2/14DH/3/2/2/93/1/1/5/2
/D/liz lightfoot1/3/1/1/DC/1/ 1/A3/1/ 8/*.1/ *.70/1/1/ 3AQ/2/10/Elizabeth Philip
s/headmistress3K/3/1/ *.*.1/ 4/4/3AQ/1/3K/*.*.*.1/4/1/0/DNMEC+2/14DI/3/2/2/LR/1/
2/1/1/1/ 8/2/1/2/6J/I/Missing candidates8/3H/1/ 39/DE/1/ 1/71/1/1/ KK/1/1/ H5/1/
1/ E5/1/1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNMEC+2/14DM/3/2/2/N6/1/8/1/1/1/ 1/2/1/1/AC/1
/ 9/ED/1/ 1/6S/1/ 39/71/1/1/ 3AB/1/1/ H5/1/1/ 3K/3/1/ 4/4/71/1/3K/*.*.*.4/4/3/0/
DNMEC+2/14DN/3/2/2/8S/1/A/4/1/1/ 1/3/1/1/6J/P/Northern Ireland election39/6J/2B/
Fielding candidates tactically to maximise number of pro-agreement MPs.8/*.1/ *.
3T/3/1/ 6I/3/E/Alliance Party13O/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNMEC+2/14D
O/3/2/2/33/1/A/1/2/1/ 1/2/1/1/D9/16/Monster Raving Loony Party manifesto9/*.1/ *
.*.1/ *.6H/3/Q/Monster Raving Loony Party140/1/O/Alan 'howling laud' Hope*.*.1/ 
*.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNMEC+2/14DP/3/2/2/OP/1/A/5/1/C/sean o'neill3/3/1
/1/73/1/ 39/*.1/ *.*.1/ *.AF/1/1/ 3B6/3/1/ 3K/3/1/ RE/1/C/Keith Sharpe4/4/3B6/3/
AF/RE/1/AF/1/4/0/0/DNMEC+2/14DS/3/2/2/BB/1/8/5/1/E/david millward1/2/1/1/DJ/1/ 1
/*.1/ *.*.1/ *.3M/3/1/ 72/1/1/ 3D9/3/6/ConnexNM/1/1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNM
EC+2/14E3/3/2/2/85/1/R/2/1/1/ 39/3/2/1/72/1/ 7/3C/1/ 4/6J/H/Labour leadership8/7
0/1/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.0/0/DNMHI+2/14GL/3/3/2/BP/1/8/1/
1/1/ 1/2/1/2/DG/1/ 1/*.1/ *.*.1/ *.N8/1/1/ N9/1/1/ 70/1/1/ *.*.1/ 4/4/N9/1/70/*.
*.*.4/4/1/0/DNMHI+2/14GM/3/3/2/EM/1/R/3/3/1/ 4/3/1/2/DT/1/ 1/DG/1/ 1/3C/1/ 4/70/
1/1/ 3K/3/1/ 3L/3/1/ AB/1/1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNMHI+2/14GN/3/3/2/EC/1/B/4
/1/1/ 1/3/1/2/6J/S/Plans for a virtual campaign39/3C/1/ 4/*.1/ *.70/1/1/ 3D9/1/8
/InventorE8/3/1/ *.*.1/ 4/4/E8/3/3D9/*.*.*.4/4/0/0/DNMHI+2/14GP/3/3/2/O0/1/1/1/1
/1/ 1/3/1/1/DT/1/ 1/A2/1/ 8/A3/1/ 8/AB/1/1/ H5/1/1/ 70/1/1/ 3L/3/1/ 1/4/H5/1/AB/
3L/1/AB/1/4/2/0/DNMHI+2/14GQ/3/3/2/FS/1/1/1/1/1/ 1/2/1/1/DG/1/ 1/A9/1/ 8/3B/1/ 3
/10M/2/1/ 71/1/1/ 72/1/1/ KT/3/1/ 4/4/10M/2/71/72/1/10M/2/4/1/0/DNMHI+2/14H1/3/3
/2/Q3/1/C/5/3/D/p j bonthrone5/2/1/1/73/1/ 39/AA/1/ 8/3B/1/ 3/GI/1/C/Matthew Sye
dN8/1/F/John Redwood MPRE/1/H/Dr. Royce Longton*.*.1/ 3/2/*.*.*.*.*.*.3/2/0/1/DN
MHI+2/14H2/3/3/2/15M/1/Q/5/1/9/ian cowie5/3/1/1/DT/1/ 1/EC/1/ 1/*.1/ *.AB/1/1/ *
.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.2/0/DNMHI+2/14H4/3/3/2/9F/1/8/5/2/D/nico
le martin1/2/1/1/DB/1/ 1/E7/1/ 1/*.1/ *.42/3/1/ D9/1/B/John Denham45/3/1/ H0/1/1
/ 1/4/H0/1/D9/*.*.*.1/4/1/0/DNMHI+2/14H6/3/3/2/5D/1/9/5/1/9/matt born1/3/1/1/3C/
1/ 4/6J/13/Refusal to take part in TV debate39/*.1/ *.3AM/3/H/Broadcasters (TV)7
0/1/1/ *.*.1/ *.*.1/ 4/4/3AM/1/70/*.*.*.4/1/0/0/DNMHI+2/14HC/3/3/2/B5/1/9/1/1/1/
 1/3/1/1/A1/1/ 8/3H/1/ 39/*.1/ *.E1/2/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/
*.0/0/DNMHI+2/14HD/3/3/2/OQ/1/9/1/1/1/ 5/3/1/1/6Q/1/ 7/4B/1/ A/*.1/ *.3K/3/1/ E1
/2/1/ 3AM/3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNMKO+2/14K1/3/4/2/5M/1/1/1/1/1/ 1
/2/1/2/3B/1/ 3/DC/1/ 1/*.1/ *.3B6/2/7/Student70/1/1/ *.*.1/ *.*.1/ 4/4/3B6/2/70/
*.*.*.4/4/0/0/DNMKO+2/14K3/3/4/2/7J/1/B/5/1/E/david millward1/3/1/2/6L/1/ 6/6J/N
/Kennedy could lose seat8/*.1/ *.72/1/1/ 3L/3/1/ 3K/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.
1/4/0/0/DNMKO+2/14K7/3/4/2/M1/1/2/1/1/1/ 8/3/1/1/DG/1/ 1/A9/1/ 8/*.1/ *.10M/2/1/
 71/1/1/ 3K/3/1/ 3L/3/1/ 1/2/3K/1/3L/3K/1/71/1/2/1/0/DNMKO+2/14KA/3/4/2/M0/1/8/5
/2/H/Rachael Sylvester1/2/1/2/DF/1/ 1/*.1/ *.*.1/ *.3L/3/1/ 3K/3/1/ 10M/2/1/ *.*
.1/ 4/4/3K/1/3L/*.*.*.1/4/1/0/DNMKO+2/14KD/3/4/2/CS/1/A/1/2/1/ 1/3/1/2/6J/N/UKIP
 inflitrated by M168/DF/1/ 1/*.1/ *.139/1/B/Lord Tebbit3R/3/1/ 3D9/1/10/Paul Syk
es - multi-millionaire3K/3/1/ 4/4/139/1/3R/*.*.*.4/4/0/0/DNMKO+2/14KG/3/4/2/71/1
/B/4/1/1/ 1/3/1/1/6Q/11/Analysis of election candidates7/70/1/ 39/*.1/ *.6J/3/J/
Election Candidates*.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.0/0/DNMKO+2/14KH/3/4
/2/MQ/1/Q/5/1/A/david hare5/2/1/1/3B/1/ 3/A1/1/ 8/D9/M/Backward looking party8/7
1/1/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/0/DNMKO+2/14KJ/3/4/2/122/1/R/5
/2/E/james barthmew5/3/1/1/6Q/1/ 7/*.1/ *.*.1/ *.3AL/3/E/TV Journalists*.*.1/ *.
*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/0/DNMKO+2/14KK/3/4/2/FJ/1/R/3/3/1/ 4/3/1/1/DT/
1/ 1/DE/1/ 1/EC/1/ 1/AB/1/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.2/0/DNMKO+
2/14KL/3/4/2/K2/1/1/1/1/1/ 1/3/1/1/6L/1/ 6/DF/1/ 1/3J/1/ 2/3AR/3/1/ 3L/3/1/ 3K/3
/1/ 3M/3/1/ 4/4/3L/1/3K/3K/1/3L/2/2/2/0/DNMO+3/14NB/3/5/2/NA/1/1/1/1/1/ 1/2/1/1/
DG/1/ 1/DF/1/ 1/*.1/ *.70/1/1/ H2/1/1/ 3L/3/1/ *.*.1/ 4/4/70/1/3L/*.*.*.4/4/1/0/
DNMO+3/14ND/3/5/2/9K/1/6/4/1/1/ 1/3/1/1/4E/1/ 4/GJ/8/Abortion1/*.1/ *.6H/3/G/Pro
life Alliance3AM/3/1/ 3AQ/1/5/Judge*.*.1/ 4/4/6H/1/3AM/3AQ/1/6H/1/4/1/0/DNMO+3/1
4NE/3/5/2/A7/1/6/5/2/H/Rachael Sylvester1/3/1/2/47/1/ 5/6L/1/ 6/*.1/ *.71/1/1/ 3
AB/3/H/Asian Businessmen3B6/3/C/Asian Voters3K/3/1/ 4/4/3AB/1/71/3AB/1/3K/1/4/1/
0/DNMO+3/14NF/3/5/2/I9/1/6/5/1/E/charlie norton1/2/1/2/DB/1/ 1/*.1/ *.*.1/ *.DL/
2/1/ 70/1/1/ 3B6/2/12/Mrs Pemberton (Hospital patient)*.*.1/ 4/4/3B6/1/70/*.*.*.
1/1/1/0/DNMO+3/14NG/3/5/2/BD/1/6/5/3/D/p j bonthrone1/2/1/1/3S/1/ A/3B/1/ 3/*.1/
 *.10I/1/1/ N8/1/H/Jonathan Djanogly70/1/1/ 3B6/3/1/ 4/4/10I/1/70/3B6/3/10I/4/4/
0/0/DNMO+3/14NK/3/5/2/5A/1/8/5/1/F/roger highfield1/3/1/1/6S/1/ 39/GJ/7/Science1
/*.1/ *.3B1/3/R/Leading Science Researchers3K/3/1/ *.*.1/ *.*.1/ 4/4/3B1/3/3K/*.
*.*.4/3/1/0/DNMO+3/14NM/3/5/2/15E/1/Q/5/1/E/daniel johnson5/3/1/1/A3/1/ 8/EH/1/ 
1/E1/1/ 1/70/1/1/ 3AL/3/N/Stern (German Magazine)3K/3/1/ *.*.1/ 1/2/3AL/1/70/3AL
/1/3K/1/2/1/1/DNMO+3/14NQ/3/5/2/6R/1/R/3/3/1/ 4/3/1/2/42/1/ 39/*.1/ *.*.1/ *.70/
1/1/ GI/3/E/'blairs babes'3AE/1/D/Harry Enfield*.*.1/ 4/4/*.*.*.*.*.*.1/4/0/0/DN
MO+3/14NS/3/5/2/1FN/1/8/3/3/1/ 39/3/1/2/6Q/15/Worldwide media comments on labour
/7/*.1/ *.*.1/ *.70/1/1/ 3D9/3/7/Britain*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/1/0/0/DN
N3I+2/14QL/3/1/2/B6/1/1/1/1/1/ 1/3/1/1/A1/1C/Personality Hague's strengths & wea
knesses8/72/E/Hague's future7/*.1/ *.70/1/1/ 71/1/1/ 3K/3/1/ *.*.1/ 4/4/70/1/71/
3K/1/71/4/1/0/2/DNN3I+2/14QP/3/1/2/KQ/1/8/1/1/1/ 1/2/1/1/DG/1/ 1/*.1/ *.*.1/ *.A
B/1/1/ 3L/3/1/ 71/1/1/ 3AB/3/L/Pro-European Business4/4/3L/1/AB/3AB/1/3L/4/4/1/0
/DNN3I+2/14QQ/3/1/2/123/1/8/1/2/1/ 5/3/1/1/DF/1/ 1/3C/1/ 4/*.1/ *.3L/3/1/ 71/1/1
/ 3D9/3/D/Euro-sceptics*.*.1/ 4/1/*.*.*.*.*.*.4/1/1/0/DNN3I+2/14QR/3/1/2/GO/1/9/
4/1/1/ 2/3/1/2/6J/15/Relationship between UK and USA pol4/*.1/ *.*.1/ *.3K/3/1/ 
3L/3/1/ 3B7/1/L/Bob Shrum/US DemocratKT/1/J/Mark Fullbrook Tory4/4/*.*.*.*.*.*.4
/4/0/0/DNN3I+2/14QT/3/1/2/91/1/9/5/1/E/david millward1/3/1/1/3F/1/ 2/3C/1/ 4/A8/
1/ 8/R4/1/C/Lord Rennard3L/3/1/ 3K/3/1/ *.*.1/ 4/4/RE/1/3L/RE/1/3K/4/1/0/0/DNN3I
+2/14R0/3/1/2/7C/1/A/1/1/1/ 1/2/1/2/DC/C/Student fees1/A9/1/ 8/*.1/ *.E0/2/1/ 3K
/3/1/ E8/3/1/ E9/3/1/ 4/1/*.*.*.*.*.*.4/1/1/0/DNN3I+2/14R1/3/1/2/7C/1/A/1/1/1/ 1
/2/1/1/DC/C/Student fees1/A9/1/ 8/*.1/ *.E0/2/1/ 3K/3/1/ E8/3/1/ E9/3/1/ 4/1/*.*
.*.*.*.*.4/1/1/0/DNN3I+2/14R2/3/1/2/K0/1/A/5/1/A/srin baker2/3/1/1/48/1/ 5/6J/H/
Party youth wings39/*.1/ *.N9/3/J/Conservative FutureTT/3/Q/Lib Dem Youth and St
udentsGJ/3/F/Labour Students*.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNN3I+2/14R5/3/1/2/6C
/1/8/1/1/1/ 1/2/1/1/DT/1/ 1/EC/1/ 1/*.1/ *.H5/1/1/ AB/1/1/ 3K/3/1/ *.*.1/ 4/4/H5
/1/AB/H5/1/3K/4/1/1/0/DNN3I+2/14R6/3/1/2/FL/1/A/1/1/1/ 1/3/1/1/3H/1/ 39/*.1/ *.*
.1/ *.E5/1/1/ KB/1/1/ 3D9/1/R/Nadhmi Auchi (billionnaire)70/1/1/ 1/4/KB/1/70/*.*
.*.1/4/0/0/DNN3I+2/14R7/3/1/2/1O/1/A/3/3/1/ 1/3/1/1/GJ/Q/Lottery money distribut
ion1/*.1/ *.*.1/ *.AB/1/1/ 3D9/3/A/Poor Areas*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1
/0/DNN6O+2/1501/3/2/2/PE/1/1/1/1/1/ 1/4/1/1/DF/1/ 1/6J/13/Jospin's speech embara
sses Labour39/*.1/ *.3B9/1/1/ 70/1/1/ 3L/3/1/ 3K/3/1/ 4/4/3L/1/3K/*.*.*.4/4/2/0/
DNN6O+2/1502/3/2/2/HE/1/1/5/2/D/alice thomson1/2/1/1/DG/1/ 1/3C/1/ 4/*.1/ *.71/1
/1/ 3D9/3/Q/Euroeceptic Campaign GroupH2/1/1/ 70/1/1/ 4/4/3D9/1/71/70/1/71/4/4/1
/0/DNN6O+2/1503/3/2/2/F4/1/4/1/2/1/ 2/3/1/1/DG/1/ 1/A8/1/ 8/*.1/ *.H2/1/1/ 42/3/
1/ 3AB/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/1/0/0/DNN6O+2/1504/3/2/2/OJ/1/4/4/1/1/ 1/4/
1/1/DF/1/ 1/*.1/ *.*.1/ *.3AG/1/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.2/0/
DNN6O+2/1505/3/2/2/LS/1/4/4/1/1/ 1/4/1/1/DF/1/ 1/*.1/ *.*.1/ *.3AG/1/1/ *.*.1/ *
.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.2/0/DNN6O+2/1507/3/2/2/MA/1/5/1/1/1/ 2/3/1/2/AF
/1/ 39/45/1/ 2/3C/1/ 4/70/1/1/ 3AM/3/1/ *.3/1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/0/0/DN
N6O+2/1509/3/2/2/B6/1/7/1/2/1/ 1/3/1/1/GJ/R/Allocation of lottery funds1/*.1/ *.
*.1/ *.AB/1/1/ AF/1/1/ 71/1/1/ 3K/3/1/ 4/4/71/1/3K/*.*.*.4/4/1/0/DNN6O+2/150A/3/
2/2/OS/1/7/5/1/D/Sean o' Neill2/3/1/2/3B/1/ 3/DG/1/ 1/73/1/ 39/N8/1/C/Nick Serpe
llGI/2/E/Candy AthertonRE/1/D/Julian Brazil3B6/3/1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNN6
O+2/150C/3/2/2/16A/1/N/5/1/F/stephen pollard2/3/1/1/DF/1/ 1/A9/1/ 8/*.1/ *.3K/3/
1/ 3L/3/1/ *.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/1/0/DNN6O+2/150E/3/2/2/89/1/O/2/1/1
/ 39/3/2/2/3C/1/ 4/72/1/ 7/*.1/ *.70/1/1/ 72/1/1/ DO/1/1/ *.*.1/ 1/1/*.*.*.*.*.*
.1/1/0/0/DNN6O+2/150H/3/2/2/I3/1/N/3/3/1/ 4/3/1/1/DF/1/ 1/DG/1/ 1/*.1/ *.3K/3/1/
 3L/3/1/ 3M/3/1/ 3AG/1/D/Lionel Jospin1/3/*.*.*.*.*.*.1/3/2/0/DNNA+3/153B/3/3/2/
10N/1/1/1/1/1/ 1/2/1/1/3C/1/ 4/A1/1/ 8/6L/1/ 6/3K/3/1/ 71/1/1/ 70/1/1/ 10I/1/1/ 
4/4/3K/1/71/10I/1/70/4/4/0/2/DNNA+3/153C/3/3/2/44/1/1/4/1/1/ 1/3/1/1/DQ/1A/Gerry
 Adams could be N.I. first minister1/*.1/ *.*.1/ *.13T/1/M/Martin McGuinness (SF
)73/1/1/ 41/3/1/ 3T/3/1/ 4/4/13T/3/73/*.*.*.4/4/0/0/DNNA+3/153E/3/3/2/15L/1/6/4/
1/1/ 5/3/1/1/DG/1/ 1/*.1/ *.*.1/ *.3K/3/1/ 70/1/1/ 3L/3/1/ *.*.1/ 4/4/*.*.*.*.*.
*.4/4/2/0/DNNA+3/153G/3/3/2/J4/1/6/5/1/R/George Jones Andrew Sparrow1/3/1/2/DG/1
/ 1/DE/1/ 1/*.1/ *.AB/1/1/ H5/1/1/ 71/1/1/ 70/1/1/ 4/4/71/1/70/*.*.*.1/4/1/0/DNN
A+3/153H/3/3/2/EC/1/6/1/2/1/ 1/2/1/1/6J/Q/Tories' portrayal of women8/DE/1/ 1/A7
/J/Manifesto for women9/71/1/1/ H5/1/1/ 3M/3/1/ *.*.1/ 4/4/3AM/1/71/3AM/1/H5/1/1
/2/0/DNNA+3/153I/3/3/2/9J/1/6/1/2/1/ 1/2/1/1/EF/1/ 1/*.1/ *.*.1/ *.3M/3/1/ 3K/3/
1/ RE/1/C/Paul Burstow*.*.1/ 4/4/3M/1/3K/RE/1/3K/4/1/1/0/DNNA+3/153T/3/3/2/159/1
/Q/39/2/M/lady annabel goldsmith5/3/1/1/DF/1/ 1/DG/1/ 1/6S/1/ 39/139/1/J/Sir Jam
es Goldsmith71/1/1/ 70/1/1/ 3L/3/1/ 3/3/*.*.*.*.*.*.3/3/1/0/DNNA+3/1540/3/3/2/JS
/1/R/3/3/1/ 4/3/1/2/A4/1/ 8/*.1/ *.*.1/ *.70/1/1/ 71/1/1/ DO/1/1/ 10I/1/1/ 2/2/D
O/1/71/10I/1/70/2/2/0/3/DNND6+2/1541/3/3/2/12Q/1/R/5/1/9/tom utley5/3/1/1/DE/1/ 
1/DC/1/ 1/EA/1/ 1/70/1/1/ AB/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/2/0/DNND6+2/
156L/3/4/2/F4/1/1/1/1/1/ 1/3/1/1/EC/1/ 1/6L/1/ 6/*.1/ *.AB/1/1/ KR/1/1/ 3K/3/1/ 
3L/3/1/ 4/4/KR/1/AB/3L/1/3K/2/4/1/0/DNND6+2/156M/3/4/2/L6/1/2/1/1/1/ 8/2/1/1/DG/
1/ 1/3B/1/ 3/*.1/ *.QJ/1/B/David Heath3M/3/1/ 71/1/1/ 70/1/1/ 1/1/*.*.*.*.*.*.1/
1/1/0/DNND6+2/156N/3/4/2/KS/1/8/5/2/G/rachel sylvester2/3/1/1/A9/1/ 8/DG/1/ 1/AE
/1/ 39/71/1/1/ JT/3/D/Senior ToriesN8/3/J/Pro-European ToriesH5/1/1/ 1/4/JT/1/71
/N8/1/71/1/4/1/0/DNND6+2/156Q/3/4/2/O2/1/8/1/1/1/ 2/3/1/2/DG/1/ 1/6L/1/ 6/*.1/ *
.3K/3/1/ 3L/3/1/ 3B6/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.3/1/1/0/DNND6+2/156T/3/4/2/F0/1
/9/1/1/1/ 1/2/1/1/A2/1/ 8/DD/1I/Prosecution for those who attack public servants
1/GJ/E/Adult literacy1/70/1/1/ 3D9/3/L/Public Sector Workers3B3/1/F/Doug McEvoy/
NUT*.*.1/ 4/4/3B3/3/70/*.*.*.4/4/3/0/DNND6+2/1570/3/4/2/15H/1/A/1/2/1/ 1/2/1/1/D
H/1/ 1/EF/1/ 1/A2/1/ 8/3K/3/1/ 3D9/3/10/National Pensioners Convention3L/3/1/ 3M
/3/1/ 4/4/3D9/1/3K/*.*.*.1/4/1/0/DNND6+2/1576/3/4/2/GR/1/B/5/3/D/p j bonthrone1/
3/1/1/3M/1/ 4/4F/1/ 4/*.1/ *.E7/3/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0
/0/DNND6+2/1577/3/4/2/M0/1/Q/5/1/A/David Hare5/3/1/2/A1/1/ 8/*.1/ *.*.1/ *.10M/2
/1/ L3/1/1/ N9/2/13/Lady who works for Kenneth Clarke*.*.1/ 1/1/N9/2/L3/*.*.*.1/
1/0/0/DNND6+2/1578/3/4/2/15C/1/Q/39/2/O/gp - dr gillian braunold5/3/1/1/DB/1/ 1/
*.1/ *.*.1/ *.3K/3/1/ 46/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/2/0/DNND6+2/157A
/3/4/2/88/1/R/2/1/1/ 39/3/2/2/3C/1/ 4/72/1/ 7/*.1/ *.70/1/1/ DO/1/1/ H6/2/1/ H5/
1/1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNNGC+2/15A1/3/5/2/QD/1/1/1/1/1/ 1/2/1/1/DB/1/ 1/DC
/1/ 1/3B/1/ 3/70/1/1/ 3D9/1/1/ 3K/3/1/ H5/1/1/ 1/4/3D9/1/3K/H5/1/3K/1/4/1/0/DNNG
C+2/15A2/3/5/2/5E/1/1/1/1/1/ 1/3/1/1/3R/1/ 2/*.1/ *.*.1/ *.10M/2/1/ 70/1/1/ 3L/3
/1/ KB/1/1/ 4/4/10M/1/70/*.*.*.4/1/0/0/DNNGC+2/15A3/3/5/2/M6/1/2/1/1/1/ 8/3/2/1/
73/1/ 39/6J/J/Ill-informed voters5/6J/B/Missing mps39/3D9/3/E/Middle England3B6/
3/1/ 71/1/1/ 70/1/1/ 4/2/*.*.*.*.*.*.4/2/0/0/DNNGC+2/15A4/3/5/2/HH/1/8/1/1/1/ 1/
2/1/1/DT/1/ 1/EC/1/ 1/*.1/ *.70/1/1/ 3K/3/1/ AB/1/1/ KR/1/1/ 1/1/KR/1/AB/*.*.*.1
/1/2/0/DNNGC+2/15A7/3/5/2/2N/1/8/3/3/1/ 1/3/1/1/DC/1/ 1/*.1/ *.*.1/ *.GI/2/E/Est
elle Morris3K/3/1/ 3B3/3/3/NUT*.*.1/ 4/4/3B3/1/3K/*.*.*.4/1/1/0/DNNGC+2/15A9/3/5
/2/NL/1/9/1/1/1/ 1/3/1/1/DC/1/ 1/A2/1/ 8/*.1/ *.3K/3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 2
/2/3K/1/3L/3L/1/3K/2/2/3/0/DNNGC+2/15AD/3/5/2/H3/1/9/5/1/A/john clare5/3/1/1/DC/
1/ 1/A2/1/ 8/A3/1/ 8/3L/3/1/ 3M/3/1/ 3K/3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/3/0/DNNG
C+2/15AE/3/5/2/RG/1/A/5/1/D/Sean O' Neill2/3/1/2/6J/Q/The campaign for Southgate
39/*.1/ *.*.1/ *.GI/1/D/Stephen TwiggH5/1/1/ N8/1/A/John Flack3B6/3/1/ 4/4/N8/1/
GI/*.*.*.3/1/1/0/DNNGC+2/15AG/3/5/2/RJ/1/B/1/1/1/ 2/3/1/1/6J/13/Women working on
 Blair's campaign39/3C/1/ 4/*.1/ *.GJ/2/G/Babes on the Bus48/3/1/ 70/1/1/ *.*.1/
 3/4/GJ/1/48/*.*.*.3/4/0/1/DNNGC+2/15AI/3/5/2/138/1/Q/39/2/H/margaret thatcher5/
3/1/1/DG/1/ 1/DF/1/ 1/3R/1/ 2/70/1/1/ 3K/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/
1/0/DNNQ+3/15DB/3/1/2/101/1/1/1/1/1/ 1/3/1/1/3R/1/ 2/3C/1/ 4/*.1/ *.70/1/1/ 71/1
/1/ 3K/3/1/ 3L/3/1/ 1/4/70/1/71/70/1/3L/1/4/0/1/DNNQ+3/15DC/3/1/2/I4/1/1/1/1/1/ 
1/3/1/1/3M/1/ 4/DG/1/ 1/*.1/ *.49/3/1/ 3D9/3/A/Royal Mail44/3/1/ *.*.1/ 4/4/*.*.
*.*.*.*.4/4/0/0/DNNQ+3/15DE/3/1/2/137/1/6/1/1/1/ 2/3/1/1/6J/20/Whether or not th
e Party Leader influences election outcomes39/*.1/ *.*.1/ *.3L/3/1/ 71/1/1/ 3K/3
/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNNQ+3/15DG/3/1/2/BN/1/6/1/1/1/ 1/2/1/2/6J/12
/Warning about another Blair Gov.8/EA/1/ 1/*.1/ *.KB/1/1/ 70/1/1/ 10G/1/1/ 10M/2
/1/ 4/4/KB/1/70/10G/1/10M/4/1/1/0/DNNQ+3/15DH/3/1/2/HS/1/6/1/1/1/ 1/2/1/1/3B/1/ 
3/*.1/ *.*.1/ *.GJ/1/C/Michael Foot3B6/3/1/ *.*.1/ *.*.1/ 2/4/3B6/2/GJ/*.*.*.2/4
/0/1/DNNQ+3/15DI/3/1/2/14L/1/7/5/2/D/alice thomson1/2/1/1/A1/1/ 8/3B/1/ 3/*.1/ *
.H6/2/1/ 3B6/3/1/ *.*.1/ *.*.1/ 3/4/3B6/2/H6/*.*.*.3/4/1/2/DNNQ+3/15DJ/3/1/2/NS/
1/8/5/1/C/sean o'neill2/2/1/1/3B/1/ 3/3G/1/ 39/A1/1/ 8/E5/1/1/ 3B6/3/L/Leicester
 East Voters*.*.1/ *.*.1/ 1/4/3B6/3/E5/*.*.*.2/4/0/0/DNNQ+3/15DK/3/1/2/C8/1/8/4/
1/E/Patrick Bishop1/3/1/2/6S/1/ 39/A1/1/ 8/*.1/ *.DS/1/1/ 70/1/1/ *.*.1/ *.*.1/ 
4/3/DS/3/70/*.*.*.4/3/0/1/DNNQ+3/15DL/3/1/2/AS/1/8/4/2/1/ 1/4/1/1/3R/1/ 2/6J/E/C
hristian vote5/*.1/ *.3AT/1/I/Archbishop of York3AT/1/O/Archbishop of Canterbury
46/3/1/ *.*.1/ 4/4/3AT/1/46/*.*.*.4/4/0/1/DNNQ+3/15DN/3/1/2/AC/1/9/1/1/1/ 1/3/1/
1/D9/L/Blair not happy as PM8/A1/1/ 8/AD/1/ 39/70/1/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.
*.*.*.*.*.*.4/*.0/1/DNNQ+3/15DO/3/1/2/HS/1/9/1/1/1/ 1/2/1/2/48/1/ 5/*.1/ *.*.1/ 
*.70/1/1/ 3B6/3/C/Young Voters3AE/3/J/Various Celebrities*.*.1/ 4/4/*.*.*.*.*.*.
4/4/1/0/DNNQ+3/15DP/3/1/2/BG/1/9/1/1/1/ 1/3/1/1/EG/1/ 1/A2/1/ 8/*.1/ *.KE/1/1/ 3
K/3/1/ *.*.1/ *.*.1/ 4/4/KE/1/3K/*.*.*.4/1/1/0/DNNQ+3/15DS/3/1/2/LJ/1/L/3/3/1/ 4
/3/1/1/DI/1/ 1/A3/1/ 8/EC/1/ 1/3K/3/1/ 70/1/1/ 3L/3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/
1/1/0/DNNQ+3/15E0/3/1/2/7A/1/6/1/1/1/ 1/3/1/1/EC/1/ 1/DT/1/ 1/*.1/ *.H5/1/1/ AB/
1/1/ 3K/3/1/ E3/1/1/ 4/4/H5/1/AB/H5/1/3K/4/4/1/0/DNNT6+2/15GL/3/2/2/P6/1/6/1/1/1
/ 1/2/1/2/A8/R/Snub to Lib Dems from Blair8/6L/1/ 6/3L/1/ 4/70/1/1/ 72/1/1/ 3L/3
/1/ *.*.1/ 4/4/*.*.*.*.*.*.2/4/0/0/DNNT6+2/15GO/3/2/2/M1/1/6/1/1/1/ 5/2/2/1/3K/1
/ 2/3B/1/ 3/3R/1/ 2/71/1/1/ 70/1/1/ 72/1/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNNT6
+2/15GQ/3/2/2/OE/1/7/1/1/1/ 2/3/1/1/3M/1/ 4/4F/1/ 4/*.1/ *.3D9/3/H/Council Offic
ialsKB/1/1/ 49/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNNT6+2/15H1/3/2/2/BT/1/8/5/1
/9/Matt born1/3/1/2/6S/Q/Endorsement from the Times39/*.1/ *.*.1/ *.3AM/3/9/The 
Times3K/3/1/ 70/1/1/ DO/1/1/ 4/4/3AM/3/3K/*.*.*.4/3/0/0/DNNT6+2/15H2/3/2/2/8R/1/
9/5/2/D/Nicole Martin1/3/1/2/DB/1/ 1/*.1/ *.*.1/ *.3K/3/1/ 3AQ/3/B/Doctors/BMA*.
*.1/ *.*.1/ 4/4/*.*.*.*.*.*.1/4/1/0/DNNT6+2/15H3/3/2/2/BB/1/9/5/2/E/sandra lavil
le1/3/1/1/DB/R/Going abroad for healthcare1/*.1/ *.*.1/ *.3D9/2/7/Patient46/3/1/
 3D9/3/3/NHS*.*.1/ 4/4/3D9/1/46/*.*.*.4/1/0/0/DNNT6+2/15H4/3/2/2/LF/1/9/4/1/1/ 1
/2/1/1/DQ/1/ 1/DQ/L/Good Friday agreement1/*.1/ *.77/1/1/ 40/3/1/ 41/3/1/ 42/3/1
/ 4/4/77/1/40/77/1/41/4/4/1/0/DNNT6+2/15H5/3/2/2/6G/1/9/5/1/E/David Millward1/3/
1/2/6J/13/Kennedy targets Labour dissidents8/*.1/ *.*.1/ *.72/1/1/ 70/1/1/ 3L/3/
1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNNT6+2/15H9/3/2/2/EK/1/P/3/3/1/ 4/3/1/1/3M/1/
 4/4F/1/ 4/*.1/ *.6J/3/N/Unscrupulous Candidates3B6/3/1/ 3D9/3/1/ *.*.1/ 1/4/*.*
.*.*.*.*.1/4/0/0/DNNT6+2/15HB/3/2/2/80/1/P/2/1/1/ 39/3/2/1/72/1/ 7/EA/1/ 1/*.1/ 
*.70/1/1/ DO/1/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNNT6+2/15HC/3/2/2/27/1/
1/3/3/1/ 1/2/1/1/A8/R/Labour casts aside Lib Dems8/43/1/ 4/A2/1/ 8/70/1/1/ 3M/3/
1/ *.*.1/ *.*.1/ 4/4/70/1/3M/*.*.*.4/4/1/0/DNO2C+2/15K1/3/3/2/O3/1/1/1/1/1/ 1/2/
1/1/3B/1/ 3/9T/G/Appeal to voters39/3K/1/ 2/71/1/1/ 70/1/1/ 10M/2/1/ *.*.1/ 4/4/
71/1/70/10M/1/70/4/1/0/0/DNO2C+2/15K2/3/3/2/FF/1/1/5/1/C/nigel bunyan1/2/1/1/3B/
1/ 3/3T/1/ 4/A1/1/ 8/29T/2/I/Mrs Shaun Woodward3D9/1/L/Mrs Woodward's butlerE6/1
/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNO2C+2/15K6/3/3/2/7N/1/8/1/1/1/ 1/2/1/1/9T/Q
/Photographers ignore Blair8/3B/1/ 3/3C/1/ 4/70/1/1/ 3D9/3/D/Photographers3K/3/1
/ *.*.1/ 1/4/3D9/1/70/3D9/1/3K/1/4/0/0/DNO2C+2/15K8/3/3/2/DC/1/A/4/1/1/ 1/3/1/1/
DQ/1/ 1/4F/1/ 4/*.1/ *.41/3/1/ 77/1/1/ 42/3/1/ 13T/2/G/Brid Rogers/SDLP4/4/77/1/
41/77/1/42/4/4/0/0/DNO2C+2/15K9/3/3/2/NR/1/8/5/2/H/Rachael Sylvester39/3/1/1/3R/
1/ 2/E1/1/ 1/*.1/ *.3B6/3/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 4/4/3B6/2/3K/3B6/2/3L/4/4/1/
0/DNO2C+2/15KA/3/3/2/TG/1/9/5/2/D/Alice Thomson1/2/1/2/3B/1/ 3/73/1/ 39/*.1/ *.H
5/1/1/ 71/1/1/ 3B6/3/1/ *.*.1/ 4/4/3B6/3/H5/*.*.*.3/1/0/0/DNO2C+2/15KB/3/3/2/AK/
1/9/1/1/1/ 1/2/1/1/3C/1/ 4/AE/1/ 39/*.1/ *.71/1/1/ H5/1/1/ 3K/3/1/ *.*.1/ 4/4/H5
/3/71/H5/1/3K/4/4/1/0/DNO2C+2/15KE/3/3/2/EA/1/A/5/1/E/David Millward1/2/1/2/EG/1
/ 1/EA/1/ 1/*.1/ *.72/1/1/ 3B7/1/E/President Bush3K/3/1/ 3L/3/1/ 4/4/72/1/3B7/72
/1/3K/4/1/1/0/DNO2C+2/15KF/3/3/2/CT/1/A/1/1/1/ 1/4/1/1/DE/1/ 1/DF/1/ 1/DG/1/ 1/A
B/1/1/ 47/3/1/ H5/1/1/ 3AF/3/1/ 4/4/H5/1/AB/3AF/1/AB/1/4/1/0/DNO2C+2/15KG/3/3/2/
43/1/A/4/1/1/ 1/3/1/1/6Q/N/ITV to move News at Ten7/*.1/ *.*.1/ *.3BB/3/1/ 3BA/3
/1/ 3AM/1/E/ITN Journalist*.*.1/ 4/4/3BA/1/3BB/3AM/1/3BB/1/4/0/0/DNO2C+2/15KH/3/
3/2/G3/1/A/4/1/1/ 1/3/1/1/3O/1/ 39/6O/1/ 6/*.1/ *.3L/3/1/ 3K/3/1/ *.*.1/ *.*.1/ 
4/4/*.*.*.*.*.*.3/2/0/0/DNO2C+2/15KI/3/3/2/OE/1/B/5/1/C/PJ Bonthrone3/2/1/2/A1/1
/ 8/*.1/ *.*.1/ *.GI/2/B/Claire WardE5/1/1/ 70/1/1/ *.*.1/ 4/4/GI/1/E5/*.*.*.4/4
/1/1/DNO2C+2/15KJ/3/3/2/G5/1/B/5/1/8/Amit Roy2/3/1/2/73/1/ 39/*.1/ *.*.1/ *.GI/1
/I/Piara Singh KhabraN8/1/9/Autar Lit*.*.1/ *.*.1/ 4/4/GI/1/N8/N8/1/GI/4/4/0/0/D
NO2C+2/15KL/3/3/2/15S/1/M/5/1/E/michael barone5/3/1/1/3Q/1/ 2/A3/1/ 8/DG/1/ 1/70
/1/1/ 3K/3/1/ 71/1/1/ 3B6/3/1/ 2/2/3B6/2/3K/*.*.*.2/2/1/0/DNO2C+2/15KN/3/3/2/87/
1/N/2/1/1/ 39/3/2/1/72/1/ 7/9T/S/Urge everyone to vote labour39/*.1/ *.70/1/1/ D
O/1/1/ *.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/1/0/0/DNO5I+2/15NB/3/4/2/10Q/1/1/1/1/1/ 1
/3/1/1/6L/1/ 6/3B/1/ 3/3Q/1/ 2/70/1/1/ 71/1/1/ 72/1/1/ *.*.1/ 4/4/70/1/71/71/1/7
0/4/4/0/0/DNO5I+2/15NC/3/4/2/C2/1/1/5/2/E/sandra laville1/3/1/1/3B/1/ 3/6J/17/Ca
mpaigning candidate catches burglar8/*.1/ *.GI/1/Q/James Selby Bennet (Poole)3D9
/2/G/Burglar's Victim*.*.1/ *.*.1/ 3/4/3D9/3/GI/*.*.*.3/4/0/0/DNO5I+2/15ND/3/4/2
/N1/1/2/1/1/1/ 1/2/1/2/3B/1/ 3/*.1/ *.*.1/ *.3B6/3/1/ 70/1/1/ 71/1/1/ 72/1/1/ 4/
2/*.*.*.*.*.*.4/2/0/0/DNO5I+2/15NG/3/4/2/JC/1/8/1/1/1/ 1/2/1/1/3B/1/ 3/6J/1G/Key
 Tories give reasons for joining Tory party8/*.1/ *.H5/1/1/ H6/2/1/ H2/1/1/ KB/1
/1/ 4/4/H5/1/3K/KB/1/3K/4/4/1/0/DNO5I+2/15NH/3/4/2/D1/1/8/5/1/D/Alan Cochrane1/3
/1/2/6J/H/Scottish election39/*.1/ *.*.1/ *.70/1/1/ 4A/3/1/ 13Q/3/1/ 3L/3/1/ 4/4
/13Q/1/4A/3L/1/4A/1/1/0/0/DNO5I+2/15NI/3/4/2/C6/1/8/5/1/C/sean o'neill1/3/1/1/6L
/1/ 6/3N/1/ 4/*.1/ *.3L/3/1/ 3K/3/1/ 3O/3/1/ 3B6/3/1/ 4/4/3B6/1/3L/3O/1/3L/1/4/0
/0/DNO5I+2/15NJ/3/4/2/C3/1/8/5/1/E/david sharrock1/3/1/1/DQ/1/ 1/DQ/R/Fate of th
e Peace agreement1/3N/1/ 4/3T/3/1/ 77/1/1/ 40/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/
0/DNO5I+2/15NM/3/4/2/O7/1/A/5/1/9/matt born1/3/1/1/6Q/T/TV coverage of election 
night7/*.1/ *.*.1/ *.3BA/3/1/ 3BB/3/1/ 3AM/3/H/Other TV Stations*.*.1/ 4/4/*.*.*
.*.*.*.4/4/0/0/DNO5I+2/15NO/3/4/2/94/1/A/1/2/1/ 1/3/1/2/6J/11/Plans for Tony's s
econd victory39/*.1/ *.*.1/ *.70/1/1/ GI/1/F/Jonathon Powell*.*.1/ *.*.1/ 4/4/*.
*.*.*.*.*.4/4/0/0/DNO5I+2/15NQ/3/4/2/17P/1/B/5/1/C/Neil Tweedie1/3/1/2/73/1/ 39/
*.1/ *.*.1/ *.70/1/1/ 71/1/1/ 3B6/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.2/2/0/0/DNO5I+2/15
NR/3/4/2/6T/1/B/5/1/C/PJ Bonthrone1/3/1/2/49/1/ 5/6L/1/ 6/*.1/ *.3D9/2/1G/Helen 
Pankhurst (Campaigner on Women's Issues)3B6/3/C/Women Voters*.*.1/ *.*.1/ 4/4/*.
*.*.*.*.*.4/4/0/0/DNO5I+2/15NS/3/4/2/93/1/B/1/1/1/ 1/3/1/1/6J/14/Platform speech
es banned in Oldham39/*.1/ *.*.1/ *.N8/1/C/Craig Heeley3D9/3/E/Oldham Council3Q/
3/1/ *.*.1/ 4/4/N8/1/3D9/*.*.*.4/4/0/0/DNO5I+2/15NT/3/4/2/MB/1/O/5/1/A/David Har
e5/3/1/2/A3/1/ 8/GJ/C/Minimum wage1/GJ/1H/Balancing social justice vs economic p
rosperity1/70/1/1/ 3L/3/1/ 72/1/1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/1/0/DNO5I+2/15O0/3
/4/2/IF/1/O/39/1/K/john boone (student)5/3/1/1/9T/1G/Author's excitement at voti
ng for the 1st time39/3K/1/ 2/48/1/ 5/RE/1/B/Evan HarrisN8/1/8/Ed Matts*.*.1/ *.
*.1/ 4/1/*.*.*.*.*.*.4/1/0/0/DNO5I+2/15O3/3/4/2/127/1/P/5/1/E/andrew grimson5/3/
1/1/6T/1/ 39/DE/1/ 1/DG/1/ 1/3B6/3/1/ 3K/3/1/ *.*.1/ *.*.1/ 0/0/3B6/1/3K/*.*.*.4
/1/1/0/DNL2O+2/1EGL/4/3/2/RK/1/G/5/1/H/david aaronovitch2/1/1/2/6Q/1/ 7/45/1/ 2/
*.1/ *.3AM/3/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/0/0/DNL2O+2/1EGM/4/3/
2/176/1/3/3/3/1/ 4/3/1/2/3R/1/ 2/EA/1/ 1/A3/1/ 8/70/1/1/ 71/1/1/ 72/1/1/ *.*.1/ 
2/2/*.*.*.*.*.*.2/2/1/1/DNL2O+2/1EGN/4/3/2/C8/1/1/3/3/1/ 4/3/1/1/3K/1/ 2/3E/1/ 2
/6Q/1/ 7/3K/3/1/ 70/1/1/ 3B6/3/1/ *.*.1/ 4/2/*.*.*.*.*.*.4/2/0/0/DNL2O+2/1EGQ/4/
3/2/I4/1/2/5/1/E/Richard Garner1/3/1/1/DC/1/ 1/6J/13/Election school snubbed by 
Harman8/3D/1/ 3/70/1/1/ GI/2/E/Harriet HarmanKB/1/1/ 3AQ/2/R/Irene Bishop (headm
istress)2/1/KB/1/70/*.*.*.2/1/1/0/DNL2O+2/1EGR/4/3/2/GN/1/2/4/1/1/ 1/3/1/2/DQ/1G
/Trimble threatens to quit over ira disarmament1/*.1/ *.*.1/ *.77/1/1/ 70/1/1/ 1
3T/1/T/Martin McGuinness (Sinn Fein)140/1/E/Peter Robinson4/4/13T/1/77/140/1/77/
2/4/0/0/DNL2O+2/1EGS/4/3/2/E1/1/2/1/1/1/ 1/1/1/2/6J/11/7 bills dropped before el
ection39/*.1/ *.*.1/ *.42/3/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.0/0/DNL2
O+2/1EH1/4/3/2/KB/1/D/1/1/1/ 1/3/1/1/3B/1/ 3/EA/1/ 1/*.1/ *.71/1/1/ 3L/3/1/ *.*.
1/ *.*.1/ 2/2/3L/3/71/*.*.*.2/2/1/1/DNL2O+2/1EH3/4/3/2/238/1/E/1/1/1/ 5/3/1/1/6J
/N/Importance of campaigns39/6L/1/ 6/6J/K/Role of the Lib Dems8/3K/3/1/ 3L/3/1/ 
3M/3/1/ 71/1/1/ 2/2/*.*.*.*.*.*.2/2/0/0/DNL2O+2/1EH4/4/3/2/18H/1/E/1/1/1/ 2/3/1/
1/3N/1/ 4/70/1/ 39/*.1/ *.3D9/3/I/Key Constituencies*.*.1/ *.*.1/ *.*.1/ 4/*.*.*
.*.*.*.*.4/*.0/0/DNL2O+2/1EH8/4/3/2/FD/1/2/3/3/1/ 5/3/1/1/6Q/19/International pr
ess comment on election7/A1/1/ 8/A3/1/ 8/70/1/1/ 3K/3/1/ 3AM/*.1/ *.*.1/ 2/2/*.*
.*.*.*.*.2/2/1/1/DNL2O+2/1EHA/4/3/2/RH/1/1/1/1/1/ 1/2/1/1/3D/1/ 3/3C/1/ 4/3K/1/ 
2/70/1/1/ 71/1/1/ 72/1/1/ *.*.1/ 4/4/71/1/70/72/1/70/4/4/1/0/DNL2O+2/1EHB/4/3/2/
FP/1/1/1/1/1/ 1/2/1/2/3D/1/ 3/*.1/ *.*.1/ *.70/1/1/ 3B6/3/1D/Girls at school whe
re Blair opened election71/1/1/ 72/1/1/ 2/4/*.*.*.*.*.*.2/4/0/0/DNL6+3/1EK1/4/4/
2/G4/1/8/5/1/A/simon carr1/1/2/2/6J/L/Last PM question time39/A1/1/ 8/A3/1/ 8/70
/1/1/ N8/1/E/Philip Hammond71/1/1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/0/1/DNL6+3/1EK2/4/
4/2/DC/1/1/5/1/G/chris blackhurst1/3/1/2/3H/1/ 39/*.1/ *.*.1/ *.70/1/1/ 10O/1/1/
 N8/1/S/Andrew Tyrie MP (Chichester)*.*.1/ 4/4/N8/1/70/*.*.*.1/1/0/0/DNL6+3/1EK3
/4/4/2/8Q/1/2/1/1/1/ 1/3/1/2/3T/1/ 4/*.1/ *.*.1/ *.E6/1/1/ D9/3/1/ 3B3/3/1/ *.*.
1/ 4/4/D9/1/E6/3B3/3/E6/2/4/0/0/DNL6+3/1EK5/4/4/2/RF/1/1/1/1/1/ 1/2/1/1/A6/1/ 9/
DD/1/ 1/EA/1/ 1/71/1/1/ 3K/3/1/ 70/1/1/ 3L/3/1/ 4/4/71/1/3K/70/1/3L/4/4/2/0/DNL6
+3/1EK6/4/4/2/GC/1/5/3/3/1/ 2/3/1/1/6Q/11/Profile of party election teams7/3C/1/
 4/*.1/ *.3L/3/1/ 3K/3/1/ 3M/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNL6+3/1EK7/4/4
/2/B3/1/5/1/1/1/ 1/2/1/1/DE/1/ 1/DG/1/ 1/3K/1/ 2/70/1/1/ AB/1/1/ 3K/3/1/ E9/3/1/
 4/4/E9/1/70/*.*.*.4/4/1/0/DNL6+3/1EK8/4/4/2/SC/1/6/1/1/1/ 1/2/1/1/DE/1/ 1/EB/1/
 1/3I/1/ 3/AB/1/1/ 70/1/1/ 3K/3/1/ 45/3/1/ 4/4/45/1/3K/*.*.*.4/4/2/0/DNL6+3/1EKD
/4/4/2/1A9/1/3/1/1/1/ 5/3/1/1/3Q/1/ 2/3R/1/ 2/40/1/ 4/70/1/1/ 42/3/1/ *.*.1/ *.*
.1/ 2/4/*.*.*.*.*.*.2/4/0/0/DNL6+3/1EKG/4/4/2/K7/1/7/5/1/A/chris gray2/3/1/1/AA/
1/ 8/73/1/ 39/*.1/ *.GI/2/E/Gisela StewartN8/1/E/Nigel Hastilow*.*.1/ *.*.1/ 3/4
/*.*.*.*.*.*.3/4/0/0/DNL96+2/1ENC/4/5/2/JO/1/8/1/1/1/ 8/2/2/1/3B/1/ 3/A1/1/ 8/6J
/E/Commons debate39/71/1/1/ AB/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/1/DNL96+
2/1END/4/5/2/RI/1/4/1/1/1/ 1/3/1/2/DE/1/ 1/A6/1/ 9/A2/1/ 8/AB/1/1/ 3L/3/1/ 3K/3/
1/ H5/1/1/ 4/4/3L/1/3K/3K/1/3L/4/4/2/0/DNL96+2/1ENE/4/5/2/PJ/1/1/1/1/1/ 1/2/1/1/
A6/1/ 9/DE/1/ 1/DG/1/ 1/71/1/1/ AB/1/1/ 70/1/1/ 3L/3/1/ 4/4/AB/1/3L/*.*.*.4/4/1/
0/DNL96+2/1ENG/4/5/2/A2/1/5/5/1/F/philip thornton5/3/1/1/A6/1/ 9/DI/1/ 1/DE/1/ 1
/3L/3/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.3/0/DNL96+2/1ENI/4/4/2/9A/1/5/
1/1/1/ 5/3/1/1/A6/1/ 9/DF/1/ 1/*.1/ *.3L/3/1/ 71/1/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.
*.*.2/2/2/0/DNL96+2/1ENM/4/5/2/8G/1/5/1/1/1/ 5/3/1/1/A6/1/ 9/DD/1/ 1/*.1/ *.3L/3
/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.3/0/DNL96+2/1ENN/4/5/2/4N/1/5/4/2/1
/ 5/3/1/1/A6/1/ 9/DP/1/ 1/*.1/ *.3L/3/1/ 3AM/3/9/Channel 4*.*.1/ *.*.1/ 4/4/3AM/
1/3L/*.*.*.4/4/3/0/DNL96+2/1ENO/4/5/2/70/1/5/4/1/1/ 5/3/1/1/A6/1/ 9/DM/1/ 1/*.1/
 *.3L/3/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.2/0/DNL96+2/1ENR/4/5/2/79/1/
5/1/1/1/ 5/3/1/1/A6/1/ 9/E0/1/ 1/E5/1/ 1/3L/3/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.
*.*.*.4/*.3/0/DNL96+2/1ENS/4/5/2/KR/1/7/1/1/1/ 1/2/1/1/3B/1/ 3/EA/1/ 1/3E/1/ 2/7
0/1/1/ GJ/3/A/Supporters*.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/2/1/DNL96+2/1EO1/4/5/2
/OO/1/3/3/3/1/ 4/3/1/1/A6/1/ 9/DE/1/ 1/EA/1/ 1/3L/3/1/ 71/1/1/ *.*.1/ *.*.1/ 3/4
/*.*.*.*.*.*.3/4/3/0/DNL96+2/1EO3/4/5/2/15B/1/4/5/1/D/michael brown5/3/1/1/A6/1/
 9/EA/1/ 1/*.1/ *.71/1/1/ 3L/3/1/ *.*.1/ *.*.1/ 3/3/*.*.*.*.*.*.3/3/3/0/DNL96+2/
1EO4/4/5/2/178/1/6/3/1/1/ 39/3/1/1/6T/1/ 39/3T/1/ 4/73/1/ 39/GI/1/G/Gerry Bermin
ghamGJ/2/C/Marie RimmerE6/1/1/ 3K/3/1/ 0/0/3B6/1/GI/3B6/1/3K/1/4/0/0/DNL96+2/1EO
5/4/5/2/5H/1/6/1/2/1/ 1/3/1/1/DB/1/ 1/*.1/ *.*.1/ *.R2/1/1/ 42/3/1/ *.*.1/ *.*.1
/ 4/4/R2/1/42/*.*.*.4/1/1/0/DNL96+2/1EO6/4/5/2/CO/1/7/1/2/1/ 1/3/1/1/3T/1/ 4/*.1
/ *.*.1/ *.GI/1/Q/David Milliband (standing)GI/1/P/David Clark MP (retiring)E6/1
/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNLIO+2/1EQL/4/1/2/HB/1/A/3/3/1/ 39/3/1/2/6T/
1/ 39/6S/1/ 39/EA/1/ 1/3K/3/1/ 3L/3/1/ 70/1/1/ 3B6/3/D/Panel Members0/0/3B6/2/3K
/3B6/1/3L/2/2/1/0/DNLIO+2/1EQM/4/1/2/5K/1/7/3/3/1/ 39/3/1/2/A1/1/ 8/*.1/ *.*.1/ 
*.3AL/1/1/ 70/1/1/ *.*.1/ *.*.1/ 4/1/*.*.*.*.*.*.4/1/0/1/DNLIO+2/1EQP/4/1/2/7J/1
/9/1/1/1/ 1/2/1/1/DK/1/ 1/DM/1/ 1/*.1/ *.70/1/1/ 3K/3/1/ 3D9/3/A/Unemployed*.*.1
/ 4/4/*.*.*.*.*.*.4/4/2/0/DNLIO+2/1EQQ/4/1/2/77/1/1/1/1/1/ 1/3/1/1/3C/1/ 4/*.1/ 
*.*.1/ *.3B8/2/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNLIO+2/1EQR/4/1
/2/TK/1/1/1/1/1/ 1/3/1/1/3S/1/ A/3C/1/ 4/A2/1/ 8/DS/1/1/ 3K/3/1/ 70/1/1/ AB/1/1/
 4/4/*.*.*.*.*.*.4/2/1/0/DNLIO+2/1EQS/4/1/2/FF/1/7/1/2/1/ 1/3/1/1/3C/1/ 4/6J/J/R
eplacing Mandleson8/*.1/ *.DS/1/1/ E8/3/18/Campaign and Communication Specialist
s3K/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNLIO+2/1ER0/4/1/2/I3/1/8/5/1/B/Ian Herb
ert1/3/1/1/3T/1/ 4/*.1/ *.*.1/ *.E6/1/1/ 3K/3/1/ GJ/3/A/SupportersGJ/2/C/Marie R
immer1/1/GJ/2/E6/*.*.*.1/1/0/0/DNLIO+2/1ER3/4/1/2/GD/1/9/1/1/1/ 1/3/1/1/6L/1/ 6/
DE/1/ 1/*.1/ *.71/1/1/ 70/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/1/DNLIO+2/1ER
4/4/1/2/J6/1/A/5/1/D/matthew beard2/3/1/2/73/1/ 39/3K/1/ 2/*.1/ *.GI/1/D/Stephen
 TwiggN8/1/A/John Flack*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNLIO+2/1ER7/4/1/2/
18F/1/4/39/1/F/Peter Mandelson5/2/1/1/A2/1/ 8/A3/1/ 8/DI/1/ 1/6J/3/A/New Labour6
J/3/13/Post Thatcherite Social Democrats*.*.1/ *.*.1/ 3/3/*.*.*.*.*.*.3/3/2/0/DN
LM+3/1F01/4/2/2/T2/1/7/1/1/1/ 1/2/1/2/3S/1/ A/3B/1/ 3/*.1/ *.70/1/1/ E8/3/T/Camp
aign Managers/Strategists3B6/3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNLM+3/1F02/4/2
/2/6J/1/3/3/3/1/ 4/3/1/2/3I/1F/Relationship between celebrities and politics39/3
C/1/ 4/6S/1/ 39/3B8/2/1/ 3K/3/1/ 3L/3/1/ 3M/3/1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNLM+3/
1F07/4/2/2/PK/1/1/1/1/1/ 1/3/1/1/6L/1/ 6/DE/1/ 1/A9/1/ 8/70/1/1/ 71/1/1/ 3L/3/1/
 H5/1/1/ 4/4/70/1/3L/*.*.*.2/1/1/0/DNLM+3/1F08/4/2/2/H8/1/1/1/2/1/ 1/2/1/1/A7/1/
 9/DB/1/ 1/EA/1/ 1/72/1/1/ 3M/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/3/0/DNLM+3/
1F09/4/2/2/LP/1/2/1/1/1/ 8/2/1/1/3B/1/ 3/A3/1/ 8/*.1/ *.RE/1/C/Edward DaveyN8/1/
A/David ShawAB/1/1/ 3K/3/1/ 4/1/*.*.*.*.*.*.4/1/0/0/DNLM+3/1F0B/4/2/2/1AG/1/6/1/
1/1/ 2/2/1/1/ED/1/ 1/6S/1/ 39/*.1/ *.AB/1/1/ 3AB/3/1/ H5/1/1/ 3K/3/1/ 4/1/H5/1/A
B/*.*.*.4/1/3/0/DNLM+3/1F0C/4/2/2/GE/1/8/1/2/1/ 1/2/1/1/DC/1/ 1/3B/1/ 3/*.1/ *.7
2/1/1/ 3K/3/1/ 3M/3/1/ R8/1/1/ 4/4/72/1/3K/*.*.*.4/4/2/0/DNLM+3/1F0D/4/2/2/E8/1/
8/1/1/1/ 1/2/1/1/D9/L/Plaid Cymru manifesto9/GJ/C/Welsh issues1/*.1/ *.3O/3/1/ 7
5/1/1/ 13R/1/D/Dafydd Wigley*.*.1/ 4/4/*.*.*.*.*.*.4/4/2/1/DNLM+3/1F0E/4/2/2/OT/
1/9/1/1/1/ 1/1/1/1/DE/1/ 1/A9/1/ 8/3B/1/ 3/71/1/1/ KK/1/1/ 42/3/1/ 3B6/3/1/ 1/4/
71/1/42/3B6/1/71/1/4/1/0/DNLM+3/1F0F/4/2/2/16Q/1/9/4/1/1/ 1/2/1/1/3T/1/ 4/3B/1/ 
3/*.1/ *.E6/1/1/ 3B6/3/1/ 70/1/1/ *.*.1/ 1/4/3B6/1/E6/70/3/E6/1/4/0/0/DNLM+3/1F0
H/4/2/2/19S/1/3/1/1/1/ 5/3/1/2/A5/1/ 9/DO/1/ 1/EA/1/ 1/3K/3/1/ 3L/3/1/ 3M/3/1/ *
.*.1/ 2/2/*.*.*.*.*.*.2/2/3/0/DNLM+3/1F0I/4/2/2/16E/1/4/4/1/1/ 5/2/1/2/A7/1/ 9/E
A/1/ 1/*.1/ *.72/1/1/ 3L/3/1/ 3K/3/1/ *.*.1/ 4/1/72/1/3L/72/2/3K/4/1/3/0/DNLP6+2
/1F3C/4/3/2/DO/1/1/1/1/1/ 1/2/1/1/DD/1/ 1/4E/1/ 4/*.1/ *.3L/3/1/ N9/1/16/Michael
 Dobbs (former vice-chairman)3B3/1/1Q/Harry Fletcher (National Association Proba
tion Officers)D9/1/C/Paul Boateng1/4/N9/1/3L/3B3/1/3L/1/4/1/0/DNLP6+2/1F3D/4/3/2
/FL/1/6/5/1/C/john rentoul2/3/1/2/6Q/12/Analysis of negative advertising7/*.1/ *
.*.1/ *.3K/3/1/ 3L/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.1/1/0/0/DNLP6+2/1F3F/4/3/2
/8H/1/8/1/2/1/ 1/3/1/1/A7/1/ 9/A7/1/ 9/*.1/ *.3M/3/1/ 72/1/1/ RA/1/D/Chris Renna
rd*.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNLP6+2/1F3I/4/3/2/N3/1/1/1/1/1/ 1/2/1/1/A5/1/ 
9/A2/1/ 8/EA/1/ 1/70/1/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNLP6+2
/1F3J/4/3/2/M3/1/2/1/1/1/ 8/3/1/1/A7/1/ 9/3B/1/ 3/DI/1/ 1/72/1/1/ NP/1/1/ 3M/3/1
/ AB/1/1/ 1/1/*.*.*.*.*.*.1/1/2/0/DNLP6+2/1F3K/4/3/2/HA/1/7/1/2/1/ 1/3/1/1/3L/1/
 4/6S/1/ 39/*.1/ *.10H/1/1/ 3M/3/1/ GJ/3/H/Labour Supporters3L/3/1/ 4/4/10H/3/3M
/10H/1/3L/4/4/0/0/DNLP6+2/1F3L/4/3/2/IE/1/8/1/2/1/ 1/2/1/1/A7/1/ 9/EA/1/ 1/*.1/ 
*.72/1/1/ 3M/3/1/ E3/1/1/ H2/1/1/ 4/4/E3/1/3M/H2/1/3M/4/4/3/0/DNLP6+2/1F3R/4/3/2
/158/1/4/39/1/10/mark seddon - labour candidate5/3/1/1/EA/1/ 1/EB/1/ 1/6J/12/Pre
dicting lab manifesto content8/3K/3/1/ 3L/3/1/ *.*.1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4
/3/0/DNLP6+2/1F3S/4/3/2/LK/1/6/1/1/1/ 1/3/1/2/DF/1/ 1/A9/1/ 8/3B/1/ 3/71/1/1/ N8
/1/O/Pro-EU Referendum Tories3B6/1/1/ *.*.1/ 1/4/3B6/1/71/N8/1/71/1/4/1/0/DNLSC+
2/1F6M/4/4/2/1AB/1/3/1/1/1/ 5/3/1/2/A5/1/ 9/6J/1H/What Labour have to achieve to
 maintain support8/EA/1/ 1/70/1/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.2/0/
DNLSC+2/1F6P/4/4/2/119/1/9/5/1/C/paul vallely1/2/1/1/3B/1/ 3/DR/1/ 1/73/1/ 39/70
/1/1/ 78/1/1/ 3D9/3/C/Bangladeshis3AM/3/1/ 4/4/3D9/1/3AM/*.*.*.4/4/1/0/DNLSC+2/1
F6R/4/4/2/NQ/1/1/1/1/1/ 1/2/1/1/3H/1/ 39/3P/1/ 3/E7/1/ 1/AE/1/1/ 70/1/1/ 3B9/1/1
/ 3B3/1/M/Dave Prentiss (UNISON)1/1/*.*.*.*.*.*.1/1/1/0/DNLSC+2/1F72/4/4/2/4H/1/
6/3/3/1/ 1/3/1/1/A5/1/ 9/*.1/ *.*.1/ *.GI/1/F/David MillibandGJ/1/P/Ed Richards 
(Policy Unit)*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNLSC+2/1F74/4/4/2/A3/1/7/4/2
/1/ 5/3/1/1/A5/1/ 9/DI/1/ 1/DE/1/ 1/3K/3/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*
.2/*.2/0/DNLSC+2/1F75/4/4/2/9B/1/7/1/2/1/ 5/3/1/1/A5/1/ 9/E3/1/ 1/DL/1/ 1/3K/3/1
/ 3AI/3/C/Rural Groups3B6/3/C/Rural Voters*.*.1/ 2/4/3AI/3/3K/3B6/1/3K/2/4/3/0/D
NLSC+2/1F76/4/4/2/9J/1/7/4/1/1/ 5/3/1/1/A5/1/ 9/DC/1/ 1/*.1/ *.3K/3/1/ *.*.1/ *.
*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.3/0/DNLSC+2/1F79/4/4/2/95/1/7/4/2/1/ 5/3/1/1/GJ/
8/Families1/A5/1/ 9/*.1/ *.3K/3/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.3/1/
DNLSC+2/1F7B/4/4/2/77/1/7/1/1/1/ 5/3/1/1/E5/1/ 1/A5/1/ 9/*.1/ *.3K/3/1/ *.*.1/ *
.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.4/*.3/0/DNLSC+2/1F7E/4/4/2/6P/1/7/5/1/F/lorna duckw
orth5/3/1/2/A5/1/ 9/DH/1/ 1/*.1/ *.3K/3/1/ 3AS/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.
*.4/4/3/0/DNLSC+2/1F7F/4/4/2/C8/1/8/5/1/B/ian burrell1/2/1/1/3P/1/ 3/DD/1/ 1/3B/
1/ 3/AH/1/1/ 3AN/3/F/Police OfficersH6/2/1/ 3D9/3/H/Police Federation1/4/H6/1/AH
/3AN/1/AH/1/4/1/0/DNLSC+2/1F7J/4/4/2/D9/1/2/4/2/1/ 5/3/1/2/A1/1/ 8/*.1/ *.*.1/ *
.70/1/1/ 71/1/1/ 3M/3/1/ *.*.1/ 2/1/*.*.*.*.*.*.1/1/0/0/DNLSC+2/1F7K/4/4/2/13M/1
/3/3/3/1/ 4/3/1/1/A3/1/ 8/EA/1/ 1/*.1/ *.70/1/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.
*.*.*.1/*.3/1/DNLSC+2/1F7L/4/4/2/L3/1/3/5/1/D/miles kington5/3/2/1/72/10/Lighthe
arted look at elections7/*.1/ *.*.1/ *.6J/3/D/Party Leaders*.*.1/ *.*.1/ *.*.1/ 
1/*.*.*.*.*.*.*.1/*.0/0/DNLSC+2/1F7M/4/4/2/GB/1/9/1/2/1/ 1/3/1/1/6J/17/Deliberat
ely not fielding a candidate39/3C/1/ 4/DB/1/ 1/3M/3/1/ GI/1/A/David Lock10L/1/1/
 *.*.1/ 4/4/GI/1/3M/3M/3/10L/4/4/1/0/DNM1I+2/1FA1/4/5/2/4E/1/A/39/1/A/uri gellar
39/3/1/2/6S/1/ 39/*.1/ *.*.1/ *.3L/3/1/ *.*.1/ *.*.1/ *.*.1/ 3/*.*.*.*.*.*.*.3/*
.0/0/DNM1I+2/1FA2/4/5/2/KM/1/9/1/1/1/ 1/2/1/2/D9/L/Green Party Manifesto9/EA/1/ 
1/*.1/ *.3P/3/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.3/0/DNM1I+2/1FA3/4/5/2
/O3/1/1/1/1/1/ 1/2/1/1/3H/1/ 39/3C/1/ 4/3B/1/ 3/AE/1/1/ 70/1/1/ 3AN/3/1/ 71/1/1/
 4/4/70/3/AE/71/1/AE/2/4/0/1/DNM1I+2/1FA4/4/5/2/9O/1/1/5/1/F/fred bridgeland1/2/
1/2/3B/1/ 3/44/1/ 3/*.1/ *.AE/1/1/ GJ/3/1/ *.*.1/ *.*.1/ 4/4/GJ/3/AE/*.*.*.3/4/0
/0/DNM1I+2/1FA5/4/5/2/B0/1/6/1/1/1/ 1/2/1/1/3P/1/ 3/DD/1/ 1/A2/1/ 8/AH/1/1/ H6/2
/1/ 3D9/3/H/Police Federation*.*.1/ 4/4/3D9/1/AH/3D9/3/H6/1/3/1/1/DNM1I+2/1FA6/4
/5/2/17F/1/6/1/1/1/ 1/2/1/1/3H/1/ 39/3E/1/ 2/3J/1/ 2/70/1/1/ 3K/3/1/ AE/1/1/ 71/
1/1/ 4/2/70/3/AE/71/1/AE/4/2/0/2/DNM1I+2/1FA7/4/5/2/LT/1/2/1/1/1/ 8/3/1/1/3H/1/ 
39/3B/1/ 3/*.1/ *.AE/1/1/ 70/1/1/ 71/1/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/1/DNM1I+2
/1FA8/4/5/2/DG/1/6/3/3/1/ 1/3/1/2/6T/1/ 39/44/1/ 3/*.1/ *.AE/1/1/ 3B6/3/1/ 3AP/1
/1/ *.*.1/ 2/4/3B6/3/AE/3AP/1/AE/2/4/0/0/DNM1I+2/1FAA/4/5/2/EI/1/7/5/3/B/ian her
bert1/3/1/2/3P/1/ 3/*.1/ *.*.1/ *.3B9/1/1/ AE/1/1/ 3B6/1/S/Stuart Roberts (farm 
worker)3D9/1/1H/Darren Humphries (school friend of Craig Evans)3/4/3B6/3/3B9/3D9
/3/3B9/3/4/0/2/DNM1I+2/1FAB/4/5/2/FQ/1/8/1/1/1/ 1/3/1/2/6J/S/Ex-Labour member vs
 Woodward8/3T/1/ 4/*.1/ *.E6/1/1/ 140/1/14/Neil Thompson (Socialist Alliance)*.*
.1/ *.*.1/ 4/4/140/1/E6/*.*.*.4/4/0/0/DNM1I+2/1FAC/4/5/2/R6/1/8/5/1/B/cahal milm
o2/3/1/1/3P/1/ 3/DB/1/ 1/*.1/ *.3AK/2/D/Sharon Storer3K/3/1/ 70/1/1/ 3D9/3/1B/So
uth Birmingham Community Health Council4/4/3AK/1/3K/3AK/1/70/4/4/0/0/DNM1I+2/1FA
G/4/5/2/132/1/A/4/1/1/ 2/3/1/2/6J/K/N. Ireland elections39/DQ/1/ 1/*.1/ *.13T/1/
N/Pat Doherty (Sinn Fein)13T/1/M/William Thompson (UUP)13T/2/J/Brid Rodgers (SDL
P)*.*.1/ 2/4/*.*.*.*.*.*.2/4/0/1/DNM1I+2/1FAI/4/5/2/KA/1/3/3/3/1/ 4/3/1/1/3H/1/ 
39/3P/1/ 3/6J/G/Out of touch MPs2/AE/1/1/ 70/1/1/ 46/3/1/ *.*.1/ 2/2/*.*.*.*.*.*
.2/2/0/1/DNM1I+2/1FAJ/4/5/2/JL/1/3/5/1/D/Miles Kington5/3/1/1/3C/1/ 4/6Q/1/ 7/DL
/1/ 1/3K/3/1/ 71/1/1/ 3AM/3/1/ *.*.1/ 4/1/*.*.*.*.*.*.4/1/1/0/DNM1I+2/1FAK/4/5/2
/15R/1/4/5/1/D/michael brown5/3/1/1/3T/1/ 4/4C/1/ 39/*.1/ *.E6/1/1/ 3K/3/1/ *.*.
1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/0/0/DNM1I+2/1FAL/4/5/2/L2/1/4/5/1/D/terence baker5
/3/1/1/6J/12/Violence can enhance reputations39/3H/1/ 39/*.1/ *.3D9/3/11/Various
 People who have PunchedAE/1/1/ *.*.1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/0/0/DNMB6+2/1F
DB/4/1/2/EE/1/9/1/1/1/ 5/3/1/2/6L/1/ 6/44/1/ 3/3K/1/ 2/3K/3/1/ 3L/3/1/ AE/1/1/ 3
B6/3/1/ 2/2/*.*.*.*.*.*.2/2/0/0/DNMB6+2/1FDD/4/1/2/18O/1/6/4/1/1/ 2/3/1/2/DL/1/ 
1/3C/1H/Delaying announcements that might affect voting4/*.1/ *.42/3/1/ AE/1/1/ 
3AQ/1/G/Judge Vandermeer3AI/3/1D/Council for the Protection of Rural England1/4/
3AI/1/42/*.*.*.1/4/1/0/DNMB6+2/1FDE/4/1/2/KT/1/1/1/1/1/ 1/3/1/1/DI/1/ 1/DE/1/ 1/
A8/1/ 8/3L/3/1/ 3K/3/1/ 70/1/1/ KS/1/F/Maurice Saatchi4/4/3K/1/3L/KS/3/70/1/4/2/
0/DNMB6+2/1FDF/4/1/2/5P/1/7/1/1/1/ 1/3/1/1/A9/1/ 8/DF/1/ 1/9T/1G/Urge people to 
vote against tory euro-sceptics39/N9/1/12/John de Courcy Ling (ex Tory MP)N8/3/M
/Eurosceptic Candidates3M/3/1/ 3L/3/1/ 4/4/N9/1/N8/N9/3/3M/4/4/0/0/DNMB6+2/1FDG/
4/1/2/GD/1/7/1/1/1/ 1/2/1/1/DS/1/ 1/DD/1/ 1/A2/1/ 8/AH/1/1/ H6/2/1/ RE/1/C/Paul 
Burstow3L/3/1/ 4/4/H6/1/AH/RE/2/AH/4/4/2/0/DNMB6+2/1FDH/4/1/2/E2/1/1/1/1/1/ 1/3/
1/1/DO/1/ 1/*.1/ *.*.1/ *.3B3/1/I/John Edmunds (GMB)AH/1/1/ 3D9/2/S/Refugee Coun
cil SpokespersonH6/1/1/ 4/4/3B3/1/AH/H6/1/AH/4/1/1/0/DNMB6+2/1FDM/4/1/2/16H/1/8/
1/1/1/ 2/2/1/1/A1/1/ 8/3C/1/ 4/EA/1/ 1/140/1/E/Tommy Sheridan6H/3/O/Scottish Soc
ialist Party*.*.1/ *.*.1/ 3/4/*.*.*.*.*.*.3/4/2/2/DNMEC+2/1FGL/4/2/2/GM/1/9/3/3/
1/ 39/3/1/2/6T/1/ 39/DO/1/ 1/*.1/ *.3B6/3/1/ 3K/3/1/ *.*.1/ *.*.1/ 0/0/3D9/2/71/
*.*.*.4/2/1/0/DNMEC+2/1FGM/4/2/2/98/1/8/1/2/1/ 1/2/1/2/DJ/1/ 1/DL/1/ 1/*.1/ *.72
/1/1/ 3K/3/1/ R9/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNMEC+2/1FGN/4/2/2/AO/1/6/5
/2/J/katherine griffiths2/3/1/2/DT/1/ 1/EC/1/ 1/*.1/ *.42/3/1/ 3L/3/1/ *.*.1/ *.
*.1/ 4/4/3L/1/42/*.*.*.4/4/1/0/DNMEC+2/1FGO/4/2/2/E2/1/6/1/1/1/ 1/2/1/2/6S/1/ 39
/41/1/ 4/*.1/ *.3L/3/1/ 3AB/3/1/ *.*.1/ *.*.1/ 4/4/3AB/3/3L/*.*.*.3/4/0/0/DNMEC+
2/1FGR/4/2/2/GL/1/1/1/1/1/ 1/3/1/1/DT/1/ 1/EC/1/ 1/DE/1/ 1/AB/1/1/ 3K/3/1/ 71/1/
1/ H5/1/1/ 4/2/71/1/3K/H5/1/AB/4/2/1/0/DNMEC+2/1FGS/4/2/2/KQ/1/2/1/1/1/ 8/3/2/1/
9T/L/Looking for Keith Vaz39/A1/1/ 8/*.1/ *.E5/1/1/ GJ/3/M/Vaz's Election Worker
s*.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/1/DNMEC+2/1FH2/4/2/2/H0/1/7/5/1/B/cahal mil
mo1/2/1/1/AA/1/ 8/EA/1/ 1/*.1/ *.6H/3/Q/Monster Raving Loony Party140/1/18/Lord 
Hope - Monster Raving Loony Party140/1/K/Screaming Lord Sutch*.*.1/ 3/3/*.*.*.*.
*.*.3/3/1/0/DNMEC+2/1FH4/4/2/2/FC/1/8/1/1/1/ 1/3/1/1/6S/N/Times to support Labou
r39/6S/O/Media support for Labour39/*.1/ *.3AM/3/9/The Times3AM/3/7/The Sun*.*.1
/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNMEC+2/1FH7/4/2/2/5A/1/9/39/1/C/andy kershaw39
/3/1/1/6S/1/ 39/*.1/ *.*.1/ *.3M/3/1/ 70/1/1/ 6J/3/A/Old Labour*.*.1/ 3/1/*.*.*.
*.*.*.3/1/1/1/DNMEC+2/1FH8/4/2/2/DO/1/2/39/1/1/ 5/3/1/1/9T/19/European interest 
in campaign (lack of)39/6Q/N/European press coverage7/*.1/ *.70/1/1/ 71/1/1/ 72/
1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNMEC+2/1FH9/4/2/2/1A4/1/3/1/1/1/ 5/3/1/1/6Q
/T/Analysis of election campaign7/DE/1/ 1/EB/1/ 1/72/1/1/ 3M/3/1/ 3K/3/1/ 3L/3/1
/ 3/3/*.*.*.*.*.*.3/3/2/0/DNMHI+2/1FK1/4/3/2/19E/1/3/5/2/C/anne mcelvoy5/3/1/2/6
J/1Q/Labour accuses broadcasters of colluding with protesters39/6Q/1/ 7/3C/1/ 4/
E1/2/1/ 3K/3/1/ 3L/3/1/ 3AM/3/1/ 1/1/E1/1/3AM/*.*.*.1/1/1/1/DNMHI+2/1FK2/4/3/2/B
4/1/6/1/1/1/ 1/2/1/2/DG/1/ 1/3B/1/ 3/*.1/ *.10M/2/1/ 70/1/1/ 71/1/1/ 3K/3/1/ 4/4
/10M/1/70/10M/1/3K/4/4/1/0/DNMHI+2/1FK3/4/3/2/1D1/1/6/1/1/1/ 5/3/1/2/3C/1/ 4/6Q/
1/ 7/*.1/ *.3K/3/1/ 3L/3/1/ GI/2/1/ 3AM/3/1/ 1/4/3AM/1/3K/3K/1/3AM/1/4/0/0/DNMHI
+2/1FK7/4/3/2/J0/1/1/2/1/1/ 5/2/2/1/A1/1/ 8/3B/1/ 3/*.1/ *.10M/2/1/ 71/1/1/ *.*.
1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/0/0/DNMHI+2/1FK8/4/3/2/IO/1/1/1/1/1/ 1/2/1/1/DT/1/
 1/A8/1/ 8/*.1/ *.AB/1/1/ H5/1/1/ 3L/3/1/ *.*.1/ 4/4/H5/1/AB/AB/1/3L/4/4/1/0/DNM
HI+2/1FKA/4/3/2/A1/1/7/5/1/B/mike pflanz1/3/1/1/6S/1/ 39/AA/1/ 8/*.1/ *.3AE/2/G/
Vanessa Redgrave140/1/D/Michael Roche6H/3/D/Marxist Party*.*.1/ 4/4/140/3/3AE/*.
*.*.4/4/1/0/DNMHI+2/1FKD/4/3/2/GP/1/9/1/2/1/ 1/3/1/1/42/1/ 39/6J/A/Ethnic MPs8/*
.1/ *.3D9/2/E/Women's Groups6J/3/S/3 main parties - lab/con/lib*.*.1/ *.*.1/ 4/4
/3D9/1/6J/*.*.*.4/4/0/0/DNMHI+2/1FKE/4/3/2/CS/1/9/1/2/1/ 1/3/1/1/41/1/ 4/*.1/ *.
*.1/ *.3D9/1/G/Tory Benefactors3L/3/1/ 3K/3/1/ 3D9/1/I/Labour Benefactors4/4/*.*
.*.*.*.*.4/4/0/0/DNMHI+2/1FKG/4/3/2/DJ/1/2/39/1/1/ 5/3/1/1/6J/R/Compare US and U
K campaigns4/*.1/ *.*.1/ *.3D9/3/7/Britain3D9/3/D/United States*.*.1/ *.*.1/ 4/4
/*.*.*.*.*.*.4/4/0/0/DNMHI+2/1FKJ/4/3/2/DO/1/9/3/3/1/ 39/3/1/1/6T/1/ 39/6Q/1/ 7/
3P/1/ 3/3B6/3/1/ AE/1/1/ *.*.1/ *.*.1/ 0/0/3B6/2/AE/*.*.*.0/2/0/1/DNMKO+2/1FNB/4
/4/2/HL/1/A/3/3/1/ 39/3/1/2/DC/1/ 1/6J/R/Education experts manifesto39/*.1/ *.3A
P/3/L/Teacher's Association3K/3/1/ 3L/3/1/ 3D9/3/1/ 4/4/3AP/2/3K/*.*.*.4/4/1/0/D
NMKO+2/1FNC/4/4/2/1AJ/1/5/5/2/E/natasha walter5/3/1/2/42/1/ 39/GJ/E/Women's issu
es1/*.1/ *.GI/2/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/2/*.*.*.*.*.*.4/2/1/0/DNMKO+2/1FND/4/
4/2/5D/1/9/39/1/B/ben pimlott39/3/1/2/6S/1/ 39/*.1/ *.*.1/ *.3K/3/1/ *.*.1/ *.*.
1/ *.*.1/ 3/*.*.*.*.*.*.*.3/*.1/0/DNMKO+2/1FNE/4/4/2/7P/1/9/4/1/1/ 1/3/1/2/A3/1/
 8/40/1/ 4/*.1/ *.70/1/1/ 3D9/3/A/Charter 883K/3/1/ *.*.1/ 1/4/3D9/1/70/3D9/1/3K
/1/4/1/1/DNMKO+2/1FNH/4/4/2/OO/1/1/1/1/1/ 1/3/1/1/6Q/1/ 7/3C/1/ 4/*.1/ *.70/1/1/
 3AM/3/C/Broadcasters3L/3/1/ *.*.1/ 4/4/70/1/3AM/70/1/3L/4/4/1/0/DNMKO+2/1FNI/4/
4/2/L7/1/2/1/1/1/ 8/3/2/1/GJ/8/The Dome1/6J/11/Wording of government statement39
/*.1/ *.42/3/1/ KA/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNMKO+2/1FNK/4/4/2
/JO/1/6/5/1/E/stephen castle1/3/1/1/DF/1/ 1/*.1/ *.*.1/ *.3AG/1/G/Fritz Bolkeste
in3D9/3/9/Brussells3D9/3/2/UK*.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNMKO+2/1FNM/4/4/2/B
G/1/6/1/1/1/ 1/3/1/1/D9/2D/Manifestos of 3 main parties would not produce change
s in public services9/DE/1/ 1/EB/1/ 1/3BC/3/S/Institute for Fiscal Studies42/3/1
/ 3L/3/1/ 3M/3/1/ 4/4/3BC/2/42/3BC/2/3L/2/2/1/0/DNMKO+2/1FNN/4/4/2/2OB/1/7/1/1/1
/ 6/3/1/1/3C/1/ 4/DF/1/ 1/E1/1/ 1/70/1/1/ 3L/3/1/ *.*.1/ *.*.1/ 4/4/70/1/3L/*.*.
*.3/4/3/0/DNMKO+2/1FNO/4/4/2/LP/1/8/1/2/1/ 1/3/1/1/6J/14/Increase in independent
 candidates39/42/1/ 39/*.1/ *.3K/3/1/ 6J/3/M/Independent Candidates*.*.1/ *.*.1/
 4/4/*.*.*.*.*.*.4/4/0/0/DNMKO+2/1FNP/4/4/2/10R/1/9/5/1/E/barrie clement2/2/1/1/
AA/1/ 8/73/1/ 39/3T/1/ 4/GI/1/C/Chris Bryant3K/3/1/ 140/2/O/Leanne Wood  Plaid C
ymru*.*.1/ 4/2/140/1/3K/*.*.*.4/2/0/1/DNMKO+2/1FNS/4/4/2/KB/1/3/3/3/1/ 4/3/1/1/D
G/1/ 1/DF/1/ 1/A8/R/Party differences on Europe8/3K/3/1/ 70/1/1/ 3L/3/1/ 71/1/1/
 2/1/*.*.*.*.*.*.2/1/2/0/DNMKO+2/1FNT/4/4/2/DQ/1/2/39/3/1/ 5/3/1/1/45/1/ 2/6J/13
/Lack of political "personalities"39/*.1/ *.9T/3/O/Party leaders in general*.*.1
/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/1/DNMO+3/1FQL/4/5/2/LR/1/1/1/1/1/ 1/3/1/1/
E7/1/ 1/E1/1/ 1/6L/1/ 6/70/1/1/ 3K/3/1/ 3B3/3/1/ 71/1/1/ 2/1/3B3/1/3K/3B3/1/71/2
/1/2/0/DNMO+3/1FQO/4/5/2/4Q/1/6/3/3/1/ 1/3/1/1/6M/1/ 6/*.1/ *.*.1/ *.3AM/3/F/The
 Independent3AR/3/1/ *.*.1/ *.*.1/ 4/4/3AM/3/3AR/*.*.*.4/4/0/0/DNMO+3/1FQQ/4/5/2
/QB/1/7/1/1/1/ 1/2/1/1/3B/1/ 3/DC/1/ 1/3C/1/ 4/70/1/1/ 3AQ/3/1/ 3B3/1/1/ 3D9/3/8
/Students4/4/3AQ/1/70/3D9/1/70/1/4/1/0/DNMO+3/1FR0/4/5/2/1AC/1/8/1/1/1/ 1/2/1/1/
3B/1/ 3/DG/1/ 1/A9/1/ 8/L3/1/1/ 3B6/3/1/ *.*.1/ *.*.1/ 4/4/3B6/1/L3/3B6/3/L3/4/4
/1/0/DNMO+3/1FR1/4/5/2/ER/1/8/1/1/1/ 1/2/1/1/DF/1/ 1/DG/1/ 1/6J/13/Modern patrio
tism vs isolationism39/70/1/1/ 3M/3/1/ 3L/3/1/ H2/1/1/ 4/4/70/1/3L/H2/1/3K/4/4/1
/0/DNMO+3/1FR2/4/5/2/7F/1/8/1/1/1/ 1/3/1/1/DD/1/ 1/*.1/ *.*.1/ *.3AI/1/B/Tony Ma
rtin3K/3/1/ 3L/3/1/ *.*.1/ 4/4/3AI/1/3K/3AI/1/3L/4/4/1/0/DNMO+3/1FR3/4/5/2/AK/1/
8/5/3/A/Terri Judd1/3/1/2/DN/1/ 1/3H/1/ 39/*.1/ *.DM/1/1/ 3B3/3/M/National Farme
rs Union44/3/4/MAFFH7/1/1/ 4/4/H7/1/44/*.*.*.1/4/1/0/DNMO+3/1FR4/4/5/2/NE/1/9/1/
1/1/ 2/3/1/2/3P/1/ 3/*.1/ *.*.1/ *.3AK/3/1/ 70/1/1/ 71/1/1/ *.*.1/ 4/4/*.*.*.*.*
.*.4/4/0/0/DNMO+3/1FR6/4/5/2/J1/1/A/1/2/1/ 2/3/1/1/6J/F/Invisible women39/42/1/ 
39/3C/1/ 4/3K/3/1/ 3L/3/1/ 3D9/3/F/Fawcett SocietyH6/2/1/ 1/1/3D9/1/3K/3D9/1/3L/
1/1/0/0/DNN3I+2/1G01/4/1/2/C2/1/1/1/1/1/ 1/3/1/1/4A/1/ 4/3C/1/ 4/3K/1/ 2/3K/3/1/
 GJ/3/D/Party Workers70/1/1/ KB/1/1/ 4/4/KB/1/70/*.*.*.4/4/0/0/DNN3I+2/1G02/4/1/
2/LE/1/2/1/1/1/ 8/3/2/1/72/1/ 7/A3/1/ 8/*.1/ *.70/1/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.
*.*.*.*.*.*.1/*.0/0/DNN3I+2/1G03/4/1/2/D4/1/3/5/3/B/cahal milmo2/3/1/1/6J/17/BNP
 puts forward candidates in Oldham8/DR/1/ 1/*.1/ *.3Q/3/1/ 78/1/1/ 140/1/C/Phil 
Edwards3D9/3/F/Racist Attacker1/4/140/1/3D9/*.*.*.1/4/1/0/DNN3I+2/1G04/4/1/2/G2/
1/6/1/1/1/ 1/3/1/1/DF/1/ 1/DG/1/ 1/*.1/ *.3B9/1/1/ 3K/3/1/ 3L/3/1/ 71/1/1/ 4/4/3
L/1/3B9/*.*.*.4/4/1/0/DNN3I+2/1G05/4/1/2/8C/1/6/1/1/1/ 1/2/1/1/3R/1/ 2/6O/R/Tori
es heading for disaster6/*.1/ *.72/1/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 4/4/72/1/3K/72/1/
3L/4/4/0/0/DNN3I+2/1G08/4/1/2/LF/1/7/5/1/H/David Aaronovitch5/3/1/1/6Q/1/ 7/6J/P
/Right desperate for votes39/*.1/ *.6J/3/9/The Right3AM/3/L/Political Journalist
s*.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNN3I+2/1G0A/4/1/2/OR/1/8/1/1/1/ 2/3/1/1/
6L/1/ 6/DB/1/ 1/DC/1/ 1/3L/3/1/ 71/1/1/ 3K/3/1/ 3B6/3/1/ 1/1/3B6/1/3L/3B6/1/3K/1
/1/1/0/DNN3I+2/1G0B/4/1/2/2J/1/8/39/2/H/Vivienne Westwood39/3/1/1/6S/1/ 39/DE/1/
 1/DF/1/ 1/3M/3/1/ *.*.1/ *.*.1/ *.*.1/ 3/*.*.*.*.*.*.*.3/*.1/0/DNN3I+2/1G0C/4/1
/2/108/1/9/4/1/1/ 1/2/1/2/A1/1/ 8/*.1/ *.*.1/ *.GI/2/J/Shona McIsaac (Lab)N8/1/C
/Stephen Howd3B6/3/1/ *.*.1/ 3/4/3B6/3/GI/*.*.*.3/1/0/1/DNN3I+2/1G0E/4/1/2/K6/1/
2/39/2/11/heidi kingstone (sa journalist)39/3/1/1/3B/1/ 3/3E/1/ 2/*.1/ *.70/1/1/
 71/1/1/ 3K/3/1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/0/1/DNN3I+2/1G0F/4/1/2/19I/1/3/5/1/E
/bruce anderson5/3/1/2/A1/1/ 8/*.1/ *.*.1/ *.70/1/1/ AB/1/1/ 71/1/1/ *.*.1/ 2/1/
*.*.*.*.*.*.2/1/1/1/DNN3I+2/1G0H/4/1/2/K7/1/4/39/1/1/ 39/2/1/1/D9/L/Green Party 
Manifesto9/EA/1/ 1/*.1/ *.3P/3/1/ *.*.1/ *.*.1/ *.*.1/ 3/*.*.*.*.*.*.*.3/*.2/0/D
NN6O+2/1G3C/4/2/2/13N/1/9/5/1/E/Bruce Anderson2/3/1/1/AA/1/ 8/73/1/ 39/*.1/ *.N8
/1/D/John Charters6J/3/N/'Dumfries' constituency3B6/3/1/ *.*.1/ 3/4/*.*.*.*.*.*.
3/4/0/1/DNN6O+2/1G3E/4/2/2/K2/1/1/5/1/E/stephen castle1/4/1/1/DF/1/ 1/DG/1/ 1/6L
/1/ 6/3AG/1/C/Romano Prodi71/1/1/ 3AG/1/D/Lionel Jospin70/1/1/ 4/4/71/1/70/3AG/1
/71/4/4/1/0/DNN6O+2/1G3F/4/2/2/HB/1/1/1/1/1/ 1/3/1/1/E7/1/ 1/DB/1/ 1/*.1/ *.3B5/
3/E/Health Experts3K/3/1/ 70/1/1/ *.*.1/ 4/4/3B5/1/3K/*.*.*.4/1/1/0/DNN6O+2/1G3G
/4/2/2/LN/1/2/1/1/1/ 8/3/2/1/A1/1/ 8/DG/1/ 1/*.1/ *.3L/3/1/ H2/1/1/ E3/1/1/ *.*.
1/ 1/1/E3/1/3L/*.*.*.1/1/1/0/DNN6O+2/1G3H/4/2/2/GK/1/6/1/1/1/ 1/3/1/2/DG/1/ 1/6Q
/1/ 7/*.1/ *.70/1/1/ AB/1/1/ 3AM/3/1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/2/1/DNN6O+2/1G3
I/4/2/2/1D1/1/6/4/1/1/ 2/4/1/1/DF/1/ 1/*.1/ *.*.1/ *.3B9/1/1/ 70/1/1/ 71/1/1/ *.
*.1/ 4/4/*.*.*.*.*.*.4/4/3/0/DNN6O+2/1G3J/4/2/2/KR/1/6/1/1/1/ 1/3/1/1/DG/1/ 1/*.
1/ *.*.1/ *.3L/3/1/ 3K/3/1/ 70/1/1/ 71/1/1/ 4/4/70/1/71/3L/1/3K/4/4/1/0/DNN6O+2/
1G3L/4/2/2/Q7/1/7/4/3/1/ 2/3/1/1/DQ/1/ 1/*.1/ *.*.1/ *.3S/3/1/ 41/3/1/ 3T/3/1/ 4
0/3/1/ 4/4/*.*.*.*.*.*.4/4/1/1/DNN6O+2/1G3M/4/2/2/9G/1/7/1/1/1/ 1/2/1/1/AC/1/ 9/
ED/1/ 1/GJ/1F/Attracting overseas firms/Economic competence1/3K/3/1/ 70/1/1/ *.*
.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNN6O+2/1G3O/4/2/2/29/1/7/39/2/N/amy jenkins/
tv director39/3/1/1/6S/1/ 39/43/1/ 4/*.1/ *.3K/3/1/ 70/1/1/ *.*.1/ *.*.1/ 3/3/*.
*.*.*.*.*.3/3/0/1/DNN6O+2/1G3P/4/2/2/G7/1/8/3/3/1/ 39/3/1/1/6T/1/ 39/A1/1/ 8/*.1
/ *.71/1/1/ 3B6/3/1/ *.*.1/ *.*.1/ 0/0/3B6/1/71/3B6/2/71/1/0/0/2/DNN6O+2/1G3Q/4/
2/2/CK/1/8/1/1/1/ 5/2/1/1/DL/1/ 1/A2/1/ 8/GJ/G/Women's policies1/3M/3/1/ 3L/3/1/
 RE/2/D/Lib-Dem Women*.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNN6O+2/1G3R/4/2/2/KP/1/8/1/
2/1/ 2/3/1/1/3C/1/ 4/AA/1/ 8/DL/1/ 1/3P/3/1/ 13S/3/7/Various*.*.1/ *.*.1/ 4/4/*.
*.*.*.*.*.4/4/1/0/DNN6O+2/1G41/4/2/2/194/1/3/1/1/1/ 5/3/1/2/DG/1/ 1/*.1/ *.*.1/ 
*.3K/3/1/ 3L/3/1/ AC/1/1/ H2/1/1/ 4/2/*.*.*.*.*.*.4/1/2/0/DNN6O+2/1G43/4/2/2/168
/1/4/5/1/D/tim luckhurst5/3/1/1/EE/1/ 1/D9/1B/Why Britain will never have a Scot
tish PM39/*.1/ *.AB/1/1/ 46/3/C/Scottish MPs6J/3/J/Scottish Parliament6J/3/B/Wes
tminster4/4/*.*.*.*.*.*.4/4/2/0/DNNA+3/1G6L/4/3/2/KD/1/1/1/1/1/ 1/3/1/1/DF/1/ 1/
A9/1/ 8/3C/1/ 4/71/1/1/ N9/3/1D/Tory Moderates (Ian Taylor/Stephen Dorrell)N8/1/
C/Lord Brittan*.*.1/ 4/4/N9/1/71/N8/1/71/1/4/1/0/DNNA+3/1G6M/4/3/2/DI/1/1/1/2/1/
 1/3/1/1/6J/S/Centrally-organised protests39/6Q/1/ 7/*.1/ *.3AI/3/H/Countryside 
Alert70/1/1/ AE/1/1/ *.*.1/ 4/4/AE/1/3AI/*.*.*.4/4/0/0/DNNA+3/1G6Q/4/3/2/GP/1/6/
1/1/1/ 1/2/1/1/DE/1/ 1/A2/1/ 8/EC/1/ 1/71/1/1/ 3L/3/1/ 3K/3/1/ E3/1/1/ 4/4/71/1/
3K/E3/1/3L/4/4/3/0/DNNA+3/1G6S/4/3/2/14E/1/7/1/1/1/ 1/2/1/1/A8/N/Lab/Con Counter
 attacks8/3C/1/ 4/*.1/ *.10I/1/1/ AG/2/1/ 70/1/1/ 71/1/1/ 4/4/10I/1/70/AG/1/71/4
/4/0/2/DNNA+3/1G6T/4/3/2/9C/1/7/1/1/1/ 1/3/1/2/3H/1F/Blair attacked for associat
ion with Microsoft8/*.1/ *.*.1/ *.70/1/1/ KG/1/1/ 72/1/1/ 3AB/1/N/Oliver Roll - 
Microsoft4/4/KG/1/70/72/1/70/1/4/0/0/DNNA+3/1G70/4/3/2/TJ/1/8/5/1/E/barrie cleme
nt2/3/1/1/6J/19/Increasing appeal of Welsh Nationalists8/A1/J/Arrogance of Labou
r8/*.1/ *.3K/3/1/ 3O/3/1/ 3L/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNNA+3/1G72/4/3
/2/BO/1/8/1/1/1/ 1/2/1/2/E7/1/ 1/AC/1/ 9/ED/1/ 1/AE/1/1/ 3K/3/1/ N8/1/C/Tim Loug
hton3AB/3/G/City Businessmen4/4/N8/1/3K/*.*.*.1/1/1/0/DNNA+3/1G76/4/3/2/L3/1/2/3
9/2/1H/graciela iglesias-rogers/argentinian journalist39/3/1/1/3K/1/ 2/6J/10/Com
pulsory Voting in Argentina4/6J/Q/Briefing the foreign press39/3K/3/1/ GI/1/E/Da
vid Miliband*.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNNA+3/1G78/4/3/2/1A7/1/3/5/2/
C/anne mcelvoy5/3/1/1/9T/N/Why author loves voting39/A1/D/William Hague8/A3/6/La
bour8/70/1/1/ 71/1/1/ 3K/3/1/ 3L/3/1/ 3/1/*.*.*.*.*.*.3/1/0/0/DNNA+3/1G79/4/3/2/
NB/1/3/5/1/D/miles kington5/3/2/1/72/1/ 7/6Q/1/ 7/*.1/ *.3K/3/1/ 3L/3/1/ 3M/3/1/
 *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNND6+2/1GA1/4/4/2/8S/1/1/1/1/1/ 1/3/1/1/E7/1/ 1
/E1/1/ 1/*.1/ *.3K/3/1/ 3D9/3/1E/Martin Taylor (commission investigating ppp)70/
1/1/ 3BC/3/4/IPPR4/4/3D9/1/3K/*.*.*.1/4/1/0/DNND6+2/1GA3/4/4/2/OJ/1/6/1/1/1/ 1/2
/1/1/DD/N/Criminal Justice reform1/DD/Q/Abuse of frontline workers1/GJ/N/Compuls
ory skills tests1/70/1/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/3/0/DNND6+2/
1GA4/4/4/2/FD/1/6/4/1/1/ 1/2/2/2/6J/13/Jordan makes a one day appearance39/3C/1/
 4/*.1/ *.3AE/2/6/JordanN9/1/F/Gyles Brandreth*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/
1/0/DNND6+2/1GA5/4/4/2/CK/1/6/1/2/1/ 1/2/1/1/GJ/14/Flexible working hours for pa
rents1/*.1/ *.*.1/ *.DN/1/1/ 3B3/3/4/TGWU3AC/3/3/CBI*.*.1/ 4/4/3B3/1/DN/3AC/3/DN
/4/4/1/0/DNND6+2/1GA8/4/4/2/TR/1/7/1/1/1/ 1/3/1/1/6J/K/Signs of Tory defeat8/3C/
1/ 4/A9/1/ 8/71/1/1/ 3L/3/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.*.*.1/1/1/1/DNND6+2/1GA9/
4/4/2/ED/1/7/1/1/1/ 1/2/1/1/6J/1H/Tories try to distance themselves from Thatche
r8/DG/1/ 1/A9/1/ 8/H5/1/1/ 10M/2/1/ *.*.1/ *.*.1/ 4/4/H5/1/10M/*.*.*.4/1/1/0/DNN
D6+2/1GAA/4/4/2/IO/1/7/1/1/1/ 1/3/1/1/DG/1/ 1/DG/1/ 1/*.1/ *.3D9/3/M/Euro 'Yes' 
Campaigners3D9/3/G/'no' campaigners3L/3/1/ 70/1/1/ 4/4/3D9/1/3L/3L/1/70/4/4/1/0/
DNND6+2/1GAC/4/4/2/RD/1/8/5/2/9/mary brad2/3/1/1/6J/L/The Scottish election39/D9
/G/Scottish parties39/EE/1/ 1/4B/3/1/ 4A/3/1/ 3N/3/1/ 3B6/3/1/ 1/4/*.*.*.*.*.*.1
/4/1/0/DNND6+2/1GAE/4/4/2/KE/1/8/3/3/1/ 39/3/1/2/6T/1/ 39/6J/G/Personal attacks3
9/*.1/ *.3B6/3/1/ 70/1/1/ 3K/3/1/ 3L/3/1/ 4/2/3B6/2/3K/3B6/2/3L/4/2/0/0/DNND6+2/
1GAG/4/4/2/43/1/9/39/2/B/kathy lette39/3/1/1/6S/1/ 39/*.1/ *.*.1/ *.3K/3/1/ 3L/3
/1/ *.*.1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/0/0/DNND6+2/1GAI/4/4/2/CJ/1/A/1/1/1/ 1/2/1
/1/46/1/ 5/DH/1/ 1/EF/1/ 1/KR/1/1/ 3M/3/1/ 72/1/1/ 3K/3/1/ 4/4/KR/1/3K/3M/1/3K/4
/4/2/0/DNND6+2/1GAM/4/4/2/1AF/1/5/5/1/D/michael dobbs5/3/1/1/3F/1/ 2/3E/1/ 2/D9/
N/Parties' lack of vision8/3K/3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/
0/DNNGC+2/1GDB/4/5/2/KA/1/1/1/1/1/ 1/2/1/1/DG/1/ 1/A9/1/ 8/*.1/ *.L3/1/1/ 71/1/1
/ 70/1/1/ *.*.1/ 4/4/L3/1/71/L3/3/70/4/1/1/0/DNNGC+2/1GDC/4/5/2/I3/1/1/4/2/1/ 1/
3/1/1/DB/1/ 1/DC/1/ 1/A3/1/ 8/3K/3/1/ 3D9/1/J/Dr Peter Harker/BMA3B3/1/F/David H
art/NAHT*.*.1/ 4/4/3D9/1/3K/3B3/1/3K/1/4/1/0/DNNGC+2/1GDF/4/5/2/G6/1/6/4/1/1/ 1/
4/1/1/DC/1/ 1/E1/1/ 1/GJ/R/Britain a 3rd world country1/3B3/1/H/David Hart (NAHT
)3K/3/1/ 3L/3/1/ *.*.1/ 4/4/3B3/1/3K/3B3/1/3L/4/4/1/0/DNNGC+2/1GDG/4/5/2/90/1/6/
1/1/1/ 1/2/1/2/DE/R/Working families tax credit1/*.1/ *.*.1/ *.3K/3/1/ 3L/3/1/ A
B/1/1/ E3/1/1/ 4/4/E3/1/3L/*.*.*.4/1/2/0/DNNGC+2/1GDI/4/5/2/4A/1/7/39/1/C/barry 
norman39/3/1/2/6S/1/ 39/EA/1/ 1/*.1/ *.3M/3/1/ 3K/3/1/ *.*.1/ *.*.1/ 3/2/*.*.*.*
.*.*.3/1/1/0/DNNGC+2/1GDK/4/5/2/JB/1/8/4/1/1/ 1/3/1/1/6Q/1B/Domination of certai
n people in the press7/*.1/ *.*.1/ *.3AM/3/9/The Press70/1/1/ 71/1/1/ 3M/3/1/ 4/
4/3AM/1/70/3AM/1/71/4/4/0/1/DNNGC+2/1GDM/4/5/2/R3/1/9/1/1/1/ 1/2/1/1/3B/1/ 3/72/
14/Hague beats Blair in coolness test7/*.1/ *.3K/3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 1/2
/*.*.*.*.*.*.1/2/0/1/DNNGC+2/1GDQ/4/5/2/19S/1/3/39/1/O/michael brown ex tory mp5
/3/1/1/6J/G/Dying Tory party8/A1/1/ 8/4C/1/ 39/3L/3/1/ 3K/3/1/ N9/1/9/Defectors*
.*.1/ 2/1/*.*.*.*.*.*.2/1/1/0/DNNGC+2/1GDR/4/5/2/L6/1/4/5/1/F/terence blacker5/3
/1/2/72/21/Relationship between baldness and lack of success in politics7/*.1/ *
.*.1/ *.71/1/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.1/*.0/0/DNNQ+3/1GGL/4/1/2/N
2/1/1/1/1/1/ 1/2/1/1/3R/1/ 2/48/1/ 5/*.1/ *.70/1/1/ 71/1/1/ 3K/3/1/ 3L/3/1/ 4/4/
3K/1/71/3L/1/70/4/4/0/1/DNNQ+3/1GGO/4/1/2/J0/1/6/1/1/1/ 1/3/1/1/3M/1/ 4/4F/1/ 4/
*.1/ *.49/3/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.0/0/DNNQ+3/1GGP/4/1/2/9S
/1/6/1/2/1/ 1/3/1/2/6J/1C/Lib Dems risk all male parliamentary party8/3L/1/ 4/*.
1/ *.3M/3/1/ 72/1/1/ 3K/3/1/ 3L/3/1/ 4/4/*.*.*.*.*.*.1/1/0/0/DNNQ+3/1GGR/4/1/2/5
M/1/6/1/1/1/ 1/2/1/1/DB/1/ 1/E7/1/ 1/*.1/ *.71/1/1/ 3K/3/1/ 70/1/1/ 3AM/3/C/BBC 
Panorama4/4/3K/1/71/3AM/1/70/4/4/1/0/DNNQ+3/1GGT/4/1/2/10E/1/8/5/1/B/ian herbert
1/3/1/2/3O/1/ 39/E0/B/Council Tax1/6O/1/ 6/3K/3/1/ 3L/3/1/ 3M/3/1/ 3B5/3/1D/Rall
ings and Thrasher - Plymouth University4/4/*.*.*.*.*.*.2/1/1/0/DNNQ+3/1GH4/4/1/2
/KS/1/2/5/1/A/tom levine5/3/1/1/3C/1/ 4/3B/1/ 3/3E/1/ 2/46/3/1/ 70/1/1/ 71/1/1/ 
*.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNNQ+3/1GH5/4/1/2/KO/1/3/3/3/1/ 4/3/1/1/3R/1/ 2/E
5/1/ 1/43/1/ 4/70/1/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/1/1/DNNQ+3/1GH
7/4/1/2/17M/1/4/5/1/B/janes rubin5/3/1/1/6J/12/Compare US and British elections4
/GJ/J/Moral/social issues1/*.1/ *.3D9/3/7/Britain3D9/3/D/United States70/1/1/ *.
*.1/ 3/2/*.*.*.*.*.*.3/2/2/0/DNNT6+2/1GK1/4/2/2/7L/1/1/1/1/1/ 1/2/2/1/6J/10/Brem
ner goes on campaign trail3/3B/1/ 3/*.1/ *.3AE/1/C/Rory BremnerAB/1/1/ 3D9/1/19/
Andrew Dunn - pretend Alastair CampbellDO/1/1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNNT6+2/1
GK2/4/2/2/FQ/1/1/1/1/1/ 1/3/1/1/3R/1/ 2/6L/1/ 6/3C/1/ 4/71/1/1/ 3K/3/1/ 70/1/1/ 
3L/3/1/ 4/4/71/1/3K/70/1/3L/2/2/0/0/DNNT6+2/1GK5/4/2/2/JE/1/6/1/2/1/ 1/3/1/1/49/
1/ 5/GJ/E/Women's issues1/3J/1/ 2/3L/3/1/ 6J/2/12/Conservative women's associati
on3K/3/1/ 3M/3/1/ 1/4/6J/1/3L/6J/1/3K/1/4/1/0/DNNT6+2/1GK6/4/2/2/B9/1/6/5/1/D/ti
m luckhurst2/3/1/1/A9/1/ 8/EE/1/ 1/*.1/ *.6J/3/P/Breakaway Scottish Tories4B/3/1
/ *.*.1/ *.*.1/ 4/1/6J/1/4B/*.*.*.4/1/1/0/DNNT6+2/1GKA/4/2/2/10N/1/7/5/1/C/john 
sweeney2/3/1/1/73/1/ 39/*.1/ *.*.1/ *.10B/1/1/ L4/1/1/ 3D9/1/J/Bishop Michael Re
id*.*.1/ 3/2/*.*.*.*.*.*.3/2/0/2/DNNT6+2/1GKB/4/2/2/13D/1/8/1/1/1/ 5/3/1/1/6L/1/
 6/6M/1/ 6/*.1/ *.3K/3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/1/0/DNNT6+2
/1GKD/4/2/2/F2/1/8/1/1/1/ 1/3/1/2/3M/1/ 4/*.1/ *.*.1/ *.49/3/1/ 70/1/1/ *.*.1/ *
.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNNT6+2/1GKE/4/2/2/GK/1/8/5/1/F/stephen pollard1/3
/1/1/6O/F/Odds on winning6/*.1/ *.*.1/ *.3AR/3/1/ 3K/3/1/ 3L/3/1/ 3M/3/1/ 4/4/*.
*.*.*.*.*.4/4/0/0/DNNT6+2/1GKF/4/2/2/EN/1/8/1/1/1/ 1/3/1/2/DN/1F/Rumours about a
 livestock cull after election1/*.1/ *.*.1/ *.71/1/1/ 42/3/1/ 44/3/4/MAFF3B3/3/M
/National Farmers Union4/4/42/1/71/*.*.*.4/4/0/0/DNNT6+2/1GKI/4/2/2/HC/1/9/1/2/1
/ 1/2/1/2/EA/1/ 1/*.1/ *.*.1/ *.70/1/1/ AB/1/1/ E5/1/1/ DS/1/1/ 4/4/70/3/AB/70/3
/E5/4/4/1/0/DNO2C+2/1GNB/4/3/2/JH/1/1/1/1/1/ 1/3/1/1/DG/1/ 1/A2/1/ 8/6L/1/ 6/70/
1/1/ 10M/2/1/ 71/1/1/ *.*.1/ 4/4/70/1/10M/71/1/70/4/4/1/0/DNO2C+2/1GND/4/3/2/11S
/1/6/1/1/1/ 1/2/1/1/A3/1/ 8/A2/1/ 8/EA/1/ 1/70/1/1/ 10M/2/1/ 3L/3/1/ AB/1/1/ 4/1
/70/1/10M/70/1/3L/4/1/2/0/DNO2C+2/1GNE/4/3/2/G7/1/6/1/1/1/ 1/2/1/1/GJ/N/Section 
28 - Gay rights1/A5/1/ 9/3C/1/ 4/AF/1/1/ AA/1/1/ 3D9/3/D/Gay Activists3K/3/1/ 4/
4/3D9/1/3K/AF/2/AA/4/4/1/0/DNO2C+2/1GNF/4/3/2/HC/1/6/1/1/1/ 1/3/1/1/4A/1/ 4/3N/1
/ 4/6J/F/Floating voters5/3K/3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0
/DNO2C+2/1GNH/4/3/2/HR/1/7/1/1/1/ 1/2/1/1/A8/16/Hague attacks Blair over kids sc
hool8/3B/1/ 3/3G/1/ 39/71/1/1/ 70/1/1/ 3K/3/1/ *.*.1/ 4/4/71/1/70/71/1/3K/4/4/1/
2/DNO2C+2/1GNL/4/3/2/DS/1/8/39/3/1/ 39/3/1/1/6T/1/ 39/3R/1/ 2/*.1/ *.3K/3/1/ 3L/
3/1/ 3B6/3/1/ *.*.1/ 0/0/3B6/2/3L/3B6/2/3M/2/2/0/0/DNO2C+2/1GP0/4/3/2/9J/1/1/4/2
/1/ 1/3/1/1/6Q/1/ 7/*.1/ *.*.1/ *.3BB/3/1/ 3BA/3/1/ *.*.1/ *.*.1/ 4/4/3BA/1/3BB/
*.*.*.1/4/0/0/DNO5I+2/1GQL/4/4/2/OG/1/1/1/1/1/ 1/3/1/1/3C/1/ 4/3Q/1/ 2/4A/1/ 4/7
0/1/1/ 71/1/1/ 72/1/1/ 3K/3/1/ 4/4/71/1/70/70/1/71/4/1/0/1/DNO5I+2/1GQM/4/4/2/JE
/1/2/1/1/1/ 1/3/1/1/AF/1/ 39/A2/1/ 8/*.1/ *.70/1/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*
.*.*.*.*.4/*.2/0/DNO5I+2/1GQP/4/4/2/11A/1/E/1/1/1/ 1/2/1/1/3B/1/ 3/3C/1/ 4/A2/1/
 8/72/1/1/ TT/3/1/ 13S/3/1/ *.*.1/ 4/4/13S/1/72/*.*.*.4/4/1/0/DNO5I+2/1GQQ/4/4/2
/10F/1/F/1/1/1/ 1/2/1/1/3B/1/ 3/6J/P/Forces of conservationism39/3C/1/ 4/71/1/1/
 3L/3/1/ H5/1/1/ H6/2/1/ 2/2/*.*.*.*.*.*.2/2/0/0/DNO5I+2/1GQS/4/4/2/31S/1/G/3/3/
1/ 39/3/1/2/71/1/ 39/*.1/ *.*.1/ *.3K/3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 4/4/*.*.*.*.*.
*.4/4/0/0/DNO5I+2/1GQT/4/4/2/HR/1/G/5/1/D/sean O' Grady39/3/1/2/6O/1/ 6/*.1/ *.*
.1/ *.71/1/1/ 3L/3/1/ 3K/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNO5I+2/1GR0/4/4/2/
N0/1/H/5/2/B/louise jury1/3/1/1/6Q/16/Broadcast coverage of election night7/*.1/
 *.*.1/ *.3AM/3/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.0/0/DNO5I+2/1GR2/4/4
/2/CD/1/I/39/3/6/voters39/3/1/1/A2/1/ 8/6T/1/ 39/*.1/ *.3K/3/1/ 3L/3/1/ 3M/3/1/ 
3B6/3/1/ 0/0/3B6/2/3K/3B6/2/3L/2/2/1/1/DNO5I+2/1GR3/4/4/2/OP/1/J/5/1/H/david aar
onovitch5/3/1/1/6Q/11/Disappearance of the Tory press7/*.1/ *.*.1/ *.3AM/3/5/Pre
ss3AM/3/F/Broadcast Media*.*.1/ *.*.1/ 2/3/*.*.*.*.*.*.2/3/0/0/DNO5I+2/1GR5/4/4/
2/PT/1/J/5/1/7/ben chu5/3/1/1/6Q/18/Analysis of press coverage of campaign7/*.1/
 *.*.1/ *.3AM/3/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 4/4/3AM/2/3K/3AM/2/3L/4/4/1/0/DNO5I+2/
1GRB/4/4/2/RN/1/5/5/1/A/mark steel5/3/1/1/6J/P/Emergence of the new left39/*.1/ 
*.*.1/ *.70/1/1/ 71/1/1/ 6H/3/I/Socialist Alliance6H/3/O/Scottish Socialist Part
y1/1/*.*.*.*.*.*.1/1/1/0/DNO5I+2/1GRC/4/4/2/1AL/1/5/5/1/C/hamish mcrae5/3/1/2/6S
/1/ 39/DI/1/ 1/E1/1/ 1/3K/3/1/ 3L/3/1/ 3B6/3/1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/2/0/D
NL2O+2/1PK3/5/3/1/FA/1/8/1/1/1/ 2/3/1/1/4D/1/ 39/D9/I/'Faceless' new MPs8/D9/G/M
illbank control39/139/3/C/Retiring MPs139/3/F/'Pager Puppets'*.*.1/ *.*.1/ 3/1/*
.*.*.*.*.*.3/1/0/1/DNL2O+2/1PK4/5/3/1/CR/1/1/3/3/1/ 1/2/1/1/3D/1/ 3/6O/1/ 6/*.1/
 *.70/1/1/ 71/1/1/ *.*.1/ *.*.1/ 3/1/71/1/70/*.*.*.3/1/0/0/DNL2O+2/1PK5/5/3/1/KB
/1/8/1/1/1/ 1/2/1/1/A3/1/ 8/A2/1/ 8/EA/1/ 1/70/1/1/ 71/1/1/ *.*.1/ *.*.1/ 3/4/71
/1/70/*.*.*.3/4/2/0/DNL6+3/1PNB/5/4/1/H6/1/6/1/1/1/ 1/1/1/2/6J/P/Last parliament
ary debate39/DF/1/ 1/6L/1/ 6/71/1/1/ 70/1/1/ 10F/1/1/ *.*.1/ 4/4/71/1/70/*.*.*.3
/1/2/0/DNL6+3/1PNE/5/4/1/K2/1/8/39/1/D/William Hague39/2/1/1/A6/1/ 9/EA/1/ 1/A2/
1/ 8/3L/3/1/ 3AM/3/7/The Sun42/3/1/ *.*.1/ 3/3/*.*.*.*.*.*.3/3/2/0/DNL6+3/1PNF/5
/4/1/BI/1/1/1/1/1/ 1/3/1/1/AD/1/ 39/*.1/ *.*.1/ *.70/1/1/ AB/1/1/ *.*.1/ *.*.1/ 
4/4/AB/3/70/70/1/AB/4/1/1/0/DNL6+3/1PNH/5/4/1/3K/1/7/3/3/1/ 1/2/1/1/3B/1/ 3/DE/1
/ 1/*.1/ *.H5/1/1/ 42/3/1/ *.*.1/ *.*.1/ 2/4/H5/1/42/*.*.*.2/4/1/0/DNL96+2/1PQM/
5/5/1/LQ/1/8/39/1/A/tony blair5/2/1/2/A2/1/ 8/EA/1/ 1/72/D/Sun manifesto7/3AM/3/
7/The Sun3L/3/1/ 3K/3/1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/2/0/DNL96+2/1PQP/5/5/1/P1/1/
8/1/1/1/ 1/2/1/1/A6/1/ 9/DE/1/ 1/EA/1/ 1/71/1/1/ 3L/3/1/ AB/1/1/ 3K/3/1/ 4/4/71/
1/3K/AB/1/3K/4/4/3/0/DNL96+2/1PQQ/5/5/1/3M/1/9/3/3/1/ 1/2/1/1/DQ/1/ 1/3B/1/ 3/*.
1/ *.13P/1/1/ 77/1/1/ 3T/3/1/ 40/3/1/ 4/4/13P/1/77/*.*.*.4/4/1/0/DNLIO+2/1Q01/5/
1/1/7N/1/9/3/3/1/ 1/2/1/2/DE/1/ 1/EC/1/ 1/*.1/ *.3AC/1/H/Digby Jones - CBI70/1/1
/ 3AL/1/B/David Frost*.*.1/ 4/2/*.*.*.*.*.*.4/2/1/0/DNLIO+2/1Q02/5/1/1/1Q/1/9/3/
3/1/ 1/2/1/2/4E/1/ 4/*.1/ *.*.1/ *.3B8/2/1/ 70/1/1/ 10M/2/1/ *.*.1/ 4/4/3B8/3/70
/*.*.*.4/4/0/0/DNLIO+2/1Q03/5/1/1/30/1/8/3/3/1/ 1/3/1/1/3T/1/ 4/*.1/ *.*.1/ *.E6
/1/1/ 3K/3/1/ 3B3/1/1/ *.*.1/ 4/4/3B3/1/3K/*.*.*.1/4/0/0/DNLIO+2/1Q08/5/1/1/3E/1
/9/1/1/1/ 1/3/1/1/6O/R/Hague's dad says he'll lose6/*.1/ *.*.1/ *.277/1/1/ 3L/3/
1/ *.*.1/ *.*.1/ 4/4/277/2/3L/*.*.*.2/4/0/0/DNLM+3/1Q3E/5/2/1/4B/1/2/1/1/1/ 1/3/
1/2/DB/1/ 1/A5/1/ 9/*.1/ *.3AQ/2/K/Matrons in Hospitals70/1/1/ 3D9/3/10/Cleaners
/caterers in hospitals*.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNLM+3/1Q3G/5/2/1/31/1/2/3/
3/1/ 1/2/1/1/3B/10/PM clashes with John Humphreys3/3G/1/ 39/*.1/ *.70/1/1/ 3AM/1
/9/The Media*.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/0/0/DNLM+3/1Q3I/5/2/1/31/1/2/1/1/1
/ 1/2/1/1/3H/1E/Torie's Welsh manifesto has spelling mistake39/3C/1/ 4/3P/1/ 3/3
L/3/1/ 71/1/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/1/0/0/DNLP6+2/1Q6L/5/3/1/3R/1/2/3
/3/1/ 1/2/1/2/A3/1/ 8/A2/1/ 8/*.1/ *.70/1/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.
*.4/*.1/0/DNLP6+2/1Q6M/5/3/1/8O/1/7/1/1/1/ 3/3/1/2/A1/1/ 8/*.1/ *.*.1/ *.AA/1/1/
 *.*.1/ *.*.1/ *.*.1/ 3/*.*.*.*.*.*.*.3/*.0/2/DNLP6+2/1Q6N/5/3/1/1N0/1/6/4/2/1/ 
6/3/1/1/A1/1/ 8/AA/1/ 8/A3/1/ 8/AA/1/1/ *.*.1/ *.*.1/ *.*.1/ 3/*.*.*.*.*.*.*.3/*
.0/3/DNLP6+2/1Q6O/5/3/1/3E/1/1/1/1/1/ 1/3/1/1/D9/S/Blunkett next home secretary8
/A3/1/ 8/*.1/ *.AA/1/1/ E7/3/1/ *.*.1/ *.*.1/ 3/4/E7/3/AA/*.*.*.3/4/1/0/DNLP6+2/
1Q6Q/5/3/1/41/1/2/3/3/1/ 1/3/1/1/DF/17/Tory support to quit EU/EU referendum1/*.
1/ *.*.1/ *.71/1/1/ N9/3/10/Tory MPs/Candidates in General*.*.1/ *.*.1/ 4/4/*.*.
*.*.*.*.4/4/0/0/DNLP6+2/1Q6R/5/3/1/42/1/2/3/3/1/ 1/3/1/1/A9/1/ 8/DE/1/ 1/*.1/ *.
71/1/1/ KK/1/1/ 70/1/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNLP6+2/1Q6S/5/3/1/82/1/2
/1/1/1/ 1/2/1/2/A9/1C/Blair/Brown the controversial relationship8/DI/1/ 1/*.1/ *
.70/1/1/ AB/1/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNLP6+2/1Q70/5/3/1/5T/1/6
/3/3/1/ 4/3/1/2/A1/1/ 8/A3/1/ 8/*.1/ *.AA/1/1/ 70/1/1/ AB/1/1/ *.*.1/ 3/4/*.*.*.
*.*.*.3/4/1/0/DNLP6+2/1Q72/5/3/1/5T/1/8/3/3/1/ 4/3/1/1/A1/1/ 8/A3/1/ 8/*.1/ *.AA
/1/1/ 70/1/1/ AB/1/1/ *.*.1/ 3/4/*.*.*.*.*.*.3/4/1/1/DNLP6+2/1Q73/5/3/1/JD/1/8/1
/1/1/ 5/3/1/1/DE/1/ 1/A9/1/ 8/*.1/ *.H5/1/1/ 3L/3/1/ KK/1/1/ 71/1/1/ 2/1/*.*.*.*
.*.*.2/1/1/0/DNLSC+2/1QA2/5/4/1/1C8/1/9/1/1/1/ 1/2/1/2/A5/1/ 9/EA/1/ 1/A2/1/ 8/7
0/1/1/ 3K/3/1/ 71/1/1/ *.*.1/ 3/3/71/1/70/*.*.*.3/3/3/0/DNLSC+2/1QA3/5/4/1/7K/1/
9/1/1/1/ 5/2/1/1/6J/O/Blair - centred campaign39/A1/1/ 8/E1/1/ 1/70/1/1/ *.*.1/ 
*.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.1/1/DNLSC+2/1QA4/5/4/1/MO/1/1/1/1/1/ 1/2/1/1/3
H/1/ 39/3P/1/ 3/3C/1/ 4/AE/1/1/ 3AK/3/1/ 3D9/3/B/Sun Readers*.*.1/ 1/4/3AK/1/AE/
3D9/1/AE/1/4/0/0/DNLSC+2/1QA5/5/4/1/46/1/2/1/1/1/ 1/3/1/1/DK/1/ 1/*.1/ *.*.1/ *.
70/1/1/ AA/1/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.3/4/1/0/DNLSC+2/1QA8/5/4/1/2C/1/9/
3/3/1/ 1/3/1/1/DG/1/ 1/*.1/ *.*.1/ *.70/1/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.
*.2/*.1/0/DNM1I+2/1QDC/5/5/1/11S/1/B/5/1/I/richard littlejohn5/3/1/2/3H/1/ 39/*.
1/ *.*.1/ *.AE/1/1/ 70/1/1/ 3AK/1/1/ *.*.1/ 1/1/70/3/AE/*.*.*.1/1/0/2/DNM1I+2/1Q
DF/5/5/1/2H/1/2/3/3/1/ 1/3/1/2/6L/1/ 6/6S/1/ 39/*.1/ *.3K/3/1/ 3L/3/1/ 70/1/1/ 3
AE/1/E/Sir John Mills4/4/3AE/3/3K/*.*.*.3/1/0/0/DNM1I+2/1QDH/5/5/1/2M/1/2/3/3/1/
 1/3/1/1/E9/1/ 1/*.1/ *.*.1/ *.3AC/1/S/Petrol Retailers Association70/1/1/ *.*.1
/ *.*.1/ 4/4/*.*.*.*.*.*.4/1/0/0/DNM1I+2/1QDI/5/5/1/2I/1/1/1/1/1/ 1/2/1/1/3B/1/ 
3/44/1/ 3/*.1/ *.AE/1/1/ 3D9/1/I/Baby Coll Mcaskill*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*
.4/4/0/0/DNM1I+2/1QDK/5/5/1/DT/1/6/5/1/D/oliver harvey2/3/2/1/3H/1/ 39/A1/17/Ana
lysis of Prescott's boxing ability8/*.1/ *.AE/1/1/ 3D9/3/E/Boxing Experts*.*.1/ 
*.*.1/ 2/4/3D9/2/AE/*.*.*.2/4/0/1/DNM1I+2/1QDM/5/5/1/1A/1/8/3/3/1/ 4/3/1/2/4G/1/
 39/*.1/ *.*.1/ *.270/2/1/ 275/2/1/ *.*.1/ *.*.1/ 3/3/*.*.*.*.*.*.3/3/0/0/DNM1I+
2/1QDO/5/5/1/5Q/1/8/3/3/1/ 4/3/1/1/3H/1/ 39/3C/1/ 4/*.1/ *.46/3/1/ AE/1/1/ *.*.1
/ *.*.1/ 3/3/*.*.*.*.*.*.3/3/0/1/DNMB6+2/1QGL/5/1/1/NL/1/8/39/1/A/tony blair5/2/
1/2/A2/1/ 8/DB/1/ 1/DC/1/ 1/71/1/1/ 3L/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/3/
0/DNMB6+2/1QGO/5/1/1/9J/1/1/1/1/1/ 1/3/1/2/DE/1/ 1/*.1/ *.*.1/ *.70/1/1/ 71/1/1/
 H5/1/1/ KK/1/1/ 4/4/70/1/71/*.*.*.3/1/1/0/DNMEC+2/1QK2/5/2/1/3J/1/8/3/3/1/ 4/3/
1/2/A9/12/Ted Heath fails to support Hague8/A1/1/ 8/*.1/ *.R5/1/1/ 71/1/1/ *.*.1
/ *.*.1/ 1/3/10F/1/71/*.*.*.1/3/0/1/DNMEC+2/1QK6/5/2/1/19P/1/6/5/1/F/Martin Phil
lips5/3/1/1/9T/S/Don't support Shaun Woodward39/A1/1/ 8/*.1/ *.E6/1/1/ *.*.1/ *.
*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/2/DNMEC+2/1QK7/5/2/1/NE/1/8/1/1/1/ 1/2/1/1/DT/
1/ 1/DE/1/ 1/EC/1/ 1/3K/3/1/ 3L/3/1/ AB/1/1/ *.*.1/ 4/4/3L/1/3K/3K/1/3L/4/4/1/0/
DNMHI+2/1QNB/5/3/1/JI/1/8/1/1/1/ 1/3/1/2/3R/1/ 2/6L/1/ 6/*.1/ *.3K/3/1/ 3L/3/1/ 
3M/3/1/ 3B5/1/1C/Prof. Paul Whiteley (University of Essex!)4/4/*.*.*.*.*.*.3/1/0
/0/DNMHI+2/1QNC/5/3/1/33/1/9/3/3/1/ 1/2/1/2/6J/1N/Blair says media not to blame 
for Prescott's hecklers7/6Q/1/ 7/*.1/ *.70/1/1/ AE/1/1/ 3AM/3/1/ *.*.1/ 4/4/*.*.
*.*.*.*.4/4/0/0/DNMHI+2/1QNE/5/3/1/5S/1/2/5/1/D/Dominac Mohan1/2/1/1/3I/1/ 3/*.1
/ *.*.1/ *.3AE/2/G/Charlotte Church70/1/1/ 3D9/2/F/Church's mother3K/3/1/ 4/4/3D
9/3/3K/*.*.*.4/4/0/0/DNMHI+2/1QNG/5/3/1/FT/1/9/1/1/1/ 5/3/1/1/3R/1/ 2/*.1/ *.*.1
/ *.3K/3/1/ 3L/3/1/ *.*.1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/1/0/DNMKO+2/1QQL/5/4/1/75/
1/1/1/1/1/ 1/2/1/2/3B/1/ 3/6Q/1/ 7/*.1/ *.3B6/2/1/ 70/1/1/ *.*.1/ *.*.1/ 4/3/3B6
/3/70/*.*.*.4/3/0/1/DNMKO+2/1QQM/5/4/1/67/1/8/3/3/1/ 4/3/1/2/DG/1/ 1/DF/1/ 1/*.1
/ *.70/1/1/ AB/1/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNMKO+2/1QQO/5/4/1/93/
1/8/1/1/1/ 1/2/1/1/DF/1/ 1/ED/1/ 1/A2/1/ 8/AB/1/1/ 6J/3/A/Old Labour3D9/3/8/Busi
ness*.*.1/ 4/4/AB/1/6J/AB/3/3D9/4/4/1/0/DNMKO+2/1QQQ/5/4/1/GG/1/8/1/1/1/ 1/3/1/1
/DG/1/ 1/DF/1/ 1/*.1/ *.70/1/1/ 3L/3/1/ AB/1/1/ 47/3/1/ 2/4/3L/1/70/*.*.*.2/4/1/
0/DNMKO+2/1QQR/5/4/1/8R/1/9/1/1/1/ 1/2/1/1/DC/1/ 1/A2/1/ 8/*.1/ *.70/1/1/ *.*.1/
 *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.3/0/DNMO+3/1R03/5/5/1/4N/1/2/1/1/1/ 1/2/1/1/3
C/1/ 4/DC/1/ 1/*.1/ *.3L/3/1/ AA/1/1/ 3K/3/1/ *.*.1/ 4/4/AA/1/3L/3L/1/3K/4/4/0/0
/DNMO+3/1R06/5/5/1/AA/1/8/3/3/1/ 4/3/1/1/AE/1/ 39/A1/1/ 8/*.1/ *.71/1/1/ H5/1/1/
 70/1/1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/0/1/DNN6O+2/1R6L/5/2/1/9C/1/8/3/3/1/ 4/3/1/1
/DG/1/ 1/9T/D/Sun anti-Euro39/DF/1/ 1/3B9/1/1/ 70/1/1/ AB/1/1/ *.*.1/ 1/4/*.*.*.
*.*.*.1/4/1/0/DNN6O+2/1R6M/5/2/1/4R/1/2/3/3/1/ 1/3/1/1/E9/1/ 1/A3/1/ 8/*.1/ *.AB
/1/1/ 3D9/3/B/Oil Experts*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.1/4/2/0/DNN6O+2/1R6N/5/2/
1/3C/1/2/3/3/1/ 1/3/1/1/DO/1/ 1/DR/1/ 1/A8/1/ 8/72/1/1/ 71/1/1/ 3L/3/1/ *.*.1/ 4
/4/72/1/3L/71/1/72/4/4/0/0/DNN6O+2/1R6O/5/2/1/15A/1/6/1/1/1/ 1/4/1/1/6J/F/Jospin
's speech39/DF/1/ 1/DF/1/ 1/3B9/1/1/ 70/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/3
/0/DNNA+3/1RA1/5/3/1/B1/1/1/1/1/1/ 1/3/1/1/DG/1/ 1/A2/1/ 8/*.1/ *.70/1/1/ AB/1/1
/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNNA+3/1RA5/5/3/1/BI/1/7/5/1/C/chris ric
hes1/3/1/1/DB/1/ 1/6J/15/Blair to be quizzed by family on tv39/GJ/F/Donor regist
ers1/70/1/1/ 3D9/3/M/Parents of dying child42/3/1/ *.*.1/ 4/4/3D9/1/42/3D9/1/70/
4/4/1/0/DNNA+3/1RA8/5/3/1/86/1/8/3/3/1/ 4/3/1/1/DG/1/ 1/DF/1/ 1/9T/G/Sun against
 euro39/70/1/1/ 3AG/1/C/Romano Prodi*.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNNA+3
/1RA9/5/3/1/EA/1/L/5/2/F/tracey kandohla1/3/1/1/A1/1/ 8/3O/1/ 39/D9/19/Local cou
ncil candidate has served time8/N8/1/13/David Goodyer - Council CandidateN9/3/C/
Local Tories*.*.1/ *.*.1/ 1/4/N9/3/N8/*.*.*.1/4/0/0/DNND6+2/1RDC/5/4/1/57/1/2/3/
3/1/ 1/2/1/1/3B/1/ 3/3F/1/ 2/*.1/ *.71/1/1/ AE/1/1/ *.*.1/ *.*.1/ 4/4/71/1/3K/KS
/1/3L/4/4/0/0/DNND6+2/1RDE/5/4/1/2L/1/2/3/3/1/ 1/3/1/1/6L/1/ 6/*.1/ *.*.1/ *.3K/
3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.3/1/0/0/DNND6+2/1RDF/5/4/1/Q6/1/8/5/
1/E/grant rollings5/3/1/1/3L/1/ 4/43/1/ 4/*.1/ *.3AE/1/B/Billy Bragg3L/3/1/ 3K/3
/1/ 3M/3/1/ 4/1/3AE/1/3L/3AE/2/3K/4/1/0/0/DNND6+2/1RDG/5/4/1/52/1/8/3/3/1/ 4/3/1
/2/A3/1/ 8/EA/1/ 1/*.1/ *.70/1/1/ AB/1/1/ *.*.1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/1/0/
DNND6+2/1RDI/5/4/1/GS/1/C/5/1/D/Charles Yates1/3/1/1/72/11/Sun provides a butler
 for a day7/3T/1/ 4/*.1/ *.3B6/2/A/Sun ReaderE6/1/1/ 3D9/1/6/Butler*.*.1/ 4/1/3B
6/3/3D9/*.*.*.1/4/0/0/DNNGC+2/1RGL/5/5/1/5E/1/1/1/1/1/ 1/2/1/1/3B/1/ 3/72/P/Blai
r's appearance (hair)7/3C/1/ 4/70/1/1/ 3AE/1/D/David Beckham*.*.1/ *.*.1/ 1/4/*.
*.*.*.*.*.1/4/0/0/DNNGC+2/1RGO/5/4/1/5F/1/8/3/3/1/ 4/3/1/1/6Q/G/Tough interviews
7/*.1/ *.*.1/ *.70/1/1/ 71/1/1/ 3AL/3/1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/0/0/DNNGC+2/
1RGR/5/5/1/3D/1/9/3/3/1/ 1/3/1/1/6J/17/Severance payments to Whitehall aides39/*
.1/ *.*.1/ *.DO/1/1/ 49/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.1/4/0/0/DNNGC+2/1RGT/
5/5/1/4I/1/9/1/1/1/ 1/2/1/1/3R/1/ 2/*.1/ *.*.1/ *.71/1/1/ 10M/2/1/ 3K/3/1/ *.*.1
/ 4/4/71/1/3K/10M/1/3K/4/4/0/0/DNNGC+2/1RH1/5/5/1/A1/1/B/5/1/I/Richard Littlejoh
n39/3/2/1/72/T/Song about Mandelson (My Way)7/A1/1/ 8/*.1/ *.DS/1/1/ *.*.1/ *.*.
1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/2/DNNGC+2/1RH2/5/5/1/HP/1/B/5/1/I/Richard Little
john5/3/1/1/3L/1/ 4/A1/1/ 8/*.1/ *.3AE/1/B/Billy Bragg72/1/1/ 3M/3/1/ *.*.1/ 2/1
/*.*.*.*.*.*.2/1/0/1/DNNQ+3/1RK1/5/1/1/2A/1/1/5/1/C/mark bowness1/3/1/1/72/15/Su
n's 'get em out to vote' campaign7/6S/1/ 39/*.1/ *.3AM/3/7/The Sun3D9/2/C/Page 3
 Girls3L/3/1/ 71/1/1/ 4/3/*.*.*.*.*.*.4/3/0/0/DNNQ+3/1RK2/5/1/1/Q5/1/6/5/1/B/mar
k bownes1/3/2/1/72/1B/Getting out the vote - Sun's campaign bus7/6S/1/ 39/*.1/ *
.AH/1/1/ 3AM/3/7/The Sun3D9/2/C/Page 3 GirlsE6/1/1/ 3/3/AH/3/3AM/*.*.*.3/3/0/0/D
NNQ+3/1RK4/5/1/1/OR/1/8/5/1/I/Richard Littlejohn5/3/1/1/AA/1/ 8/*.1/ *.*.1/ *.3M
/3/1/ 72/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/1/DNNQ+3/1RK5/5/1/1/8Q/1/9/1/1
/1/ 1/3/1/2/AF/1/ 39/*.1/ *.*.1/ *.E5/1/1/ 70/1/1/ E7/3/1/ *.*.1/ 4/4/*.*.*.*.*.
*.1/4/0/0/DNNQ+3/1RK6/5/1/1/34/1/9/3/3/1/ 1/2/1/2/3I/1/ 3/*.1/ *.*.1/ *.70/1/1/ 
3L/3/1/ H6/2/1/ 3K/3/1/ 4/4/H6/1/70/*.*.*.4/1/0/1/DNNT6+2/1RNB/5/2/1/9R/1/1/5/1/
B/charles rae39/3/2/1/6L/1/ 6/9T/F/Swing to tories39/72/K/Sun's cleavage girls7/
3D9/2/I/Sun's Lesley Soden3L/3/1/ *.*.1/ *.*.1/ 3/2/3D9/3/3L/*.*.*.3/2/0/0/DNNT6
+2/1RNC/5/2/1/EK/1/6/5/1/B/mark bownes1/3/2/1/72/N/Sun looks for Keith Vaz7/*.1/
 *.*.1/ *.E5/1/1/ N8/1/G/John Mugglestone3B6/3/1/ 3D9/2/C/Page 3 Girls1/4/N8/1/E
5/3B6/1/E5/1/4/0/0/DNNT6+2/1RNE/5/2/1/9R/1/8/3/3/1/ 4/2/1/1/A1/1/ 8/6S/1/ 39/DG/
1/ 1/70/1/1/ 3AL/1/D/Jeremy Paxman*.*.1/ *.*.1/ 3/4/*.*.*.*.*.*.3/4/1/0/DNNT6+2/
1RNF/5/2/1/2M/1/8/3/3/1/ 4/3/2/1/6L/1/ 6/3B/1/ 3/3C/1/ 4/3L/3/1/ 3K/3/1/ 3AE/1/C
/Rory Bremner3D9/2/H/Tory Page 3 Girls3/1/*.*.*.*.*.*.3/1/0/0/DNNT6+2/1RNH/5/2/1
/51/1/9/1/1/1/ 1/2/1/1/3C/1/ 4/AE/1/ 39/*.1/ *.71/1/1/ 275/2/1/ 3K/3/1/ *.*.1/ 1
/4/71/1/3K/*.*.*.1/4/0/0/DNNT6+2/1RNI/5/2/1/H6/1/9/1/1/1/ 1/3/1/1/72/16/Word 'Bl
air' to mean 'total wipeout'7/6O/1/ 6/*.1/ *.3D9/3/P/Oxford English Dictionary70
/1/1/ 3AR/3/1/ 71/1/1/ 4/4/3AR/3/70/*.*.*.4/4/0/0/DNNT6+2/1RNK/5/2/1/5P/1/9/5/1/
B/michael lee1/2/1/1/6O/T/Hague predicts win for Tories6/3B/1/ 3/A2/1/ 8/71/1/1/
 3L/3/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/1/0/DNO2C+2/1RQL/5/3/1/9O/1/1/5/2/F/v
ictoria newton1/3/1/1/3H/1I/Celebrities endorsing Labour who won't be voting39/4
8/1/ 5/3Q/1/ 2/3AE/2/N/Terri Dwyer (soap star)3AE/1/L/Gary Lucy (soap star)3B8/2
/1/ 3K/3/1/ 1/4/3B8/3/3K/*.*.*.1/4/0/0/DNO2C+2/1RQP/5/3/1/1P/1/6/3/3/1/ 1/3/2/1/
49/1/ 5/6J/1H/Independent candidate appealing to women voters8/*.1/ *.139/1/B/Mi
cky Betts*.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.0/0/DNO2C+2/1RQS/5/3/1/K5/1/9/
5/1/B/michael lea1/3/1/1/3G/1/ 39/*.1/ *.*.1/ *.E5/1/1/ 3L/3/1/ *.*.1/ *.*.1/ 1/
4/3L/1/E5/*.*.*.1/4/0/1/DNO2C+2/1RQT/5/3/1/5L/1/9/1/1/1/ 1/3/1/2/6L/1/ 6/*.1/ *.
*.1/ *.3L/3/1/ 3K/3/1/ 3M/3/1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/0/0/DNO2C+2/1RR0/5/3/1
/1A/1/8/3/3/1/ 4/3/1/2/D9/S/Gordon is happy, Tony is not8/*.1/ *.*.1/ *.70/1/1/ 
AB/1/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNO5I+2/1S01/5/4/1/FA/1/1/5/1/D/da
vid yelland5/3/1/1/9T/1O/A message to Blair - what Labour must do in the future3
9/6S/1/ 39/*.1/ *.70/1/1/ 71/1/1/ *.*.1/ *.*.1/ 3/3/*.*.*.*.*.*.3/3/0/0/DNO5I+2/
1S09/5/4/1/26/1/7/3/3/1/ 1/1/1/1/6O/F/Odds on winning6/*.1/ *.*.1/ *.3AR/3/1/ 3K
/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNO5I+2/1S0A/5/4/1/114/1/7/5/1/I/ric
hard littlejohn5/3/1/1/9T/R/Urging readers to vote tory39/3R/1/ 2/A2/1/ 8/3K/3/1
/ 3L/3/1/ 10G/1/1/ 3M/3/1/ 1/2/*.*.*.*.*.*.1/2/1/0/DNO5I+2/1S0B/5/4/1/PQ/1/9/1/1
/1/ 5/3/1/1/9T/K/Blair must do better39/DE/1/ 1/DB/1/ 1/70/1/1/ AB/1/1/ 3L/3/1/ 
*.*.1/ 1/3/*.*.*.*.*.*.1/3/2/0/DNO5I+2/1S0C/5/4/1/59/1/9/4/2/1/ 1/3/1/1/6Q/12/TV
 coverage of election campaign7/*.1/ *.*.1/ *.3AM/3/B/TV Channels*.*.1/ *.*.1/ *
.*.1/ 4/*.*.*.*.*.*.*.4/*.0/0/DNL2O+2/26NB/6/3/1/6F/1/3/1/1/1/ 1/2/1/2/3I/1/ 3/E
A/1/ 1/*.1/ *.70/1/1/ 3L/3/1/ *.*.1/ *.*.1/ 4/4/70/1/3L/*.*.*.4/1/2/0/DNL2O+2/26
ND/6/3/1/1A6/1/2/1/1/1/ 6/3/1/1/3C/1/ 4/A2/1/ 8/E1/1/ 1/70/1/1/ *.*.1/ *.*.1/ *.
*.1/ 3/*.*.*.*.*.*.*.3/*.3/1/DNL2O+2/26NF/6/3/1/E5/1/7/5/1/F/Tom Newton Dunn1/2/
1/1/3B/1/ 3/3P/1/ 3/DH/1/ 1/71/1/1/ 3AS/2/1/ 3B6/2/1/ *.*.1/ 1/4/3AS/1/71/3B6/1/
71/1/4/0/0/DNL2O+2/26NG/6/3/1/5H/1/7/1/1/1/ 1/3/1/2/9T/13/Negative endorsement f
rom a celeb39/*.1/ *.*.1/ *.71/1/1/ 3AE/1/11/Anthony Worrall Thompson (chef)*.*.
1/ *.*.1/ 4/4/3AE/1/71/*.*.*.1/4/0/0/DNL2O+2/26NH/6/3/1/30/1/7/1/2/1/ 1/3/1/2/6J
/1D/Alaister Campbell quit job to join campaign39/*.1/ *.*.1/ *.DO/1/1/ 3K/3/1/ 
*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNL2O+2/26NI/6/3/1/2Q/1/7/1/1/1/ 1/2/1/1/3
B/1/ 3/*.1/ *.*.1/ *.3B6/1/T/Baby that Blair Tries to Kiss70/1/1/ 3B6/1/D/Baby's
 Father*.*.1/ 4/4/3B6/3/70/*.*.*.4/4/0/0/DNL2O+2/26NM/6/3/1/P3/1/4/1/1/1/ 5/3/1/
1/3K/1/ 2/3J/1/ 2/A3/1/ 8/70/1/1/ 3L/3/1/ AB/1/1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/1/0
/DNL2O+2/26NN/6/3/1/23/1/1/3/3/1/ 9/3/2/1/A1/1/ 8/*.1/ *.*.1/ *.71/1/1/ *.*.1/ *
.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/0/DNL6+3/26QL/6/4/1/M6/1/4/1/1/1/ 1/2/1/2/3I/
1/ 3/EA/1/ 1/*.1/ *.70/1/1/ AB/1/1/ DP/1/1/ 3L/3/1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNL6
+3/26QM/6/4/1/B4/1/1/1/1/1/ 1/1/1/1/6J/N/Heath's farewell speech39/DG/1/ 1/*.1/ 
*.10F/1/1/ 71/1/1/ *.*.1/ *.*.1/ 4/1/10F/1/71/*.*.*.4/1/1/0/DNL6+3/26QN/6/4/1/2A
/1/2/5/2/H/Lorraine Davidson1/2/1/1/3B/1/ 3/3H/1/ 39/*.1/ *.3K/3/1/ KN/1/1/ 3D9/
3/5/Tesco*.*.1/ 4/4/*.*.*.*.*.*.1/1/0/0/DNL6+3/26QO/6/4/1/BP/1/2/1/2/1/ 1/3/1/1/
3G/1/ 39/3F/E/Smear campaign2/*.1/ *.70/1/1/ 10O/1/1/ 3L/3/1/ N8/1/C/Andrew Tyri
e4/4/N8/1/70/10O/1/3L/4/4/0/0/DNL6+3/26QQ/6/4/1/25/1/2/1/1/1/ 1/3/1/1/3C/1/ 4/6J
/B/Tory morale8/*.1/ *.71/1/1/ E8/3/1/ E7/3/1/ *.*.1/ 1/4/E8/1/71/E7/1/71/1/4/0/
1/DNL6+3/26QS/6/4/1/EL/1/4/1/1/1/ 1/1/1/1/A9/1/ 8/DG/1/ 1/6J/J/Heath's last spee
ch39/10F/1/1/ 3L/3/1/ 71/1/1/ 3K/3/1/ 3/1/10F/3/3K/10F/1/71/3/1/1/0/DNL6+3/26R2/
6/4/1/63/1/5/1/1/1/ 1/2/1/1/A2/1/ 8/EB/1/ 8/*.1/ *.AB/1/1/ *.*.1/ *.*.1/ *.*.1/ 
4/*.*.*.*.*.*.*.4/*.2/0/DNL6+3/26R3/6/4/1/2I/1/2/1/2/1/ 1/3/1/1/DQ/1G/Trimble th
reatens to quit over ira disarmament1/*.1/ *.*.1/ *.E2/1/1/ 77/1/1/ *.*.1/ *.*.1
/ 4/4/E2/1/77/*.*.*.4/4/0/0/DNL96+2/2703/6/5/1/C0/1/2/4/1/1/ 1/3/1/1/DI/E/Intere
st rates1/*.1/ *.*.1/ *.3K/3/1/ 3B3/3/1/ 3AC/3/1/ 3L/3/1/ 4/4/3B3/3/3K/3B3/1/3L/
4/4/0/0/DNL96+2/2704/6/5/1/4F/1/2/1/1/1/ 1/3/1/1/3I/1/ 3/*.1/ *.*.1/ *.70/1/1/ E
8/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNL96+2/2706/6/5/1/1K/1/2/3/3/1/ 1/
3/1/1/A9/1/ 8/*.1/ *.*.1/ *.10F/1/1/ 71/1/1/ *.*.1/ *.*.1/ 4/1/10F/1/71/*.*.*.4/
1/0/0/DNL96+2/270A/6/5/1/86/1/4/1/2/1/ 1/3/1/2/6J/P/Booth slags off Mandleson8/*
.1/ *.*.1/ *.DS/1/1/ GI/1/A/John Booth70/1/1/ 3B6/3/K/Voters of Hartlepool4/4/GI
/1/DS/*.*.*.1/4/0/0/DNL96+2/270B/6/5/1/3B/1/4/1/2/1/ 1/3/1/1/6J/D/Tory meltdown8
/A9/1/ 8/6J/I/Tory move to right8/71/1/1/ JT/3/D/Senior Tories3L/3/1/ *.*.1/ 4/4
/JT/1/71/*.*.*.1/4/0/0/DNL96+2/270F/6/5/1/AO/1/6/1/1/1/ 5/3/1/1/DE/1/ 1/E9/1/ 1/
A1/1/ 8/71/1/1/ 3L/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/1/DNL96+2/270G/6/5/1
/2J/1/5/1/2/1/ 1/3/1/1/4C/1/ 39/*.1/ *.*.1/ *.71/1/1/ L1/1/1/ 3L/3/1/ *.*.1/ 1/4
/L1/1/3L/*.*.*.1/4/0/0/DNL96+2/270H/6/5/1/9F/1/6/1/1/1/ 7/3/1/1/4D/1/ 39/*.1/ *.
*.1/ *.10C/1/1/ 10F/1/1/ 3L/3/1/ 139/3/D/Departing MPs3/2/*.*.*.*.*.*.3/2/0/0/DN
LIO+2/273B/6/1/1/AS/1/7/1/1/1/ 1/3/1/2/6S/1/ 39/*.1/ *.*.1/ *.3B8/2/1/ 70/1/1/ 3
AE/3/2G/Other Celebrities (recode - dickie bird, tanni grey-thompson, kevin what
ely)3K/3/1/ 4/4/3B8/3/70/3AE/3/3K/4/3/0/0/DNLIO+2/273F/6/1/1/60/1/1/1/1/1/ 1/3/1
/1/6O/R/Hague's dad says he'll lose6/6L/1/ 6/*.1/ *.277/1/1/ 71/1/1/ 3AR/3/1/ *.
*.1/ 4/1/277/1/71/3AR/1/71/4/1/0/0/DNLIO+2/273G/6/1/1/69/1/2/1/1/1/ 1/3/1/2/6O/1
/ 6/*.1/ *.*.1/ *.71/1/1/ 70/1/1/ 277/1/1/ DS/1/1/ 1/3/*.*.*.*.*.*.1/3/1/0/DNLM+
3/276L/6/2/1/3T/1/6/3/3/1/ 4/3/1/2/E4/14/Affordable housing for key workers1/*.1
/ *.*.1/ *.3D9/3/L/Public Sector Workers3K/3/1/ *.*.1/ *.*.1/ 4/3/*.*.*.*.*.*.4/
3/1/0/DNLM+3/276M/6/2/1/K9/1/4/1/2/1/ 1/2/1/2/DE/1/ 1/A9/1/ 8/3H/1/ 39/71/1/1/ 7
0/1/1/ KK/1/1/ 3AB/3/1/ 1/4/70/1/71/3AB/3/70/1/4/1/0/DNLM+3/276N/6/2/1/8I/1/1/1/
1/1/ 1/3/1/1/GJ/M/Cheap loans for nurses1/A5/1/ 9/E5/1/ 1/E7/1/1/ 70/1/1/ 3D9/3/
6/Nurses*.*.1/ 4/4/*.*.*.*.*.*.4/4/2/0/DNLM+3/276O/6/2/1/1O/1/4/3/3/1/ 1/2/1/1/A
9/L/Thatcher defies Hague8/3B/1/ 3/*.1/ *.10M/2/1/ 71/1/1/ N8/1/14/John Marshall
 (Finchley candidate)*.*.1/ 1/4/*.*.*.*.*.*.1/4/0/1/DNLM+3/276P/6/2/1/3N/1/5/1/1
/1/ 1/3/1/1/6S/1/ 39/EA/1/ 1/*.1/ *.3AE/1/D/Alex Ferguson3K/3/1/ 3D9/3/H/Other C
elebrities70/1/1/ 4/4/3AE/3/3K/3D9/3/3K/4/3/1/0/DNLM+3/276T/6/2/1/1M/1/5/3/3/1/ 
1/3/1/1/3S/1/ A/3C/1/ 4/*.1/ *.70/1/1/ DS/1/1/ *.*.1/ *.*.1/ 4/4/DS/1/70/*.*.*.1
/4/0/0/DNLP6+2/27A4/6/3/1/7H/1/2/1/1/1/ 1/2/1/2/3F/1/ 2/A8/2B/Conflict over vide
os accusing Labour of being responsible for two rapes8/4E/1/ 4/3L/3/1/ 3K/3/1/ N
8/1/D/Michael Dobbs3AQ/2/13/Juliet Lyon (Prison Reform Trust)4/4/*.*.*.*.*.*.1/4
/0/0/DNLP6+2/27A5/6/3/1/21/1/2/3/3/1/ 1/3/1/2/6J/10/Tory's 'airgun' charge dropp
ed8/*.1/ *.*.1/ *.N8/1/I/Christian Sweeting*.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.
4/*.0/0/DNLP6+2/27A7/6/3/1/3G/1/2/5/2/B/jill palmer1/3/1/1/DB/1/ 1/A2/1/ 8/*.1/ 
*.3D9/3/1/ E7/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNLSC+2/27DB/6/4/1/4I/1
/7/1/1/1/ 1/3/1/2/DG/1/ 1/*.1/ *.*.1/ *.70/1/1/ 3L/3/1/ 3D9/1/P/Paul Sykes (euro
-sceptic)*.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNLSC+2/27DD/6/4/1/74/1/6/3/3/1/ 4/3/1/1
/DB/1/ 1/6S/1/ 39/E1/1/ 1/3K/3/1/ 70/1/1/ *.*.1/ *.*.1/ 2/4/*.*.*.*.*.*.2/4/1/0/
DNLSC+2/27DE/6/4/1/27/1/6/3/3/1/ 4/3/1/1/3P/1/ 3/3H/1/ 39/45/1/ 2/GJ/3/J/Labour 
Spin DoctorsAE/1/1/ 70/1/1/ 71/1/1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNLSC+2/27DK/6/4/1/2
H/1/7/3/3/1/ 1/2/1/2/A2/1/ 8/*.1/ *.*.1/ *.AA/1/1/ 10M/2/1/ 3B3/3/I/Headteachers
 Union*.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNLSC+2/27DM/6/4/1/11/1/1/3/3/1/ 9/2/1/1/44
/1/ 3/3P/1/ 3/*.1/ *.AE/1/1/ 3B9/1/1/ *.*.1/ *.*.1/ 4/1/*.*.*.*.*.*.4/1/0/0/DNM1
I+2/27GL/6/5/1/L1/1/4/5/1/A/Don MacKay1/3/1/2/A1/1M/Prescott's old trainer comme
nts on his boxing skills8/3H/1/ 39/*.1/ *.AE/1/1/ GJ/1/17/Benny Lloyd  (Prescott
's old trainer)3B6/2/E/Chantell Jones3B6/1/A/John Cronk4/4/GJ/3/AE/3B6/1/AE/2/4/
0/1/DNM1I+2/27GN/6/5/1/SP/1/2/5/2/9/lucy rock1/3/1/1/3P/1/ 3/3B/1/ 3/*.1/ *.AE/1
/1/ GI/3/A/Labour MPs*.*.1/ *.*.1/ 2/4/GI/2/AE/*.*.*.2/4/0/2/DNM1I+2/27GS/6/5/1/
AQ/1/5/5/1/L/Paul Byrne Jan disley1/3/1/1/9T/I/Profile of heckler39/*.1/ *.*.1/ 
*.3B9/1/1/ 3D9/3/K/Craig Evan's Friends3K/3/1/ *.*.1/ 2/4/3D9/1/3K/3D9/3/3B9/2/4
/0/0/DNM1I+2/27H1/6/5/1/6R/1/6/1/1/1/ 7/3/1/2/DE/1/ 1/3L/1/ 4/*.1/ *.KK/1/1/ 71/
1/1/ H5/1/1/ 139/1/J/Keith Joseph (Tory)2/4/*.*.*.*.*.*.2/4/1/0/DNM1I+2/27H2/6/5
/1/1K/1/6/1/1/1/ 7/2/1/2/3B/11/Mandleson leaves BBC show upset3/*.1/ *.*.1/ *.DS
/1/1/ AB/1/1/ *.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/0/0/DNM1I+2/27H3/6/5/1/AT/1/7/1/
2/1/ 1/2/1/1/3P/1/ 3/3B/1/ 3/DO/1/ 1/AH/1/1/ 3AQ/3/6/Police3L/3/1/ *.*.1/ 4/4/3A
Q/1/AH/AH/1/3L/1/4/1/1/DNM1I+2/27H6/6/5/1/1R/1/7/3/3/1/ 1/2/2/1/4G/M/Ffion speak
s in public39/*.1/ *.*.1/ *.275/2/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.0/
0/DNM1I+2/27H7/6/5/1/CB/1/C/3/3/1/ 2/3/2/1/3P/1/ 3/6J/1Q/Politicians throughout 
the world who have had skirmishes39/*.1/ *.AE/1/1/ 46/3/1/ *.*.1/ *.*.1/ 4/4/*.*
.*.*.*.*.4/4/0/0/DNM1I+2/27H8/6/5/1/66/1/6/1/1/1/ 7/3/1/1/A1/1/ 8/A3/1/ 8/*.1/ *
.10H/1/1/ 3K/3/1/ *.*.1/ *.*.1/ 1/3/*.*.*.*.*.*.1/3/1/0/DNM1I+2/27H9/6/5/1/8L/1/
6/3/3/1/ 4/3/1/1/3E/1/ 2/3H/1/ 39/A1/1/ 8/AE/1/1/ *.*.1/ *.*.1/ *.*.1/ 3/*.*.*.*
.*.*.*.3/*.0/1/DNM1I+2/27HA/6/5/1/1E/1/1/3/3/1/ 9/3/2/1/A2/1/ 8/44/1/ 3/*.1/ *.A
E/1/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.0/0/DNMB6+2/27K1/6/1/1/AD/1/2/1/
2/1/ 1/3/1/2/3C/1/ 4/A9/1/ 8/6L/1/ 6/71/1/1/ 10F/1/1/ N8/1/C/Lord SaatchiN9/1/L/
Giles Marshall (Tory)4/4/*.*.*.*.*.*.1/4/0/0/DNMB6+2/27K2/6/1/1/66/1/5/5/1/A/pau
l byrne1/3/1/2/3F/1/ 2/*.1/ *.*.1/ *.3L/3/1/ AE/1/1/ 3AM/3/1/ 3AK/1/1/ 1/4/3AK/3
/AE/*.*.*.1/4/0/0/DNMB6+2/27K3/6/1/1/2M/1/1/1/1/1/ 1/3/1/1/DS/1/ 1/*.1/ *.*.1/ *
.AH/1/1/ 3D9/3/8/Perverts*.*.1/ *.*.1/ 4/1/AH/1/3D9/*.*.*.4/1/1/0/DNMB6+2/27K4/6
/1/1/50/1/2/1/2/1/ 1/2/1/1/EB/1/ 1/A8/1/ 8/*.1/ *.H5/1/1/ KK/1/1/ 3L/3/1/ E3/1/1
/ 4/4/E3/1/3L/*.*.*.4/4/1/0/DNMB6+2/27K5/6/1/1/6G/1/2/1/2/1/ 1/2/1/1/6J/1B/Labou
r predicts contents of a Tory budget9/EA/1/ 1/*.1/ *.3K/3/1/ 3L/3/1/ H5/1/1/ *.*
.1/ 4/1/3K/1/3L/*.*.*.4/1/2/0/DNMB6+2/27K8/6/1/1/3P/1/4/5/1/A/paul byrne1/3/1/1/
3H/1C/Celebrity supporter not registered to vote39/*.1/ *.*.1/ *.3B8/2/1/ E7/3/1
/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNMB6+2/27KA/6/1/1/I2/1/5/1/1/1/ 1/2/1/1
/DS/1/ 1/A1/1/ 8/*.1/ *.AH/1/1/ 3D9/3/B/Paedophiles3AE/2/F/Carol VordermanH6/2/1
/ 4/1/3AE/3/AH/H6/1/AH/2/1/2/0/DNMB6+2/27KB/6/1/1/6G/1/6/3/3/1/ 4/3/1/2/DD/1/ 1/
*.1/ *.*.1/ *.3D9/3/B/PaedophilesAH/1/1/ *.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/1/0/D
NMB6+2/27KC/6/1/1/3H/1/6/3/3/1/ 4/3/1/1/9T/I/Critical of Tories39/6O/1/ 6/6J/12/
Not listening to ordinary people2/3L/3/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1
/*.0/0/DNMEC+2/27NB/6/2/1/1K/1/2/3/3/1/ 1/3/1/2/AD/1/ 39/*.1/ *.*.1/ *.70/1/1/ A
B/1/1/ *.*.1/ *.*.1/ 4/1/*.*.*.*.*.*.4/1/0/0/DNMEC+2/27NC/6/2/1/BQ/1/2/1/1/1/ 1/
2/1/2/DB/1/ 1/A2/1/ 8/*.1/ *.70/1/1/ 3D9/3/6/Nurses*.*.1/ *.*.1/ 4/4/*.*.*.*.*.*
.4/4/2/0/DNMEC+2/27NE/6/2/1/2H/1/2/3/3/1/ 1/2/1/2/3H/1/ 39/*.1/ *.*.1/ *.H5/1/1/
 72/1/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.1/1/0/0/DNMHI+2/27QN/6/3/1/31/1/2/1/1/1/ 
1/3/1/1/A1/I/Ambitious Blunkett8/A9/B/Blair/Brown8/*.1/ *.AA/1/1/ E7/3/1/ 70/1/1
/ AB/1/1/ 4/4/E7/1/AA/*.*.*.1/4/0/1/DNMHI+2/27QO/6/3/1/2T/1/2/1/1/1/ 1/2/1/1/DE/
1/ 1/EB/1/ 1/3H/1/ 39/KK/1/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 1/4/3K/1/KK/*.*.*.1/4/1/0/D
NMHI+2/27QQ/6/3/1/62/1/6/3/3/1/ 4/3/1/2/6J/O/Magaret Thatcher Returns39/A1/1/ 8/
*.1/ *.10M/2/1/ 70/1/1/ 3L/3/1/ 3K/3/1/ 1/3/*.*.*.*.*.*.1/3/0/0/DNMHI+2/27QR/6/3
/1/9J/1/2/1/2/1/ 1/2/1/1/DG/1/ 1/A9/1/ 8/*.1/ *.10M/2/1/ 3L/3/1/ 71/1/1/ *.*.1/ 
4/4/3L/1/10M/*.*.*.1/4/1/0/DNMKO+2/2801/6/4/1/131/1/4/39/1/A/alan sugar5/3/1/2/6
S/1/ 39/DI/1/ 1/*.1/ *.3K/3/1/ 3L/3/1/ 10M/2/1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/0/0/D
NMKO+2/2802/6/4/1/1P/1/2/3/3/1/ 1/3/1/2/6J/Q/Locals decline Hague visit8/*.1/ *.
*.1/ *.70/1/1/ 3B6/3/1/ *.*.1/ *.*.1/ 1/4/3B6/1/71/*.*.*.1/4/0/0/DNMKO+2/2803/6/
4/1/1N/1/2/3/3/1/ 1/3/1/2/48/1/ 5/6L/1/ 6/3K/1/ 2/3B6/3/1/ 70/1/1/ *.*.1/ *.*.1/
 4/4/*.*.*.*.*.*.4/4/0/0/DNMKO+2/2805/6/4/1/AS/1/2/1/1/1/ 5/3/1/1/DG/1/ 1/DF/1/ 
1/3H/1/ 39/H2/1/1/ 3L/3/1/ 71/1/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNMKO+2/2807/6
/4/1/L3/1/5/1/1/1/ 1/3/1/1/A9/1/ 8/A1/1/ 8/*.1/ *.N9/2/17/Doreen Whitehead - Hag
ue's confidante71/1/1/ H5/1/1/ 275/2/1/ 4/4/N9/3/71/N9/1/H5/4/4/0/2/DNMKO+2/2808
/6/4/1/8K/1/6/3/3/1/ 4/3/1/1/6S/1/ 39/DF/1/ 1/*.1/ *.3L/3/1/ 71/1/1/ *.*.1/ *.*.
1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNMKO+2/2809/6/4/1/FR/1/1/1/1/1/ 1/3/1/1/A9/1/ 8/DG/1
/ 1/*.1/ *.H2/1/1/ 71/1/1/ AB/1/1/ 3L/3/1/ 1/1/AB/1/3L/*.*.*.1/1/1/0/DNMO+3/283B
/6/5/1/4H/1/1/1/1/1/ 1/2/1/1/4E/1/ 4/DC/1/ 1/DD/1/ 1/3L/3/1/ 71/1/1/ AA/1/1/ 3B3
/3/H/Doug McEvoy - NUT1/1/AA/1/3L/3B3/1/3L/1/1/0/0/DNMO+3/283D/6/5/1/FH/1/2/1/1/
1/ 3/3/1/1/4A/1/ 4/AA/1/ 8/*.1/ *.AB/1/1/ *.*.1/ *.*.1/ *.*.1/ 3/*.*.*.*.*.*.*.3
/*.0/1/DNMO+3/283F/6/5/1/6N/1/6/3/3/1/ 4/3/1/1/4E/1/ 4/GJ/I/Youth/young people1/
EH/1/ 1/3L/3/1/ AB/1/1/ 3K/3/1/ *.*.1/ 1/3/*.*.*.*.*.*.1/3/1/0/DNMO+3/283G/6/5/1
/EE/1/6/1/1/1/ 5/3/1/1/A9/B/Blair/Brown8/*.1/ *.*.1/ *.AB/1/1/ 70/1/1/ AA/1/1/ *
.*.1/ 3/1/*.*.*.*.*.*.3/1/0/1/DNMO+3/283J/6/5/1/55/1/7/1/1/1/ 1/2/1/2/AF/1/ 39/G
J/D/Student debts1/*.1/ *.70/1/1/ DN/1/1/ 3D9/1/8/Students*.*.1/ 4/4/3D9/2/70/*.
*.*.4/4/0/0/DNMO+3/283L/6/5/1/24/1/2/3/3/1/ 1/3/1/1/6J/S/Effect of weather on po
lling39/*.1/ *.*.1/ *.3D9/3/A/Met Office3K/3/1/ 3L/3/1/ *.*.1/ 4/3/*.*.*.*.*.*.4
/3/0/0/DNN3I+2/286M/6/1/1/3TP/1/2/2/1/1/ 39/3/1/1/72/1I/Imagine it's 2006 & the 
Tories won 2001 election7/A3/1/ 8/EA/1/ 1/71/1/1/ 3L/3/1/ *.*.1/ *.*.1/ 1/1/*.*.
*.*.*.*.1/1/0/1/DNN3I+2/286N/6/1/1/FB/1/2/1/1/1/ 39/3/1/1/72/1I/Imagine it's 200
6 & the Tories won 2001 election7/DO/1/ 1/DF/1/ 1/3K/3/1/ 70/1/1/ H6/2/1/ *.*.1/
 1/1/*.*.*.*.*.*.1/1/0/0/DNN3I+2/286Q/6/1/1/C3/1/5/5/2/B/jill palmer39/3/1/1/72/
1I/Imagine it's 2006 & the Tories won 2001 election7/DB/1/ 1/*.1/ *.H0/1/1/ 3K/3
/1/ 3D9/3/F/Nurse Spokesman*.*.1/ 1/1/3D9/1/3K/*.*.*.1/1/0/0/DNN3I+2/286T/6/1/1/
1O/1/4/3/3/1/ 39/3/1/1/72/1I/Imagine it's 2006 & the Tories won 2001 election7/D
C/1/ 1/*.1/ *.KK/1/1/ 3D9/3/7/Parents*.*.1/ *.*.1/ 1/4/3D9/1/KK/*.*.*.1/4/0/0/DN
N3I+2/2870/6/1/1/8R/1/6/5/1/D/Stephen White39/3/1/2/72/1I/Imagine it's 2006 & th
e Tories won 2001 election7/DI/1/ 1/*.1/ *.3B6/3/H/McLoughlin Family3L/3/1/ E3/1
/1/ 3D9/2/P/Katie Richmond (teenager)4/4/3B6/1/3L/*.*.*.4/1/0/0/DNN3I+2/2873/6/1
/1/DP/1/7/1/1/1/ 39/3/1/1/72/1I/Imagine it's 2006 & the Tories won 2001 election
7/EA/1/ 1/*.1/ *.71/1/1/ H5/1/1/ AB/1/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNN3I+2/
2874/6/1/1/9G/1/H/1/1/1/ 1/3/1/1/3C/1/ 4/A1/1/ 8/6L/1/ 6/70/1/1/ 71/1/1/ DR/3/1/
 *.*.1/ 4/1/E7/1/71/*.*.*.4/1/0/1/DNN3I+2/2875/6/1/1/C/1/1/3/3/1/ 9/3/1/1/9T/M/D
angers of voting tory7/*.1/ *.*.1/ *.71/1/1/ 70/1/1/ 72/1/1/ *.*.1/ 1/4/*.*.*.*.
*.*.1/4/0/0/DNN6O+2/28A1/6/2/1/89/1/1/5/1/E/kevin sullivan1/3/1/1/48/1/ 5/6L/1/ 
6/*.1/ *.3B6/3/C/Young Voters3D9/3/B/Big Brother6J/3/K/The Electoral System*.*.1
/ 4/4/3B6/3/3D9/3B6/1/6J/4/4/0/0/DNN6O+2/28A2/6/2/1/D1/1/1/1/1/1/ 1/2/1/1/6O/1/ 
6/DG/1/ 1/3C/1/ 4/H7/1/1/ 3K/3/1/ H5/1/1/ 3K/3/1/ 4/4/*.*.*.*.*.*.4/1/1/0/DNN6O+
2/28A3/6/2/1/C7/1/2/1/1/1/ 1/3/1/2/6L/1/ 6/*.1/ *.*.1/ *.70/1/1/ 71/1/1/ AB/1/1/
 3B6/3/1/ 4/4/3B6/3/AB/*.*.*.3/1/0/0/DNN6O+2/28A4/6/2/1/73/1/2/5/1/D/graham brou
gh1/4/1/1/DF/1/ 1/A2/1/ 8/*.1/ *.3B9/1/1/ 70/1/1/ N8/3/D/Euro-Sceptics*.*.1/ 4/4
/3B9/2/70/70/1/3B9/4/4/1/0/DNN6O+2/28A6/6/2/1/64/1/6/3/3/1/ 4/3/1/1/A1/1/ 8/6S/1
/ 39/DG/1/ 1/71/1/1/ AB/1/1/ 3K/3/1/ 3L/3/1/ 1/3/*.*.*.*.*.*.1/3/0/1/DNN6O+2/28A
7/6/2/1/1R/1/6/3/3/1/ 4/3/1/1/72/1E/Politicians should live in big brother house
7/48/1/ 5/*.1/ *.46/3/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/1/DNNA+3/28D
B/6/3/1/GH/1/1/1/1/1/ 1/3/1/1/DG/1/ 1/3C/1/ 4/*.1/ *.70/1/1/ 3AB/1/J/Chris Gent/
Vodafone139/1/D/Geoffrey Howe*.*.1/ 1/4/3AB/1/70/139/1/70/1/4/1/0/DNNA+3/28DC/6/
3/1/3N/1/2/5/1/E/steve mccomish1/2/1/1/6J/S/Thatcher handbags journalist39/DG/1/
 1/3C/1/ 4/10M/2/1/ 3AL/1/P/Peter Hayes - tv reporter3AM/3/1/ *.*.1/ 1/4/10M/1/3
AM/3AL/1/10M/1/4/0/0/DNNA+3/28DD/6/3/1/45/1/2/1/1/1/ 1/2/1/1/6O/1/ 6/EC/1/ 1/3H/
1/ 39/H1/1/1/ 3K/3/1/ H7/1/1/ *.*.1/ 4/4/H1/3/3K/H7/3/3K/1/3/1/0/DNNA+3/28DE/6/3
/1/1N/1/2/3/3/1/ 1/3/1/2/6L/1/ 6/*.1/ *.*.1/ *.3K/3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 4/
4/*.*.*.*.*.*.3/1/0/0/DNNA+3/28DJ/6/3/1/20/1/4/5/1/C/Gavin Cordon1/3/1/2/A8/I/Ma
jor slams Labour8/6L/1/ 6/*.1/ *.10I/1/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/4/10I/1/3K/*.*
.*.4/1/0/0/DNNA+3/28DK/6/3/1/1S/1/4/1/1/1/ 1/2/1/1/AC/1/ 9/DE/1/ 1/A2/1/ 8/AB/1/
1/ 3L/3/1/ *.*.1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/1/0/DNNA+3/28DM/6/3/1/A0/1/6/3/3/1/
 4/3/1/2/DG/1/ 1/A5/1/ 9/*.1/ *.3AB/1/L/Chris Gent (Vodafone)3L/3/1/ 70/1/1/ *.*
.1/ 3/1/3AB/1/3L/*.*.*.3/1/1/0/DNND6+2/28GL/6/4/1/6P/1/2/1/1/1/ 1/3/1/1/DD/1B/Re
form for attackers of frontline workers1/DD/1/ 1/*.1/ *.70/1/1/ 3AQ/3/H/Frontlin
e Workers3D9/3/9/Attackers*.*.1/ 4/4/70/1/3D9/70/3/3AQ/4/4/1/0/DNND6+2/28GM/6/4/
1/2N/1/2/3/3/1/ 1/3/1/1/6L/1/ 6/3C/1/ 4/DF/1/ 1/71/1/1/ 3L/3/1/ 3K/3/1/ *.*.1/ 1
/1/*.*.*.*.*.*.1/1/0/0/DNND6+2/28GN/6/4/1/2J/1/2/1/1/1/ 1/3/1/1/6O/1/ 6/*.1/ *.*
.1/ *.N9/1/E/Stuart Wheeler3L/3/1/ *.*.1/ *.*.1/ 4/4/N9/1/3L/*.*.*.3/1/0/0/DNND6
+2/28GR/6/4/1/MR/1/6/1/1/1/ 5/2/1/1/A1/1/ 8/A2/1/ 8/3B/1/ 3/72/1/1/ 3AE/2/E/Hono
r Blackman*.*.1/ *.*.1/ 2/3/*.*.*.*.*.*.2/3/1/0/DNNGC+2/28K1/6/5/1/JO/1/1/1/1/1/
 1/2/1/1/6L/1/ 6/DG/1/ 1/DF/1/ 1/3L/3/1/ 70/1/1/ 3K/3/1/ 71/1/1/ 1/3/*.*.*.*.*.*
.1/3/1/0/DNNGC+2/28K2/6/5/1/F7/1/2/1/2/1/ 1/3/1/1/6J/13/Hague accused of gagging
 Tory mps8/DG/1/ 1/*.1/ *.3D9/1/P/Paul Sykes - Euro Sceptic71/1/1/ 3K/3/1/ *.*.1
/ 4/1/3D9/1/71/3D9/3/3K/4/1/1/0/DNNGC+2/28K6/6/5/1/2A/1/2/5/2/H/dorothy lepkowsk
a1/3/1/1/DC/1/ 1/*.1/ *.*.1/ *.3L/3/1/ 71/1/1/ 3B3/1/H/David Hart - NAHT*.*.1/ 4
/4/3B3/1/3L/3B3/1/71/4/4/1/0/DNNGC+2/28K9/6/5/1/7O/1/6/3/3/1/ 4/3/1/2/DF/1/ 1/DG
/1/ 1/6L/1/ 6/71/1/1/ 3D9/1/O/Paul Sykes (anti-Europe)3B6/3/1/ *.*.1/ 1/1/*.*.*.
*.*.*.1/1/1/0/DNNGC+2/28KA/6/5/1/3G/1/6/3/3/1/ 4/3/1/2/3T/1/ 4/*.1/ *.*.1/ *.3L/
3/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/0/DNNGC+2/28KE/6/5/1/1K/1/6/2/1/
1/ 7/3/2/2/72/J/Tony Blair's bottom7/*.1/ *.*.1/ *.70/1/1/ 3B6/3/A/1000 Women*.*
.1/ *.*.1/ 4/4/3B6/3/70/*.*.*.4/4/0/0/DNNGC+2/28KF/6/5/1/1R/1/6/1/1/1/ 7/3/1/1/3
B/1/ 3/*.1/ *.*.1/ *.N8/1/12/Desmond Swayne (New Forest West)71/1/1/ 10M/1/1/ *.
*.1/ 1/1/N8/3/10M/*.*.*.1/1/0/0/DNNGC+2/28KG/6/5/1/77/1/6/2/1/1/ 7/3/1/2/E2/1/ 1
/*.1/ *.*.1/ *.AB/1/1/ 270/2/1/ 3L/3/1/ *.*.1/ 4/1/AB/1/3L/*.*.*.2/1/1/0/DNNGC+2
/28KH/6/5/1/1R/1/6/2/1/1/ 7/3/2/2/72/1C/Which celebrities do politicians look li
ke7/*.1/ *.*.1/ *.AE/1/1/ 3AE/1/A/Les Dawson71/1/1/ 3AE/1/S/Alec Gilroy (Coronat
ion St.)4/4/*.*.*.*.*.*.4/4/0/0/DNNQ+3/28NB/6/1/1/DP/1/2/1/1/1/ 1/2/1/1/AE/1/ 39
/6L/1/ 6/3C/1/ 4/71/1/1/ GI/1/B/Fraser Kemp*.*.1/ *.*.1/ 1/4/GI/1/71/*.*.*.1/4/0
/0/DNNQ+3/28ND/6/1/1/4M/1/2/1/1/1/ 1/2/1/2/3K/1/ 2/*.1/ *.*.1/ *.70/1/1/ 3L/3/1/
 3B6/3/B/Youth RallyAB/1/1/ 4/4/AB/1/3L/*.*.*.4/1/0/0/DNNQ+3/28NE/6/1/1/25/1/2/1
/1/1/ 1/3/1/2/6S/1/ 39/48/1/ 5/49/1/ 5/3AE/3/B/Celebreties70/1/1/ *.*.1/ *.*.1/ 
4/4/*.*.*.*.*.*.4/1/0/0/DNNQ+3/28NI/6/1/1/7B/1/6/3/3/1/ 4/3/1/1/3Q/1/ 2/3C/1/ 4/
*.1/ *.3L/3/1/ 71/1/1/ 70/1/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNNQ+3/28NJ/6/1/1/
1JR/1/6/5/1/C/tony parsons2/3/1/1/DH/1/ 1/*.1/ *.*.1/ *.3D9/2/L/Joan Hall - Pens
ioner3K/3/1/ 3AS/3/1/ *.*.1/ 3/2/3D9/2/3K/3AS/2/3K/3/2/2/0/DNNT6+2/28QL/6/2/1/R/
1/1/3/3/1/ 9/3/2/1/45/1/ 2/*.1/ *.*.1/ *.70/1/1/ 71/1/1/ 72/1/1/ *.*.1/ 4/4/*.*.
*.*.*.*.4/4/0/0/DNNT6+2/28QN/6/2/1/23/1/2/3/3/1/ 1/3/1/2/6S/1/ 39/*.1/ *.*.1/ *.
70/1/1/ 71/1/1/ N8/1/1A/Anthony Nelson (Tory) defected to Labour*.*.1/ 4/4/N8/3/
70/*.*.*.3/1/0/0/DNNT6+2/28QP/6/2/1/2O/1/2/3/3/1/ 1/3/1/2/6S/1/ 39/*.1/ *.*.1/ *
.70/1/1/ 3AL/3/T/The Times and Financial Times3K/3/1/ *.*.1/ 4/4/3AL/3/3K/*.*.*.
1/4/0/0/DNNT6+2/28R0/6/2/1/31/1/6/3/3/1/ 4/3/1/1/ED/1/ 1/*.1/ *.*.1/ *.3K/3/1/ 3
L/3/1/ N8/1/1A/Anthony Nelson (Tory) defected to Labour*.*.1/ 3/1/N8/1/3L/N8/3/3
K/3/1/0/0/DNNT6+2/28R1/6/2/1/1G6/1/6/2/1/1/ 2/3/1/1/DC/1/ 1/9T/15/Journalist re-
visits his old school39/*.1/ *.3AQ/1/R/Derek Richmond - Headmaster3D9/3/E/Teachi
ng Staff3K/3/1/ 3L/3/1/ 3/3/3AQ/2/3K/3AQ/1/3L/3/3/1/0/DNO2C+2/2901/6/3/1/DN/1/1/
5/1/F/tom newton dunn2/3/2/1/72/I/Leader's underwear7/*.1/ *.*.1/ *.70/1/1/ 71/1
/1/ 10I/1/1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/0/0/DNO2C+2/2904/6/3/1/2N/1/4/1/1/1/ 1/2
/1/1/DO/1/ 1/*.1/ *.*.1/ *.71/1/1/ 3D9/1/7/Refugee*.*.1/ *.*.1/ 1/4/3D9/1/71/*.*
.*.1/4/1/0/DNO2C+2/2905/6/3/1/3F/1/4/1/2/1/ 1/4/1/1/EB/1/ 1/*.1/ *.*.1/ *.AB/1/1
/ 47/3/1/ *.*.1/ *.*.1/ 4/4/AB/1/47/*.*.*.4/4/1/0/DNO2C+2/2907/6/3/1/82/1/4/5/1/
1/ 1/2/1/2/3G/1/ 39/*.1/ *.*.1/ *.70/1/1/ E5/1/1/ 71/1/1/ H2/1/1/ 4/4/71/1/70/*.
*.*.1/1/0/0/DNO2C+2/2908/6/3/1/1Q/1/4/3/3/1/ 1/2/2/2/72/1C/Blair can't drink as 
much as Euan or Hague7/3B/1/ 3/*.1/ *.70/1/1/ 71/1/1/ 271/1/1/ *.*.1/ 4/4/*.*.*.
*.*.*.3/1/0/0/DNO2C+2/290A/6/3/1/A9/1/5/1/1/1/ 1/3/1/1/GJ/1A/Tories' own pension
 fund in difficulties1/DH/1/ 1/*.1/ *.3L/3/1/ 3D9/1/18/David Harvey - father ran
 pension fundD9/1/C/Ian McCarthy*.*.1/ 1/4/3D9/1/3L/D9/1/3L/1/4/1/0/DNO2C+2/290B
/6/3/1/87/1/6/3/3/1/ 4/3/2/2/72/K/The underpants story7/*.1/ *.*.1/ *.70/1/1/ 71
/1/1/ *.*.1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/0/0/DNO2C+2/290C/6/3/1/2T/1/6/3/3/1/ 4/3
/1/2/72/K/The underpants story7/*.1/ *.*.1/ *.DO/1/1/ 10I/1/1/ *.*.1/ *.*.1/ 1/4
/*.*.*.*.*.*.1/4/0/0/DNO5I+2/293B/6/4/1/4/1/1/3/3/1/ 9/3/1/1/A1/1/ 8/*.1/ *.*.1/
 *.71/1/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/1/DNO5I+2/293C/6/4/1/12D/1
/4/1/1/1/ 1/3/1/1/3L/1/ 4/72/R/Mock funeral for the tories7/3B/1/ 3/71/1/1/ H5/1
/1/ H6/1/1/ 70/1/1/ 1/1/71/1/70/*.*.*.1/1/0/0/DNO5I+2/293G/6/4/1/2D/1/7/5/2/I/al
exandra williams1/2/1/1/6O/13/Hague's helicopter nearly crashes6/*.1/ *.*.1/ *.7
1/1/1/ JT/3/D/Senior ToriesKS/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNO5I+2/293H/6
/4/1/2J/1/6/3/3/1/ 1/2/1/1/3B/1/ 3/4A/P/Final tv appeal to voters4/*.1/ *.70/1/1
/ 71/1/1/ 72/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNO5I+2/293J/6/4/1/27/1/7/1/1/1
/ 1/3/1/1/6L/1/ 6/*.1/ *.*.1/ *.3K/3/1/ 3L/3/1/ 3AR/3/4/Poll*.*.1/ 4/1/3AR/3/3K/
3AR/1/3L/4/1/0/0/DNO5I+2/293N/6/4/1/R9/1/8/1/1/1/ 5/3/1/1/A1/1/ 8/9T/1F/Critical
 of New Labour but will vote for them39/6S/1/ 39/70/1/1/ 71/1/1/ *.*.1/ *.*.1/ 1
/1/*.*.*.*.*.*.1/1/0/1/DNO5I+2/293P/6/4/1/33/1/A/5/1/A/Ruki Sayid1/3/2/2/72/12/T
ony Blair wears CK boxer shorts7/*.1/ *.*.1/ *.70/1/1/ 3AL/1/D/Eamonn Holmes*.*.
1/ *.*.1/ 4/4/*.*.*.*.*.*.3/4/0/0/DNO5I+2/293S/6/4/1/2F/1/B/2/1/1/ 5/3/1/1/DO/1/
 1/*.1/ *.*.1/ *.3D9/3/E/Asylum Seekers3AE/3/2E/Various Tory Supporters who said
 they'd leave the country if Labour got in*.*.1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/1/0/
DNO5I+2/293T/6/4/1/10K/1/C/5/2/B/jane ridley39/3/2/1/72/O/Election night party k
it7/*.1/ *.*.1/ *.71/1/1/ 72/1/1/ AE/1/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/1/DNL2O+2
/2HQL/7/3/1/G3/1/2/5/2/E/rebecca pavely1/3/1/2/DQ/1G/Trimble threatens to quit o
ver ira disarmament1/*.1/ *.*.1/ *.77/1/1/ 40/3/1/ 13T/1/K/Peter Robinson (DUP)1
6J/1/S/Martin McGuiness (Sinn Fein)4/4/13T/1/77/*.*.*.4/4/0/0/DNL2O+2/2HQM/7/3/1
/LJ/1/2/5/1/A/john deans1/2/1/2/DF/1/ 1/A2/1/ 8/*.1/ *.AC/1/1/ 3AH/3/D/EU Social
ists3L/3/1/ *.*.1/ 4/4/3L/1/AC/AC/1/3L/4/4/1/0/DNL2O+2/2HQN/7/3/1/167/1/C/39/1/D
/john mortimer5/3/1/1/6J/12/Prospect of an election campaign39/3C/1/ 4/*.1/ *.70
/1/1/ 3K/3/1/ 46/3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNL2O+2/2HQR/7/3/1/TL/1/6/1
/1/1/ 1/2/1/1/3D/1/ 3/A2/1/ 8/GJ/S/Civil servants severance pay1/70/1/1/ 3D9/3/7
/Parents71/1/1/ 72/1/1/ 4/4/3D9/1/70/*.*.*.1/4/1/0/DNL2O+2/2HQT/7/3/1/44/1/7/3/3
/1/ 1/3/1/1/6Q/1/ 7/*.1/ *.*.1/ *.70/1/1/ 3BA/3/1/ 3AL/2/E/Caroline Quinn*.*.1/ 
1/1/*.*.*.*.*.*.1/1/0/0/DNL6+3/2I01/7/4/1/BA/1/6/5/1/D/graeme wilson1/3/1/2/6L/1
/ 6/DB/1/ 1/*.1/ *.70/1/1/ 3AQ/3/7/DoctorsH0/1/1/ *.*.1/ 4/4/3AQ/1/70/H0/1/70/1/
4/1/0/DNL6+3/2I04/7/4/1/30/1/6/1/1/1/ 1/1/1/1/4D/1/ 39/A1/1/ 8/A9/1/ 8/10F/1/1/ 
71/1/1/ 10C/1/1/ 70/1/1/ 4/4/10F/1/71/*.*.*.4/1/0/1/DNL6+3/2I06/7/4/1/IL/1/8/5/1
/D/graeme wilson1/2/1/1/DE/1/ 1/EB/1/ 1/*.1/ *.AB/1/1/ 3AL/1/E/John HumphreysH5/
1/1/ 3BC/3/R/Institute of Fiscal Studies1/4/3AL/1/AB/H5/1/AB/1/4/2/0/DNL6+3/2I09
/7/4/1/Q3/1/1/1/1/1/ 1/2/1/1/DE/1/ 1/3C/1/ 4/DG/1/ 1/AB/1/1/ 70/1/1/ 71/1/1/ 3AQ
/2/R/Irene Bishop (headmistress)1/1/71/1/70/3AQ/1/70/1/1/2/0/DNL6+3/2I0A/7/4/1/L
T/1/6/1/1/1/ 5/1/2/1/6J/L/Last PM question time39/A8/1/ 8/A9/1/ 8/70/1/1/ 71/1/1
/ 45/3/1/ *.*.1/ 1/2/45/1/70/*.*.*.1/2/0/0/DNL6+3/2I0B/7/4/1/8F/1/C/3/3/1/ 4/1/1
/1/3G/1/ 39/*.1/ *.*.1/ *.70/1/1/ 10O/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0
/DNL6+3/2I0D/7/4/1/9F/1/9/5/1/C/bill mouland1/2/1/1/3I/1/ 3/*.1/ *.*.1/ *.AE/1/1
/ 3K/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNL96+2/2I3B/7/5/1/J3/1/C/3/3/1/
 4/3/1/1/A6/1/ 9/EA/1/ 1/*.1/ *.3L/3/1/ 71/1/1/ 3K/3/1/ *.*.1/ 2/4/*.*.*.*.*.*.2
/4/1/0/DNL96+2/2I3E/7/5/1/S4/1/1/1/1/1/ 1/3/1/1/3G/1/ 39/*.1/ *.*.1/ *.E5/1/1/ 2
9T/2/7/Mrs Vaz10O/1/1/ GI/1/J/Robert Sheldon (MP)1/1/GI/1/E5/GI/1/29T/1/1/0/0/DN
L96+2/2I3F/7/5/1/1LO/1/6/5/1/9/john dean1/2/1/1/A6/1/ 9/A2/1/ 8/EA/1/ 1/71/1/1/ 
3L/3/1/ 3K/3/1/ *.*.1/ 3/3/71/1/3K/*.*.*.3/3/3/0/DNL96+2/2I3G/7/5/1/6B/1/8/1/1/1
/ 1/3/1/1/3T/1/ 4/*.1/ *.*.1/ *.E6/1/1/ 3K/3/1/ E9/3/1/ *.*.1/ 1/1/E9/1/E6/*.*.*
.1/1/0/0/DNL96+2/2I3H/7/5/1/47/1/8/1/1/1/ 1/2/1/1/DE/1/ 1/A9/1/ 8/A9/G/Blair/Bro
wn rift8/70/1/1/ AB/1/1/ 3K/3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNL96+2/2I3I/7/3
/1/NK/1/7/5/1/L/edward heatcoat amory5/3/1/1/A6/1/ 9/EA/1/ 1/*.1/ *.3L/3/1/ 71/1
/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/2/0/DNLIO+2/2I6L/7/1/1/53/1/4/3/3/1/ 1/2/2
/2/72/N/Cherie Blair's footwear7/3B/1/ 3/*.1/ *.270/2/1/ *.*.1/ *.*.1/ *.*.1/ 4/
*.*.*.*.*.*.*.4/*.0/0/DNLIO+2/2I6M/7/1/1/IE/1/6/1/1/1/ 1/2/1/2/3E/18/Blair shoul
d be allowed to meet people2/A2/1/ 8/*.1/ *.70/1/1/ E8/1/1/ *.*.1/ *.*.1/ 4/4/*.
*.*.*.*.*.1/4/1/0/DNLIO+2/2I6O/7/1/1/NR/1/4/1/1/1/ 2/2/1/1/3B/1/ 3/A1/1/ 8/3S/1/
 A/70/1/1/ 270/1/1/ GJ/1/16/John Burton - Blair's election agent3B6/3/1/ 1/2/GJ/
2/70/3B6/1/70/1/2/0/1/DNLIO+2/2I6Q/7/1/1/MD/1/5/1/1/1/ 1/3/1/1/3C/1/ 4/A9/1/ 8/3
B/1/ 3/AB/1/1/ DS/1/1/ *.*.1/ *.*.1/ 1/1/DS/1/AB/*.*.*.1/1/1/1/DNLIO+2/2I6R/7/1/
1/A1/1/A/3/3/1/ 4/3/1/1/AB/1/ 39/3T/1/ 4/*.1/ *.70/1/1/ E6/1/1/ D9/3/A/Senior MP
s*.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNLIO+2/2I6S/7/1/1/PO/1/E/2/1/1/ 5/3/1/2/3C/1/ 4
/3H/1/ 39/DD/1/ 1/70/1/1/ E6/1/1/ 3B3/3/H/Police FederationAH/1/1/ 1/1/*.*.*.*.*
.*.1/1/0/0/DNLM+3/2IA1/7/2/1/BM/1/5/3/3/1/ 1/2/1/2/A9/O/Blair/Brown relationship
8/DI/1/ 1/AD/1/ 39/70/1/1/ AB/1/1/ D9/3/H/Cabinet Ministers*.*.1/ 4/1/D9/1/AB/*.
*.*.4/1/1/0/DNLM+3/2IA2/7/2/1/PP/1/7/5/1/C/paul eastham1/2/1/2/ED/1/ 1/A2/1/ 8/D
E/1/ 1/AB/1/1/ 3AB/3/14/Labour Supporting Business LeadersH5/1/1/ *.*.1/ 4/4/3AB
/3/AB/H5/1/AB/2/4/1/0/DNLM+3/2IA4/7/2/1/1SC/1/4/1/1/1/ 1/2/1/1/3G/1/ 39/3B/S/Joh
n Humphires berates Blair3/*.1/ *.70/1/1/ 3AL/1/E/John HumphreysE5/1/1/ GI/1/H/G
eoffrey Robinson4/4/3AL/1/70/3AL/1/E5/1/4/0/0/DNLM+3/2IA5/7/2/1/PN/1/5/1/1/1/ 5/
2/1/1/3B/1/ 3/3E/1/ 2/*.1/ *.70/1/1/ 3B6/3/1/ *.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/
0/1/DNLM+3/2IA7/7/2/1/FQ/1/6/5/1/D/Graeme Wilson2/3/1/2/3T/1/ 4/*.1/ *.*.1/ *.E6
/1/1/ 3B3/1/I/Ken Jackson (AEEU)70/1/1/ *.*.1/ 1/4/3B3/3/E6/*.*.*.1/4/0/0/DNLM+3
/2IA8/7/2/1/HE/1/8/5/1/C/Paul Eastham1/3/1/2/3H/1A/Close friend of Blair accused
 of scandel39/*.1/ *.*.1/ *.3B3/1/F/Roger Lyons MSF70/1/1/ *.*.1/ *.*.1/ 4/4/*.*
.*.*.*.*.1/1/0/0/DNLM+3/2IA9/7/2/1/KF/1/A/3/3/1/ 4/3/1/1/EA/1/ 1/9T/10/12 questi
ons Blair must answer39/*.1/ *.70/1/1/ 3AL/1/E/John Humphreys*.*.1/ *.*.1/ 1/3/*
.*.*.*.*.*.1/3/2/0/DNLM+3/2IAA/7/2/1/AP/1/7/3/3/1/ 1/3/1/1/4E/1/ 4/A1/1/ 8/*.1/ 
*.3B8/2/1/ 70/1/1/ 270/2/1/ *.*.1/ 1/4/3B8/3/70/3B8/3/270/1/4/0/0/DNLM+3/2IAB/7/
2/1/2O/1/7/3/3/1/ 1/3/1/1/6J/19/Bell stands as Independent in Brentwood8/*.1/ *.
*.1/ *.10B/1/1/ N9/3/I/Disaffected ToriesKT/3/H/Brentwood & Ongar*.*.1/ 4/4/N9/1
/KJ/*.*.*.4/4/0/0/DNLP6+2/2IDC/7/3/1/GF/1/8/5/1/C/paul eastham1/4/1/2/EG/1/ 1/*.
1/ *.*.1/ *.70/1/1/ 3B5/1/14/John Bolton - us dep. defence sec.AC/1/1/ *.*.1/ 4/
4/3B5/1/70/3B5/1/AC/1/4/1/0/DNLP6+2/2IDD/7/3/1/B1/1/C/3/3/1/ 4/3/1/1/A1/1/ 8/A3/
1/ 8/A2/1/ 8/70/1/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/1/DNLP6+2/2IDE/7
/3/1/PP/1/1/1/1/1/ 1/2/1/1/DD/1/ 1/3C/1/ 4/3F/1/ 2/3L/3/1/ 70/1/1/ 3K/3/1/ 71/1/
1/ 4/4/3L/1/3K/3K/1/3L/4/1/1/0/DNLP6+2/2IDG/7/3/1/P5/1/8/5/1/A/john deans1/2/1/1
/A7/1/ 9/DE/1/ 1/EA/1/ 1/72/1/1/ 3M/3/1/ 70/1/1/ 71/1/1/ 4/4/72/1/70/72/1/71/4/4
/3/0/DNLP6+2/2IDO/7/3/1/5E/1/P/3/3/1/ 1/3/1/1/3C/20/Culling animals to get rid o
f foot and mouth before election4/GJ/C/Foot & Mouth1/*.1/ *.3AA/1/1/ 44/3/4/MAFF
*.*.1/ *.*.1/ 4/4/3AA/1/44/*.*.*.4/4/1/0/DNLSC+2/2IGL/7/4/1/6Q/1/3/3/3/1/ 1/2/1/
2/3H/1/ 39/3P/1/ 3/*.1/ *.AE/1/1/ 3B9/1/1/ 3B6/2/N/Craig Evan's Girlfriend*.*.1/
 1/4/3B6/1/AE/*.*.*.1/4/0/1/DNLSC+2/2IGM/7/4/1/LR/1/J/1/1/1/ 1/2/1/2/3B/1/ 3/4B/
1/ A/A5/1/ 9/70/1/1/ 3K/3/1/ 3AM/1/C/TV ReportersAB/1/1/ 1/1/3AM/1/3K/*.*.*.1/1/
0/0/DNLSC+2/2IGN/7/4/1/16E/1/I/1/1/1/ 1/2/1/1/A5/1/ 9/A2/1/ 8/EA/1/ 1/3K/3/1/ 70
/1/1/ *.*.1/ *.*.1/ 4/2/*.*.*.*.*.*.4/2/3/0/DNLSC+2/2IGO/7/4/1/14E/1/2/1/1/1/ 1/
2/1/1/3P/1/ 3/3B/1/ 3/*.1/ *.AE/1/1/ 70/1/1/ AH/1/1/ 3AK/1/1/ 1/1/3AK/1/70/3AK/1
/AH/1/1/0/0/DNLSC+2/2IGQ/7/4/1/PS/1/I/5/1/L/edward heatcoat amory5/3/1/1/A5/1/ 9
/EA/1/ 1/*.1/ *.GI/1/F/David Milliband3K/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/
2/0/DNLSC+2/2IGR/7/4/1/KM/1/5/5/2/C/sarah harris1/2/1/1/3P/1/ 3/DB/1/ 1/3B/1/ 3/
3AK/2/D/Sharon Storer70/1/1/ 3D9/1/1E/Keith Sedgewick - storer's partner (patien
t)*.*.1/ 3/1/3AK/1/70/*.*.*.3/1/1/0/DNLSC+2/2IGS/7/4/1/NI/1/4/5/1/F/matthew hick
ley1/2/1/1/3P/1/ 3/DD/1/ 1/A3/1/ 8/AH/1/1/ 3AQ/3/1/ *.*.1/ *.*.1/ 1/4/3AQ/1/AH/*
.*.*.1/4/1/0/DNLSC+2/2IGT/7/4/1/11/1/1/3/3/1/ 9/2/1/1/44/1/ 3/3P/1/ 3/*.1/ *.AE/
1/1/ 3B9/1/1/ *.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/0/0/DNM1I+2/2IK1/7/5/1/14A/1/C/1
/1/1/ 3/3/1/2/AA/1/ 8/A1/1/ 8/*.1/ *.AE/1/1/ 70/1/1/ GI/3/G/Other Labour MPs*.*.
1/ 2/4/*.*.*.*.*.*.2/4/0/3/DNM1I+2/2IK2/7/5/1/A5/1/7/5/1/D/graham keeley1/3/1/2/
3H/1/ 39/9T/M/Profile of Craig Evans39/*.1/ *.3B9/1/1/ 3D9/3/O/Relations of Crai
g EvansAE/1/1/ *.*.1/ 4/4/3D9/1/AE/3D9/3/3B9/4/4/0/1/DNM1I+2/2IK3/7/5/1/M0/1/2/1
/1/1/ 1/2/1/1/DO/1/ 1/*.1/ *.*.1/ *.71/1/1/ 3K/3/1/ 3D9/3/K/Bogus Asylum Seekers
*.*.1/ 4/4/71/1/3K/71/1/3D9/4/4/1/0/DNM1I+2/2IK5/7/5/1/97/1/6/3/3/1/ 2/3/1/1/A1/
1/ 8/*.1/ *.*.1/ *.AE/1/1/ *.*.1/ *.*.1/ *.*.1/ 2/*.*.*.*.*.*.*.2/*.0/2/DNM1I+2/
2IK6/7/5/1/11S/1/8/1/1/1/ 1/3/1/2/72/1E/Daily Mail play a practical joke on Wood
ward7/3B/1/ 3/A1/1/ 8/E6/1/1/ 3D9/1/6/ButlerN8/1/D/Lee Rotherham*.*.1/ 1/3/N8/1/
E6/*.*.*.1/3/0/1/DNM1I+2/2IK8/7/5/1/CG/1/9/5/1/D/Graeme Wilson1/3/1/1/3T/1/ 4/*.
1/ *.*.1/ *.3K/3/1/ 140/1/D/Neil ThompsonE6/1/1/ *.*.1/ 1/4/140/1/3K/*.*.*.1/4/0
/0/DNM1I+2/2IKA/7/5/1/86/1/A/5/1/F/Matthew Hickley1/2/1/2/DD/1/ 1/*.1/ *.*.1/ *.
H6/2/1/ AH/1/1/ 3B3/3/F/Police Officers*.*.1/ 4/4/H6/3/3B3/*.*.*.3/1/1/0/DNM1I+2
/2IKB/7/5/1/JS/1/C/3/3/1/ 4/3/1/2/6J/1G/Criticising "hippocritical/arrogant Labo
ur MPs8/*.1/ *.*.1/ *.AE/1/1/ 70/1/1/ AH/1/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNM
1I+2/2IKC/7/5/1/LO/1/E/1/1/1/ 5/3/1/2/DG/1/ 1/*.1/ *.*.1/ *.70/1/1/ *.*.1/ *.*.1
/ *.*.1/ 4/*.*.*.*.*.*.*.1/*.1/0/DNM1I+2/2IKD/7/5/1/PR/1/7/1/1/1/ 1/3/1/1/3H/1/ 
39/A1/1/ 8/*.1/ *.AE/1/1/ 70/1/1/ 71/1/1/ 3B9/1/1/ 1/4/70/3/AE/*.*.*.1/4/0/0/DNM
B6+2/2INB/7/1/1/3B/1/5/3/3/1/ 1/3/1/2/3G/1/ 39/*.1/ *.*.1/ *.70/1/1/ KB/1/1/ E5/
1/1/ GI/1/H/Geoffrey Robinson4/4/KB/1/E5/KB/1/GI/4/4/0/0/DNMB6+2/2IND/7/1/1/6O/1
/5/3/3/1/ 1/2/1/1/3B/1/ 3/6J/T/Gordon Brown misses TV debate8/*.1/ *.AB/1/1/ 3L/
3/1/ 3BA/3/1/ *.*.1/ 4/4/3L/1/AB/AB/1/3BA/1/4/0/0/DNMB6+2/2INE/7/1/1/7S/1/5/3/3/
1/ 1/3/1/1/6L/1/ 6/*.1/ *.*.1/ *.3L/3/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.1
/3/1/0/DNMB6+2/2INF/7/1/1/F8/1/4/3/3/1/ 1/3/1/1/ED/1/ 1/DE/1/ 1/GJ/C/Minimum wag
e1/3L/3/1/ 3AC/3/1/ 3K/3/1/ *.*.1/ 4/4/3AC/3/3L/3AC/1/3K/4/4/1/0/DNMB6+2/2INK/7/
1/1/BA/1/4/5/1/D/gordon raynor1/3/1/1/3H/1/ 39/A1/1/ 8/*.1/ *.GI/2/D/Helen Brint
on29T/1/K/Brinton's ex-husband3D9/3/K/Brinton's Neighbours*.*.1/ 1/4/29T/1/GI/3D
9/1/GI/1/4/0/1/DNMB6+2/2INL/7/1/1/4S/1/5/3/3/1/ 1/3/1/1/DD/1/ 1/*.1/ *.*.1/ *.3D
9/3/P/Sentencing Advisory PanelAH/1/1/ 3L/3/1/ 3K/3/1/ 1/4/3L/1/3K/*.*.*.1/4/1/0
/DNMEC+2/2IQM/7/2/1/CT/1/A/3/3/1/ 4/3/1/2/DT/1/ 1/*.1/ *.*.1/ *.AB/1/1/ 3K/3/1/ 
DP/1/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNMEC+2/2IQN/7/2/1/327/1/G/1/1/1/ 6/3/1/1
/EA/1/ 1/DF/1/ 1/A1/1/ 8/10M/2/1/ 70/1/1/ 3K/3/1/ 71/1/1/ 3/4/10M/1/70/10M/1/71/
3/4/3/2/DNMEC+2/2IQO/7/2/1/118/1/1/1/1/1/ 1/2/1/1/DT/1/ 1/DE/1/ 1/*.1/ *.3K/3/1/
 AB/1/1/ H5/1/1/ 71/1/1/ 1/1/H5/1/3K/71/1/3K/1/1/1/0/DNMEC+2/2IQQ/7/4/1/HD/1/6/1
/1/1/ 1/3/1/1/6Q/1/ 7/3P/1/ 3/*.1/ *.E1/2/1/ 3K/3/1/ 3AM/3/1/ *.*.1/ 4/4/E1/1/3A
M/3AM/1/3K/1/1/0/0/DNMEC+2/2IQR/7/2/1/S5/1/6/1/1/1/ 1/3/1/1/3G/1/ 39/3B/1/ 3/9T/
N/Searching for Keith Vaz39/E5/1/1/ 3B6/3/1/ *.*.1/ *.*.1/ 1/4/3B6/1/E5/*.*.*.1/
4/0/1/DNMEC+2/2IQS/7/2/1/6A/1/6/3/3/1/ 1/3/1/1/6J/8/Cronyism39/DB/1/ 1/*.1/ *.3D
9/1/P/Barman @ PM's Labour ClubH0/1/1/ 3B2/1/I/Hospital spokesman70/1/1/ 1/4/H0/
1/3D9/3B2/1/3D9/1/4/0/0/DNMHI+2/2J07/7/3/1/EK/1/6/3/3/1/ 1/3/1/1/DT/1/ 1/6L/1/ 6
/3P/1/ 3/H5/1/1/ 3K/3/1/ 70/1/1/ AB/1/1/ 4/2/H5/1/AB/AB/1/70/4/2/1/0/DNMKO+2/2J3
C/7/4/1/9I/1/6/3/3/1/ 1/4/1/2/DB/1/ 1/EB/1/ 1/A2/1/ 8/3K/3/1/ 3BC/3/S/Institute 
for Fiscal Studies70/1/1/ 3BC/3/B/King's Fund1/4/*.*.*.*.*.*.1/4/1/0/DNMKO+2/2J3
E/7/4/1/7A/1/4/3/3/1/ 1/3/1/1/6J/12/Shaun Woodward's election advert8/A1/1/ 8/*.
1/ *.E6/1/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/1/DNMKO+2/2J3F/7/4/1/70/
1/4/3/3/1/ 1/2/1/1/DC/1/ 1/*.1/ *.*.1/ *.70/1/1/ AA/1/1/ 3K/3/1/ *.*.1/ 4/4/*.*.
*.*.*.*.4/4/2/0/DNMKO+2/2J3H/7/4/1/PA/1/7/1/1/1/ 1/2/2/1/3B/1/ 3/DB/1/ 1/A1/1/ 8
/72/1/1/ 3B6/1/1/ 3M/3/1/ *.*.1/ 2/4/3B6/3/72/*.*.*.2/4/1/1/DNMKO+2/2J3K/7/4/1/1
ER/1/D/5/1/M/Edward Heathcoat Amory2/3/1/2/DF/1/ 1/*.1/ *.*.1/ *.47/3/1/ 70/1/1/
 *.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/3/0/DNMO+3/2J6L/7/5/1/Q2/1/6/1/1/1/ 1/2/1/1/3
B/1/ 3/DF/1/ 1/A1/1/ 8/3R/3/1/ 140/1/L/Mick Faulkener - UKIP3B6/3/1/ *.*.1/ 3/3/
3B6/3/3R/*.*.*.3/3/1/0/DNMO+3/2J6M/7/5/1/KM/1/6/5/1/E/michael clarke2/3/1/1/4B/1
/ A/*.1/ *.*.1/ *.3AL/3/M/Undercover Journalists3K/3/1/ GJ/3/C/Spin Doctors3AM/3
/1/ 4/1/*.*.*.*.*.*.4/1/0/0/DNMO+3/2J6N/7/5/1/14F/1/7/5/1/C/paul eastham1/2/1/1/
DG/1/ 1/DF/1/ 1/3C/1/ 4/70/1/1/ H2/1/1/ 3L/3/1/ 3K/3/1/ 1/4/H2/1/70/*.*.*.1/4/1/
0/DNMO+3/2J6Q/7/5/1/KK/1/E/5/1/H/andreww alexander5/3/1/1/GJ/J/Threat to democra
cy1/DF/1/ 1/DE/1/ 1/3K/3/1/ 3AG/1/G/Frits Bolkestein70/1/1/ *.*.1/ 1/1/*.*.*.*.*
.*.1/1/2/0/DNN3I+2/2JA1/7/1/1/QM/1/1/5/1/A/Ray Massey2/3/1/2/E9/1/ 1/*.1/ *.*.1/
 *.3AC/3/G/Petrol CompaniesAB/1/1/ 3D9/1/1D/Ray Holloway (Petrol Retailers Assoc
iation)3B5/1/13/Prof. Oswald (Warwick University)4/4/*.*.*.*.*.*.1/4/1/0/DNN3I+2
/2JA2/7/1/1/HL/1/2/1/1/1/ 1/2/1/1/DG/1/ 1/A9/1/ 8/*.1/ *.AC/1/1/ 3K/3/1/ 3L/3/1/
 71/1/1/ 4/4/3L/1/3K/3K/1/71/4/4/1/1/DNN3I+2/2JA3/7/1/1/JF/1/A/3/3/1/ 4/3/1/1/DG
/1/ 1/3C/1/ 4/AD/1/ 39/70/1/1/ 71/1/1/ AB/1/1/ *.*.1/ 1/3/*.*.*.*.*.*.1/3/1/1/DN
N3I+2/2JA4/7/1/1/CM/1/G/5/1/A/john deans5/3/1/1/DE/1/ 1/DT/1/ 1/*.1/ *.H5/1/1/ 3
K/3/1/ E3/1/1/ 3L/3/1/ 4/4/H5/1/3K/E3/1/H5/2/1/2/1/DNN3I+2/2JA5/7/1/1/JP/1/H/1/1
/1/ 1/3/1/1/3G/1/ 39/*.1/ *.*.1/ *.E5/1/1/ 3D9/1/11/Mr. Auchi - Iranian Business
man6J/3/1A/Commons Standards & Privileges Committee3K/3/1/ 1/1/6J/1/E5/3K/1/E5/1
/1/0/0/DNN3I+2/2JA6/7/1/1/JC/1/H/5/1/D/Tom Rawstorne2/3/1/2/3G/1/ 39/*.1/ *.*.1/
 *.3D9/1/1J/Nadhmi Auchi (very rich Iraq friend of Keith Vaz)E5/1/1/ *.*.1/ *.*.
1/ 2/4/*.*.*.*.*.*.2/1/0/0/DNN6O+2/2JDB/7/2/1/187/1/D/5/1/E/stephen glover5/3/1/
1/DG/1/ 1/3C/1/ 4/3R/1/ 2/71/1/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/2/0
/DNN6O+2/2JDC/7/2/1/1+2/1/1/1/1/1/ 5/2/1/1/3R/1/ 2/DF/1/ 1/3C/1/ 4/3K/3/1/ DO/1/
1/ 3L/3/1/ 3AG/1/D/Lionel Jospin1/1/DO/1/3L/3L/1/3AG/1/1/2/1/DNN6O+2/2JDF/7/2/1/
PJ/1/5/5/1/J/martin vander weyer5/3/1/1/DG/1/ 1/DI/1/ 1/A1/1/ 8/70/1/1/ AB/1/1/ 
42/3/1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/1/1/DNN6O+2/2JDG/7/2/1/PI/1/4/1/1/1/ 1/2/1/2/
A1/1/ 8/*.1/ *.*.1/ *.10B/1/1/ L4/1/1/ 3B6/1/E/Andrew Wheeler*.*.1/ 2/4/*.*.*.*.
*.*.2/4/0/0/DNN6O+2/2JDJ/7/2/1/5O/1/A/3/3/1/ 4/3/1/1/DB/1/ 1/*.1/ *.*.1/ *.70/1/
1/ 3D9/3/8/Patients*.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/0/0/DNNA+3/2JGP/7/3/1/IK/1/
6/5/2/F/Rebecca Paveley1/4/1/1/DF/1/ 1/*.1/ *.*.1/ *.3AG/1/C/Romano Prodi70/1/1/
 71/1/1/ *.*.1/ 4/4/71/1/3AG/71/1/70/1/1/2/0/DNNA+3/2JGS/7/3/1/JR/1/A/3/3/1/ 4/4
/1/1/DG/1/ 1/DF/1/ 1/6J/15/That Lib Dems will become 2nd party8/70/1/1/ 72/1/1/ 
42/3/1/ AB/1/1/ 1/1/*.*.*.*.*.*.1/1/1/0/DNNA+3/2JH0/7/3/1/NC/1/1/1/1/1/ 1/2/1/1/
3C/1/ 4/DG/1/ 1/A1/1/ 8/71/1/1/ 70/1/1/ 10I/1/1/ 3K/3/1/ 3/1/10I/1/70/10I/1/3K/3
/1/1/1/DNND6+2/2JK2/7/4/1/5D/1/6/3/3/1/ 1/2/1/1/3B/1/ 3/72/M/Cherie's fashion se
nse7/*.1/ *.270/2/1/ *.*.1/ *.*.1/ *.*.1/ 3/*.*.*.*.*.*.*.3/*.0/0/DNND6+2/2JK3/7
/4/1/8E/1/7/3/3/1/ 1/2/1/1/EF/1/ 1/A2/1/ 8/*.1/ *.3M/3/1/ 72/1/1/ 3K/3/1/ *.*.1/
 4/4/3M/1/3K/*.*.*.4/4/1/0/DNND6+2/2JK5/7/4/1/3B/1/6/3/1/1/ 1/2/1/1/GJ/M/Flexibl
e working hours1/*.1/ *.*.1/ *.DN/1/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.
1/0/DNND6+2/2JK8/7/4/1/8E/1/7/3/3/1/ 1/3/1/1/DH/1/ 1/*.1/ *.*.1/ *.KR/1/1/ 3L/3/
1/ 3AS/3/1/ *.*.1/ 4/4/KR/3/3AS/*.*.*.4/4/1/0/DNNGC+2/2JNB/7/5/1/S9/1/1/1/1/1/ 1
/2/1/1/DB/1/ 1/DC/1/ 1/*.1/ *.70/1/1/ 3K/3/1/ 3D9/1/L/Health RepresentativeH5/1/
1/ 1/1/3D9/1/3K/H5/1/3K/1/1/1/0/DNNGC+2/2JND/7/5/1/186/1/6/5/1/N/Edward Heathcoa
te-Amory2/3/1/1/DB/1/ 1/*.1/ *.*.1/ *.3K/3/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*
.*.1/*.2/0/DNNGC+2/2JNE/7/5/1/J6/1/7/3/3/1/ 2/3/1/1/GJ/16/Not enough college pla
ces for nurses1/DB/1/ 1/*.1/ *.3B6/2/11/Josie Sinclair (would be nurse)42/3/1/ 3
D9/2/14/Royal College of Nursing spokesman*.*.1/ 4/4/3D9/1/42/*.*.*.4/1/1/0/DNNG
C+2/2JNG/7/5/1/NQ/1/8/1/1/1/ 1/2/1/2/3B/1/ 3/*.1/ *.*.1/ *.71/1/1/ 275/2/1/ 70/1
/1/ 3B6/3/1/ 3/3/3B6/3/71/*.*.*.3/3/0/0/DNNGC+2/2JNI/7/5/1/JI/1/C/3/3/1/ 4/3/1/1
/DB/1/ 1/E1/1/ 1/A3/1/ 8/70/1/1/ 3K/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/1/1/D
NNGC+2/2JNJ/7/5/1/16E/1/C/5/2/E/Kitty Dimbleby5/3/1/2/A4/1B/Comment from Jonatho
n Dimbleby's daughter8/3K/1/ 2/*.1/ *.3K/3/1/ 70/1/1/ 3B8/2/1/ 71/1/1/ 1/1/*.*.*
.*.*.*.1/1/0/0/DNNQ+3/2JQL/7/1/1/OJ/1/1/1/1/1/ 1/3/1/1/DB/1/ 1/6J/E/Counterattac
ks39/*.1/ *.3K/3/1/ 3BC/1/11/Health Think Tank (King's Fund)D9/1/T/John Denham (
health minister)*.*.1/ 1/3/3BC/1/3K/*.*.*.1/3/1/0/DNNQ+3/2JQN/7/1/1/O1/1/4/39/1/
6/doctor5/3/1/1/DB/1/ 1/9T/P/Will not be voting Labour39/*.1/ *.3K/3/1/ 3D9/3/Q/
Doctors/medical profession*.*.1/ *.*.1/ 1/4/*.*.*.*.*.*.1/4/1/0/DNNQ+3/2JQP/7/1/
1/55/1/5/3/3/1/ 5/3/1/1/3R/1/ 2/6J/P/Australian state election4/*.1/ *.3K/3/1/ 3
L/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNNQ+3/2JQQ/7/1/1/7Q/1/5/3/3/1/ 1/3
/1/2/A2/1/ 8/AF/1/ 39/*.1/ *.70/1/1/ AA/1/1/ AH/1/1/ AE/1/1/ 4/4/*.*.*.*.*.*.4/4
/1/0/DNNT6+2/2K01/7/2/1/IF/1/2/5/2/A/john deans1/2/1/1/3B/J/Newsnight interview3
/DE/1/ 1/6J/H/Labour leadership8/70/1/1/ 3AL/1/D/Jeremy PaxmanAB/1/1/ E5/1/1/ 4/
4/3AL/3/70/70/3/AB/4/4/1/1/DNNT6+2/2K04/7/2/1/96/1/6/3/3/1/ 1/2/1/1/6J/16/Wilf S
elf and Alister Campbell clash39/3B/1/ 3/*.1/ *.DO/1/1/ 3AE/1/9/Will Self*.*.1/ 
*.*.1/ 4/4/DO/1/3AE/*.*.*.4/4/0/1/DNNT6+2/2K05/7/2/1/3N/1/6/3/3/1/ 1/3/1/2/GJ/C/
Foot & mouth1/*.1/ *.*.1/ *.71/1/1/ 3K/3/1/ 3B3/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/1/
0/0/DNNT6+2/2K08/7/2/1/7R/1/A/3/3/1/ 4/3/1/1/6Q/1/ 7/*.1/ *.*.1/ *.3BA/3/1/ 42/3
/1/ *.*.1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/0/0/DNNT6+2/2K09/7/2/1/2S/1/A/3/3/1/ 4/3/1
/1/AF/1/ 39/A1/1/ 8/*.1/ *.AA/1/1/ GI/2/E/Estelle Morris*.*.1/ *.*.1/ 3/3/*.*.*.
*.*.*.3/3/0/1/DNNT6+2/2K0A/7/2/1/17D/1/D/5/1/D/Steven Glover5/3/1/1/GJ/I/State i
ncompetancy1/E1/1/ 1/*.1/ *.70/1/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/2
/0/DNNT6+2/2K0B/7/2/1/2IA/1/G/2/2/1/ 6/3/1/2/A1/1/ 8/*.1/ *.*.1/ *.71/1/1/ 275/2
/1/ 70/1/1/ *.*.1/ 3/3/71/3/275/71/1/70/3/3/1/2/DNO2C+2/2K3B/7/3/1/I5/1/2/1/1/1/
 1/2/1/1/6J/F/Floating voters5/4A/1/ 4/6L/1/ 6/71/1/1/ 70/1/1/ *.*.1/ *.*.1/ 4/4
/71/1/70/70/1/71/4/1/0/0/DNO2C+2/2K3C/7/3/1/KA/1/6/5/2/A/jenny hope1/3/1/1/DB/1O
/Leaked report says manipulating hospital waiting lists1/*.1/ *.*.1/ *.3D9/3/L/N
ational Audit Office3B2/3/D/Health Report44/3/6/Health3D9/3/3/NHS4/4/*.*.*.*.*.*
.4/4/1/0/DNO2C+2/2K3D/7/3/1/GC/1/6/5/1/C/Paul Eastham1/2/1/1/3G/1/ 39/*.1/ *.*.1
/ *.70/1/1/ E5/1/1/ 3BA/3/1/ 3D9/2/G/Elizabeth Filkin1/1/3BA/1/70/3D9/1/E5/1/1/0
/1/DNO2C+2/2K3E/7/3/1/CK/1/6/3/3/1/ 1/4/1/2/6J/P/Unionist threats to Blair8/*.1/
 *.*.1/ *.70/1/1/ 3B3/3/3/GMB*.*.1/ *.*.1/ 4/4/3B3/1/70/*.*.*.1/4/1/0/DNO2C+2/2K
3F/7/3/1/42/1/6/3/3/1/ 1/2/1/1/3C/1/ 4/3I/1/ 3/48/1/ 5/3K/3/1/ 70/1/1/ 3AE/3/J/V
arious Celebrities*.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNO2C+2/2K3H/7/3/1/LP/1/7/1/1/1
/ 1/2/1/2/3B/1/ 3/*.1/ *.*.1/ *.71/1/1/ 275/2/1/ 3B6/1/1/ *.*.1/ 4/3/3B6/3/275/*
.*.*.2/3/0/0/DNO2C+2/2K3K/7/3/1/27B/1/A/5/1/M/edward heathcote amory5/3/1/1/EA/1
/ 1/A3/1/ 8/*.1/ *.70/1/1/ 3K/3/1/ AB/1/1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/3/0/DNO5I+
2/2K6L/7/4/1/MR/1/1/1/1/1/ 1/3/1/1/6L/1/ 6/4A/1/ 4/*.1/ *.70/1/1/ 71/1/1/ 72/1/1
/ *.*.1/ 4/4/70/1/71/71/1/70/1/3/1/1/DNO5I+2/2K6P/7/4/1/S6/1/6/1/1/1/ 5/2/1/1/3B
/1/ 3/3E/1/ 2/A1/9/Arrogance8/70/1/1/ E8/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/
0/1/DNO5I+2/2K6Q/7/4/1/JT/1/C/3/3/1/ 5/3/1/1/3R/1/ 2/6S/1/ 39/*.1/ *.3K/3/1/ *.*
.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/0/DNO5I+2/2K6S/7/4/1/185/1/D/5/1/H/James
 Bartholomew39/3/1/2/72/1O/Where can you go to escape another four years of Blai
r7/*.1/ *.*.1/ *.70/1/1/ *.*.1/ *.*.1/ *.*.1/ 1/*.*.*.*.*.*.*.1/*.0/0/DNO5I+2/2K
6T/7/4/1/SH/1/7/5/1/E/robert hardman5/2/1/1/3B/1/ 3/*.1/ *.*.1/ *.71/1/1/ 3B6/3/
1/ *.*.1/ *.*.1/ 3/4/3B6/3/71/*.*.*.3/4/0/0/DNL2O+2/2T01/8/3/1/11J/1/6/1/2/1/ 2/
3/1/2/EA/1/ 1/A4/1/ 8/*.1/ *.3K/3/1/ 3L/3/1/ 3M/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/
3/1/DNL2O+2/2T02/8/3/1/8O/1/2/1/2/1/ 1/3/1/2/DQ/1G/Trimble threatens to quit ove
r ira disarmament1/*.1/ *.*.1/ *.77/1/1/ 70/1/1/ DS/1/1/ *.*.1/ 4/4/*.*.*.*.*.*.
4/4/0/0/DNL2O+2/2T03/8/3/1/167/1/1/1/1/1/ 1/2/1/1/3D/1/ 3/A2/1/ 8/3B/1/ 3/70/1/1
/ 71/1/1/ 3L/3/1/ 3AQ/2/R/Irene Bishop (headmistress)3/4/70/1/3L/3AQ/3/70/3/4/1/
0/DNL2O+2/2T05/8/3/1/BD/1/7/3/3/1/ 1/2/1/1/4G/1/ 39/*.1/ *.*.1/ *.270/2/1/ 275/2
/1/ 276/2/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNL2O+2/2T07/8/3/1/QD/1/C/1/1/1/ 5/3
/1/1/DB/1/ 1/DG/1/ 1/A2/1/ 8/70/1/1/ 3K/3/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.*.*.2/2/2
/0/DNL2O+2/2T08/8/3/1/42/1/6/3/3/1/ 1/3/1/1/4D/1/ 39/*.1/ *.*.1/ *.10F/1/1/ 10C/
1/1/ 10I/1/1/ 139/3/9/Other MPs4/4/*.*.*.*.*.*.4/4/0/0/DNL6+3/2T3B/8/4/1/5L/1/6/
3/3/1/ 1/2/1/2/3B/1/ 3/*.1/ *.*.1/ *.72/1/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.
*.4/*.0/0/DNL6+3/2T3D/8/4/1/P0/1/C/5/2/B/laura kibby5/3/1/1/4G/1/ 39/*.1/ *.*.1/
 *.270/2/1/ 275/2/1/ 70/1/1/ 71/1/1/ 3/1/*.*.*.*.*.*.3/1/0/1/DNL6+3/2T3G/8/4/1/7
L/1/C/3/3/1/ 4/3/1/1/A1/1/ 8/6L/1/ 6/*.1/ *.71/1/1/ 3B6/3/1/ 70/1/1/ *.*.1/ 1/4/
3B6/1/71/*.*.*.1/4/0/1/DNL6+3/2T3H/8/4/1/BJ/1/4/1/1/1/ 8/1/1/1/6J/L/Last PM ques
tion time39/A1/1/ 8/*.1/ *.71/1/1/ 70/1/1/ 3K/3/1/ *.*.1/ 4/4/71/1/70/*.*.*.4/4/
0/1/DNL96+2/2T6L/8/5/1/7L/1/5/3/3/1/ 1/2/1/2/3B/1/ 3/*.1/ *.*.1/ *.70/1/1/ *.*.1
/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.0/0/DNL96+2/2T6M/8/5/1/4G/1/2/3/3/1/ 1/3/1/1
/DD/1/ 1/*.1/ *.*.1/ *.3AN/1/12/David French - Police Federation3K/3/1/ 3L/3/1/ 
*.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNL96+2/2T6N/8/5/1/I1/1/2/1/2/1/ 1/3/1/1/DB/1/ 1/
*.1/ *.*.1/ *.3K/3/1/ AD/1/1/ 3M/3/1/ *.*.1/ 4/4/3M/1/3K/*.*.*.2/2/1/0/DNL96+2/2
T6O/8/5/1/RD/1/4/1/1/1/ 1/2/1/1/A6/1/ 9/EA/1/ 1/A9/1/ 8/3L/3/1/ 3K/3/1/ 71/1/1/ 
AB/1/1/ 4/4/71/1/3K/AB/1/3L/1/4/2/0/DNL96+2/2T6Q/8/5/1/69/1/C/3/3/1/ 4/3/1/2/A6/
1/ 9/A2/1/ 8/*.1/ *.3L/3/1/ 42/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNLIO+
2/2TA1/8/1/1/JH/1/8/1/1/1/ 1/2/1/2/DG/1/ 1/DE/1/ 1/3C/1/ 4/71/1/1/ KE/1/1/ 42/3/
1/ *.*.1/ 4/4/KE/1/42/*.*.*.1/4/1/0/DNLIO+2/2TA2/8/1/1/76/1/7/3/3/1/ 1/2/1/1/3C/
1/ 4/6S/1/ 39/6J/1B/Rory Bremner banned from labour battlebus3/3B8/2/1/ 70/1/1/ 
3AE/1/C/Rory Bremner3K/3/1/ 4/4/3B8/3/70/3AE/1/3K/4/2/0/0/DNLIO+2/2TA3/8/1/1/44/
1/8/3/3/1/ 1/3/1/1/6O/R/Hague's dad says he'll lose6/*.1/ *.*.1/ *.277/1/1/ 71/1
/1/ 29T/2/D/Hague's aunts*.*.1/ 4/4/277/1/71/*.*.*.4/1/0/0/DNLIO+2/2TA4/8/1/1/SM
/1/6/1/1/1/ 1/2/1/1/DC/1/ 1/3E/1/ 2/3B/1/ 3/70/1/1/ GJ/3/D/Campaign TeamE8/3/1/ 
*.*.1/ 3/4/GJ/3/70/GJ/1/E8/3/4/2/0/DNLM+3/2TDB/8/2/1/EA/1/3/5/1/B/david smith1/3
/1/2/6S/1/ 39/3C/1/ 4/*.1/ *.3B8/2/1/ 70/1/1/ 10M/2/1/ 71/1/1/ 4/4/3B8/3/70/3B8/
3/10M/4/4/0/0/DNLM+3/2TDD/8/2/1/56/1/6/5/1/A/adrian lee1/3/1/1/6S/1/ 39/A3/1/ 8/
DI/1/ 1/3AC/3/1/ 3K/3/1/ 3L/3/1/ *.*.1/ 4/4/3AC/3/3K/3L/1/3AC/4/3/0/0/DNLM+3/2TD
E/8/2/1/BT/1/6/1/2/1/ 1/2/1/1/A7/1/ 9/EA/1/ 1/3B/1/ 3/3M/3/1/ 72/1/1/ *.*.1/ *.*
.1/ 4/3/*.*.*.*.*.*.4/3/3/0/DNLM+3/2TDF/8/2/1/SG/1/6/1/1/1/ 1/3/1/2/DE/1/ 1/DB/1
/ 1/*.1/ *.3L/3/1/ KK/1/1/ 70/1/1/ 71/1/1/ 4/4/70/3/71/*.*.*.1/1/1/0/DNLM+3/2TDG
/8/2/1/8R/1/C/3/3/1/ 4/3/1/1/DB/1/ 1/DB/A/BMA report1/*.1/ *.42/3/1/ 3D9/3/3/BMA
3D9/3/3/GPs*.*.1/ 1/4/3D9/1/42/*.*.*.1/4/1/0/DNLM+3/2TDI/8/2/1/J5/1/D/5/1/D/vane
ssa feltz5/3/1/1/3I/1/ 3/6S/1/ 39/*.1/ *.3B8/2/1/ 70/1/1/ 3AE/3/H/Other Celebrit
ies*.*.1/ 2/1/*.*.*.*.*.*.2/1/0/1/DNLP6+2/2TGM/8/3/1/92/1/6/3/3/1/ 1/3/1/2/A1/1/
 8/3N/1/ 4/3L/1/ 4/KK/1/1/ 3M/3/1/ *.*.1/ *.*.1/ 1/4/3M/1/KK/*.*.*.1/4/0/1/DNLP6
+2/2TGO/8/3/1/9L/1/7/1/1/1/ 1/2/1/1/A5/1/ 9/3B/1/ 3/EA/1/ 1/70/1/1/ 273/1/1/ *.*
.1/ *.*.1/ 4/4/273/1/70/*.*.*.2/4/2/0/DNLP6+2/2TGQ/8/3/1/1FE/1/D/39/3/1/ 5/3/1/2
/A2/1/ 8/EA/1/ 1/*.1/ *.70/1/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.3/0/DNL
P6+2/2TGR/8/3/1/9L/1/7/5/2/A/jane young1/2/1/1/6S/1/ 39/3B/1/ 3/*.1/ *.DO/1/1/ 3
AE/2/E/Britney Spears70/1/1/ 3B6/1/1/ 4/4/3AE/3/DO/3B6/3/70/4/4/0/0/DNLSC+2/2TK1
/8/4/1/GO/1/A/3/3/1/ 1/3/1/2/A5/1/ 9/EA/1/ 1/*.1/ *.3K/3/1/ *.*.1/ *.*.1/ *.*.1/
 4/*.*.*.*.*.*.*.4/*.3/0/DNLSC+2/2TK4/8/4/1/J2/1/2/1/2/1/ 1/2/1/1/3P/1/ 3/3B/1/ 
3/*.1/ *.AE/1/1/ 70/1/1/ 3AK/3/1/ KB/1/1/ 4/4/3AK/1/70/KB/1/70/4/1/0/1/DNM1I+2/2
TNB/8/5/1/C5/1/4/5/1/B/tony brooks1/3/1/2/6J/12/Friends rally around Craig Evans
39/*.1/ *.*.1/ *.AE/1/1/ 3B9/1/1/ 29T/2/I/Craig's girlfriend3B6/1/1A/Barry Hende
rson (Friend of Craig Evan's)4/4/29T/3/3B9/3B6/3/3B9/4/3/0/0/DNM1I+2/2TNC/8/5/1/
5D/1/6/5/1/H/padraig flannagan1/2/1/1/3P/1/ 3/3L/1/ 4/*.1/ *.71/1/1/ 140/1/O/Dav
id Hall (independent)3D9/1/A/Paul Sykes3M/3/1/ 1/4/140/1/71/3D9/3/3M/1/4/1/0/DNM
1I+2/2TND/8/5/1/163/1/I/5/2/B/michael day5/3/1/1/6Q/1B/2 journalists comment on 
Prescott's punch7/3H/1/ 39/3P/1/ 3/AE/1/1/ 46/3/1/ *.*.1/ *.*.1/ 2/2/*.*.*.*.*.*
.2/2/0/2/DNM1I+2/2TNE/8/5/1/NL/1/1/1/2/1/ 1/2/1/1/3H/1/ 39/3C/1/ 4/*.1/ *.AA/1/1
/ 70/1/1/ 3K/3/1/ 71/1/1/ 4/4/70/3/AA/71/1/3K/4/2/0/1/DNM1I+2/2TNJ/8/5/1/G4/1/5/
1/1/1/ 3/3/1/1/3H/1/ 39/A1/1/ 8/*.1/ *.AE/1/1/ GJ/1/L/Prescott's Biographer3D9/1
/F/Former shipmate*.*.1/ 2/4/3D9/3/AE/*.*.*.2/4/0/2/DNM1I+2/2TNK/8/5/1/81/1/C/3/
3/1/ 4/3/1/1/3P/1/ 3/3C/1/ 4/3C/1/ 4/AE/1/1/ 46/3/1/ *.*.1/ *.*.1/ 3/4/*.*.*.*.*
.*.3/4/0/0/DNMB6+2/2TQL/8/1/1/8J/1/C/3/3/1/ 4/3/1/2/3C/1/ 4/A1/1/ 8/*.1/ *.71/1/
1/ 3L/3/1/ 3K/3/1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNMB6+2/2TQM/8/1/1/R5/1/C/1/1/
1/ 5/2/1/2/DM/1/ 1/3C/1/ 4/*.1/ *.71/1/1/ 3L/3/1/ 3K/3/1/ 72/1/1/ 1/1/72/1/71/*.
*.*.1/1/1/0/DNMB6+2/2TQN/8/1/1/K4/1/4/5/1/B/laura kibby1/4/1/1/DB/1/ 1/E7/1/ 1/D
B/H/Paying to use NHS1/3AQ/3/6/Nurses42/3/1/ 70/1/1/ 3B3/2/L/Christine Hancock R
CN4/4/3AQ/1/42/3B3/1/42/1/4/1/0/DNMEC+2/3001/8/2/1/91/1/7/3/3/1/ 1/2/1/2/GJ/8/Re
d tape1/DE/1/ 1/AD/1/ 39/AB/1/1/ 3AC/1/I/John Davies (ACCA)KG/1/1/ 70/1/1/ 4/4/K
G/1/AB/*.*.*.4/4/0/0/DNMHI+2/303B/8/3/1/GB/1/2/1/1/1/ 1/3/1/2/DT/1/ 1/A2/1/ 8/DE
/1/ 1/70/1/1/ 3L/3/1/ AB/1/1/ 3K/3/1/ 4/4/3L/1/3K/AB/1/3L/4/4/2/0/DNMKO+2/306L/8
/4/1/1K/1/B/3/3/1/ 1/3/1/2/6J/17/Ludovic Kennedy to run for parliament8/GJ/J/Leg
alise euthanasia1/*.1/ *.3AL/1/19/Ludovic Kennedy (independent candidate)KB/1/1/
 *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/1/0/DNMKO+2/306N/8/4/1/1QA/1/8/1/1/1/ 6/3/1/1
/EB/1/ 1/DG/1/ 1/3C/1/ 4/70/1/1/ *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.2/1/DN
MKO+2/306O/8/4/1/EQ/1/B/1/2/1/ 1/2/1/1/DG/1/ 1/DF/1/ 1/DE/1/ 1/3K/3/1/ 3L/3/1/ H
5/1/1/ 3D9/3/8/Brussels4/4/H5/1/3D9/3K/1/3L/4/1/1/0/DNMKO+2/306P/8/4/1/5H/1/B/3/
3/1/ 1/2/1/1/6J/1H/Rory Bremner not allowed to speak at CBI dinner3/*.1/ *.*.1/ 
*.3AE/1/C/Rory BremnerAB/1/1/ 3AC/3/3/CBI*.*.1/ 4/4/3AE/1/3AC/*.*.*.4/4/0/0/DNMO
+3/30A1/8/5/1/NF/1/B/1/1/1/ 1/3/1/1/3C/1/ 4/DC/1/ 1/A9/1/ 8/3L/3/1/ N8/3/M/Left 
and Centre Tories3B3/3/G/Teacher's unions71/1/1/ 4/4/3B3/1/3L/N8/1/71/1/1/0/0/DN
MO+3/30A4/8/5/1/86/1/C/3/3/1/ 4/3/1/2/DF/1/ 1/A9/1/ 8/*.1/ *.N8/3/G/Pro-europena
 MPs10M/2/1/ 71/1/1/ 47/3/1/ 2/1/71/1/47/*.*.*.2/1/0/0/DNMO+3/30A5/8/5/1/QK/1/C/
5/1/D/john kampfner5/3/1/1/42/1/ 39/3C/1/ 4/*.1/ *.3K/3/1/ GI/2/9/Women MPs70/1/
1/ 3L/3/1/ 1/4/*.*.*.*.*.*.1/4/0/0/DNN3I+2/30DB/8/1/1/HG/1/1/5/1/G/anthony mitch
ell1/3/1/1/E9/1/ 1/*.1/ *.*.1/ *.3AC/3/10/Federation of Petrol Suppliers3D9/3/6/
AA/RAC70/1/1/ 3D9/3/D/Oil Companies4/4/3AC/1/3D9/*.*.*.4/4/1/0/DNN3I+2/30DD/8/1/
1/B9/1/A/1/1/1/ 1/3/1/1/DG/1/ 1/A9/1/ 8/*.1/ *.71/1/1/ H5/1/1/ 3AB/3/K/Businss f
or Sterling*.*.1/ 4/4/3AB/1/71/*.*.*.1/4/1/0/DNN3I+2/30DF/8/1/1/8I/1/C/3/3/1/ 4/
3/1/2/GJ/1E/Stopping oil giants ripping off the consumer1/*.1/ *.*.1/ *.3AC/3/J/
Oil Industry GiantsAB/1/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/0/0/DNN3I+2/30DG/8/
1/1/PM/1/C/5/1/D/john kampfner5/3/1/1/DG/1/ 1/A9/1/ 8/3C/1/ 4/71/1/1/ 70/1/1/ 3L
/3/1/ *.*.1/ 1/2/70/1/3L/*.*.*.1/2/1/0/DNN6O+2/30GL/8/2/1/1Q/1/C/3/3/1/ 4/3/2/1/
72/17/Blair's bottom is sexiest in politics7/*.1/ *.*.1/ *.70/1/1/ 71/1/1/ 72/1/
1/ *.*.1/ 3/1/*.*.*.*.*.*.3/1/0/2/DNN6O+2/30GM/8/2/1/67/1/8/5/1/C/david hudson1/
3/1/1/DO/1/ 1/DR/1/ 1/A8/1/ 8/3M/3/1/ 71/1/1/ 3L/3/1/ 72/1/1/ 4/4/3L/1/3M/3K/1/3
M/1/4/1/0/DNN6O+2/30GN/8/2/1/27/1/A/3/3/1/ 1/2/1/1/3B/1/ 3/D9/P/Blair says no mo
re babies8/*.1/ *.70/1/1/ 270/2/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNN6O+2
/30GO/8/2/1/1Q/1/A/3/3/1/ 1/2/1/1/3B/1/ 3/72/H/Kennedy's clothes7/*.1/ *.72/1/1/
 *.*.1/ *.*.1/ *.*.1/ 4/*.*.*.*.*.*.*.4/*.0/0/DNN6O+2/30H1/8/2/1/5A/1/C/3/3/1/ 4
/3/1/1/DB/1/ 1/*.1/ *.*.1/ *.70/1/1/ 42/3/1/ *.*.1/ *.*.1/ 2/1/*.*.*.*.*.*.2/1/0
/0/DNNA+3/30K5/8/3/1/70/1/B/1/1/1/ 1/3/1/2/3H/16/Blair accused of endorsing Micr
osoft8/*.1/ *.*.1/ *.70/1/1/ KG/1/1/ 3AB/1/17/James Blaney (Microsoft spokespers
on)DN/1/1/ 4/4/KG/1/70/*.*.*.2/4/0/0/DNNA+3/30K6/8/3/1/7K/1/C/3/3/1/ 4/3/1/1/48/
1/ 5/3J/1/ 2/*.1/ *.3D9/3/A/Youngsters46/3/1/ *.*.1/ *.*.1/ 1/1/*.*.*.*.*.*.1/1/
0/0/DNND6+2/30NB/8/4/1/HO/1/2/1/1/1/ 1/3/1/1/6O/1/ 6/A9/1/ 8/3C/1/ 4/3L/3/1/ 71/
1/1/ 3AR/1/1/ N8/3/G/Left-wing Tories4/4/N8/1/71/*.*.*.1/1/0/1/DNND6+2/30ND/8/4/
1/6G/1/A/3/3/1/ 1/2/1/1/DB/1/ 1/DB/K/Bone marrow register1/*.1/ *.3D9/3/T/Parent
s of 8 year old patient3K/3/1/ 70/1/1/ *.*.1/ 4/4/3D9/1/3K/*.*.*.4/1/1/0/DNNGC+2
/30QM/8/5/1/CL/1/2/1/1/1/ 1/3/1/1/3C/1/ 4/DG/1/ 1/3F/1/ 2/71/1/1/ KJ/1/1/ N8/1/B
/Tim CollinsKS/3/1/ 4/4/71/1/KJ/71/1/N8/1/1/1/0/DNNGC+2/30QO/8/5/1/5R/1/8/3/3/1/
 1/3/1/1/DB/1/ 1/*.1/ *.*.1/ *.3D9/1/L/Head Consultant - BMA42/3/1/ *.*.1/ *.*.1
/ 4/4/3D9/1/42/*.*.*.4/4/1/0/DNNGC+2/30QP/8/5/1/2A/1/8/3/3/1/ 1/2/1/1/3H/1/ 39/D
K/1/ 1/E0/21/Council cuts - workers shown on election leaflet to lose jobs1/AD/1
/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.1/1/0/0/DNNGC+2/30QR/8/5/1/E4/1/9/1/2/
1/ 2/2/1/2/3K/1/ 2/6S/1/ 39/DE/1/ 1/70/1/1/ 3B8/2/1/ AB/1/1/ 71/1/1/ 4/4/71/1/AB
/*.*.*.3/3/1/0/DNNGC+2/30QT/8/5/1/4E/1/9/3/3/1/ 1/3/1/2/E1/1/ 1/*.1/ *.*.1/ *.3B
3/1/H/David Hart (NAHT)3K/3/1/ 3L/3/1/ *.*.1/ 4/4/3B3/1/3K/3B3/1/3L/4/1/1/0/DNNG
C+2/30R0/8/5/1/9A/1/C/3/3/1/ 4/3/1/2/A3/1/ 8/DB/1/ 1/DC/1/ 1/70/1/1/ 3AQ/3/K/Tea
chers and Doctors3K/3/1/ 3L/3/1/ 2/4/3AQ/1/3K/*.*.*.2/4/1/0/DNNQ+3/3101/8/1/1/KA
/1/6/1/1/1/ 1/3/1/1/AE/1/ 39/6L/1/ 6/3C/1/ 4/71/1/1/ N8/3/J/Pro-European Tories3
L/3/1/ *.*.1/ 1/4/N8/1/71/*.*.*.1/4/0/0/DNNQ+3/3103/8/1/1/8N/1/6/1/2/1/ 1/3/1/1/
48/1/ 5/3C/1/ 4/4A/1/ 4/3AE/3/A/Soap stars70/1/1/ 3L/3/1/ *.*.1/ 4/4/70/1/3L/*.*
.*.4/4/0/0/DNNQ+3/3104/8/1/1/C6/1/7/3/3/1/ 1/3/1/1/3L/1/ 4/3N/1/ 4/3M/1/ 4/70/1/
1/ 72/1/1/ 3L/3/1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNNT6+2/313C/8/2/1/R3/1/6/1/2/
1/ 1/2/1/1/9T/14/Urge Tory voters to swap to labour39/6L/1/ 6/3R/1/ 2/70/1/1/ 71
/1/1/ 3L/3/1/ *.*.1/ 4/4/70/1/3L/*.*.*.4/4/0/0/DNNT6+2/313F/8/2/1/CT/1/7/3/3/1/ 
1/2/1/1/3C/1/ 4/48/1/ 5/3F/1/ 2/3K/3/1/ 3L/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/
4/1/0/DNNT6+2/313G/8/2/1/9B/1/C/3/3/1/ 4/3/1/2/3L/1/ 4/6L/1/ 6/*.1/ *.71/1/1/ 70
/1/1/ *.*.1/ *.*.1/ 1/3/*.*.*.*.*.*.1/3/0/0/DNO2C+2/316N/8/3/1/EA/1/8/1/1/1/ 1/2
/1/1/3C/1/ 4/4A/1/ 4/3N/1/ 4/3L/3/1/ 71/1/1/ 3B6/1/1/ *.*.1/ 4/4/3B6/1/71/*.*.*.
4/1/1/0/DNO2C+2/316O/8/3/1/A8/1/9/3/3/1/ 1/2/1/1/3G/1/ 39/*.1/ *.*.1/ *.70/1/1/ 
E5/1/1/ 3AM/1/1/ *.*.1/ 4/4/70/1/3AM/3AM/1/E5/4/1/0/0/DNO5I+2/31A1/8/4/1/NR/1/1/
3/3/1/ 4/3/1/1/6S/1/ 39/A3/1/ 8/*.1/ *.70/1/1/ 71/1/1/ 3K/3/1/ 3L/3/1/ 3/1/*.*.*
.*.*.*.3/1/1/0/DNO5I+2/31A2/8/4/1/GH/1/2/1/1/1/ 1/3/1/1/6P/1/ 6/6J/S/Effect of w
eather on turnout39/*.1/ *.3L/3/1/ 3K/3/1/ *.*.1/ *.*.1/ 4/4/*.*.*.*.*.*.4/4/0/0
/DNO5I+2/31A3/8/4/1/KS/1/8/1/2/1/ 1/2/1/1/3B/1/ 3/4A/1/ 4/*.1/ *.70/1/1/ 3B6/3/1
/ 3L/3/1/ *.*.1/ 3/4/70/1/3L/3B6/3/70/3/4/0/0/DNO5I+2/31A6/8/4/1/BE/1/9/5/1/G/Pa
draic Flanagan1/2/1/2/3B/1/ 3/*.1/ *.*.1/ *.71/1/1/ 70/1/1/ 3B6/3/15/Workers at 
Smithfield's meat market*.*.1/ 4/4/71/1/70/*.*.*.1/4/0/0/DNO5I+2/31A7/8/4/1/LS/1
/B/1/1/1/ 2/3/1/2/D9/1I/Considering future prospects of campaign players8/*.1/ *
.*.1/ *.70/1/1/ AB/1/1/ 71/1/1/ 72/1/1/ 2/2/*.*.*.*.*.*.2/2/0/2/DNO5I+2/31A8/8/4
/1/79/1/A/3/3/1/ 2/3/1/2/6O/1/ 6/*.1/ *.*.1/ *.71/1/1/ 3K/3/1/ 3M/3/1/ *.*.1/ 4/
4/*.*.*.*.*.*.4/4/0/0/DNO5I+2/31A9/8/4/1/7B/1/B/3/3/1/ 1/3/1/2/6Q/1I/ITV and BBC
 battle for viewers on election night7/*.1/ *.*.1/ *.3AL/1/E/David Dimbleby3AL/1
/H/Jonathon Dimbleby3BA/3/1/ 3BB/3/1/ 4/4/*.*.*.*.*.*.4/4/0/0/DNO5I+2/31AA/8/4/1
/EF/1/B/3/3/1/ 2/3/1/2/6J/P/Five faces worth watching8/*.1/ *.*.1/ *.E5/1/1/ DS/
1/1/ 10B/1/1/ KK/1/1/ 4/4/*.*.*.*.*.*.1/1/0/0/DNO5I+2/31AB/8/4/1/RK/1/C/1/1/1/ 4
/3/1/2/A1/1/ 8/*.1/ *.*.1/ *.70/1/1/ 3L/3/1/ 10M/2/1/ 71/1/1/ 3/1/*.*.*.*.*.*.3/
1/1/1/ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
