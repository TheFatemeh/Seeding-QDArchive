�����@����@����@����@@@@@@@@@@@@@@@@@@@@ASCII SPSS PORT FILE                    
00000-0000-0000-0000--------------------!3#))0303300/240&),%00000000000000000000
0200002'220'&)3000#0000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrst
uvwxyz .<(+0&[]!$*);^-/|,%_>?`:#@'="000000~000000000000000000000{}\0000000000000
00000000000000000000000000000000000000000000000000000000SPSSPORTA8/200301316/120
944112/SPSS for MS WINDOWS Release 10.048/5B/70/4/IDNO5/5/0/5/5/0/CS/Unique Iden
tification Number70/5/PAPER5/1/0/5/1/0/C9/Newspaper70/7/ARTDATE40/8/0/40/8/0/CF/
Date of Article76/4/PAGE1/6/0/1/6/0/CB/Page Number70/7/ARTSIZE5/4/0/5/4/0/CF/Num
ber of Words70/6/ARTTYP5/1/0/5/1/0/CC/Article Type78A/8/HEADLINE1/8A/0/1/8A/0/C8
/Headline73A/7/AUTHNME1/3A/0/1/3A/0/CE/Name of AuthorD1/5/PAPER8/1/8/Guardian2/5
/Times3/9/Telegraph4/B/Independent5/3/Sun6/6/Mirror7/4/Mail8/7/ExpressD1/6/ARTTY
P2/1/8/Campaign2/C/Non-CampaignFB6P/1/DNL2O+2/2/01H7/1/2A/Lessons from the gospe
l of St Tony: Lessons from the gospel of St TonyK/Sketch Simon HoggartB6Q/1/DNL2
O+2/2/01LH/1/1Q/With a hymn and a touch of humility, Blair names the day10/Micha
el White Political editorBA8/1/DNL6+3/2/01Q7/1/36/Labour rejects claims of pound
s 5bn tax black hole: Campaign opens with row over public spending1I/Larry Ellio
tt, Charlotte Denny and Michael WhiteBA9/1/DNL6+3/2/01GC/1/R/Tories pledge 6p pe
trol cut13/Nicholas Watt and Patrick WintourBDH/1/DNL96+2/2/01DS/1/49/MP TORPEDO
ES PEERAGE TACTIC: MANIFESTO TO MAKE PROMISES ON HUNTING AND CRIME, BUT PARTY HI
TS TROUBLE IMPOSING STARS ON SAFE SEATSI/PETER HETHERINGTONBDP/1/DNL96+2/2/01TL/
1/4D/TAX WAR: LABOUR PLEDGES NO RISE: MANIFESTO TO MAKE PROMISES ON HUNTING AND 
CRIME, BUT PARTY HITS TROUBLE IMPOSING STARS ON SAFE SEATS13/PATRICK WINTOUR AND
 KEVIN MAGUIREBGT/1/DNLIO+2/2/01104/1/2L/Woodward scrapes in: Millbank role atta
cked as Tory defector chosen for safe seat1O/Patrick Wintour, Angelique Chrisafi
s and Kevin MaguireBK2/1/DNLM+3/2/01RK/1/44/Hague denies pounds 20bn handout: To
ry campaign honeymoon over as Labour seizes on call for Bush-style tax cutting p
rogramme11/Nicholas Watt and Michael WhiteBNG/1/DNLP6+2/2/01CF/1/12/Voters unmov
ed by Tory tax plans11/Alan Travis Home affairs editorBNH/1/DNLP6+2/2/019R/1/T/T
o the north, to grease palmsE/Ewen MacAskillBNJ/1/DNLP6+2/2/0112H/1/4F/Secret re
form agenda revealed: Push to privatise big areas of health and education: Secre
t agenda revealed on privatisation of services1F/Patrick Wintour Chief political
 correspondentBQR/1/DNLSC+2/2/01I9/1/N/Secret jail reform plan11/Alan Travis Hom
e affairs editorBQT/1/DNLSC+2/2/01NP/1/3P/Election turns ugly for Labour: Protes
ter throws an egg, Prescott throws a punch and Labour's big day is in turmoilD/K
evin MaguireC09/1/DNM1I+2/2/01NJ/1/3M/Ranks close around Prescott: Blair backs d
eputy but clash with protester set to restrict walkabouts even further11/Michael
 White and Kevin MaguireC11/1/DNM1I+2/2/01K3/1/1S/Egg-thrower a 'mild-mannered g
iant' who loves his lurchersC/Helen CarterC3J/1/DNMB6+2/2/01MR/1/1C/Majority wan
t to let in unskilled migrants11/Alan Travis Home affairs editorC6S/1/DNMEC+2/2/
01SG/1/2S/TV inciting protests - Labour: Angry BBC and ITN deny claims made in c
onfidential letter12/Patrick Wintour and Anne PerkinsC6T/1/DNMEC+2/2/01N3/1/2E/H
ague says pound could sink euro: Tory leader to play single currency card16/Mich
ael White and Jonathan FreedlandCA3/1/DNMHI+2/2/01Q9/1/2K/Blair asks French: be 
quiet on EU: Fears that speech by Jospin would help Tories1F/Patrick Wintour Chi
ef political correspondentCA4/1/DNMHI+2/2/01FF/1/3F/Thatcher says never to singl
e currency: Return of the mummy: Tory matriarch goes on stage and off messageE/E
wen MacAskillCDC/1/DNMKO+2/2/01N8/1/2B/Tory tax ploy misfires: Harmonisation of 
taxes is not on, says Brussels1J/Ian Black in Brussels and Michael White in Lond
onCEA/1/DNMKO+2/2/01F3/1/T/TUC fears for public services1F/Patrick Wintour Chief
 political correspondentCGL/1/DNMO+3/2/01N8/1/45/Sketch: Enter the minister: She
epless in Settle where the folk doubt your mettle: Brown glum-hands voters in cr
isis-hit DalesD/Simon HoggartCGM/1/DNMO+3/2/01FL/1/S/Blair defines patriotic rol
e10/Michael White Political editorCK1/1/DNN3I+2/2/01GD/1/Q/Lib Dems target top T
ories13/Lucy Ward Political correspondentCND/1/DNN6O+2/2/01MJ/1/T/Jospin rejects
 federal Europe19/Jon Henley in Paris and Patrick WintourCQL/1/DNNA+3/2/01SN/1/3
R/Tories face poll meltdown: Labour lead now at 19 points as Hague's euro campai
gn backfires: Tories face poll meltdownT/Alan Travis and Michael WhiteCQM/1/DNNA
+3/2/01R9/1/25/A noise like Omaha Beach. 'Out, out, out.' But she is out, Sketch
D/Simon HoggartD3B/1/DNNGC+2/2/01SK/1/3D/Tories: the cracks begin to show: Angry
 Patten to launch attack on strategy hours after election result1D/Michael White
, Nicholas Watt and Sarah HallD3C/1/DNNGC+2/2/01HI/1/13/Brown - our radical seco
nd term -11/Larry Elliott and Kevin MaguireD49/1/DNNGC+2/2/012B/1/J/Peerage for 
Ashdown1/ D6L/1/DNNQ+3/2/01N6/1/33/Culture and sport ministry to be broken up: C
ulture, media and sport ministry to be broken up10/Michael White Political edito
rDA1/1/DNNT6+2/2/01PT/1/32/Left plans assault on Blair: Disenchanted activists t
o urge radical direction in second term1F/Patrick Wintour Chief political corres
pondentDA2/1/DNNT6+2/2/0174/1/21/Election 2001: Tories raise fears of mass foot 
and mouth cull1D/Nicholas Watt, Paul Brown and Michael WhiteDDB/1/DNO2C+2/2/01PP
/1/34/Hague to get survival ultimatum: Leader will be told to sack aides and scr
ap hardline policies10/Michael White Political editorDDC/1/DNO2C+2/2/01L6/1/1T/H
ague to get survival ultimatum: Tories stage late recovery11/Alan Travis Home af
fairs editorDGL/1/DNO5I+2/2/01OE/1/3I/'You hold the key': Party leaders in last 
appeal to maximise vote as Labour poll lead points to big majority10/Michael Whi
te Political editorDGM/1/DNO5I+2/2/0110L/1/17/Hearty appetite - for a condemned 
manD/Matthew EngelMA3/2/DNL2O+2/2/01Q5/1/26/Blair's election war cry Labour tack
les Tories head on over Europe12/Philip Webster and Roland WatsonMA4/2/DNL2O+2/2
/01IP/1/18/And low came a demi-idol seeking votesE/Matthew ParrisMDD/2/DNL6+3/2/
01N4/1/15/Labour's lead just keeps on growingD/Peter RiddellMDE/2/DNL6+3/2/01PI/
1/1E/Blair's latest election pledges are tax freeE/Philip WebsterMGP/2/DNL96+2/2
/017K/1/18/Ben who? Bengali? I'll put you on holdD/Andrew PierceMGQ/2/DNL96+2/2/
01PO/1/14/Hague blasts pension scare tactics12/Philip Webster and Roland WatsonM
K5/2/DNLIO+2/2/01M1/1/18/Top business leaders sign up to Labour10/Philip Webster
 and Tom BaldwinMK6/2/DNLIO+2/2/01ES/1/19/Mothers will take brunt of welfare cut
s11/Roland Watson and James LandaleMNB/2/DNLM+3/2/014Q/1/16/Labour says Letwin l
eaked tax report12/Philip Webster, Political EditorMNF/2/DNLM+3/2/01NP/1/1A/Priv
ate health 'factories' to rescue NHS15/David Charter, Health CorrespondentMNI/2/
DNLM+3/2/01IA/1/1N/Call me Mr: how Blair plans to evict peers from Lords18/James
 Landale, Political CorrespondentMQL/2/DNLP6+2/2/0153/1/15/Kennedy aims for 'mor
al opposition'S/Peter Riddell and Greg HurstMQO/2/DNLP6+2/2/01MH/1/1O/Blair look
s to third term in unremitting reform pledge12/Philip Webster, Political EditorM
QP/2/DNLP6+2/2/01HB/1/Q/Loyalty beyond lip serviceD/Andrew PierceN05/2/DNLSC+2/2
/01KP/1/19/Minister floored in egg-throwing fracas1F/Roland Watson, James Landal
e and Melissa KiteN06/2/DNLSC+2/2/01NK/1/22/Blair orders the public services to 
ditch dogma and go private11/Philip Webster Political EditorN07/2/DNLSC+2/2/01G0
/1/R/Professionals desert ToriesD/Peter RiddellN3F/2/DNM1I+2/2/01J5/1/T/Prescott
 refuses to apologise1F/Philip Webster, Tom Baldwin and Roland WatsonN3G/2/DNM1I
+2/2/01KP/1/1A/'Have a go if you think yer Left enough'G/Magnus LinklaterN6Q/2/D
NMB6+2/2/01KJ/1/14/Tory grandee shatters Europe truce12/James Landale and Philip
 WebsterN6R/2/DNMB6+2/2/016Q/1/T/Portillo accuses Brown on taxE/Philip WebsterNA
3/2/DNMEC+2/2/01B3/1/R/NHS staff to get university11/Nigel Hawkes and Philip Web
sterNA4/2/DNMEC+2/2/01Q4/1/1C/Questioners browned off by slippery GordonE/Matthe
w ParrisNA5/2/DNMEC+2/2/01KJ/1/19/Labour fury at TV 'setting up' protests1F/Phil
ip Webster, Paul McCann and James LandaleNDD/2/DNMHI+2/2/01MK/1/16/Thatcher stre
tches Tory line on euro11/Philip Webster and Melissa KiteNDE/2/DNMHI+2/2/01L1/1/
1T/Blair's doorstep delivery for postal voters in target seats1A/Andrew Pierce, 
Sam Coates and Sam ListerNDF/2/DNMHI+2/2/01G9/1/T/'I'm back: the Mummy returns'D
/Ben MacintyreNGN/2/DNMKO+2/2/01T8/1/1Q/Record lead for Labour Times poll points
 to huge victoryD/Peter RiddellNGO/2/DNMKO+2/2/017G/1/1K/Brown digs at Tories wi
th Euro warning to business10/Philip Webster and Tom BaldwinNK1/2/DNMO+3/2/01M8/
1/15/Archbishops decry cynical campaignsT/Tom Baldwin and Roland WatsonNNB/2/DNN
3I+2/2/01KN/1/14/Riots put race back on poll agenda1I/Russell Jenkins, Tom Baldw
in and Dominic KennedyNNC/2/DNN3I+2/2/01G2/1/18/City chiefs call for euro 'leade
rship'T/Roland Watson and Tom BaldwinNQN/2/DNN6O+2/2/01QG/1/15/Jospin fuels Euro
pe row with Labour1J/Philip Webster, Charles Bremner and James LandaleNQO/2/DNN6
O+2/2/01I3/1/13/Select more Asians, says Thatcher1F/Andrew Pierce, Dominic Kenne
dy and Greg HurstO01/2/DNNA+3/2/01O7/1/11/Hague retreats on euro deadline12/Pete
r Riddell and Philip WebsterO3B/2/DNND6+2/2/0172/1/11/Kennedy scents success in 
polls1E/Philip Webster, Peter Riddell and Greg HurstO6L/2/DNNGC+2/2/01K3/1/14/Pe
erages for Heseltine and AshdownS/James Landale and Greg HurstO6M/2/DNNGC+2/2/01
PL/1/1B/Blair looks to business for Whitehall fixD/Peter RiddellOA1/2/DNNQ+3/2/0
1J2/1/1G/Blair in last push as Tories warn of landslide1F/Philip Webster, Tom Ba
ldwin and Roland WatsonODB/2/DNNT6+2/2/01L0/1/1B/Labour row as Brown blocks yout
h pay rise1F/Tom Baldwin, Philip Webster and James LandaleODC/2/DNNT6+2/2/019B/1
/11/WUCIWUG - LBR is on msg for UthB/Tom BaldwinOGL/2/DNO2C+2/2/01II/1/18/Brown 
vows: I am ready to be unpopular12/Philip Webster, Political EditorOGM/2/DNO2C+2
/2/0173/1/17/'Feelgood' factor set to boost Labour16/Gary Duncan, Economics Corr
espondentOK1/2/DNO5I+2/2/01NC/1/12/Blair heads for second landslide12/Peter Ridd
ell and Philip WebsterOKM/2/DNO5I+2/2/01NC/1/1O/Parties keep a weather eye on Be
ckham and the elements1/ 13DO/3/DNL2O+2/2/01IL/1/21/Surely, children of the futu
re will be adults Election sketchD/Frank Johnson13DP/3/DNL2O+2/2/01TJ/1/3K/Here 
beginneth Blair's crusade Bid for second term launched at school Hague starts el
ection fight from soapboxT/George Jones Political Editor13GR/3/DNL6+3/2/01OR/1/2
I/Tory pledge to cut 28p off a gallon Labour lead shrinks in first election poll
T/George Jones Political Editor13K7/3/DNL96+2/2/01O1/1/3L/BROWN FACES BLACK HOLE
' IN SPENDING: CHANCELLOR CHALLENGED ON MISSING POUNDS 5BN, GEORGE JONES POLITIC
AL EDITOR1/ 13NB/3/DNLIO+2/2/01ON/1/2C/Stitch-up row mars Blair's big speech Ex-
Tory is handed safe Labour seatT/George Jones Political Editor13NH/3/DNLIO+2/2/0
1KC/1/1I/We cannot cope without more officers, say police15/Philip Johnston Home
 Affairs Editor13QS/3/DNLM+3/2/01PN/1/30/Blair counters 'spin' claims Labour lea
der changes course as Mandelson criticises campaign1H/George Jones, Benedict Bro
gan and Alice Thomson1407/3/DNLP6+2/2/01OG/1/19/Police facing pay and pensions s
hake-up1G/Rachel Sylvester George Jones and Andy McSmith143D/3/DNLSC+2/2/019G/1/
14/Lowest turnout since 1874 forecastC/Anthony King143H/3/DNLSC+2/2/01RC/1/4D/Pr
escott punches a protester Labour's wobbly Wednesday: Deputy PM manhandled by cr
owd, Blair harangued on NHS, Straw jeered by police1J/George Jones Political Edi
tor and Benedict Brogan146P/3/DNM1I+2/2/0113M/1/2Q/Prescott calls in the minders
 Police inquiry into punch-up John is John, insists BlairT/George Jones Politica
l Editor146R/3/DNM1I+2/2/01FN/1/1J/We will clear up Labour's asylum mess, says H
agueC/George Jones14A7/3/DNMB6+2/2/01T2/1/2E/Blair under fire from boardrooms Te
legraph letter warns of Labour 'threat'T/George Jones Political Editor14AF/3/DNM
B6+2/2/01B1/1/15/Brown accused on national insurance1C/Andy McSmith Chief Politi
cal Correspondent14DG/3/DNMEC+2/2/01Q9/1/40/TV to blame for protests, says Labou
r Angry broadcasters reject party chief 2's claim that they 'incited' election d
emosS/George Jones and Tom Leonard14DH/3/DNMEC+2/2/0193/1/15/Top head attacks Bl
air 'false dawn'10/Liz Lightfoot and George Jones14GP/3/DNMHI+2/2/01O0/1/3T/Labo
ur wriggles over 50pc tax Brown seeks way out of National Insurance row But thre
at remains to axe limit on paymentsT/George Jones Political Editor14GQ/3/DNMHI+2
/2/01FS/1/1K/I would never give up the pound, declares Thatcher13/George Jones a
nd Rachel Sylvester14K1/3/DNMKO+2/2/015M/1/1B/Blair gets to grips with cost of l
earning19/Benedict Brogan Political Correspondent14KL/3/DNMKO+2/2/01K2/1/20/Not 
even Prescott's punch can knock out the voters' cynicismT/George Jones Political
 Editor14NB/3/DNMO+3/2/01NA/1/2D/Parties draw battle lines over Europe Blair: ba
ck euro Tories: scrap NiceT/George Jones Political Editor14QL/3/DNN3I+2/2/01B6/1
/1E/Labour sets its sights on Hague's 'weakness'19/Benedict Brogan Political Cor
respondent1501/3/DNN6O+2/2/01PE/1/2F/Jospin reveals 'superstate' plan French PM 
calls for EU economic government1I/George Jones, Benedict Brogan and Andrew Spar
row1502/3/DNN6O+2/2/01HE/1/21/There will be no turning back if we join the euro,
 says Hague14/Alice Thomson and Rachel Sylvester153B/3/DNNA+3/2/0110N/1/3N/The c
ampaign turns personal Labour unveils poster ridiculing Hague Major attacks Blai
r for 'bare-faced deception'T/George Jones Political Editor153C/3/DNNA+3/2/0144/
1/T/Adams 'can be First Minister'16/David Sharrock Ireland Correspondent156L/3/D
NND6+2/2/01F4/1/1M/Brown is planning tax on child benefit, claim ToriesT/George 
Jones Political Editor15A1/3/DNNGC+2/2/01QD/1/2J/School and health chiefs attack
 Blair Labour blamed for 'Third World' standards1H/George Jones, Sarah Womack an
d Rachel Sylvester15A2/3/DNNGC+2/2/015E/1/11/Thatcher warning over landslideC/Ge
orge Jones15DB/3/DNNQ+3/2/01101/1/2I/Blair tries to counter new Tory tactics Hag
ue stokes fears of Labour landslideT/George Jones Political Editor15DC/3/DNNQ+3/
2/01I4/1/1K/Fraud risk forces review of rules on postal voting1D/Andy McSmith, C
hief Political Correspondent15HC/3/DNNT6+2/2/0127/1/Q/Blair casts aside Lib Dems
1/ 15K1/3/DNO2C+2/2/01O3/1/45/Hague's last hurrah for Tories Forces of conservat
ism still on the march, he says Consign Thatcherism to history, Blair urgesT/Geo
rge Jones Political Editor15K2/3/DNO2C+2/2/01FF/1/4B/The butler lends a hand to 
his Labour master Defector Woodward drafts in high-class help for St Helens batt
le, reports Nigel BunyanC/NIGEL BUNYAN15NB/3/DNO5I+2/2/0110Q/1/47/It's all over 
bar the voting Final polls predict second landslide victory for Blair Tories sti
ll hope to increase number of MPsT/George Jones Political Editor15NC/3/DNO5I+2/2
/01C2/1/1T/Labour candidate comes down firmly on side of law and orderE/Sandra L
aville1EGN/4/DNL2O+2/2/01C8/1/2K/LEADING ARTICLE: ELECTION 2001: BRITAIN DESERVE
S MORE THAN STUNTS AND SOUNDBITES1/ 1EHA/4/DNL2O+2/2/01RH/1/2I/ELECTION 2001: BL
AIR'S BATTLE CRY: 'I SEEK A FRESH MANDATE FOR RADICAL CHANGE'C/Andrew Grice1EHB/
4/DNL2O+2/2/01FP/1/2G/ELECTION 2001: CHEESIER THAN A WOTSITS FACTORY (BUT IT LOO
KED A TREAT ON TV)A/Paul Waugh1EK2/4/DNL6+3/2/01DC/1/1G/BLAIR ACCUSED OF 'COVER-
UP' OVER HINDUJA LINKSG/Chris Blackhurst1EK5/4/DNL6+3/2/01RF/1/4F/ELECTION 2001:
 HAGUE PUTS TAX AT HEART OF CAMPAIGN; AS TORIES LAUNCH TAX -CUTTING MANIFESTO, L
ABOUR IS FORCED ON THE BACK FOOT OVER POUT/Andrew Grice Political Editor1ENE/4/D
NL96+2/2/01PM/1/4E/ELECTION 2001: LABOUR AND TORIES SNARED BY PLEDGES ON TAXATIO
N; BRUISING DAY FOR THE MAIN PARTIES AS THEY CHOOSE SPENDING AS THE FIRSTT/Andre
w Grice Political Editor1EQQ/4/DNLIO+2/2/0177/1/2F/LABOUR'S FIRST ELECTION BROAD
CAST: NO POLITICIANS BUT ONE FORMER SPICE GIRL15/Ben Russell Political Correspon
dent1EQR/4/DNLIO+2/2/01TK/1/1N/ELECTION 2001: MANDELSON URGES LESS SPIN, MORE VI
SIONT/Andrew Grice Political Editor1F07/4/DNLM+3/2/01NA/1/43/ELECTION 2001: NEW 
BLOW TO TORIES AS VOTERS REJECT CUTS IN TAX AND PUBLIC SPENDING; CONSERVATIVE 32
% LABOUR 46% LIB DEM 13%T/Andrew Grice Political Editor1F08/4/DNLM+3/2/01H8/1/33
/ELECTION 2001: KENNEDY PROMISES POUNDS 1,000 'HANDCUFFS' FOR NURSES TO LOCK THE
M INTO THE NHS1B/Marie Woolf Chief Political Correspondent1F3C/4/DNLP6+2/2/01DO/
1/1S/FURY OVER TORY BROADCAST THAT BLAMES LABOUR FOR RAPE CASES10/Ben Russell An
d Jason Bennetto1F3I/4/DNLP6+2/2/01N3/1/25/ELECTION 2001: BLAIR RISKS WRATH OF L
EFT IN PUBLIC SECTOR REFORMST/Andrew Grice Political Editor1F6R/4/DNLSC+2/2/01NQ
/1/14/PRESCOTT ATTACK RUINS LABOUR'S DAYT/Andrew Grice Political Editor1FA3/4/DN
M1I+2/2/01O3/1/1E/ELECTION 2001: PRESCOTT ROW DERAILS CAMPAIGN1B/Andrew Grice, P
aul Waugh And Nigel Morris1FA4/4/DNM1I+2/2/019O/1/29/ELECTION 2001: WITH FIGHT N
IGHT OVER, IT'S BACK TO KISSING WEE BABIESE/Fred Bridgland1FDE/4/DNMB6+2/2/01KT/
1/1E/TORY CUTS WILL COST POUNDS 25BN, SAYS LABOURR/Andrew Grice And Paul Waugh1F
DH/4/DNMB6+2/2/01E2/1/19/UNION CHIEF ATTACKS STRAW'S ASYLUM PLAN16/Nigel Morris 
Political Correspondent1FGR/4/DNMEC+2/2/01GL/1/1A/TORIES DRAW BLOOD OVER LABOUR 
TAX POLICYT/Andrew Grice And Nigel Morris1FK7/4/DNMHI+2/2/01J0/1/2D/ELECTION 200
1: BRAVE BILLIE WATCHES AS THE MAGUS WEAVES HER STRANGE SPELL9/Will Self1FK8/4/D
NMHI+2/2/01IO/1/1H/ELECTION 2001: BROWN RULES OUT BIG RISES IN TAXC/Andrew Grice
1FNH/4/DNMKO+2/2/01OO/1/2K/ELECTION 2001: FRUSTRATED BLAIR ACCUSES MEDIA OF IGNO
RING 'REAL ELECTION ISSUES'13/Andrew Grice And Donald Macintyre1FQL/4/DNMO+3/2/0
1LR/1/26/ELECTION 2001: VOTERS TURN AGAINST BLAIR PLANS FOR PUBLIC SERVICEST/And
rew Grice Political Editor1G01/4/DNN3I+2/2/01C2/1/1T/ELECTION 2001: LABOUR PLANS
 5AM ELECTION DAY CALL TO VOTERS15/Ben Russell Political Correspondent1G3E/4/DNN
6O+2/2/01K2/1/1H/ELECTION 2001: PRODI UNDERMINES BLAIR ON EUROPE1H/Stephen Castl
e, John Lichfield And Andrew Grice1G3F/4/DNN6O+2/2/01HB/1/1P/ELECTION 2001: LABO
UR PLANS WILL HARM NHS, WARN EXPERTS16/Nigel Morris Political Correspondent1G6L/
4/DNNA+3/2/01KD/1/2T/ELECTION 2001: TORIES BREAK RANKS OVER EUROPE; FORMER MINIS
TERS URGE HAGUE TO MAKE U-TURNT/Andrew Grice Political Editor1G6M/4/DNNA+3/2/01D
I/1/1L/ELECTION 2001: COUNTRY PROTESTERS 'TO TARGET BLAIR'1B/Marie Woolf Chief P
olitical Correspondent1GA1/4/DNND6+2/2/018S/1/2L/ELECTION 2001: BLAIRITE THINK-T
ANK WARNS AGAINST LABOUR PLANS FOR PUBLIC SERVICEST/Andrew Grice Political Edito
r1GDB/4/DNNGC+2/2/01KA/1/1N/ELECTION 2001: CLARKE ATTACKS TORY LEADER OVER EUROP
ET/Andrew Grice Political Editor1GDC/4/DNNGC+2/2/01I3/1/1I/NHS CARE TOO POOR FOR
 DOCTORS' FAMILIES FAMILIES1E/Lorna Duckworth Social Affairs Correspondent1GGL/4
/DNNQ+3/2/01N2/1/13/HAGUE ACCUSED OF SPOILING TACTICSR/Andrew Grice And Paul Wau
gh1GK1/4/DNNT6+2/2/017L/1/1J/ELECTION 2001: BROWN IMPRESSED BY COMIC'S STEALTH14
/Paul Waugh Deputy Political Editor1GK2/4/DNNT6+2/2/01FQ/1/1O/ELECTION 2001: VOT
ERS UNDETERRED BY LANDSLIDE WARNINGS1A/Andrew Grice, Paul Waugh And Ben Russell1
GNB/4/DNO2C+2/2/01JH/1/1I/ELECTION 2001: BLAIR SETS DATE FOR EURO CAMPAIGNT/Andr
ew Grice Political Editor1GP0/4/DNO5I+2/2/019J/1/1I/NEWS AT TEN IS CANCELLED DUE
 TO LACK OF INTEREST11/Louise Jury Media Correspondent1GQL/4/DNO5I+2/2/01OG/1/2F
/ELECTION 2001: THE SPIN IS SPUN, THE PUNCHES THROWN. NOW THE NATION DECIDESC/An
drew Grice1PK4/5/DNL2O+2/2/01CR/1/P/HAGUE HASN'T GOT A PRAYER1/ 1PNF/5/DNL6+3/2/
01BI/1/F/TONY SNUBS GORD12/Trevor Kavanagh Political Editor1Q6O/5/DNLP6+2/2/013E
/1/1C/BLUNKETT IS NEXT HOME SECRETARY - OFFICIAL12/Trevor Kavanagh Political Edi
tor1QA4/5/DNLSC+2/6/01, 02MO/1/8/TWO JABSK/George Pascoe-Watson1QDI/5/DNM1I+2/2/
012I/1/J/TWO BIBS V TWO JABS1E/George Pascoe-Watson Deputy Political Editor1QGO/
5/DNMB6+2/2/019J/1/S/HAGUE'S POUNDS 25BN TAX HOLEK/George Pascoe-watson1QQL/5/DN
MKO+2/2/0175/1/8/MY HAIROT/David Wooding and Jamie Pyatt1RA1/5/DNNA+3/2/01B1/1/1
8/PM WON'T BE RUSHED INTO POLL OVER EURO12/Trevor Kavanagh Political Editor1RGL/
5/DNNGC+2/2/015E/1/I/BLAIR DOES A BECKST/Nic Cecil, Political Reporter1RK1/5/DNN
Q+3/2/012A/1/R/THE TORY'S WAY OUT IN FRONTC/Mark Bowness1RNB/5/DNNT6+2/2/019R/1/
1D/HOW COME THERE'S A BIG SWING TO THE TORIES?S/Charles Rae and Mark Bowness1RQL
/5/DNO2C+2/2/019O/1/N/EXPOSED: LABOUR TV BABE14/Victoria Newton and Nicole Lampe
rt1S01/5/DNO5I+2/6/01, 08FA/1/M/DON'T LET US DOWN TONYD/David Yelland26NN/6/DNL2
O+2/2/011L/1/36/ELECTION 2001: BRIDGET HAGUE'S DIARY; WARNING: VOTING FOR HAGUE 
CAN SERIOUSLY DAMAGE YOUR HEALTH1/ 26QM/6/DNL6+3/6/01, 04B4/1/2T/ELECTION 2001: 
NATIONAL HEATH SERVICE; TED DOES NATION A FAREWELL FAVOUR BY KNIFING HAGUET/Jame
s Hardy, Political Editor273F/6/DNLIO+2/6/01, 0260/1/1B/ELECTION 2001:HAGUE'S A 
NO-HOPER SAYS DADF/Paul Gilfeather276N/6/DNLM+3/6/01, 058I/1/1E/ELECTION 2001: N
URSES CHEAP LOANS; EXCLUSIVEB/James Hardy27DM/6/DNLSC+2/2/016/1/1D/MANIFISTO: PR
ESCOTT IN AMAZING STREET BRAWL1/ 27HA/6/DNM1I+2/2/011K/1/39/FORGET ROCKY, MEET L
ABOUR'S PRIZE CHAMP.. STOCKY; (AND YES, THAT IS PREZZA, THE EAST HULL STALLION)1
/ 27K3/6/DNMB6+2/2/012M/1/25/ELECTION 2001: I'LL END EVIL ON NET; STRAW'S CHILD 
PORN CRACKDOWN12/Paul Gilfeather Whitehall Editor2809/6/DNMKO+2/2/011N/1/1J/ELEC
TION 2001: MELTDOWN; EURO ROW SHATTERS TORIEST/James Hardy, Political Editor283B
/6/DNMO+3/2/014H/1/29/ELECTION 2001: KIDS ARE VILE SAY THE TORIES; FURY OVER ELE
CTION TV AD13/Paul Gilfeather, Whitehall Editor2875/6/DNN3I+2/2/01C/1/1H/VOTE TO
RY ...AND SEE WHAT WILL HAPPEN IF YOU DO1/ 28A1/6/DNN6O+2/6/01, 0289/1/1K/ELECTI
ON 2001: ELECTION IS A BIG BOTHER; EXCLUSIVEG/Kevin O'sullivan28A2/6/DNN6O+2/6/0
1, 02D1/1/2F/ELECTION 2001: WE'VE LOST; TOP TORY ADMITS: I'VE PUT A BET ON JUNE 
7 DEFEAT12/Paul Gilfeather Whitehall Editor28DB/6/DNNA+3/6/01, 02GH/1/33/ELECTIO
N 2001: EU SILLY BILLY; TORY VODAFONE BOSS SAVAGES HAGUE - ELECTION 2001: 9 DAYS
 TO GO11/Paul Gilfeather And Suzy Jagger28K1/6/DNNGC+2/6/01, 02JO/1/2E/ELECTION 
2001: TATTY BYE TORIES; SHOCK PRO-EURO POLL TICKLES 'DODDY' BLAIRT/James Hardy, 
Political Editor28QL/6/DNNT6+2/2/01R/1/17/ELECTION 2001: PS: EXCITING ISN'T IT?1
/ 2901/6/DNO2C+2/6/01, 02DN/1/4F/ELECTION 2001: IT'S OFFICIAL, THIS ELECTION IS.
. PANTS!; AS BLAIR REVEALS HE WEARS SUPER-COOL CALVIN KLEIN UNDERWEAR,WE ASK: IS
 THIS TH1/ 293B/6/DNO5I+2/2/014/1/11/ELECTION 2001: X MARKS THE CLOT1/ 2I09/7/DN
L6+3/2/01Q3/1/2J/LABOUR REFUSES TO RULE OUT TAX INCREASES; Tax will be the elect
ion battlegroundQ/David Hughes;Graeme Wilson2I3E/7/DNL96+2/2/01S4/1/2K/VAZ IN NE
W SLEAZE ROW; Watchdog MPs order Minister's wife to hand over documentsC/David H
ughes2IDE/7/DNLP6+2/6/01, 02PP/1/39/NOW IT'S REALLY GETTING DIRTY; Shock TV from
Tories as Blair pours scorn on the Conservative centuryC/David Hughes2IGT/7/DNLS
C+2/2/0111/1/2I/On the disastrous day Labour finally met real voters...The two j
ags floor showF/picture caption2IQO/7/DNMEC+2/6/01, 04118/1/33/THE TICKING N.I. 
TIMEBOMB; Labour refuse eight times to rule out new threat to family incomesC/Da
vid Hughes2JA1/7/DNN3I+2/2/01QM/1/1G/PETROL TO RISE 30p A GALLON AFTER THE ELECT
IONA/Ray Massey2JDC/7/DNN6O+2/2/011+2/1/N/LABOUR: IT'S IN THE BAGC/David Hughes2
JH0/7/DNNA+3/2/01OT/1/2A/LABOUR REVEALS ITS NASTY STREAK; As new poll gives Blai
r a bigger leadC/David Hughes2JNB/7/DNNGC+2/2/01S9/1/4D/NHS: FANTASY AND REALITY
; Wave of condemnation as Blair puts Labour's record on health at centre stage o
f the general election battleN/David Hughes;John Deans2JQL/7/DNNQ+3/6/01, 02OJ/1
/17/FURY AS LABOUR FACES TV ATTACK ON NHSC/David Hughes2K6L/7/DNO5I+2/2/01MR/1/1
A/Blair still on for a landslide say pollsC/David Hughes2T03/8/DNL2O+2/2/01167/1
/C/BLAIR BY 25013/PATRICK O'FLYNN AND KIRSTY WALKER2TNE/8/DNM1I+2/6/01, 04NL/1/2
J/BLAIR BACKS DEPUTY OVER ELECTION PUNCH-UP; I'LL FIGHT ON, SAYS THUMPER PRESCOT
T17/ALISON LITTLE POLITICAL CORRESPONDENT30DB/8/DNN3I+2/6/01, 02HG/1/2G/ANGER AS
 OIL COMPANY BOSSES PLAN HUGE RISE; PETROL SET TO HIT GBP 4 A GALLONG/ANTHONY MI
TCHELL31A1/8/DNO5I+2/5/01,12NR/1/19/ELECTION LEADER; OUR VOTE IS TONY BLAIR1/ ZZ
