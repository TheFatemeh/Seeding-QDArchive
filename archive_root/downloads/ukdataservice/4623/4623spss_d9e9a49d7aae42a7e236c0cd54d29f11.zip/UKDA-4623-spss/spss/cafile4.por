�����@����@����@����@@@@@@@@@@@@@@@@@@@@ASCII SPSS PORT FILE                    
00000-0000-0000-0000--------------------!3#))0303300/240&),%00000000000000000000
0200002'220'&)3000#0000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrst
uvwxyz .<(+0&[]!$*);^-/|,%_>?`:#@'="000000~000000000000000000000{}\0000000000000
00000000000000000000000000000000000000000000000000000000SPSSPORTA8/200301316/121
113112/SPSS for MS WINDOWS Release 10.048/5B/70/4/IDNO5/5/0/5/5/0/CS/Unique Iden
tification Number70/5/PAPER5/1/0/5/1/0/C9/Newspaper70/7/ARTDATE40/8/0/40/8/0/CF/
Date of Article76/4/PAGE1/6/0/1/6/0/CB/Page Number70/7/ARTSIZE5/4/0/5/4/0/CF/Num
ber of Words70/6/ARTTYP5/1/0/5/1/0/CC/Article Type78A/8/HEADLINE1/8A/0/1/8A/0/C8
/Headline73A/7/AUTHNME1/3A/0/1/3A/0/CE/Name of AuthorD1/5/PAPER8/1/8/Guardian2/5
/Times3/9/Telegraph4/B/Independent5/3/Sun6/6/Mirror7/4/Mail8/7/ExpressD1/6/ARTTY
P2/1/8/Campaign2/C/Non-CampaignFDIA/1/DNO5I+2/2/01BR/2/1H/Barrymore questioned a
bout death of party guest12/Nick Hopkins Crime correspondentDF0/1/DNO2C+2/2/01MC
/2/1B/Share collapse signals Railtrack break-upQ/Keith Harper and Neil HumeDBL/1
/DNNT6+2/2/01AN/2/10/Biggs's condition deterioratesE/Jeevan VasagarDBK/1/DNNT6+2
/2/01R5/2/4I/Disbelief and rage as new king is crowned: Prince's pyre: Heir to t
he throne is cremated after Nepalese capital is closed off amid rioting1F/Bhagir
ath Yogi in Kathmandu and Rory McCarthyD8A/1/DNNQ+3/2/01TP/2/2F/US raises crime 
fears in Ashcroft tax haven: US fears in Ashcroft tax haven1E/Rob Evans, David H
encke, and David PallisterD8B/1/DNNQ+3/2/01KJ/2/3J/Israeli forces await order to
 act: The face of the 22-year-old suicide bomber who killed 19 Jewish youngsters
10/Suzanne Goldenberg in Tel AvivD8C/1/DNNQ+3/2/019P/2/16/Massacre in Nepal blam
ed on accident1G/Rory McCarthy in Islamabad and AP in KathmanduD51/1/DNNGC+2/2/0
1HD/2/17/McVeigh appeals for stay of executionR/Julian Borger in WashingtonD1N/1
/DNND6+2/2/01CO/2/1M/Ministers call for cut in price of third world drugs11/Mich
ael White and Larry ElliottD1M/1/DNND6+2/2/01JF/2/18/Number's up for Murdoch/Pac
ker venture1D/Patrick Barkham in Sydney and David TeatherD1K/1/DNND6+2/2/01GS/2/
35/Archer trial opens with bribe claim: Peer accused of paying friend to lie ove
r prostitute storyA/Paul KelsoD1L/1/DNND6+2/2/01PN/2/15/Post Office services to 
be sold off1F/Patrick Wintour Chief political correspondentCSA/1/DNNA+3/2/01HS/2
/1H/Plot to oust Mugabe dismays Zimbabwe opposition1K/Andrew Meldrum in Harare a
nd Richard Norton-TaylorCP1/1/DNN6O+2/2/01O1/2/13/White extremists to blame - Bl
air11/Michael White and Polly ToynbeeCP0/1/DNN6O+2/2/0111B/2/3J/Mugabe faces cou
p plot: Secret warning from military that it will overthrow president if civil u
nrest worsensM/Hugo Young in PretoriaCLK/1/DNN3I+2/2/01OS/2/2P/Racial tension bl
amed for riot: Hundreds fight police in battles on streets of OldhamS/David Ward
 and Nicholas WattCLL/1/DNN3I+2/2/01DM/2/24/Heard the one about the archbishop a
nd the Moonie acupuncturist?K/Rory Carroll in RomeCIB/1/DNMO+3/2/018I/2/16/RSC a
bandons its roots to lure stars14/Fiachra Gibbons Arts correspondentCIA/1/DNMO+3
/2/01OS/2/1E/Deficit of pounds 6bn sparks new rail crisisT/Keith Harper Transpor
t editorCF0/1/DNMKO+2/2/01PB/2/4H/Palestinian lecturer held after trip to UK: Sh
ort launches inquiry as Israel refuses access to lawyer: Lecturer arrested after
 trip to UK11/Suzanne Goldenberg in JerusalemCF1/1/DNMKO+2/2/017Q/2/15/Cricket r
ocked by corruption report16/Vivek Chaudhary Sports correspondentCBK/1/DNMHI+2/2
/01135/2/1F/Top officers condemned over fatal police raidS/Nick Hopkins and Nick
 DaviesC8A/1/DNMEC+2/2/01LG/2/1E/US brokers new round of talks in Middle East1S/
Julian Borger in Washington and Jane Martinson in New YorkC51/1/DNMB6+2/2/011BE/
2/1A/Loathing thy neighbour in the Gaza Strip16/Suzanne Goldenberg in the Gaza S
tripC50/1/DNMB6+2/2/01MT/2/38/Heading for disaster; Cheney Warns Israel ; Sharon
 Threatens All-out Force ; Tanks Continue Firing17/Suzanne Goldenberg and Brian 
WhitakerC1K/1/DNM1I+2/2/01KL/2/33/Railtrack fails to meet deadline on speed curb
s: Railtrack fails to meet speed curbs deadlineT/Keith Harper Transport editorBS
A/1/DNLSC+2/2/019G/2/1L/World's smallest baby weighs in at just 604 grammesR/Sar
ah Boseley Health editorBP0/1/DNLP6+2/2/01GF/2/1A/So, do you find these posters 
offensive?10/Clare Dyer Legal correspondentBLK/1/DNLM+3/2/01EK/2/O/Millions for 
new BT boss10/David Teather and Jill TreanorBLL/1/DNLM+3/2/01JM/2/Q/Berlusconi s
avours victory1G/Rory Carroll in Rome and Ian Black in BrusselsBIC/1/DNLIO+2/2/0
15N/2/18/Berlusconi ahead in Italian exit pollsK/Rory Carroll in RomeBIA/1/DNLIO
+2/2/01II/2/15/City secrets held by PR firm leakedS/Paul Murphy Financial editor
BIB/1/DNLIO+2/2/01188/2/15/A friend's lament for Douglas AdamsF/Richard DawkinsB
F0/1/DNL96+2/2/01BK/2/1N/Prince's Trust turned down Hinduja cash on MI5 advice18
/David Hencke Westminster correspondentBF1/1/DNL96+2/2/01C0/2/1H/BBC's Oscar-nig
ht star stunned by lower billing10/Matt Wells Media correspondentBBK/1/DNL6+3/2/
01173/2/1K/Israel vows revenge after boys are stoned to deathR/Ewen MacAskill in
 JerusalemB8A/1/DNL2O+2/2/017J/2/1C/Dando trial told of gun particle discovery12
/Nick Hopkins Crime correspondentB8B/1/DNL2O+2/2/015P/2/P/Trimble threatens to q
uit1/ MBK/2/DNL2O+2/2/0186/2/1D/Dogs can join the club to watch tail-endersB/Ivo
 TennantMF0/2/DNL6+3/2/0182/2/S/Kidman puts on carefree show1S/Dalya Alberge in 
Cannes and Grace Bradberry in Los AngelesMF1/2/DNL6+3/2/01CA/2/17/How alcohol ma
kes the heart go longerC/Nigel HawkesMIA/2/DNL96+2/2/01CA/2/1A/Mystery disease k
ills thoroughbred foalsT/Martin Fletcher in WashingtonMIB/2/DNL96+2/2/01IC/2/11/
Officer confirms farm suspicionR/Tim Reid and Andrew NorfolkMLK/2/DNLIO+2/2/0185
/2/19/University goal won't be met until 201010/John O'Leary, Education EditorML
L/2/DNLIO+2/2/01AG/2/13/Charity false start dismays LewisE/Andrew NorfolkMLM/2/D
NLIO+2/2/012F/2/J/Berlusconi comebackK/Richard Owen in RomeMLN/2/DNLIO+2/2/019K/
2/13/New executives lead with the chinP/James Bone and Laura PeekMP1/2/DNLM+3/2/
01KK/2/1H/Divorce law confusion as ex-wife wins Pounds 4mS/Helen Studd and Franc
es GibbMP2/2/DNLM+3/2/015B/2/14/All ports alert for striped menace15/Valerie Ell
iott, Countryside EditorMP0/2/DNLM+3/2/019A/2/16/Berlusconi ready for return to 
powerC/Richard OwenMSA/2/DNLP6+2/2/01IF/2/18/Chemists at risk as prices are slas
hedR/Nigel Hawkes, Health EditorN1K/2/DNLSC+2/2/01DD/2/19/Former royal aide give
n life for murderG/Michael HorsnellMSB/2/DNLP6+2/2/017E/2/12/Bullied veteran han
gs in 'shame'B/Helen StuddN50/2/DNM1I+2/2/0184/2/1B/Police find body parts in hu
nt for priestE/Andrew NorfolkN51/2/DNM1I+2/2/01DS/2/23/Consumer chaos looms as f
irms predict drastic shortage of eurosS/Gary Duncan and Sally PattenN52/2/DNM1I+
2/2/013C/2/J/Cambridge top againC/John O'LearyN8A/2/DNMB6+2/2/0154/2/1C/Triumpha
nt Liverpool given heroes' welcomeF/Russell JenkinsN8B/2/DNMB6+2/2/01G0/2/1D/Top
 judge gives medical claimants a wiggingC/Frances GibbN8C/2/DNMB6+2/2/01F2/2/1S/
This is your stewardess speaking. Er, where are we going?,D/David CharterNBK/2/D
NMEC+2/2/0184/2/1E/Flowers bring out Princess after four monthsD/Alan HamiltonNB
L/2/DNMEC+2/2/01B0/2/18/Freeze-frame juror frees video accusedB/Joanna BaleNF0/2
/DNMHI+2/2/018O/2/1J/T-shirts, mugs and Diana trinkets to rescue Abbey12/Fran Li
ttlewood and Adam SherwinNF1/2/DNMHI+2/2/016E/2/16/Hindus must wear badge, says 
Taleban1/ NIA/2/DNMKO+2/2/01G4/2/1H/Prince is dismayed by RSPCA's Pounds 2,000 g
iftD/Andrew PierceNIB/2/DNMKO+2/2/01BC/2/1L/Wildcat strike halts mail deliveries
 across Britain15/Christine Buckley Industrial EditorNIC/2/DNMKO+2/2/01DO/2/S/Br
ibes that buy exam success13/Glen Owen Education CorrespondentNLK/2/DNMO+3/2/01I
F/2/14/Unions force private deals retreat15/Tom Baldwin Deputy Political EditorN
LL/2/DNMO+3/2/01A4/2/19/Thousands die in need of intensive careQ/Nigel Hawkes He
alth EditorNLM/2/DNMO+3/2/01DG/2/1F/Zebedee will tell clubbers: It's time for be
dT/Oliver Wright and Joanna BaleNP0/2/DNN3I+2/2/01KN/2/14/Riots put race back on
 poll agenda1I/Russell Jenkins, Tom Baldwin and Dominic KennedyNP1/2/DNN3I+2/2/0
17A/2/T/Crowd attacks Aylesbury houseC/Helen DanielNP2/2/DNN3I+2/2/018I/2/10/Dam
ilola report for prosecutorF/Stewart TendlerNP3/2/DNN3I+2/2/018P/2/S/War-torn zo
o is now a jungleO/Stephen Farrell in KabulNSA/2/DNN6O+2/2/018E/2/1B/Clinton def
eats jitters at the Old Course8/Tim ReidNSB/2/DNN6O+2/2/01BR/2/1B/Legal bust-up 
over a second front for art10/Grace Bradberry in Los AngelesO1M/2/DNNA+3/2/01I2/
2/1Q/Private sector in secret talks over care for the elderly15/David Charter, H
ealth CorrespondentO1K/2/DNNA+3/2/018A/2/S/Race violence feared at Test14/Russel
l Jenkins and Richard HobsonO1L/2/DNNA+3/2/018F/2/11/Hot heads find way to chill
 out18/Gillian Harris, Scotland CorrespondentO50/2/DNND6+2/2/01QB/2/Q/Lord Arche
r 'lied on oath'8/Tim ReidO51/2/DNND6+2/2/01G8/2/18/Roland Dumas jailed in bribe
ry scandalO/Charles Bremner in ParisO52/2/DNND6+2/2/017G/2/1G/Bush's daughter ca
ught out by drink laws againT/Martin Fletcher in WashingtonO53/2/DNND6+2/2/01L3/
2/14/An author riveted by his own drama12/Matthew Parris at the Old BaileyO8A/2/
DNNGC+2/2/01IF/2/1N/Britons face 500 lashes for defying Saudi alcohol law14/Dani
el McGrory and Elizabeth JudgeO8B/2/DNNGC+2/2/014I/2/11/'Feelgood' consumers on 
a spree1/ OBL/2/DNNQ+3/2/01OS/2/Q/Second fatal crash at showQ/Helen Studd and Jo
hn NaishOBK/2/DNNQ+3/2/0182/2/16/Dance ends for Quinn, for ever Zorba10/Grace Br
adberry in Los AngelesOBM/2/DNNQ+3/2/01RF/2/17/Palace recasts royal gunman as vi
ctimS/Stephen Farrell in KathmanduOBN/2/DNNQ+3/2/011P/2/11/World pressure mounts
 on Arafat1/ OF1/2/DNNT6+2/2/018G/2/Q/New king strives for unityS/Stephen Farrel
l in KathmanduOF0/2/DNNT6+2/2/01AF/2/11/Archer aide feared diary deceitE/Andrew 
NorfolkOIA/2/DNO2C+2/2/01SI/2/2D/The prince told his nephew 'Put the gun down. Y
ou've done enough damage.'S/Stephen Farrell in KathmanduOIB/2/DNO2C+2/2/01JI/2/1
9/Archer's picnic hamper of blank cheques8/Tim ReidOID/2/DNO2C+2/2/0115/2/P/Rail
track hits record low1/ OIC/2/DNO2C+2/2/019N/2/1B/Portrait of the artist as a yo
ung peacockN/Dalya Alberge in VeniceOLO/2/DNO5I+2/2/01D7/2/1D/Danger! don't get 
too cosy with that teapot17/Mark Henderson, Science CorrespondentOLN/2/DNO5I+2/2
/012J/2/M/Barrymore drugs arrest1/ OLM/2/DNO5I+2/2/01BS/2/15/Secret test for Alz
heimer's vaccineR/Nigel Hawkes, Health EditorOLK/2/DNO5I+2/2/0178/2/R/Pound slum
ps against dollar10/Lea Paterson, Economics Editor15P0/3/DNO5I+2/2/0180/2/1Q/Ala
s poor pupils . . . The Tempest, that is the questionE/Richard Savill15P1/3/DNO5
I+2/2/012H/2/N/Sterling at 15 year low1/ 15LL/3/DNO2C+2/2/01IE/2/11/Damages for 
sex therapy wardersC/Sean O'Neill15LK/3/DNO2C+2/2/01GC/2/12/One in four GP refer
rals 'wrong'P/Celia Hall Medical Editor15IA/3/DNNT6+2/2/01MK/2/3A/Waiting lists 
are fiddled - official NHS trusts 'massage' figures to meet targets, says Audit 
OfficeP/Celia Hall Medical Editor15ID/3/DNNT6+2/2/019Q/2/1G/No-ball row as Engla
nd collapse to Test defeatE/Thomas Harding15IC/3/DNNT6+2/2/01DC/2/19/Private sch
ools look to drop GCSE exams17/Liz Lightfoot Education Correspondent15IB/3/DNNT6
+2/2/01CP/2/1L/Riots as new king pledges to find truth of massacre1B/Alex Spilli
us and Rahul Bedi in Kathmandu15F2/3/DNNQ+3/2/01AI/2/1H/Lewis fans angry at Narn
ia without ChristianityQ/Toby Harnden in Washington15F1/3/DNNQ+3/2/0198/2/11/Man
, 72, is held over hate mailF/Nicola Woolcock15F0/3/DNNQ+3/2/01D2/2/1J/Nepal is 
left in turmoil as massacre story denied1B/Alex Spillius and Rahul Bedi in Kathm
andu15BM/3/DNNGC+2/2/019M/2/18/Bankers get pounds 14,000 for gap year13/Helen Du
nne Associate City Editor15BL/3/DNNGC+2/2/01KO/2/1K/Stoppard tears strips off 's
elf-indulgent' artists13/Nigel Reynolds Arts Correspondent15BK/3/DNNGC+2/2/01TN/
2/R/Archer 'set up bogus diary'11/Sue Clough Courts Correspondent158A/3/DNND6+2/
2/01KO/2/2T/Lord Archer 'paid pounds 20,000 for false alibi' Novelist denies lyi
ng to sex libel trial11/Sue Clough Courts Correspondent158C/3/DNND6+2/2/019G/2/1
D/Land Rover's 8,000 workforce 'to be halved'E/Thomas Harding158B/3/DNND6+2/2/01
AA/2/1A/Bush twins accused of breaking drink lawO/Ben Fenton in Washington1552/3
/DNNA+3/2/0195/2/17/Human bells are music to brides' earsE/Richard Savill1551/3/
DNNA+3/2/01CF/2/1G/House prices still rising as people live aloneQ/David Litteri
ck City Staff1550/3/DNNA+3/2/01R6/2/1P/Children of violent parents must be expel
led, say heads17/Liz Lightfoot Education Correspondent151L/3/DNN6O+2/2/01E6/2/O/
Body found near BluebirdC/David Graves151K/3/DNN6O+2/2/015K/2/18/After the freez
e: an eagle called ThorC/Auslan Cramb14SA/3/DNN3I+2/2/01SH/2/46/Race riot town o
n a knife-edge Police face renewed street clashes Worst ethnic violence in 15 ye
ars Row over 'smear' on Tories11/Nigel Bunyan and Andrew Sparrow14SC/3/DNN3I+2/2
/01A4/2/1B/Big bottoms come out tops for good healthE/Tara Womersley14SB/3/DNN3I
+2/2/0192/2/11/Warders held in helicopter raidT/Harry de Quetteville in Paris14P
4/3/DNMO+3/2/019N/2/1F/Hundreds trapped after wedding hall collapsesO/Alan Philp
s in Jerusalem14P2/3/DNMO+3/2/01FT/2/15/Train delays will last another year16/Pa
ul Marston Transport Correspondent14P1/3/DNMO+3/2/01BK/2/12/Anti-hunting MP outf
oxed by hunt14/Maurice Weaver and Charlie Methven14P0/3/DNMO+3/2/01NH/2/1Q/Lawye
r jailed for murdering her babies is not struck offT/Joshua Rozenberg Legal Edit
or14LL/3/DNMKO+2/2/01I7/2/17/Millions of letters delayed by strikeE/Thomas Hardi
ng14LM/3/DNMKO+2/2/01FM/2/1A/Cricket cheating claims 'tip of iceberg'C/David Gra
ves14LK/3/DNMKO+2/2/01HC/2/1K/Chaotic, poor and stupid: a German view of Britain
J/Toby Helm in Berlin14IB/3/DNMHI+2/2/01BF/2/13/All-singing seats for Opera Hous
eF/Norman Lebrecht14IA/3/DNMHI+2/2/01KH/2/13/Police cleared on bedroom killing11
/John Steele Crime Correspondent14F2/3/DNMEC+2/2/019T/2/1I/Celebrity caesareans 
set bad example, say nursesD/Nicole Martin14F1/3/DNMEC+2/2/018R/2/13/England cri
cket fixing 'in 1970s'R/Mihir Bose and Thomas Penny14F0/3/DNMEC+2/2/01GM/2/1I/1,
000 farms in hotspot face foot and mouth curbs10/David Brown Agriculture Editor1
4BM/3/DNMB6+2/2/01AM/2/1I/The great driver gender dispute takes to the air18/Dav
id Derbyshire Science Correspondent14BL/3/DNMB6+2/2/018Q/2/S/England sweep Pakis
tan asideH/Michael Henderson14BK/3/DNMB6+2/2/01L8/2/1D/Two British women get lif
e over Dubai drugsE/Sandra Laville148B/3/DNM1I+2/2/0185/2/T/Wind of change chill
s EnglandC/Thomas Penny148A/3/DNM1I+2/2/017S/2/12/First day with no foot and mou
th10/David Brown Agriculture Editor1450/3/DNLSC+2/2/01PD/2/13/Duchess's dresser 
jailed for life11/Sue Clough Courts Correspondent141K/3/DNLP6+2/2/01N4/2/1B/Medi
cine prices slashed as legal row ends14/Thomas Penny and Rosie Murray-West141M/3
/DNLP6+2/2/018G/2/16/EU's big message to stub out smoking17/Ambrose Evans-Pritch
ard in Strasbourg141L/3/DNLP6+2/2/01AO/2/1A/Bush gets tough with ban on the Real
 IRAQ/Toby Harnden in Washington13SB/3/DNLM+3/2/01F7/2/11/Euro could cause chaos
, EU told15/Ambrose Evans-Pritchard in Brussels13SC/3/DNLM+3/2/01GK/2/1M/Mother'
s plea as husband kills mentally ill daughterD/David Sapsted13SD/3/DNLM+3/2/014S
/2/10/Father of 5 charged over RosieE/Sandra Laville13SA/3/DNLM+3/2/018K/2/11/Fo
otsie plunges on single trade15/Simon English Banking Correspondent13P2/3/DNLIO+
2/2/0174/2/1N/Zeta Jones tackles rugby in her debut as a film-makerO/Nigel Reyno
lds in Cannes13P1/3/DNLIO+2/2/019M/2/1H/Berlusconi's coalition 'on way to poll v
ictory'1D/Anton La Guardia and Bruce Johnston in Rome13P0/3/DNLIO+2/2/01EK/2/20/
Stranger stabs girl to death as she sunbathes in city centreE/Adrian Addison13LN
/3/DNL96+2/2/01AL/2/1H/Blood clots may affect one in 10 air travellers18/David D
erbyshire Science Correspondent13LM/3/DNL96+2/2/01HE/2/1J/Minister 'lied' over p
lan to merge Scots brigades15/Michael Smith Defence Correspondent13LL/3/DNL96+2/
2/0173/2/T/Couple's joy as herd is savedE/Richard Savill13LK/3/DNL96+2/2/01HA/2/
41/I'm not scared of you, sonny What the 5ft 6in judge said to the violent robbe
r who leapt over the dock and threatened him11/Maurice Weaver and Thomas Penny13
IC/3/DNL6+3/2/019D/2/18/Milk 'is good for the heart after all'P/Celia Hall Medic
al Editor13IB/3/DNL6+3/2/0196/2/11/Two Jewish boys killed by rocksN/Ohad Gozani 
in Tel Aviv13IA/3/DNL6+3/2/01H8/2/1I/Worshippers may be able to nominate their b
ishop17/Victoria Combe Religion Correspondent13F1/3/DNL2O+2/2/01HL/2/17/Scots 't
ried to set up Nazi alliance'15/Michael Smith Defence Correspondent13F0/3/DNL2O+
2/2/018R/2/13/30 infants in TB scare at nursery10/Celia Hall and Richard Alleyne
1GSB/4/DNO5I+2/2/019H/2/1I/TRAIN FIRMS DEMAND NEW ROLE RUNNING RAIL NETWORK15/Ba
rrie Clement And Michael Harrison1GSA/4/DNO5I+2/2/01AM/2/1M/BARRYMORE IS ARRESTE
D BY POLICE INVESTIGATING MURDERE/Jason Bennetto1GP1/4/DNO2C+2/2/01H6/2/2C/TELFO
RD HANGING: 'EVIDENCE MAY HAVE BEEN CONTAMINATED BY POLICE SURGEON'18/Ian Burrel
l Home Affairs Correspondent1GP2/4/DNO2C+2/2/01I6/2/2G/RAILTRACK CRISIS AFTER SH
ARES PLUNGE ON WARNING THAT THEY MAY BE 'WORTHLESS'12/Michael Harrison Business 
Editor1GLL/4/DNNT6+2/2/01AI/2/1J/NEW NEPALESE KING PLEDGES TO INVESTIGATE MASSAC
REP/Peter Popham In Kathmandu1GLK/4/DNNT6+2/2/01J0/2/1T/TELFORD: CORONER TELLS J
URY OF 'HORRIFIC' RACIAL HARASSMENT18/Ian Burrell Home Affairs Correspondent1GIC
/4/DNNQ+3/2/01AN/2/1R/'SUPERB, GREAT, UNBELIEVABLE' ... AND THAT WAS THE CRITIC1
0/David Usborne In San Francisco1GIB/4/DNNQ+3/2/01CD/2/1K/POST WORKERS THREATEN 
NEW WAVE OF NATIONAL STRIKES11/Barrie Clement Transport Editor1GIA/4/DNNQ+3/2/01
59/2/1N/GUN MASSACRE OF ROYAL FAMILY WAS CAUSED BY 'ACCIDENT'1A/Daniel Lak In Ka
thmandu And Peter Popham1GF1/4/DNNGC+2/2/017S/2/18/THE SECRET OF LIFE: THERE IS 
NO SECRETD/Matthew Beard1GF0/4/DNNGC+2/2/0198/2/1M/ARCHER'S SECRETARY 'COPIED DI
ARY SHE FORGED FOR HIM'C/Kim Sengupta1GBK/4/DNND6+2/2/01S3/2/29/ARCHER APPEARS I
N A NEW COURTROOM DRAMA, ACCUSED OF MAKING UP STORIESC/Kim Sengupta1GBL/4/DNND6+
2/2/018P/2/1R/FRANCE JAILS CORRUPT MINISTER AND 'WHORE OF THE REPUBLIC'N/John Li
chfield In Paris1G8A/4/DNNA+3/2/019B/2/1P/OUTSIDE INFILTRATORS BLAMED FOR STOKIN
G OLDHAM VIOLENCE1C/Ian Herbert North Of England Correspondent1G8B/4/DNNA+3/2/01
9E/2/1O/ASHES GO COAST TO COAST ON HOLIDAY OF AN AFTERLIFETIMEC/Steve Boggan1G51
/4/DNN6O+2/2/0163/2/T/BODY FOUND AT 'BLUEBIRD' SITEC/Paul Peachey1G50/4/DNN6O+2/
2/01FS/2/1T/WOOLF CALLS FOR NEW COURT TO RESOLVE ENVIRONMENTAL DISPUTES1C/Robert
 Verkaik Legal Affairs Correspondent1G1M/4/DNN3I+2/2/019N/2/17/ST KILDA CALLS TI
ME ON UNLICENSED BARC/Steve Boggan1G1L/4/DNN3I+2/2/01BJ/2/1N/HEADTEACHERS IN WOR
LDWIDE RECRUITMENT DRIVE FOR STAFF11/Richard Garner Education Editor1G1K/4/DNN3I
+2/2/01L1/2/13/BITTER RACE ROW AFTER OLDHAM RIOTS/Andrew Grice And Ian Herbert1F
SC/4/DNMO+3/2/018K/2/1A/'MET: THE MOVIE'- A REAL TRAFFIC-STOPPER18/Ian Burrell H
ome Affairs Correspondent1FSA/4/DNMO+3/2/01C9/2/1L/DEFECTION OF ROGUE SENATOR RO
CKS BUSH ADMINSTRATIONR/Mary Dejevsky In Washington1FSB/4/DNMO+3/2/01F2/2/22/RAI
LTRACK SAYS POUNDS 3.6BN 'BLACK HOLE' COULD MAKE IT GO BUST12/Michael Harrison B
usiness Editor1FP1/4/DNMKO+2/2/01A9/2/1Q/ITV PLANS AN EARLY SLOT FOR SATURDAY'S 
SNATCH OF THE DAY17/David Lister Media And Culture Editor1FP0/4/DNMKO+2/2/01FF/2
/2A/THREAT OF NATIONAL POSTAL STRIKE AS WILDCAT ACTION CRIPPLES DELIVERIESB/Caha
l Milmo1FLK/4/DNMHI+2/2/01D4/2/22/CHIEF CONSTABLE 'FAILED TO TELL THE TRUTH' OVE
R FATAL SHOOTINGQ/Ian Burrell And Chris Gray1FLL/4/DNMHI+2/2/01AH/2/1C/TALIBAN T
ELLS HINDUS TO WEAR SPECIAL SIGNSF/Rupert Cornwell1G3B/4/DNMEC+2/2/019H/2/1S/US 
PEACE PLAN CONDEMNED AS 'A GREEN LIGHT FOR SETTLEMENTS'1Q/Phil Reeves In Jerusal
em And Mary Dejevsky In Washington1FIA/4/DNMEC+2/2/01IK/2/34/SHOCK AT GROWING NU
MBER OF FOREIGN NURSES; MORE COMING FROM ABROAD THAN ARE TRAINED IN BRITAIN1E/Lo
rna Duckworth Social Affairs Correspondent1FIC/4/DNMEC+2/2/01E4/2/15/LUNG CANCER
 RISK 'DOUBLE FOR WOMEN'15/Michael Durham Health Correspondent1FF2/4/DNMB6+2/2/0
1II/2/1E/SHARON IGNORES US REBUKE AS CRISIS ESCALATES1S/Andrew Buncombe In Washi
ngton And Eric Silver In Jerusalem1FF0/4/DNMB6+2/2/017T/2/1B/GOUGH AND CADDICK B
OWL ENGLAND TO VICTORYB/Chris Maume1FBK/4/DNM1I+2/2/01A3/2/1L/RAILTRACK MISSES D
EADLINE AS 700 SPEED CURBS REMAIN11/Barrie Clement Transport Editor1FBL/4/DNM1I+
2/2/018P/2/1L/RU READY 4 THE LATEST EU IDEA? SNOOPING ON TXT MSGS13/Robert Verka
ik And Stephen Castle1F8B/4/DNLSC+2/2/015T/2/1C/WHY ASTHMATICS DREAD THOSE DAYS 
OF THUNDERE/Michael Durham1F8B/4/DNLSC+2/2/017I/2/18/HEADS CALL FOR END OF 'OUTD
ATED' GCSES11/Richard Garner Education Editor1F8A/4/DNLSC+2/2/01DQ/2/1A/POLICE A
CCUSED OF 'INSTITUTIONAL SEXISM'1C/Robert Verkaik Legal Affairs Correspondent1F5
0/4/DNLP6+2/2/01AR/2/1M/GADDAFI 'HAS ADMITTED' HIS ROLE IN LOCKERBIE BOMBING18/I
mre Karacs In Berlin And Kim Sengupta1F51/4/DNLP6+2/2/018F/2/1Q/'SUNDAY MIRROR' 
WILL FACE CONTEMPT CASE OVER LEEDS TRIAL18/Ian Burrell Home Affairs Corresponden
t1F1K/4/DNLM+3/2/01CD/2/1A/FBI ENDED MCVEIGH GANG HUNT WITHIN WEEKSS/Andrew Gumb
el In Los Angeles1ESA/4/DNLIO+2/2/01F2/2/32/MEDIA TYCOON BERLUSCONI CONFIDENT OF
 VICTORY DESPITE LAST-MINUTE SURGE FOR CENTRE-LEFT RIVALO/Frances Kennedy In Ita
ly1ESB/4/DNLIO+2/2/01B9/2/1L/COURT WILL BE ASKED TO PUT LIMITS ON HOUSEHOLD PETS
1C/Robert Verkaik Legal Affairs Correspondent1EP2/4/DNL96+2/2/017B/2/1K/RUPERT M
URDOCH TO BECOME FATHER AGAIN AT AGE OF 70P/David Usborne In New York1EP1/4/DNL9
6+2/2/0172/2/20/BT CHIEF'S BONUS OF POUNDS 1.5M FOR TAKING FIRM TO THE BRINK12/M
ichael Harrison Business Editor1EP0/4/DNL96+2/2/01HK/2/1H/MCVEIGH 'DID NOT ACT A
LONE IN OKLAHOMA BOMBING'17/Andrew Gumbel In Terre Haute, Indiana1ELK/4/DNL6+3/2
/01C9/2/1I/BOYS PLAYING TRUANT STONED TO DEATH ON WEST BANK11/Phil Reeves In Tek
oa, West Bank1PP0/5/DNL6+3/2/01E4/2/R/ENDERS ROBBIE BEATEN BY JOB1I/Victoria New
ton, Showbiz Editor, and Derek Brown1PSA/5/DNL96+2/2/0110E/2/10/LOWEST HOME LOAN
S FOR 40 YEARSK/George Pascoe-Watson1PSB/5/DNL96+2/2/011S/2/R/DANDO JURY SEE MUR
DER SCENEB/Ian Hepburn1Q1K/5/DNLIO+2/2/016T/2/I/8 KIDS FROM 6 DADSA/John Coles1Q
50/5/DNLM+3/2/016E/2/S/ONE WINNER SCOOPS POUNDS 20MC/Paul Crosbie1QIA/5/DNMB6+2/
2/01CM/2/17/LOTTERY WINNER'S POUNDS 50,000 NICKEDA/John Scott1QLL/5/DNMEC+2/2/01
3P/2/17/SURVIVOR NASTY NICK IS FIRST OFF ISLEE/Giovanna Iozzi1QLK/5/DNMEC+2/2/01
26/2/T/ANGEL OF DEATH TO WED VAMPIREF/Alastair Taylor1QP0/5/DNMHI+2/2/01L5/2/M/E
XECUTED BY THE POLICEP/Neil Syson and John Scott1QSA/5/DNMKO+2/2/01CG/2/T/30P PU
NTER SCOOPS POUNDS 1/2MB/Nick Parker1R1K/5/DNMO+3/2/0123/2/T/30P BET WON ME POUN
DS 500,000D/Andrew Parker1R50/5/DNN3I+2/2/013T/2/27/HE'S THE PITS: F1 ACE COULTH
ARD CRASHED CAR THEN LEFT GIRL IN LURCHD/Richie Taylor1R8A/5/DNN6O+2/2/011P/2/10
/HOSPITAL CLEANER SNATCHES BABYE/Martin Wallace1RBK/5/DNNA+3/2/013G/2/K/CHARLOTT
E THE HARLOTE/Victor Chapple1RF0/5/DNND6+2/2/014A/2/12/CAPTAIN'S SEXY PIC FOR HE
R MAJOR8/John Kay1RIA/5/DNNGC+2/2/013D/2/L/ARCHER AIDE BOMBSHELLD/Mike Sullivan1
S1K/5/DNO5I+2/2/012B/2/P/BARRYMORE IN MURDER PROBE1/ 28SA/6/DNNT6+2/2/0134/2/2M/
HELLO CAMPER!; JOSH: IF YOU THINK BRIAN IS A BIT CAMP .. JUST WAIT TILL YOU SEE 
MEE/Nicola Methven28P0/6/DNNQ+3/6/01, 05AA/2/4I/BARRYMORE: THE FACTS; POOL VICTI
M HAD SEX WITH THREE MEN - DEAD MAN SUFFERED SERIOUS SEXUAL INJURIES - COKE, ECS
TASY AND DRINK FOUND IN HI11/Aidan Mcgurran And Jeff Edwards28IA/6/DNND6+2/2/01G
L/2/1O/THE BIG 'LIE'; ARCHER FAKED ALIBI AND DIARY, JURY TOLDQ/Harry Arnold And 
Lucy Rock28IB/6/DNND6+2/6/01, 085N/2/1R/BIG BROTHER COKE CONFESSION: I'M FOREVER
 SNORTING -BUBBLEC/Jon Clements2850/6/DNMO+3/6/01, 04CB/2/1N/MARRIED CHARLOTTE H
AS SECRET FLING ON SURVIVOR ISLAND9/Jane Kerr281K/6/DNMKO+2/2/0117/2/12/DAY TWO:
 JORDAN TELLS ALL TO 3AM1/ 27SA/6/DNMHI+2/2/0173/2/1T/COP-OUT; FURY AS POLICE WA
LK FREE AFTER INNOCENT MAN KILLEDB/Adrian Shaw27P0/6/DNMEC+2/2/016D/2/1J/SURVIVO
RS KNIFED ME; NASTY NICK IN RAGE AT TV AXEP/Nicola Methven, Tv Editor27P1/6/DNME
C+2/6/01, 08EJ/2/19/RAILWAY BOSS IN POLICE QUIZ ON HATFIELDC/Steve Dennis27LK/6/
DNMB6+2/6/01, 145A/2/12/ULRIKA GIVES A LITTLE PEEP OF BOB/Eva Simpson27BL/6/DNLP
6+2/2/012R/2/R/HIGH ST DRUGS PRICES HALVED18/Tracey Harrison Consumer Correspond
ent27BK/6/DNLP6+2/6/01, 0583/2/22/POINTLESS; ZETA'S POUNDS 4,000 EYE OP TO LOOK 
EXACTLY THE SAMEI/Alexandra Williams278A/6/DNLM+3/2/0132/2/27/HELP ME DIE, DAD; 
FATHER TELLS HOW HE KILLED HIS TORMENTED DAUGHTERQ/Chris Hughes And Nic North275
0/6/DNLIO+2/2/013C/2/25/WE'LL SUE; POUNDS 3M LOTTERY LOSERS PLAN COURT FIGHT WIT
H CAMELOTF/Lorraine Fisher271K/6/DNL96+2/6/01, 02BO/2/1I/A CHILD OF 12 .. AND PR
EGNANT BY ONE OF FIVE MEN12/Steve Dennis And Ros Wynne-jones2K8A/7/DNO5I+2/2/011
35/2/2J/SHAMING OF BARRYMORE; Comedian quizzed in murder inquiry over death in h
is poolS/Stephen Wright;Gordon Rayner2K50/7/DNO2C+2/2/01S2/2/3S/JAIL WARDERS PAY
OUT STORM; Fury over GBP 200,000 compensation for officers 'traumatised' by work
ing with sex offendersF/Matthew Hickley2K1K/7/DNNT6+2/2/0111L/2/32/NHS TO RATION
 DENTAL BRACES; 50,000 children may face bills of up to GBP 2,500 for treatmentA
/Jenny Hope2JLK/7/DNND6+2/6/01, 08O1/2/2N/LORD ARCHER'S 'SEX COVER-UP'; Tory pee
r set up false alibi and faked diary, says QCB/Paul Harris2J8A/7/DNMO+3/2/01R0/2
/R/CAR INSURANCE SET TO ROCKETA/Ray Massey2J50/7/DNMKO+2/6/01, 02112/2/3N/POSTME
N: BACK TO THE BAD OLD DAYS; Illegal wildcat strikers give a timely reminder of 
the era of industrial chaosC/Darren Behar2J1K/7/DNMHI+2/6/01, 0211T/2/2H/PHILIP'
S RIFT WITH CHARLES; New biography stokes conflict in the Royal FamilyB/Richard 
Kay2IP0/7/DNMB6+2/6/01, 02QN/2/25/HOUSE PRICES 'SURE TO PLUNGE'; Fears over surg
e in lending levelsR/Darren Behar;Duncan Gardham2ILK/7/DNM1I+2/2/01KC/2/17/COMPA
NY PENSION FUNDS RUN OUT OF CASHN/Darren Behar;Matt Kovac2IBK/7/DNLM+3/6/01, 021
7O/2/2K/WHY I KILLED MY DAUGHTER; Loving father smothers depressed girl to end h
er agonyF/Christian Gysin2I8A/7/DNLIO+2/2/01SI/2/3K/ROSIE, 16 KNIFED TO DEATH BY
 A TOTAL STRANGER; Horror as schoolgirl is attacked as she relaxes in the sunshi
neD/Tom Rawstorne2HSA/7/DNL2O+2/6/01, 051AO/2/33/ECSTASY: MY TRAGIC GIRL'S WASTE
D LIFE; Mother's anguished plea over last picture of Lorna, 19F/Christian Gysin3
1BK/8/DNO5I+2/6/01, 0511A/2/2K/POLICE QUIZ STAR OVER DRUGS DURING BODY-IN-POOL M
URDER PROBE; BARRYMORE ARRESTEDC/JOHN CHAPMAN318A/8/DNO2C+2/6/01, 04KE/2/4E/LAST
 WORDS OF SAD ZOE, 12, WHO DIED OF DRUG OVERDOSE WHEN HER PARENTS' MARRIAGE ENDE
D; I LOVE YOU MUM, BUT I NEED TO LOVE MY DADDY TOOS/HARRY COOKE AND JOHN CHAPMAN
3150/8/DNNT6+2/6/01, 02KO/2/2G/AA DEMANDS ACTION OVER SPEED CAMERA ERRORS; INNOC
ENT DRIVERS IN FINES FIASCOB/LAURA WHITE311K/8/DNNQ+3/6/01, 04L9/2/42/EGGS AND P
OULTRY ARE 'INFECTED WITH DANGEROUS TOXINS'; POISON IN OUR FOOD SCANDAL, EXCLUSI
VE BY MICHAEL DAY AND ADRIAN LEE1/ 30SA/8/DNNGC+2/6/01, 041B6/2/2O/SECRETARY HID
 HER 'DISHONEST' DIARY SECRET FOR 13 YEARS; ARCHER MADE GIRL FAKE ENTRYB/JOHN TW
OMEY30P0/8/DNND6+2/6/01, 041CH/2/31/TORY LORD LIED TO WIN EXPRESS LIBEL CASE, CO
URT TOLD; CALL GIRL SEX ALIBI 'FAKED' BY ARCHER11/JOHN TWOMEY CRIME CORRESPONDEN
T30LK/8/DNNA+3/6/01, 04MA/2/P/TRAIN FARES SET TO DOUBLEA/JANE YOUNG30IA/8/DNN6O+
2/6/01, 08SO/2/3F/POLICE FEAR WEEKEND CLASHES COULD SPREAD TO OTHER TOWNS AND DI
SRUPT TEST MATCH; COPYCAT RACE RIOT WARNINGR/DAVID HUDSON AND GREG SWIFT30BK/8/D
NMO+3/6/01, 06RS/2/3F/EXCLUSIVE: HUMANS IN FOOT-AND-MOUTH AREAS NOW FACE CJD, WA
RNS GOVERNMENT SCIENTIST; DON'T DRINK THE WATER1I/ANTHONY MITCHELL, JOHN INGHAM 
AND MARK BLACKLOCK308A/8/DNMKO+2/6/01, 04RI/2/2Q/GOOD CAUSES LOSE GBP 39M BUT BO
SSES STILL GET A BONUS; SCANDAL OF THE LOTTERY FAT CATSA/GREG SWIFT3050/8/DNMHI+
2/6/01, 04M6/2/2R/CHARLES 'UPSET' AFTER FATHER CALLS HIM A LIGHTWEIGHT; PHILIP: 
MY SON'S UNFIT TO BE KING1C/ROBERT JOBSON, ROYAL EDITOR AND MYRA PHILP301K/8/DNM
EC+2/6/01, 02MG/2/2L/EXCLUSIVE: POLICE ACCUSED OF TARGETING DRIVERS INSTEAD OF C
ROOKS; BRITAIN IN FEAR19/RACHEL BAIRD HOME AFFAIRS CORRESPONDENT2TSA/8/DNMB6+2/2
/01F5/2/2K/RELIEF AS BRITISH PAIR ESCAPE FIRING SQUAD; TEARS OF DRUGS WOMEN JAIL
ED FOR LIFEC/JOHN CHAPMAN2TLK/8/DNLSC+2/6/01, 041FS/2/2N/KILLER GETS LIFE FOR ST
ABBING HER LOVER IN RAGE; 'FERGIE'S AIDE IS GUILTY OF MURDER11/JOHN TWOMEY CRIME
 CORRESPONDENT2TIA/8/DNLP6+2/2/01IM/2/2R/EVERY HOUSEHOLD SET TO SAVE AT LEAST GB
P 30 A YEAR; CHEMISTS TO SLASH PRICE OF MEDICINE17/MARK TOWNSEND CONSUMER AFFAIR
S EDITOR2TF0/8/DNLM+3/2/01MC/2/2O/FATHER TELLS OF TORMENT FACING HIS FAMILY; THE
 DAY I HAD TO KILL MY DARLING DAUGHTERS/JOHN CHAPMAN AND DENNIS RICE2TBK/8/DNLIO
+2/6/01, 04N0/2/3H/'VULNERABLE' GIRLS OF 11 WILL BE TAUGHT TO AVOID THE DANGERS 
OF PROSTITUTION; PUPILS TO GET LESSONS IN VICE10/MARK BLACKLOCK AND LAURA WHITE2
T8A/8/DNL96+2/2/01KQ/2/29/CHEER AS MORTGAGES PLUNGE TO NEW LOW; MORTGAGES PLUMME
T TO RECORD LOW11/MARK TOWNSEND AND DAVID ANDREWS2T50/8/DNL6+3/6/01, 09M1/2/2J/N
EIGHBOURS SAW SUSPECT DAY TV STAR WAS SHOT; DANDO 'KILLER' LURKED BY HER HOUSE11
/JOHN TWOMEY CRIME CORRESPONDENTZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
