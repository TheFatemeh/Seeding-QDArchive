�����@����@����@����@@@@@@@@@@@@@@@@@@@@ASCII SPSS PORT FILE                    
00000-0000-0000-0000--------------------!3#))0303300/240&),%00000000000000000000
0200002'220'&)3000#0000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrst
uvwxyz .<(+0&[]!$*);^-/|,%_>?`:#@'="000000~000000000000000000000{}\0000000000000
00000000000000000000000000000000000000000000000000000000SPSSPORTA8/200301316/121
728112/SPSS for MS WINDOWS Release 10.048/5B/70/4/IDNO5/5/0/5/5/0/CS/Unique Iden
tification Number70/5/PAPER5/1/0/5/1/0/C9/Newspaper70/7/ARTDATE40/8/0/40/8/0/CF/
Date of Article72/4/PAGE1/2/0/1/2/0/CB/Page Number74/7/ARTSIZE1/4/0/1/4/0/CF/Num
ber of Words70/6/ARTTYP5/1/0/5/1/0/CC/Article Type78A/8/HEADLINE1/8A/0/1/8A/0/C8
/Headline73A/7/AUTHNME1/3A/0/1/3A/0/CE/Name of AuthorD1/5/PAPER8/1/8/Guardian2/5
/Times3/F/Daily Telegraph4/B/Independent5/3/Sun6/6/Mirror7/4/Mail8/7/ExpressD1/6
/ARTTYP2/1/8/Campaign2/C/Non-CampaignFB6L/1/DNL2O+2/2/023/3561/2O/Election 2001:
 High profile jobs for women: Poll roles Ministers head regional teams13/Lucy Wa
rd Political correspondentB6T/1/DNL2O+2/2/043/8051/3S/Election 2001: Blair preac
hes lesson of trust and change: Labour launch:Prime minister promises to meet ne
w challengesA/Sarah HallB71/1/DNL2O+2/2/053/8201/43/Election 2001: History books
 have some bad news for the Tories: The polls A comeback from this point would b
e unprecedented11/Alan Travis Home affairs editorB73/1/DNL2O+2/2/063/8171/5C/Ele
ction 2001: Doorstep troops to get air support from high-octane leader: Lib Dem 
strategy Party to combine trademark local campaigning with new punchy offerings1
3/Lucy Ward Political correspondentB74/1/DNL2O+2/2/063/1781/1F/Election 2001: Wh
at's at stake for Tony BlairD/Kevin MaguireB76/1/DNL2O+2/2/073/2041/1I/Election 
2001: What's at stake for William HagueD/Kevin MaguireB78/1/DNL2O+2/2/194/10981/
4P/Comment & Analysis: Election 2001: Different futures beckon for Blair: The Gu
ardian's top commentators unveil the landscape that lies ahead of usI/Jonathan F
reedlandB79/1/DNL2O+2/2/194/11811/4B/Comment & Analysis: Election 2001: His plac
e in history: The Guardian's top commentators unveil the landscape that lies ahe
ad of usD/Polly ToynbeeB7A/1/DNL2O+2/2/203/8091/3L/Comment & Analysis: Brown is 
waiting in the wings: But the chancellor may yet be denied a chance at the top j
obC/Seumas MilneB7B/1/DNL2O+2/2/053/7821/46/Election 2001: I will give you back 
Britain, says Hague: Tory launch Leader makes a pitch to 'real people' outside W
estminster17/Nicholas Watt Political correspondentBA1/1/DNL6+3/2/174/10481/43/Co
mment & Analysis: Keeping Tory spirits up. George Osborne was Hague's speechwrit
er. Now he seeks Neil Hamilton's old seatE/George OsborneBA3/1/DNL6+3/2/053/3431
/45/Election 2001: Campaign trail: Prescott trundles along road to Damascus: Bat
tle bus starts 10,000-mile trip with late arrivalC/Jamie WilsonBA5/1/DNL6+3/2/05
3/6571/3H/Election 2001: Selection: Safe seat found for Tory defector: Sudden re
tirement paves way for Shaun Woodward11/Kevin Maguire and Michael WhiteBA6/1/DNL
6+3/2/053/4611/3O/Election 2001: Strategy: Lib Dems ask openly for tactical vote
s: Third party breaks taboos in bid for breakthrough13/Lucy Ward Political corre
spondentBAA/1/DNL6+3/2/023/6011/20/Sketch: Heath bids adieu with a final attack 
- on the ToriesD/Simon HoggartBAB/1/DNL6+3/2/043/4741/46/Election 2001: Europe: 
Heath's parting shot on euro undermines Hague attack on Labour: Tory divisions e
xposed by former leader17/Nicholas Watt Political correspondentBAC/1/DNL6+3/2/06
3/9141/62/Election 2001: First term report: First the taxes, now the spending: T
hinktank says chancellor has turned round public finances but has only succeeded
 in slowing growth of inequality13/Larry Elliott and Charlotte DennyBAF/1/DNL6+3
/2/193/4071/2K/Leading article: Success for the economy: Now Mr Brown must share
 it more fairly1/ BDB/1/DNL96+2/2/063/3221/3B/ELECTION 2001: ULSTER: BLACKMAIL T
HREAT FORCES UNIONIST TO PULL OUT: CANDIDATE ACTS TO PROTECT FAMILY13/ROSIE COWA
N IRELAND CORRESPONDENTBDC/1/DNL96+2/2/193/6001/2S/LEADING ARTICLE: A DRIVE FOR 
THE CAR VOTE: BESIDES CHEAP PETROL, THE TORIES OFFER LITTLE1/ BDD/1/DNL96+2/2/05
3/5751/1R/ELECTION 2001: SKETCH: YEE HAH, CHAPS! IT'S THE MANIFESTOD/SIMON HOGGA
RTBDE/1/DNL96+2/2/063/5051/3G/ELECTION 2001: INQUIRY: VAZ UNDER RENEWED PRESSURE
 AS DOCUMENTS DEADLINE LOOMS: MINISTER'S WIFE FACES FINE16/ANNE PERKINS POLITICA
L CORRESPONDENTBDF/1/DNL96+2/2/063/4741/37/election 2001: legislation: last ditc
h deal saves nhs bill: compromise all round as time runs out13/John Carvel socia
l affairs editorBDG/1/DNL96+2/2/073/4911/3Q/ELECTION 2001: LIB DEMS: CALL FOR TA
CTICAL VOTING TO SAVE LEWES MP: KEY MARGINAL AGAIN HEARS PLEA FOR ANTI-TORY PACT
16/ANNE PERKINS POLITICAL CORRESPONDENTBDI/1/DNL96+2/2/044/21671/68/ELECTION 200
1: CONSERVATIVE MANIFESTO: PLEDGE TO SET PEOPLE FREE WITH TAX CUTS AND ATTACK ON
 BUREAUCRACY: PROMISES ON SCHOOLS, CRIME AND HEALTH IN 'MOST AMBITIOUS PROGRAMME
 FOR GENERATION'17/NICHOLAS WATT POLITICAL CORRESPONDENTBDJ/1/DNL96+2/2/053/6661
/3N/ELECTION 2001: SPENDING: DISPUTE OVER REAL COST OF TORY TAX CUTS: LABOUR SAY
S INSURANCE SWITCH WOULD HIT PENSIONS11/MICHAEL WHITE AND NICHOLAS WATTBDN/1/DNL
96+2/2/174/11981/4J/COMMENT & ANALYSIS: ELECTION 2001: GREED TAKES A BOW: AS THE
 TORIES REVERT TO BRIBERY TO WIN VOTES, LABOUR MUST DELIVER A LESSON IN REALITYD
/POLLY TOYNBEEBDO/1/DNL96+2/2/173/9371/6B/COMMENT & ANALYSIS: ELECTION 2001: ANA
LYSIS: MAKING HISTORY: IF TONY BLAIR REALLY WANTS TO LEAVE HIS MARK, HE NEEDS TO
 TAKE A LEAF OUT OF THE MARGARET THATCHER BOOK OF MANIPULATIVE STATECRAFTC/DAVID
 WALKERBGL/1/DNLIO+2/2/103/4961/35/Election 2001: Special 8-page pullout: guardi
an.co.uk/politics: Hague faces growing euro revolt18/David Hencke Westminster co
rrespondentBGM/1/DNLIO+2/2/143/2121/3O/Election 2001: Special 8-page pullout: gu
ardian.co.uk/politics: Why I'm voting for...: Jamie Webster, shop stewardD/Jamie
 WebsterBGN/1/DNLIO+2/2/123/4511/3R/Election 2001: Special 8-page pullout: guard
ian.co.uk/politics: Lib Dems to pledge pounds 1,000 extra for NHS workers10/Mich
ael White Political EditorBH1/1/DNLIO+2/2/143/8701/4H/Election 2001: Special 8-p
age pullout: guardian.co.uk/politics: Inside the campaign: Labour is fighting th
e wrong election - the last oneI/Jonathan FreedlandBH3/1/DNLIO+2/2/154/19221/6M/
Election 2001: Special 8-page pullout: guardian.co.uk/politics: The view from th
e Guardian panel: Introducing the Guardian panel - people from all over the Unit
ed Kingdom and from various walks of life.1/ BH6/1/DNLIO+2/2/203/8241/46/Comment
 & Analysis: Tony rushes on to the low ground: Endpiece: This campaign is becomi
ng a fight to appeal to baser instinctsE/Roy HattersleyBH8/1/DNLIO+2/2/123/4781/
3O/Election 2001: Special 8-page pullout: guardian.co.uk/politics: Straw pledge 
to boost police falls short of demand10/Patrick Wintour and Paul KelsoBK3/1/DNLM
+3/2/173/4451/2S/Election2001: Special 8-page pullout: Tories pin hopes on winni
ng back former supportersT/Kevin Maguire and Alan TravisBK4/1/DNLM+3/2/173/2471/
6A/Election2001: Special 8-page pullout: In Labour's sights: The sort of younger
 voters you may be able to encourage to vote tend to be found in the new-build e
states or modern council estates.1/ BK6/1/DNLM+3/2/233/6031/2S/Leading article: 
Labour's Sugar and Spice: But Blair's big tent needs to be fair as well1/ BKD/1/
DNLM+3/2/154/13831/51/Election2001: Special 8-page pullout: Dissent: Straw v Cot
ton in old mill town: Race and crime dominate the battle in the home secretary's
 own backyardB/Vikram DoddBKE/1/DNLM+3/2/163/5041/2P/Election2001: Special 8-pag
e pullout: Working age ministry plan in Whitehall shake-upQ/Lucy Ward and Anne P
erkinsBKF/1/DNLM+3/2/163/6931/32/Election2001: Special 8-page pullout: 'Ethics M
an' Martin Bell launches battle for BrentwoodC/Owen BowcottBKG/1/DNLM+3/2/163/40
51/4E/Election2001: Special 8-page pullout: Other party watch: Political life go
es on beyond the big three: Today: Democratic Unionist partyB/Rosie CowanBKL/1/D
NLM+3/2/194/13141/5R/Election2001: Special 8-page pullout: Honest joker's charm 
offensive: The interview: Charles Kennedy: 'Stuff them all' party leader pins ho
pes of change on euro vote cooperation11/Polly Toynbee and Michael WhiteBKN/1/DN
LM+3/2/214/11781/7K/Comment & Analysis: Election 2001: Guardian commentators off
er rival ideologies. On the left, they're against corporate giants and fat cats.
 But on the right, it's the state and its employees who are reviled: In love wit
h businessE/George MonbiotBKQ/1/DNLM+3/2/183/3461/1Q/Election2001: Special 8-pag
e pullout: Why I'm not voting10/Russell Sage, fashion designerBND/1/DNLP6+2/2/16
3/4031/1B/Election 2001: All substance and no styleG/Jonathan GlanceyBNK/1/DNLP6
+2/2/133/6131/39/Election 2001: Tories in scare tactics row: Election broadcast 
links crimes to early release scheme17/Nicholas Watt Political correspondentBNL/
1/DNLP6+2/2/133/3931/64/Election 2001: Truth watch: Today: Early release scheme:
 Justified claim, tweaking the figures or outrageous lie? Alan Travis gives his 
verdict on the latest statement from the partiesB/Alan TravisBNN/1/DNLP6+2/2/133
/6481/1N/Election 2001: Think tank highlights cost of tax cuts10/Larry Elliott E
conomics editorBNO/1/DNLP6+2/2/143/5921/2L/Election 2001: Sketch: Chucklesome Ch
arlie relaunches himself as a sober salesmanD/Simon HoggartBNP/1/DNLP6+2/2/143/6
791/3P/Election 2001: ICM poll: Tory attack falls on deaf ears: Most voters say 
they would back tax rise to boost services11/Alan Travis Home affairs editorBNR/
1/DNLP6+2/2/154/11541/4P/Election 2001: Today: Northampton: Unspoken issue for m
arginal Britain: Matthew Engel watches the dilemma of an Asian Tory candidate on
 the stumpD/Matthew EngelBNS/1/DNLP6+2/2/163/8021/1J/Election 2001: Lib Dems tar
get disaffected Tories13/Lucy Ward Political correspondentBNT/1/DNLP6+2/2/173/61
31/1D/Election 2001: Blair: we need 10 more years1O/Michael White, Kevin Maguire
 and Richard Norton-TaylorBO1/1/DNLP6+2/2/183/8521/2N/Election 2001: Inside the 
campaign: Leaked report will annoy publicly and privatelyF/Patrick WintourBO3/1/
DNLP6+2/2/183/5001/24/Election 2001: The debate nobody wants: Railtrack renation
alisedT/Keith Harper Transport editorBO6/1/DNLP6+2/2/203/9711/2F/Election 2001: 
Campaign day: Cheerio statesman, step forward ordinary blokeD/Stuart MillarBO8/1
/DNLP6+2/2/213/7961/15/Comment & Analysis: The Italian jobC/Seumas MilneBO9/1/DN
LP6+2/2/213/8801/1M/Comment & Analysis: Oh yes, Kennedy's the man for meA/AL Ken
nedyBOA/1/DNLP6+2/2/193/3591/1S/Election 2001: Oh dad, do me a favour and put a 
sock in itD/Michael WhiteBOB/1/DNLP6+2/2/183/3231/26/Election 2001: Why I'm voti
ng Labour: Jude Kelly, theatre directorA/Jude KellyBOC/1/DNLP6+2/2/164/13691/4B/
Election 2001: Pledge on raising tax for sake of public services: Manifesto stre
sses schools and health, but plays down vote reform13/Lucy Ward Political corres
pondentBQL/1/DNLSC+2/2/193/3681/35/Election 2001: Partywatch: Political life goe
s on beyond the big three Today Socialist Alliance9/Lucy WardBQM/1/DNLSC+2/2/143
/7711/63/Election 2001: Pressure grows on top Tory in pounds 20bn row: Hague fac
es new embarrassment over tax cuts after shadow cabinet minister comes out of hi
ding and admits giving interview17/Nicholas Watt Political correspondentBQO/1/DN
LSC+2/2/193/6201/1O/Election 2001: Pro-Europe Tory challenges Eurosceptics17/Nic
holas Watt Political correspondentBQS/1/DNLSC+2/2/133/4871/1I/Election 2001: NHS
 commercial links under attackT/John Carvel and Kevin MaguireBR0/1/DNLSC+2/2/133
/1721/1Q/Election 2001: Furious NHS protester takes Blair to task11/Ewen MacAski
ll and Owen BowcottBR1/1/DNLSC+2/2/133/6711/2N/Election 2001: Blair goes private
: Manifesto stirs controversy over public services10/Michael White Political edi
torBR3/1/DNLSC+2/2/143/4371/1Q/Election 2001: Hague renews Conservative attack o
n crime10/Anne Perkins and Nicholas WattBR4/1/DNLSC+2/2/143/2811/62/Election 200
1: Truth watch: Justified claim, tweaking the figures oroutrageous lie? David Wa
lker gives his verdict on the latest big statement from the parties: Today: Poli
ce numbersC/David WalkerBR5/1/DNLSC+2/2/154/12151/5I/Election 2001: Campaign tra
il: 'Little' Billy aims for more altitude: Gary Younge delivers his verdict on t
he leaders' electioneering performances: Today: William HagueB/Gary YoungeBR6/1/
DNLSC+2/2/164/14631/3L/Election 2001: Economy the key to Labour pledges: Manifes
to: No rise in tax and a doubling of public investmentF/Patrick WintourBR8/1/DNL
SC+2/2/173/5981/1S/Election 2001: Sketch: Vote green hair for wraparound careD/S
imon HoggartBR9/1/DNLSC+2/2/173/6421/3N/Election 2001: Luck, skill and the loomi
ng euro: Analysis: 'Work in progress' but crucial choice still lies ahead10/Larr
y Elliott Economics editorBRA/1/DNLSC+2/2/173/3171/23/Election 2001: 'Ask Tony a
 nice soft question' request to media12/Kevin Maguire and Ewen MacAskillBRB/1/DN
LSC+2/2/183/8661/2N/Election 2001: Inside the campaign : Forked road to rehabili
tation of tax-and-spendI/Jonathan FreedlandBRD/1/DNLSC+2/2/183/3111/22/Election 
2001: Why I'm voting Lib Dem Shaun Hill, restaurateurA/Shaun HillBRF/1/DNLSC+2/2
/193/7671/4A/Election 2001: Slow march to success for Scottish socialists: Party
 fights high-profile campaign with eye on Holyrood poll in 2003C/Kirsty ScottBRG
/1/DNLSC+2/2/193/4791/1K/Election 2001: Lib Dems make way for NHS protesterE/Jee
van VasagarBRH/1/DNLSC+2/2/203/8901/2J/Election2001: Bob and Hayley raise stakes
 in battle of the celebs: Campaign dayH/Martin WainwrightBRI/1/DNLSC+2/2/214/125
41/55/Comment & Analysis: Running up a profit: Gas, phones, rail and water have 
all been handed over to the private managers so loved by Blair, Felicity Lawrenc
e1/ BRJ/1/DNLSC+2/2/223/8391/4C/Comment & Analysis: Election watch: Unmasked:Bla
ir without the spin: Labour's manifesto ignores the Tories and offers a clear vi
sionA/Hugo YoungBRK/1/DNLSC+2/2/233/7011/2E/Leading article: Ready, willing and 
able: Labour pitches for a second term1/ C04/1/DNM1I+2/2/173/9211/3H/Election 20
01: How Millbank moved to soften the blow: After the punch, Labour holds line in
 classic fashion1B/Lucy Ward, Michael White and Kirsty ScottC08/1/DNM1I+2/2/173/
2081/1G/Election 2001: Experts advise on tackling rageD/Steven MorrisC0B/1/DNM1I
+2/2/163/6881/4P/Election 2001: Bruiser's surface conceals a soft centre: They m
ay call him Thumper, but the deputy PM has a reputation for loyalty and dedicati
on10/Michael White Political editorC0C/1/DNM1I+2/2/163/2291/1G/Election 2001: Le
gality hinges on self defenceB/Vikram DoddC0D/1/DNM1I+2/2/173/7911/6R/Election 2
001: View from Guardian panel: Members of the panel - chosen from across the UK 
to represent different groups - give their views on John Prescott's behaviour af
ter being confronted by demonstrators1/ C0E/1/DNM1I+2/2/193/4951/1J/Election 200
1: Woodward faces challenge from leftJ/Angelique ChrisafisC0G/1/DNM1I+2/2/193/41
71/21/Election 2001: Sinn Fein will get Commons offices, says Adams13/Rosie Cowa
n Ireland correspondentC0J/1/DNM1I+2/2/203/8651/2P/Election 2001: Inside the cam
paign : Jail cash could be used to unlock social tensionD/Larry ElliottC0O/1/DNM
1I+2/2/213/4251/86/Election 2001: 2-minute interview: In which a politician goes
 up against the clock on the issues of the day. This is a direct transcription, 
no tweaks, no corrections. Today David Trimble, leader of the Ulster Unionist pa
rty, talks to Rosie CowanB/Rosie CowanC0R/1/DNM1I+2/2/213/2611/31/Election 2001:
 Political life goes on beyond the big three: Today: Green party, Party watch1/ 
C0T/1/DNM1I+2/2/263/8441/44/Comment & Analysis: Election watch: Blair does handl
e people well: Those arguments made it the best day of Labour's campaignA/Hugo Y
oungC3E/1/DNMB6+2/2/163/8541/2N/Election 2001: Inside the campaign: The dangers 
of a strategy aimed at the faithfulI/Jonathan FreedlandC3H/1/DNMB6+2/2/143/2611/
70/Election 2001: 2-minute interview: In which a politician goes up against the 
clock on the issues of the day. This is a direct transcription, no tweaks, no co
rrections. Today: Mike O'Brien talks to Kevin MaguireD/Kevin MaguireC3K/1/DNMB6+
2/2/114/13081/55/Election 2001: Dog days or new dawn?: Throughout the campaign M
atthew Engel is meeting politicians on their own patch: Today: Peter Mandelson i
n HartlepoolD/Matthew EngelC3L/1/DNMB6+2/2/113/6011/1H/Election 2001: GPs back w
oman who berated BlairC/Sophie LomaxC3M/1/DNMB6+2/2/123/6301/2L/Election 2001: S
ketch: Come on, then! Vote for me if you think you're hard enoughD/Simon Hoggart
C3R/1/DNMB6+2/2/153/3121/28/Election 2001: Post-poll shake-up could see Dobson b
ecome chief whip10/Michael White Political editorC3S/1/DNMB6+2/2/153/2741/5T/Ele
ction 2001: Truthwatch: Justified claim, tweaking the figures or outrageous lie?
 David Walker gives his verdict on the latest statement from the parties Today S
cottish spendingC/David WalkerC40/1/DNMB6+2/2/174/10371/3S/Election 2001: Nation
alist vote wooed in a pincer movement: Northern Ireland Fierce contest between S
DLP and Sinn Fein13/Rosie Cowan Ireland correspondentC43/1/DNMB6+2/2/193/8451/1B
/Comment & Analysis: Humphrys and his kindE/Roy HattersleyC44/1/DNMB6+2/2/203/80
31/3R/Comment & Analysis: Voices from hustings of the past: Good to have Ted Hea
th's advice to the disillusioned electorateA/Ian AitkenC6L/1/DNMEC+2/2/183/8251/
2M/Election 2001: Inside the campaign: Letter writers try to dent Labour's reput
ationB/Mark MilnerC6O/1/DNMEC+2/2/163/3161/5R/Election 2001: Truth watch: Justif
ied claim, tweaking the figures or outrageous lie? David Walker gives his verdic
t on the latest big statement from the parties: Today: Red tapeC/David WalkerC6P
/1/DNMEC+2/2/213/7611/1A/Comment & Analysis: To save our hospitalE/Richard Taylo
rC6R/1/DNMEC+2/2/143/4671/1T/Election 2001: Blair berated by single mother over 
New DealC/Jamie WilsonC71/1/DNMEC+2/2/133/6301/2C/Election 2001: Sketch: This is
 Planet Vaz, but no sign of the Vaz of VazD/Simon HoggartC73/1/DNMEC+2/2/153/985
1/47/Election 2001: Campaign trail: Marathon man travels into the unknown: Kenne
dy's strategy is all about positioning for next timeD/Stephen BatesC74/1/DNMEC+2
/2/163/6921/3Q/Election 2001: Tories in new tax bombshell claim: Hague pledges t
o peg national insurance contributions to inflation16/Anne Perkins Political cor
respondentC75/1/DNMEC+2/2/173/9651/5A/Election 2001: First-time voters: R they u
p 4 it? Soft-soap pleas put off students: 'Naff' celebrities add to the alienati
on of those who know an election is onJ/Angelique ChrisafisC77/1/DNMEC+2/2/183/4
621/20/Election 2001: Why I'm undecided: Rowan Williams, archbishopQ/Rowan Willi
ams, archbishopC79/1/DNMEC+2/2/194/15911/5N/Election 2001: Interview: William Ha
gue: 'I've been toughened up. I'm used to fighting': The Tory leader debunks the
 myths about those polls, those policies, and that speech16/Jonathan Freedland a
nd Michael WhiteC7C/1/DNMEC+2/2/213/8511/27/Comment & Analysis: From the right: 
Bogus friends of asylum seekersE/Minette MarrinC7D/1/DNMEC+2/2/233/5961/29/Leadi
ng article: A bold vision: But is Labour privatising by stealth?1/ CA1/1/DNMHI+2
/2/214/11761/5H/Election 2001: Never send to know for whom the Bell tolls: Matth
ew Engel is touring Britain and visiting key constituencies in the campaign: Tod
ay: Brentwood and OngarD/Matthew EngelCA5/1/DNMHI+2/2/193/2491/2S/Election 2001:
 Party watch: Political life goes on beyond the big three: Today: The SDLPB/Rosi
e CowanCAB/1/DNMHI+2/2/153/3391/1I/Election 2001: Another leftwing foe for Woodw
ardJ/Angelique ChrisafisCAD/1/DNMHI+2/2/163/5001/1H/Election 2001: Only 20% of c
andidates are women13/Lucy Ward Political correspondentCAF/1/DNMHI+2/2/173/4891/
28/Election 2001: Nurses jeer junior minister as Milburn keeps distance13/John C
arvel Social affairs editorCAH/1/DNMHI+2/2/203/7911/2L/Election 2001: Inside the
 campaign: Whose brief is it anyway? ask Scottish votersC/Kirsty ScottCAI/1/DNMH
I+2/2/203/5741/27/Election 2001: TV watch: Mr Boom and Mr Bust but where is Mr B
lair?B/Mark LawsonCAJ/1/DNMHI+2/2/203/3881/29/Election 2001: Why I'm voting:... 
Labour: Gina Ford, childcare writer9/Gina FordCAL/1/DNMHI+2/2/233/7901/4A/Commen
t & Analysis: The private sector: Labour seems to see commercial managers as sav
iours of the health service: Under the knifeC/Seumas MilneCAM/1/DNMHI+2/2/243/83
91/48/Comment & Analysis: Election watch: Rolling back the size of the state: Th
e Tories know the questions, but not the right answersA/Hugo YoungCDD/1/DNMKO+2/
2/133/1531/14/Election 2001: Labour's 10 targets1/ CDF/1/DNMKO+2/2/143/6651/21/E
lection 2001: Sketch : But I know Shaun Woodward's butler...D/Simon HoggartCDH/1
/DNMKO+2/2/153/6011/4J/Election 2001: Ashdown lays into 'miser' Blair: He sits i
n Downing Street counting his popularity like Silas Marner, scoffs Lib Dem ex-al
ly13/Lucy Ward Political correspondentCDK/1/DNMKO+2/2/133/5831/1Q/Election 2001:
 Specialist school plans unfair, say headsS/Will Woodward and Sarah HallCDN/1/DN
MKO+2/2/134/11741/5D/Election 2001: A royal progress - but where is the inspirat
ion?: Campaign trail: Gary Younge gives his verdict on the party leaders' perfor
mances Today: Tony BlairB/Gary YoungeCDO/1/DNMKO+2/2/163/3721/25/Election 2001: 
Blair accused of breaking promise on voting reform13/Lucy Ward Political corresp
ondentCDP/1/DNMKO+2/2/203/5711/2D/Election 2001: Profit-making private company t
akes over running of school10/Will Woodward Education editorCDQ/1/DNMKO+2/2/213/
5671/3C/Election 2001: Nurse and fire unions turn on Labour: Public sector worke
rs urged to make protest votesS/John Carvel and Seumas MilneCDR/1/DNMKO+2/2/213/
6591/3A/Election 2001: Anger over C4 expose of party HQs: Secret videos aim to s
how how media is manipulated18/David Hencke Westminster correspondentCDS/1/DNMKO
+2/2/213/8471/7G/Election 2001: View from the Guardian panel: Members of the pan
el respond to the question: has Margaret Thatcher's intervention helped or hinde
red the Tories and has she managed to make the euro a bigger issue in the campai
gn?1/ CE3/1/DNMKO+2/2/234/10181/46/Election 2001: A McMuffin - with the history 
lesson to go: On the stump: The Tories' leading intellect essays the common touc
hF/Oliver BurkemanCE6/1/DNMKO+2/2/253/8271/1P/Comment & Analysis: Songs to rally
 and rouse: ElsewhereB/David McKieCE7/1/DNMKO+2/2/253/7871/1I/Comment & Analysis
: They used to press the fleshC/Keith HarperCE9/1/DNMKO+2/2/273/6011/2M/Leading 
article: Not losing is not enough: Gordon's garden strategy is too limited1/ CEB
/1/DNMKO+2/2/264/11891/4B/Comment & Analysis: The lady rounds on her creation: E
lection watch: The anger of a vengeful mother threatens to destroy the ToriesA/H
ugo YoungCGN/1/DNMO+3/2/153/6611/35/Election 2001: Storm at new Tory film: Educa
tion broadcast 'will alienate parents and teachers'17/Nicholas Watt Political co
rrespondentCGO/1/DNMO+3/2/153/6711/22/Election 2001: Shake-up likely to give Blu
nkett anti-drug roleD/Kevin MaguireCGS/1/DNMO+3/2/163/4681/1G/Election 2001: Lab
our moves to allay NHS fears1F/Patrick Wintour Chief political correspondentCH2/
1/DNMO+3/2/193/6911/3T/Election 2001: Silenced women bring loud protests: Brown 
under fire for keeping female stars out of the media spotlight13/Lucy Ward Polit
ical correspondentCH3/1/DNMO+3/2/193/5141/23/Election 2001: Fear of postal votes
 delay despite end of strike1B/Lucy Ward, Seumas Milne and Michael WhiteCHB/1/DN
MO+3/2/223/8061/2R/Election 2001: Campaign day: Portillo in a jam as conserve pa
rty takes on ConservativesH/Martin WainwrightCHC/1/DNMO+3/2/234/11491/52/Comment
 & Analysis: The future is tactical: Tribalism is old hat. We should follow the 
advice of a new website and think about how best to use our votesD/Polly Toynbee
CHE/1/DNMO+3/2/243/8521/4K/Comment & Analysis: Election watch: Politicians treat
 voters like idiots: Is it any wonder the electorate aren't interested in the el
ection?A/Hugo YoungCHF/1/DNMO+3/2/253/6011/2O/Leading article: Wanted: a great d
ebate: Part of the answer is in Tony Blair's hands1/ CK4/1/DNN3I+2/2/043/2031/1C
/Election 2001: Worries over polling system10/Clare Dyer Legal correspondentCK5/
1/DNN3I+2/2/054/10531/5A/Election 2001: On-off charm of a sure thing: Matthew En
gel is touring Britain and visiting key constituencies: Today: Michael Portillo 
in Kensington and ChelseaD/Matthew EngelCK7/1/DNN3I+2/2/063/1241/18/Election 200
1: Young women ignore poll13/Lucy Ward Political correspondentCKA/1/DNN3I+2/2/06
3/2441/30/Election 2001: Party watch: Political life goes on beyond the big thre
e: Today: The Greens9/Lucy WardCKC/1/DNN3I+2/2/134/11431/6S/Comment & Analysis: 
Election 2001: Our commentators enter the euro fray from the just-say-no left an
d the dithering middle ground while Roy Hattersley congratulates Blair on coming
 clean: It's about democracyB/Gary YoungeCKE/1/DNN3I+2/2/133/8131/7H/Comment & A
nalysis: Election 2001 Our commentators enter the euro fray from the just-say-no
 left and the dithering middle ground while Roy Hattersley congratulates Blair o
n coming clean: Endpiece: A Labour win means we'll go inE/Roy HattersleyCKG/1/DN
N3I+2/2/143/8631/40/Comment & Analysis: Fundamentally wrong: A Muslim campaign a
gainst a group of pro-Israel Labour MPs is deeply disturbingJ/Geoffrey Wheatcrof
tCNE/1/DNN6O+2/2/163/2951/6S/Election 2001: 2-minute interview: In which a polit
ician goes up against the clock on the issues of the day. This is a direct trans
cription, no tweaks, no corrections. Today: Chris Smith talks to Anne PerkinsC/A
nne PerkinsCNF/1/DNN6O+2/2/163/8581/31/Election 2001: Inside the campaign : Now 
it's getting personal - and it's just the businessI/Jonathan FreedlandCNH/1/DNN6
O+2/2/113/6701/2B/Election 2001: Sketch : Coloured foam, cotton wool, and a plas
tic heartD/Simon HoggartCNJ/1/DNN6O+2/2/123/7041/4T/Election 2001: Tories predic
t 'rigged' euro vote: 'Discretionary' referendum would be a cheat and voters mus
t be given a clear-cut choice, says Maude10/Nicholas Watt and Anne PerkinsCNK/1/
DNN6O+2/2/123/3071/63/Election 2001: Truthwatch: Justified claim, tweaking the f
igures or outrageous lie? Alan Travis gives his verdict on the latest big statem
ent from the parties Today Voting on the euroB/Alan TravisCNL/1/DNN6O+2/2/134/10
061/64/Election 2001: Relaxed, nice, funny, honest - is this really the way to w
in votes?: Campaign trail: Charles Kennedy comes over as the soul of affability,
 but that might have a downsideC/Kirsty ScottCNM/1/DNN6O+2/2/144/12841/6J/Electi
on 2001: Tiptoeing into the minefield: Analysis: Privatisation: This has emerged
 as one of the key election issues. Patrick Wintour examines the IPPR case for g
reater private sector involvementF/Patrick WintourCNP/1/DNN6O+2/2/153/4591/1T/El
ection 2001: Blair's local council set to reject refugeesI/Peter HetheringtonCNQ
/1/DNN6O+2/2/153/3601/3E/Election 2001: Party watch: Political life goes on beyo
nd the big three Today The British National partyE/Tania BraniganCNR/1/DNN6O+2/2
/163/5301/2N/Election 2001: Predictability rules as Sunday papers bring up the r
ear: Press watchE/Roy GreensladeCNT/1/DNN6O+2/2/163/3181/1R/Election 2001: Why I
 wish I was voting Green UA FanthorpeI/poet, UA FanthorpeCO3/1/DNN6O+2/2/183/800
1/30/Election 2001: Campaign day : In soggy Blackpool and sunny Llandudno, the s
how must go on:D/Stuart MillarCQN/1/DNNA+3/2/133/6091/4B/Election 2001: Labour a
ttacks 'Thatcher in a wig': Tory leader is focus of poster launch but Millbank d
enies personalising campaign10/Michael White Political editorCQR/1/DNNA+3/2/143/
6051/4D/Election 2001: Dancing to the tune of Mission Impossible - the Tory camp
aign: Central office upbeat as it prepares for the inevitable17/Nicholas Watt Po
litical correspondentCR0/1/DNNA+3/2/154/10911/57/Election 2001: Something of the
 knight about him: Matthew Engel is visiting key constituencies in the campaign:
 Today: Michael Howard in Folkestone and HytheD/Matthew EngelCR1/1/DNNA+3/2/163/
6351/6A/Election 2001: Labour's business manifesto: Blair pledge to make big tak
eovers easier: PM takes pride in close relationship with private sector but unio
n leaders call for improved job rightsD/Kevin MaguireCR3/1/DNNA+3/2/163/2371/1Q/
Election 2001: Backer warns Tories of 'one issue' danger13/Charlotte Denny and D
avid TeatherCR5/1/DNNA+3/2/183/8361/2I/Election 2001: Inside the campaign: Labou
r has swallowed too many City lunchesB/Paul MurphyCR6/1/DNNA+3/2/183/5351/2J/Ele
ction 2001: Radio watch: Not-so-Spanish inquisition from realm of cyberspaceB/Ma
rk LawsonCRA/1/DNNA+3/2/193/3981/24/Election 2001: Care plight costs homes of 70
,000, claim Lib Dems17/Nicholas Watt Political correspondentCRC/1/DNNA+3/2/193/6
271/31/Election 2001: Campaign day: Freudian slips, bookies' wisdom, and a luckl
ess school reunionD/Stuart MillarCRD/1/DNNA+3/2/214/11221/4P/Comment & Analysis:
 Steady Tony: Blair has no radical heart. His next term will be as gradualist as
 his first, and that's why he's such a successD/Polly ToynbeeCRF/1/DNNA+3/2/223/
8261/4D/Comment & Analysis: Election watch: What a promising start: The Tories a
re already colluding in their own defeat in a euro referendumA/Hugo YoungD01/1/D
NND6+2/2/153/6771/3T/Election 2001: Blair pledge to stem 'yob attacks' on public
 staff: Tough plans include ban on some parents from schoolsE/Ewen MacAskillD03/
1/DNND6+2/2/153/6651/28/Election 2001: Hague shows the strain as new polls deepe
n Tory gloom17/Nicholas Watt Political correspondentD07/1/DNND6+2/2/163/3221/1N/
Election 2001: Brown throws weight behind regionalism1C/Peter Hetherington Regio
nal affairs editorD08/1/DNND6+2/2/174/12381/5I/Election 2001: A decent fellow le
ading a lost cause: Richard Williams sees the crowds come out for William Hague 
- but the mood can only be said to be muted and subduedG/Richard WilliamsD0A/1/D
NND6+2/2/183/8921/4O/Election 2001: Analysis: Drug firms: Chancellor delivers mo
ral message on killer diseases: Brown puts in pounds 75m but UN fund falls well 
shortR/Sarah Boseley Health editorD0B/1/DNND6+2/2/194/10361/3E/Election 2001: Gr
eens: Long bus ride to distant destination: Realistic idealists keep ambitions i
n check13/Lucy Ward Political correspondentD0D/1/DNND6+2/2/193/5821/1P/Election 
2001: Lib Dems and Tories battle for grey vote10/Michael White Political editorD
0N/1/DNND6+2/2/243/8351/48/Comment & Analysis: Canny voters take it personally: 
Election watch: We can easily judge Blair and Hague despite stunts and spinA/Hug
o YoungD3D/1/DNNGC+2/2/153/2641/1O/Election 2001: War of words: Labour unveils n
ew slogan13/Lucy Ward Political correspondentD3E/1/DNNGC+2/2/153/6501/30/Electio
n 2001: GPs threaten mass walkout: Mutiny may overshadow Labour offensive on hea
lth13/John Carvel Social affairs editorD3J/1/DNNGC+2/2/163/3121/1K/Election 2001
: Campbell and co in row over payoffs10/Michael White Political editorD3M/1/DNNG
C+2/2/183/3441/1K/Election 2001: Apathetic women make Labour nervousB/Alan Travi
sD3O/1/DNNGC+2/2/183/3211/1L/Election 2001: Brown rules out tax on child benefit
13/Lucy Ward Political correspondentD3P/1/DNNGC+2/2/193/9731/5H/Election 2001: M
emories linger in town that defied the doom: Luton: Despite the closure of Vauxh
all, the prospects look good for its workers - and their two Labour MPsB/Gary Yo
ungeD3R/1/DNNGC+2/2/193/2101/1S/Election 2001: Positive for England, negative fo
r ScotlandE/Ewen MacAskillD3S/1/DNNGC+2/2/203/8421/2O/Election 2001: Trimble tee
ters on the edge of moral high ground, Inside the campaignB/Rosie CowanD3T/1/DNN
GC+2/2/203/8201/2O/Election 2001: TV watch: Skill that should be taught at a nig
ht school for comediansB/Mark LawsonD40/1/DNNGC+2/2/203/3651/1L/Election 2001: T
he debate nobody wants: Food safetyC/James MeikleD45/1/DNNGC+2/2/234/11521/43/Co
mment & Analysis: Snooker the Tories: Take a shot at tactical voting and send a 
message about proportional representationD/Polly ToynbeeD46/1/DNNGC+2/2/243/8441
/4H/Comment & Analysis: We too have twisted the truth: Election watch: Journalis
ts have spent too long on a party that doesn't stand a chanceA/Hugo YoungD47/1/D
NNGC+2/2/253/6001/2F/Leader: Mr Blair's other election: Fresh divisions loom in 
Northern Ireland1/ D6M/1/DNNQ+3/2/113/6631/2R/Election 2001: Tories attack 'smug
' Blair: Hague steps up warning over Labour landslide16/Anne Perkins Political c
orrespondentD6N/1/DNNQ+3/2/114/10361/4Q/Election 2001: Dr Jokey and Mr Hidebound
: Matthew Engel is watching how key players in the election perform on their own
 patch Today: Gordon BrownD/Matthew EngelD6Q/1/DNNQ+3/2/123/5581/1H/Election 200
1: Panorama backs down on NHS claim15/Anne Perkins Political correspondenD6T/1/D
NNQ+3/2/143/4471/3I/Election 2001: Portillo's pension payments warning: Brown wi
ll tax contributions of better-off, claim Tories10/Michael White Political edito
rD70/1/DNNQ+3/2/143/2451/1M/Election 2001: SNP leader makes pitch for grey votes
1/ D71/1/DNNQ+3/2/143/4921/21/Election 2001: Scottish Tories prepare to split fr
om UK partyD/Gerard SeenanD72/1/DNNQ+3/2/153/6441/2F/Election 2001: Sketch: Hats
 off to Soames, off-message but in majestic formD/Simon HoggartD74/1/DNNQ+3/2/16
3/5521/2J/Election 2001: Thin pickings, and not much creative juice on the side:
 Ad watchD/Tony BrignullD75/1/DNNQ+3/2/163/4851/1H/Election 2001: The debate nob
ody wants The Dome9/Lucy WardD77/1/DNNQ+3/2/173/6291/43/Election 2001: Broadshee
ts soldier on as tabloids wilt: Analysis: The media: Coverage dominated by a nar
row range of issues10/Peter Golding and David DeaconD7A/1/DNNQ+3/2/173/4361/14/E
lection 2001: What the papers say1/ D7B/1/DNNQ+3/2/183/9371/2S/Election 2001: Ca
mpaign day: Heard the one about the nun, the bishop and Ann Widdecombe?H/Martin 
WainwrightD7E/1/DNNQ+3/2/224/11651/4B/Comment & Analysis: Now Gordon Brown must 
be moved to another job: Trouble is guaranteed as long as he is glowering in the
 TreasuryD/Peter PrestonD7F/1/DNNQ+3/2/223/8171/3L/Comment & Analysis: Endpiece:
 Blair, the philosopher king: He has thrown Locke, Mill and Marx out of the wind
owE/Roy HattersleyD7G/1/DNNQ+3/2/223/7871/4J/Comment & Analysis: If you want a p
eerage, join the Lib Dems: Why create 24 new peers a week before the election? A
nd who are they, anyway?A/Ian AitkenDA4/1/DNNT6+2/2/133/6291/37/Election 2001: V
ictory is not in the bag - Blair: Media reports of landslide prompt turnout fear
sS/Ewen MacAskill and Lucy WardDA5/1/DNNT6+2/2/133/9141/4T/Election 2001: Blesse
d are the Real People: Matthew Engel spends the final campaign days with the lea
ders of the main parties: Today: Charles KennedyD/Matthew EngelDA8/1/DNNT6+2/2/1
43/4531/1F/Election 2001: Hague plays on landslide fears17/Nicholas Watt Politic
al correspondentDA9/1/DNNT6+2/2/143/4241/1I/Election 2001: Former Tory minister 
joins Labour16/Anne Perkins Political correspondentDAB/1/DNNT6+2/2/154/12181/5B/
Election 2001: How politics can tip the scales of justice: Analysis: Crime: Pena
l policy is often made more for political than rational reasons based on evidenc
eA/Mike HoughDAC/1/DNNT6+2/2/163/3891/1O/Election 2001: Brown blocks plan to rai
se minimum wage1F/Patrick Wintour Chief political correspondentDAD/1/DNNT6+2/2/1
63/3981/1F/Election 2001: Stop extremists, Trimble urges13/Rosie Cowan Ireland c
orrespondentDAG/1/DNNT6+2/2/183/8621/2T/Election 2001: Inside the campaign: Doub
le vision of two-timing voters in local electionsI/Peter HetheringtonDAM/1/DNNT6
+2/2/193/2441/28/Election 2001: We will take fresh look at Act of Settlement, sa
ys PMD/Gerard SeenanDAP/1/DNNT6+2/2/213/8041/16/Comment & Analysis: Passion poli
ticsA/Ros CowardDAR/1/DNNT6+2/2/223/8791/24/Comment & Analysis: I'm embarrassed 
to be a Tory: From the rightE/Minette MarrinDDG/1/DNO2C+2/2/143/5491/2C/Election
 2001: Hague reopens school choice row in attack on 'rattled' PM17/Nicholas Watt
 Political correspondentDDI/1/DNO2C+2/2/154/18071/66/Election 2001: Analysis: Ta
ctical voting: Switching sides: the key seats where it will make a difference: I
t magnified the Tory humiliation in 1997. But what part will it play this time?C
/David WalkerDDJ/1/DNO2C+2/2/163/5691/3Q/Election 2001: Kennedy pledges a 'voice
 for voiceless': Lib Dem focus moves to global issues and plan for opposition13/
Lucy Ward Political correspondentDDL/1/DNO2C+2/2/173/8121/4T/Election 2001: Prom
otion: Blunkett tenses for the next challenge: Minister poised to become home se
cretary says he will not lose touch with his rootsB/Gary YoungeDDM/1/DNO2C+2/2/1
63/2071/1N/Election 2001: Study finds health risk in Labour vote14/John Carvel, 
Social Affairs editorDDN/1/DNO2C+2/2/173/2721/6I/Election 2001: Truth watch: Jus
tified claim, tweaking the figures or outrageous lie? David Walker gives his ver
dict on the latest big statement from the parties: Today: Labour landslide, Trut
h watchC/David WalkerDDQ/1/DNO2C+2/2/183/3511/1K/Election 2001: The debate nobod
y wants...: CultureC/Dan GlaisterDDS/1/DNO2C+2/2/193/5741/3T/Election 2001: Vaz 
faces new claims over pounds 400,000 flats: Blair dismisses questions on ministe
r as 'extraordinary'18/David Hencke Westminster correspondentDDT/1/DNO2C+2/2/193
/3021/1L/Election 2001: Byers persuades EU to ease aid rules1H/Patrick Wintour a
nd Andrew Osborn in LuxembourgDE1/1/DNO2C+2/2/214/11751/52/Comment & Analysis: I
t's the poor that matter: A protest vote against a government that has done so m
uch to alleviate poverty is supreme self-indulgenceD/Polly ToynbeeDE6/1/DNO2C+2/
2/193/3911/1E/Election 2001: Big fall in Labour membershipD/Kevin MaguireDGN/1/D
NO5I+2/2/153/6851/3C/Election 2001: Blair tends Labour roots: PM ends campaign o
n upbeat note among supporters in the northE/Ewen MacAskillDGO/1/DNO5I+2/2/153/4
381/1Q/Election 2001: Last stop for Labour's election battlebusE/Ewen MacAskillD
GS/1/DNO5I+2/2/173/5731/56/Election 2001: Hague: Our forces are on the march: Sh
adow cabinet members deliver articles of faith in eve of poll demonstration rall
ying round party leaderD/Nicholas WattDGT/1/DNO5I+2/2/173/3451/1Q/Election 2001:
 Save the pound group attacks Tory tactics1F/Patrick Wintour Chief political cor
respondentDH0/1/DNO5I+2/2/173/4271/2C/Election 2001: Final opinion polls point t
o increased majority for Blair11/Alan Travis Home affairs editorDH2/1/DNO5I+2/2/
203/8081/22/Election 2001: TV watch: Long debate comes down to micro moansB/Mark
 LawsonDH3/1/DNO5I+2/2/203/5191/14/Election 2001: What the papers say1/ DH5/1/DN
O5I+2/2/203/3711/1A/Election 2001: Abstainers grow in numberD/Kevin MaguireDH7/1
/DNO5I+2/2/223/7831/35/Election 2001: Campaign day: A life less comfortable as p
arties trundle on to the back straightD/Stuart MillarDH8/1/DNO5I+2/2/234/11441/4
K/Comment & Analysis: Cardboard characters: So wary are the party leaders of say
ing anything honest that they turned this election into a boreI/Jonathan Freedla
ndDHA/1/DNO5I+2/2/244/10481/56/Comment & Analysis: White Labour politicians are 
certainly smoother now: New Labour worthies are now more or less at their ease e
ncountering black strangersD/Mike PhillipsDHB/1/DNO5I+2/2/253/5931/2D/Leading ar
ticle: Tell it like it is: A second-term priority: no more spin1/ DHC/1/DNO5I+2/
2/253/3211/2E/Leading article: Bucking the swing: Some MPs deserve saving; other
s do not1/ MA0/2/DNL2O+2/2/133/5491/17/Law bars Cherie from war of the wives11/H
elen Rumbelow and Melissa KiteMA1/2/DNL2O+2/2/123/4101/13/Trimble to quit if IRA
 keeps arms1G/Christopher Walker Chief Ireland CorrespondentMA6/2/DNL2O+2/2/093/
5841/1I/No applause for leading man in tacky school playD/Peter RiddellMA8/2/DNL
2O+2/2/104/15601/1B/Why the regions will be in the front line9/Tim HamesMAB/2/DN
L2O+2/2/123/1801/14/Cook takes hold of European agenda18/James Landale and Allan
 Hall in BerlinMAD/2/DNL2O+2/2/133/5991/1E/Hague takes his soapbox to date with 
destiny16/Melissa Kite Political CorrespondentMAF/2/DNL2O+2/2/183/9771/1D/Roll u
p for the most exciting election everB/Alice MilesMAG/2/DNL2O+2/2/184/14051/18/A
 passionate vote for the Apathy PartyD/Simon JenkinsMAH/2/DNL2O+2/2/093/4131/R/Q
ueen to forgo day at AscotT/Tom Baldwin and Andrew PierceMDB/2/DNL6+3/2/093/7281
/17/Blair trails on points in final roundE/Matthew ParrisMDI/2/DNL6+3/2/103/5191
/17/Blair was warned by MI6 over Hindujas13/Dominic Kennedy and Roland WatsonMDJ
/2/DNL6+3/2/103/5341/1D/Pledge card trumped by dead hand of realityB/Alice Miles
MDK/2/DNL6+3/2/103/3581/1E/'No deal' to hand Brown the party leadershipE/Philip 
WebsterMDL/2/DNL6+3/2/113/2511/15/Greens show they hold the whip hand8/Tim ReidM
DM/2/DNL6+3/2/113/3981/1L/Fleet Street's finest save unkindest cuts for HagueF/B
rian MacArthurMDP/2/DNL6+3/2/113/5701/1K/Tory defector in line for safe seat aft
er MP quitsB/Tom BaldwinMGL/2/DNL96+2/2/113/1821/I/Portillo's pledges1/ MGN/2/DN
L96+2/2/132/501/11/Waiting lists 'increase by 61%'1/ MGO/2/DNL96+2/2/143/6241/11
/Tories wilt in Oxford hothousesH/Mary Ann SieghartMGR/2/DNL96+2/2/093/7201/16/A
 vision to pacify the bean countersG/Anatole KaletskyMGS/2/DNL96+2/2/093/6121/1D
/Noddy meets Kafka in a tale of two BritainsD/Ben MacintyreMH1/2/DNL96+2/2/103/1
361/T/Scepticism gets the fuel voteF/Valerie ElliottMH2/2/DNL96+2/2/103/1341/Q/S
ingle issues get the voteF/Alexandra FreanMH6/2/DNL96+2/2/133/6431/17/St Helens 
prepares to tackle defector18/Damian Whitworth in Thatto Labour ClubMH8/2/DNL96+
2/2/132/501/10/Hackers aim for Internet chaos1/ MH9/2/DNL96+2/2/093/5911/19/Puzz
led by the rubric of William's cubeE/Matthew ParrisMK9/2/DNLIO+2/2/073/2671/19/G
inger changes sides to spice up LabourH/Nicholas WapshottMNC/2/DNLM+3/2/133/5351
/1C/... as Doris stalks the Prince of Darkness10/Damian Whitworth in HartlepoolM
ND/2/DNLM+3/2/173/4271/F/Electoral Spice1/ MNG/2/DNLM+3/2/163/9701/1A/The leader
 of a far too loyal oppositionC/Michael GoveMNH/2/DNLM+3/2/143/5511/14/It all ad
ds up to the numbers gameD/Peter RiddellMNJ/2/DNLM+3/2/043/2181/14/Hindujas to a
void election troubleO/Stephen Farrell in DelhiMNK/2/DNLM+3/2/133/6371/12/Iron L
ady shops for Tory victoryD/Andrew PierceMNM/2/DNLM+3/2/133/3461/12/Welsh launch
 lost in translation17/Melissa Kite, Political CorrespondentMNN/2/DNLM+3/2/143/1
071/G/Bankers' verdictC/Lea PatersonMNP/2/DNLM+3/2/143/2691/1E/Humphrys has spot
 of pure fun hounding BlairH/Nicholas WapshottMNQ/2/DNLM+3/2/143/1471/11/Defecto
r tipped for high officeD/Roland WatsonMNS/2/DNLM+3/2/153/5271/1C/Blair rings ch
anges at No 10 to beat Brown16/Tom Baldwin, Deputy Political EditorMO0/2/DNLM+3/
2/153/2921/19/Kennedy takes his secret weapon on tourA/Greg HurstMO2/2/DNLM+3/2/
153/1201/19/Bell has 'no hope' of winning Tory seat1/ MO3/2/DNLM+3/2/163/7871/2A
/Why captains of industry are less keen to sign on Labour's dotted lineJ/Patienc
e WheatcroftMO4/2/DNLM+3/2/143/6471/1I/Tory tax tangle gives Hague Pounds 12bn h
eadache1O/Tom Baldwin Roland Watson, Sam Lister and Melissa KiteMQT/2/DNLP6+2/2/
123/6021/1C/Cockney market forces drive Ginger bananasE/Matthew ParrisMR0/2/DNLP
6+2/2/134/23581/15/Kennedy makes honesty his watchword1/ MR1/2/DNLP6+2/2/133/265
1/11/Electoral reform gets few votesA/Sam CoatesMR2/2/DNLP6+2/2/143/6431/1I/Port
illo tries to repair damage to Tory tax plan25/Philip Webster Political Editor a
nd Lea Paterson Economics EditorMR3/2/DNLP6+2/2/143/1291/14/Balls joins Brown fo
r the campaignE/Philip WebsterMR4/2/DNLP6+2/2/143/6021/1B/Invisible man Letwin g
ives press the slip15/Tom Baldwin Deputy Political EditorMR6/2/DNLP6+2/2/153/600
1/1C/Tory broadcast blames Labour for two rapes1O/Melissa Kite, Political Corres
pondent and Adam SherwinMRD/2/DNLP6+2/2/113/5351/11/Just don't read the small pr
intD/Peter RiddellN02/2/DNLSC+2/2/143/5241/1I/Manifesto strong on the what but t
hin on the howD/Peter RiddellN03/2/DNLSC+2/2/173/8901/19/A craven audience at co
urt of King TonyE/Matthew ParrisN08/2/DNLSC+2/2/023/3031/11/Yard reviews guard o
n ministersF/Stewart TendlerN0C/2/DNLSC+2/2/154/17161/1T/'The NHS has to earn th
e confidence of each new generation'1/ N0E/2/DNLSC+2/2/153/4601/1B/Policy fudge 
leaves bitter taste in mouth23/Roland Watson Chief Political Correspondent and S
tewart TendlerN0H/2/DNLSC+2/2/183/3551/17/New Kennedy conspiracy theory is bornH
/Nicholas WapshottN0N/2/DNLSC+2/2/193/4181/1C/Lib Dems make legal threat on euro
 leafletD/Andrew PierceN3B/2/DNM1I+2/2/103/2181/16/No Extra security for Prime M
inister17/James Landale Political CorrespondentN3C/2/DNM1I+2/2/193/6361/I/Pressi
ng the flesh1/ N3E/2/DNM1I+2/2/183/9771/1F/Next time will be much more like the 
old daysH/Mary Ann SieghartN3H/2/DNM1I+2/2/094/13301/17/The punch that sent them
 all spinning1E/Roland Watson Tom Baldwin and Philip WebsterN3K/2/DNM1I+2/2/103/
3441/17/'Raging Bull' fans flames of interestH/Nicholas WapshottN3M/2/DNM1I+2/2/
113/2791/16/Straw stings police into new protest15/Stewart Tendler Crime Corresp
ondentN3N/2/DNM1I+2/2/123/6431/1J/It must be being so cheerful that keeps him go
ingE/Matthew ParrisN3P/2/DNM1I+2/2/123/5101/18/Hague puts off our voters, admits
 ToryD/Andrew PierceN3Q/2/DNM1I+2/2/143/5681/1F/Blair hospital cleared in six ho
urs by report11/David Charter and Oliver WrightN40/2/DNM1I+2/2/143/2591/T/Nurse 
wipes floor with LabourD/David CharterN6L/2/DNMB6+2/2/083/2871/14/Tories to focu
s on euro and asylumQ/Tom Baldwin and Greg HurstN6O/2/DNMB6+2/2/103/3081/14/Ex-a
ide 'confirms' leadership pactA/Greg HurstN6P/2/DNMB6+2/2/093/7971/1P/Man in whi
te seeks forces of darkness, Damian Whitworth1/ N6S/2/DNMB6+2/2/073/9341/18/Cric
ket fans say Hague fails race testD/Ben MacintyreN73/2/DNMB6+2/2/103/5721/1A/Bro
wn refuses to be drawn on tax detailsE/Philip WebsterN75/2/DNMB6+2/2/083/6901/1E
/'Voters believe Europe is all we care about'D/James LandaleNA1/2/DNMEC+2/2/123/
3221/M/'Prepare for 50% rate'C/Helen NugentNA2/2/DNMEC+2/2/133/1501/P/Unionist m
anifesto leaked1G/Christopher Walker Chief Ireland CorrespondentNA6/2/DNMEC+2/2/
113/5831/15/Late starter Clarke dodges questionR/Ben Macintyre in NottinghamNA7/
2/DNMEC+2/2/113/5521/1N/... as elusive Vaz surfaces a bit glazed and confused11/
Oliver Wright in Leicester EastNAB/2/DNMEC+2/2/133/5911/1A/Marginal differences 
help make crime payG/Damian WhitworthNAC/2/DNMEC+2/2/144/13401/1D/Scrap the batt
le-buses and vote for boredomC/Libby PurvesNAD/2/DNMEC+2/2/133/2601/1B/Heath ref
uses to lend Tory leader support1D/Roland Watson Chief Political CorrespondentNA
G/2/DNMEC+2/2/153/6281/H/Smoke and mirrors1/ NAH/2/DNMEC+2/2/133/1441/15/Refugee
s denounce Hague as 'Hitler'16/Melissa Kite Political CorrespondentNDB/2/DNMHI+2
/2/023/4211/10/Hague's whisky swayed ThatcherD/Andrew PierceNDG/2/DNMHI+2/2/023/
8211/15/'Above all, we must keep the pound'1/ NDH/2/DNMHI+2/2/153/5481/1G/Party 
chiefs try to blur Scottish battle linesD/Peter RiddellNDK/2/DNMHI+2/2/163/5571/
1F/Blair in retreat after shooting the messenger1K/Philip Webster Political Edit
or and Andrew NorfolkNDN/2/DNMHI+2/2/173/2401/R/Blockbuster appeal on tellyH/Nic
holas WapshottNDO/2/DNMHI+2/2/173/5681/1B/A transport of delight in the Widdecop
terE/Matthew ParrisNDP/2/DNMHI+2/2/183/9721/1B/Can you tell the medium from the 
message?B/Alice MilesNDR/2/DNMHI+2/2/193/5341/N/The vote is in the post1/ NGL/2/
DNMKO+2/2/143/8861/1J/Tories face close call in marginal Midlands seatsH/William
 Rees-MoggNGQ/2/DNMKO+2/2/133/4681/1B/How Blair babes have faded out of pictureR
/Jill Sherman and Greg HurstNGT/2/DNMKO+2/2/153/7211/15/Dome cheats Tory out of 
amazing dayE/Matthew ParrisNH0/2/DNMKO+2/2/153/6261/19/Mackinlay gives Mondeo ma
n both barrelsG/Damian WhitworthNH1/2/DNMKO+2/2/163/5671/1I/Brussels rejects 'sc
aremongering' Tory tax claim23/Philip Webster, Roland Watson, David Lister and C
harles BremnerNH4/2/DNMKO+2/2/184/14171/1D/Who should we blame for this dire ele
ction?G/Anatole KalestkyNH5/2/DNMKO+2/2/163/3151/1E/Portillo scores own goal on 
VAT, says LabourD/Roland WatsonNH6/2/DNMKO+2/2/173/3241/1A/Jousting knights seek
 polling Holy GrailD/Ben MacintyreNK3/2/DNMO+3/2/153/4251/1A/Ice cream? We'd rat
her you flew the flagK/Benedict NightingaleNK6/2/DNMO+3/2/163/3561/O/Tory does E
urope his wayG/Damian WhitworthNK8/2/DNMO+3/2/173/7141/16/A prophet finds honour
 in his countyE/Matthew ParrisNKA/2/DNMO+3/2/173/3431/1N/One party political adv
ert you'll see again and againH/Nicholas WapshottNKB/2/DNMO+3/2/173/1361/S/Labou
r ejects Woodward rebel15/Tom Baldwin Deputy Political EditorNKD/2/DNMO+3/2/183/
4601/19/Local hero at centre of policing debateQ/Andrew Norfolk in the FensNKG/2
/DNMO+3/2/193/5111/18/Kennedy strives to master his own glenG/Magnus LinklaterNK
I/2/DNMO+3/2/204/13241/17/Hague wins the sense of humour battleD/Simon JenkinsNK
J/2/DNMO+3/2/203/7901/2F/Amid the platoons with a passion for politics lurk the 
noble awkward squadsD/Philip HowardNNE/2/DNN3I+2/2/113/4561/1E/Leo's debut bring
s out Our Tone's human sideH/Nicholas WapshottNNG/2/DNN3I+2/2/123/5031/1H/Lib De
ms claim they will be the real OppositionB/Tom BaldwinNNH/2/DNN3I+2/2/123/2861/1
8/British ballot 'violates human rights'C/Frances GibbNNM/2/DNN3I+2/2/133/4541/1
C/Great spotted optimist is rare Labour birdG/Damian WhitworthNNN/2/DNN3I+2/2/13
3/3981/T/The acceptable faces of powerE/Mark HendersonNNO/2/DNN3I+2/2/133/1751/1
7/Millbank to play personality politicsD/Roland WatsonNNP/2/DNN3I+2/2/144/13741/
1D/Don't be fooled - this is the euro electionH/William Rees-MoggNQL/2/DNN6O+2/2
/133/6791/D/French lesson1/ NQP/2/DNN6O+2/2/023/5371/1C/The real rift in Europe 
is not the ChannelD/Peter RiddellNQR/2/DNN6O+2/2/063/5541/1H/Trimble faces gospe
l of the abominable 'No men'1H/Christopher Walker, Chief Ireland CorrespondentNQ
S/2/DNN6O+2/2/073/6931/1I/Tiny Haystacks refuses to submit on count of 238E/Matt
hew ParrisNQT/2/DNN6O+2/2/073/5391/1M/Modern barons of Runnymede battle over tra
ffic noiseG/Damian WhitworthNR1/2/DNN6O+2/2/083/8341/1K/Race runs through politi
cs like veins in eel fleshT/Ben Macintyre In the East EndO03/2/DNNA+3/2/083/5451
/1K/Tory Left attacks party obsession with race debate16/Tom Baldwin, Deputy Pol
itical EditorO06/2/DNNA+3/2/093/6821/1G/Valleys offer half a chance to half a We
lshmanD/Ben MacintyreO09/2/DNNA+3/2/103/5401/1C/Corporate joy bedevilled by lack
 of detailJ/Patience WheatcroftO0B/2/DNNA+3/2/143/9931/1B/A vote that Blair can 
neither rig nor win9/Tim HamesO3C/2/DNND6+2/2/023/6051/T/'No charges for elderly
 care'14/David Charter Health CorrespondentO3F/2/DNND6+2/2/133/3981/19/Tories wo
uld lose most in tactical vote9/Tim HamesO3G/2/DNND6+2/2/143/4451/19/Poll gives 
Lib Dems boost in confidenceD/Peter RiddellO3H/2/DNND6+2/2/143/3141/17/Kennedy p
repares for a final flourishA/Greg HurstO3I/2/DNND6+2/2/143/3421/1C/Labour loses
 from change to polling methodD/Peter RiddellO3L/2/DNND6+2/2/153/2191/15/Somethi
ng must be done, says victimD/Oliver WrightO3M/2/DNND6+2/2/153/5771/19/How to sp
ot when fingers do the talkingD/Ben MacintyreO3N/2/DNND6+2/2/163/6011/1I/Portill
o takes a lead in keeping the ship steady11/Philip Webster Political EditorO3O/2
/DNND6+2/2/163/3031/16/Tory puts faith in the late swingers12/James Landale and 
Helen RumbelowO3P/2/DNND6+2/2/163/4071/1N/Silence in the jungle means there's a 
big beast about15/Tom Baldwin Deputy Political EditorO3S/2/DNND6+2/2/173/4171/1G
/Just one opportunity to enter euro, says Blair1E/Philip Webster Melissa Kite an
d David ListerO40/2/DNND6+2/2/183/9661/1C/For those of you who have just woken u
p...B/Alice MilesO41/2/DNND6+2/2/184/13491/12/The euro bomb is already tickingG/
Anatole KaletskyO6N/2/DNNGC+2/2/094/20451/1E/Will this Napoleon risk all to unit
e Europe?E/Peter StothardO6P/2/DNNGC+2/2/103/4181/1B/Voters believe Labour will 
increase taxesD/Peter RiddellO6R/2/DNNGC+2/2/113/6911/12/Old bear makes a meal o
f supportE/Matthew ParrisO6T/2/DNNGC+2/2/113/1461/13/Blair under dual attack on 
health16/Melissa Kite Political CorrespondentO70/2/DNNGC+2/2/123/5401/17/Missing
, presumed gagged: the CabinetT/Roland Watson and Tom BaldwinO73/2/DNNGC+2/2/133
/5371/1D/Tories ease up on euro in face of landslide10/Philip Webster and Tom Ba
ldwinO76/2/DNNGC+2/2/193/6161/F/Labour's health1/ OA2/2/DNNQ+3/2/023/5191/14/Pan
orama wrong on NHS, says LabourC/Nigel HawkesOA4/2/DNNQ+3/2/073/2511/13/Rain for
ecast to hit poll turnoutA/Sam ListerOA8/2/DNNQ+3/2/083/2681/13/Brown rejects EU
 tax liaison roleE/Philip WebsterOA9/2/DNNQ+3/2/093/5271/16/Red rose blooms in C
onstable countryC/Adam SherwinOAA/2/DNNQ+3/2/093/1691/16/Soap stars help Blair w
oo young voteD/James LandaleODD/2/DNNT6+2/2/073/8511/17/Labour's heartlands put 
to Royle testB/Alice MilesODG/2/DNNT6+2/2/083/2941/12/Points decision for Paxo v
 BlairH/Nicholas WapshottODI/2/DNNT6+2/2/093/5221/17/Women on verge of a nervous
 countdownE/Matthew ParrisODJ/2/DNNT6+2/2/093/2331/15/Blair dismisses PR voting 
as unfairS/James Landale and Greg HurstODM/2/DNNT6+2/2/103/6511/1G/Why Scotland 
enjoys a better class of electionH/William Rees-MoggODN/2/DNNT6+2/2/103/3461/1A/
Wishart rocks glens with anti-Tory riffsG/Damian WhitworthODO/2/DNNT6+2/2/143/96
51/17/Why kick the Tory dog when it's down?C/Michael GoveOGP/2/DNO2C+2/2/093/409
1/1C/Soap stars spell it out in final countdownE/Helen RumbelowOGQ/2/DNO2C+2/2/1
03/5321/1A/Olive oil voters may drizzle to Lib DemsQ/Ben Macintyre In IslingtonO
H2/2/DNO2C+2/2/123/4671/1B/Labour defends Vaz over new sleaze claimsB/Tom Baldwi
nOH5/2/DNO2C+2/2/123/6961/17/The match facts of political football1/ OH6/2/DNO2C
+2/2/163/9661/1C/Tories face a decade out in the wildernessB/Alice MilesOH7/2/DN
O2C+2/2/164/14201/18/Democracy is about more than electionsD/Simon JenkinsOH8/2/
DNO2C+2/2/163/7881/22/You can count me out of this campaign - it's just a mug's 
gameA/Alan CorenOH9/2/DNO2C+2/2/113/2901/1I/Blair says it's time to shake of leg
acy of 1980sD/James LandaleOK4/2/DNO5I+2/2/103/5021/1Q/Stay-aways 'dishonour Bri
tain's war dead' Tony's travels18/James Landale, Political CorrespondentOK7/2/DN
O5I+2/2/113/9671/1H/Defeat may leave Hague facing his own exit poll10/Tom Baldwi
n and Philip WebsterOK9/2/DNO5I+2/2/123/4631/1D/Main players leave Lib Dems to s
core freelyA/Greg HurstOKA/2/DNO5I+2/2/123/6781/17/Devon Tories dig in to repel 
invasionN/Ben Macintyre In TotnesOKD/2/DNO5I+2/2/143/4131/T/Health matters most 
to votersD/Peter RiddellOKG/2/DNO5I+2/2/143/3731/14/Pundits make their final for
ecastsE/Helen RumbelowOKK/2/DNO5I+2/2/183/7881/2B/After weeks of political forep
lay, there's nothing to beat the joy of xH/Mary Ann SieghartOKL/2/DNO5I+2/2/193/
6351/A/Vote today1/ 13DB/3/DNL2O+2/2/053/1521/17/Key question for Downing Street
 aides16/Sarah Womack Political Correspondent13DC/3/DNL2O+2/2/053/5231/1G/Hague 
on his soapbox targets 'the real people'18/Andrew Sparrow Political Corresponden
t13DF/3/DNL2O+2/2/063/4421/14/Cook signs Left's blueprint for EUJ/Toby Helm in B
erlin13DH/3/DNL2O+2/2/043/5161/1R/Backbenchers are promised another free vote on
 foxhuntingG/Rachel Sylvester13DJ/3/DNL2O+2/2/043/8421/18/Spin doctors send Blai
r back to schoolT/George Jones Political Editor13DN/3/DNL2O+2/2/233/8291/H/Make 
a difference1/ 13GL/3/DNL6+3/2/053/6721/14/Speech at school rebounds on Blair10/
Andy McSmith and Liz Lightfoot13GM/3/DNL6+3/2/043/3551/1D/Blair vows not to rais
e tax on high earners19/Benedict Brogan Political Correspondent13GP/3/DNL6+3/2/2
33/9641/2F/Last blast of the trumpet (as I think I said last time) The Thursday 
columnD/Boris Johnson13GQ/3/DNL6+3/2/053/2141/1E/Tories plan to lock up 12-year-
old offendersG/Rachel Sylvester13GS/3/DNL6+3/2/043/7121/18/Tories chip away at L
abour's poll leadC/Anthony King13H0/3/DNL6+3/2/224/10501/6Q/Like Kinnock in Shef
field, Blair has betrayed himself This time a Labour leader did not foolishly pu
nch the air, but his performance at St Olave's school revealed his own worst fau
lts, writes Daniel JohnsonE/Daniel Johnson13H1/3/DNL6+3/2/043/2201/15/Doctors 'w
ithdraw support over NHS'P/Celia Hall Medical Editor13K1/3/DNL96+2/2/053/2751/10
/LIB DEMS PUT PR ON BACK BURNERE/DAVID MILLWARD13K2/3/DNL96+2/2/073/4501/1L/BLAI
R AIDE HEADS FOR SAFE SEAT AS DAVID CLARK QUITS1C/ANDY MCSMITH CHIEF POLITICAL C
ORRESPONDENT13K3/3/DNL96+2/2/063/5441/1B/MEN ONLY BANNED BY LABOUR'S GENDER AGEN
DA16/SARAH WOMACK POLITICAL CORRESPONDENT13K4/3/DNL96+2/2/123/5561/34/ABOLITION 
PLANS REMOVED FROM BILL AS POLL NEARS: COMMUNITY HEALTH COUNCILS, MICHAEL KALLEN
BACH1/ 13K6/3/DNL96+2/2/054/16201/5R/HANDING BACK POWER TO THE PEOPLE: ANDREW SP
ARROW LOOKS AT THE STRENGTHS, WEAKNESSES AND OMISSIONS IN THE CONSERVATIVES' 48-
PAGE GENERAL ELECTION MANIFESTO, TIME FOR COMMON SENSEE/ANDREW SPARROW13K8/3/DNL
96+2/2/023/6641/2A/RAGE AND RUMOUR . . . JUST LIKE THE FLIGHT FROM SAIGON: COMMO
NS SKETCHD/FRANK JOHNSON13KC/3/DNL96+2/2/123/6101/1J/BROWN AND PORTILLO CLASH OV
ER GREY VOTE: PENSIONS1G/MICHAEL KALLENBACH PARLIAMENTARY CORRESPONDENT13KD/3/DN
L96+2/2/264/10431/7A/WHY I FOR ONE AM NOT GOING TO TAKE VOTER APATHY LYING DOWN:
 TELEVISION AND RADIO'S COMMITMENT TO BALANCE IN THEIR ELECTION COVERAGE IS LARG
ELY RESPONSIBLE FOR OUR BOREDOM WITH THE POLITICAL PROCESS, SAYS ARMANDO IANNUCC
IG/ARMANDO IANNUCCI13KE/3/DNL96+2/2/273/9811/1F/COMMON SENSE SAYS: HAVE ANOTHER 
LOOK AT HAGUED/ALICE THOMSON13NC/3/DNLIO+2/2/063/3721/1C/Senior Lib Dems 'castin
g doubt on Kennedy'11/Sarah Womack and Andrew Sparrow13NG/3/DNLIO+2/2/053/2041/1
0/Leadership question unanswered12/George Jones and Benedict Brogan13NI/3/DNLIO+
2/2/053/3921/1B/Bremner's worst impressions are confirmedF/Benedict Brogan13NJ/3
/DNLIO+2/2/053/3741/1B/Hague aims for smooth ride with the press18/Andrew Sparro
w Political Correspondent13NK/3/DNLIO+2/2/063/3981/2A/God is opposed to Britain 
joining EU's single currency, says economist17/Victoria Combe Religion Correspon
dent13NN/3/DNLIO+2/2/213/5561/H/Watching Woodward1/ 13NO/3/DNLIO+2/2/073/5231/1M
/Wife of former RUC chief fights for Good Friday deal16/David Sharrock Ireland C
orrespondent13NP/3/DNLIO+2/2/053/6991/54/Blair takes his 'big idea' to heartland
 The Prime Minister returns to his North-East constituency to reject 'old-style 
socialism', reports Benedict BroganF/Benedict Brogan13QL/3/DNLM+3/2/043/2121/Q/W
elcome for Tory desertersC/Andy McSmith13QO/3/DNLM+3/2/063/7641/2P/Ethics Man du
sts down his white suit for new crusade Constituency Spotlight BrentwoodC/Sean O
'Neill13R1/3/DNLM+3/2/043/5801/1N/Blair encounters giant spin machine on Highlan
d fling19/Benedict Brogan Political Correspondent13R3/3/DNLM+3/2/073/3111/1H/Pee
rage 'bribes' to be looked at after electionG/Rachel Sylvester13RA/3/DNLM+3/2/23
3/6181/G/Purer than pure?1/ 13RC/3/DNLM+3/2/053/3771/1F/Widdecombe is scoring po
ints in rugby country16/Sarah Womack Political Correspondent1401/3/DNLP6+2/2/093
/3741/1G/Hague frees MPs to back call for EU referendum14/Andrew Sparrow and Phi
lip Johnston1402/3/DNLP6+2/2/233/5791/R/Shock: Tories want tax cuts1/ 1404/3/DNL
P6+2/2/083/6561/1L/Policies you won't read about in Labour's manifestoG/RACHEL S
YLVESTER1406/3/DNLP6+2/2/063/3111/Q/Blair's 21st century dreamT/George Jones Pol
itical Editor1409/3/DNLP6+2/2/063/3121/P/Free school plan attacked1C/Andy McSmit
h Chief Political Correspondent140C/3/DNLP6+2/2/073/2091/17/Vaz is centre of att
ention once again16/Sarah Womack Political Correspondent140D/3/DNLP6+2/2/073/969
1/1M/Ultra-Right entry unites parties in anti-racist pact8/AMIT ROY140F/3/DNLP6+
2/2/083/3021/10/Tories attack 'joke proposals'E/DAVID MILLWARD140G/3/DNLP6+2/2/0
93/5781/13/Re-arrange this well known phraseE/ANDREW SPARROW140I/3/DNLP6+2/2/223
/6981/1L/The Lib Dems' big idea: screening 'Eurotrash' laterA/DAVID HARE140K/3/D
NLP6+2/2/233/9731/1A/Pity the poor Labour voters of St Helens9/Tom Utley140M/3/D
NLP6+2/2/063/5021/3T/pounds 20 billion? It's mere pocket money for the State Por
tillo's pounds 8bn boast looks meagre, says George TrefgarneG/George Trefgarne14
3C/3/DNLSC+2/2/103/7871/2C/The pub where mole catching beats politics Constituen
cy Spotlight HexhamE/Sandra Barwick143E/3/DNLSC+2/2/023/4441/P/Prescott swings f
rom leftT/George Jones Political Editor143J/3/DNLSC+2/2/033/1301/1G/Arrest puts 
an end to Liberal man's poll fightB/Paul Stokes143K/3/DNLSC+2/2/063/7691/2B/Gran
d plan threatens to put an end to the quiet life Manifesto AnalysisC/George Jone
s143O/3/DNLSC+2/2/273/9541/47/The People are ignorant, stupid and usually wrong 
James Bartholomew blames politicians for sucking up to the foolish electorateH/J
ames Bartholomew143Q/3/DNLSC+2/2/273/5451/I/Ambition misplaced1/ 143R/3/DNLSC+2/
2/103/4081/1H/Minister faces problems after Lib Dems pull outC/Andy McSmith143S/
3/DNLSC+2/2/073/2961/12/Letwin clears up Tory tax policy10/Stewart Payne and And
y McSmith146L/3/DNM1I+2/2/043/4611/29/Blair makes a good fist of defending his d
eputy On the campaign trailF/Benedict Brogan146N/3/DNM1I+2/2/053/9901/2B/Prescot
t the Labour heavyweight v Craig Evans, the Gentle Giant of RhylC/Nigel Bunyan14
6Q/3/DNM1I+2/2/063/1481/9/StatwatchA/Erin Baker146S/3/DNM1I+2/2/023/6871/1P/Quit
 before the Las Vegas rematch, John Campaign SketchD/Frank Johnson146T/3/DNM1I+2
/2/043/4961/1D/Party hit squads are on a mission of mayhem11/Sarah Womack and An
drew Sparrow1473/3/DNM1I+2/2/063/2991/1A/Ffion's first words: 'This is hard work
'16/Sarah Womack Political Correspondent1474/3/DNM1I+2/2/063/6231/1D/Merseyside 
stalwarts rebel against Woodward1C/Andy McSmith Chief Political Correspondent147
8/3/DNM1I+2/2/273/9931/24/Suppose they threw an election and no one came The Fri
day columnD/Alice Thomson147A/3/DNM1I+2/2/273/5441/H/The clenched fist1/ 147C/3/
DNM1I+2/2/063/6651/17/Widdecombe wins over police delegates11/John Steele Crime 
Correspondent147D/3/DNM1I+2/2/073/2651/1A/Millionaire finances campaign to quit 
EUT/George Jones Political Editor147F/3/DNM1I+2/2/083/3991/12/TV stations put aw
ay stopwatchesE/Thomas Harding14A1/3/DNMB6+2/2/042/971/1A/Brittan warns Hague ov
er hostility to EUT/George Jones Political Editor14A2/3/DNMB6+2/2/234/10661/29/H
ague is fighting the right fight at the wrong time The Monday columnC/Peter Obor
ne14A4/3/DNMB6+2/2/063/3111/1J/Mandelson 'told Blair to do deal over leadership'
1C/Andy McSmith Chief Political Correspondent14A6/3/DNMB6+2/2/063/8541/2R/Safe U
nionist seat that holds key to future of Ulster Constituency Spotlight Strangfor
dE/David Sharrock14A8/3/DNMB6+2/2/043/5121/4M/Spin doctors sour battle bus relat
ions Labour is determined to press on with its media control strategy, despite c
riticism, writes Tom LeonardB/Tom Leonard14A9/3/DNMB6+2/2/043/6691/6Q/NHS is suf
fering from Labour's rhetoric, say GPs In the first of an occasional series that
 will give professionals who are trying to implement Government policy their say
, Celia Hall hears the doctors' caseA/Celia Hall14AA/3/DNMB6+2/2/043/4511/1C/Bus
iness's big guns sign up for the ToriesG/George Trefgarne14AB/3/DNMB6+2/2/073/37
71/1E/Overcoming any problems in casting your voteA/Erin Baker14AC/3/DNMB6+2/2/0
73/8751/2F/Why a poor turn-out points to a democracy in good health Electionb An
alysisC/Anthony King14AD/3/DNMB6+2/2/073/7551/1E/Hague puts euro in front line f
or final push16/Sarah Womack Political Correspondent14AE/3/DNMB6+2/2/233/4631/Q/
Labour is bad for business1/ 14AG/3/DNMB6+2/2/023/4731/N/Nurses fear NHS charges
D/Nicole Martin14AI/3/DNMB6+2/2/073/6231/5L/Woodward finds another new allegianc
e First it was Blair's Labour, now the Tory defector seeking a Northern seat dis
covers a passion for Rugby League. Nigel Bunyan reportsC/Nigel Bunyan14DC/3/DNME
C+2/2/073/3181/1A/Blair the tunesmith writes the words too16/Sarah Womack Politi
cal Correspondent14DD/3/DNMEC+2/2/083/4061/13/Blair denies pact over leadership1
C/Andy McSmith Chief Political Correspondent14DE/3/DNMEC+2/2/083/5971/4S/Film pr
oducer gives credit to the Tories Rachel Sylvester reports on a recruit from Hol
lywood with views on what is good for Britain and what is notG/Rachel Sylvester1
4DI/3/DNMEC+2/2/023/6571/1K/Some of our candidates are missing Campaign SketchD/
Frank Johnson14DM/3/DNMEC+2/2/083/6961/1A/We'll cut red tape, Hague tells busine
ssT/George Jones Political Editor14DN/3/DNMEC+2/2/103/2681/12/Ulster Unionist ho
pes are lifted16/David Sharrock Ireland Correspondent14DO/3/DNMEC+2/2/102/931/R/
Raving loonies draw a blank16/Sarah Womack Political Correspondent14DP/3/DNMEC+2
/2/103/7451/4P/Blair's former manor still thinks old Labour Constituency Profile
 Islington South 'Forget the wine bars, this is the tenth most deprived borough'
C/Sean O'Neill14DS/3/DNMEC+2/2/083/3411/14/Train lets Kennedy take the strainE/D
avid Millward14E3/3/DNMEC+2/2/273/2451/S/Alastair's election briefingG/Armando I
annucci14GL/3/DNMHI+2/2/023/6901/20/The end of Oliver, who dared to ask for more
 Campaign sketchD/Frank Johnson14GM/3/DNMHI+2/2/273/4421/D/Hard pounding1/ 14GN/
3/DNMHI+2/2/083/5491/15/The mummy returns to handbag Labour18/Andrew Sparrow Pol
itical Correspondent14H1/3/DNMHI+2/2/123/7831/2R/Blairite prince of ping pong pu
rsues runaway Redwood Constituency spotlight - WokinghamD/P J Bonthrone14H2/3/DN
MHI+2/2/264/10721/7I/How Brown can quietly raise taxes to 50 per cent of income 
Ian Cowie, personal finance editor, explains how, on past form, the Chancellor c
an deny plans to change the rate of income tax but still take a bigger slice of 
our money9/Ian Cowie14H4/3/DNMHI+2/2/083/2851/17/NHS staff will man 'health fact
ories'D/Nicole Martin14H6/3/DNMHI+2/2/093/1631/12/ITV offers leaders a live deba
te9/Matt Born14HC/3/DNMHI+2/2/093/3351/1E/Red booklet reveals how McDonagh backe
d Benn1C/Andy McSmith Chief Political Correspondent14HD/3/DNMHI+2/2/093/7461/65/
Too much screaming and shouting when all it needed was a quiet word Most journal
ists want a working relationship with the parties but a heavy-handed edict will 
not get them on your sideF/Michael Brunson14K3/3/DNMKO+2/2/113/2291/15/Kennedy '
running third' in own seatE/David Millward14K7/3/DNMKO+2/2/023/6611/1N/Thatcher 
broadside scuppers Tory calm Campaign sketchD/Frank Johnson14KA/3/DNMKO+2/2/083/
6601/24/Why Labour believes the Tories have scored an own goal on EuropeJ/By Rac
hel Sylvester14KD/3/DNMKO+2/2/103/3881/1L/UKIP has been penetrated by MI6 pair, 
claims Tebbit16/Sarah Womack Political Correspondent14KG/3/DNMKO+2/2/113/2111/13
/Candidate numbers fall below 1997I/By Philip Johnston14KH/3/DNMKO+2/2/263/6861/
1M/What Hague offers is not policy, but rather flatteryA/David Hare14KJ/3/DNMKO+
2/2/273/9621/53/The 'mission to explain' has turned into propaganda Voters want 
to hear what politicians say, not what television reporters think, says James Ba
rtholomewF/James Barthomew14KK/3/DNMKO+2/2/273/4691/C/The cap fits1/ 14ND/3/DNMO
+3/2/063/2901/18/ProLife Alliance broadcast battle lostT/Joshua Rozenberg Legal 
Editor14NE/3/DNMO+3/2/063/3071/1C/Asian Tory supporters 'unhappy with Hague'G/Ra
chel Sylvester14NF/3/DNMO+3/2/063/5491/15/TV caller lambasts Beckett over NHS1H/
Charlie Norton, Andy McSmith and Andrew Sparrow14NG/3/DNMO+3/2/063/3431/1E/Major
 gives would-be successor a guided tourD/P J Bonthrone14NK/3/DNMO+3/2/083/1601/1
1/Hawking backs Labour on scienceF/Roger Highfield14NM/3/DNMO+3/2/264/10641/7B/B
lair's hypocrisy has robbed the poor even of their dignity Daniel Johnson argues
 that, in one regard, Stern was right to point the finger at the Prime Minister:
 he really has done less than nothing for the aspiring needyE/Daniel Johnson14NQ
/3/DNMO+3/2/273/2071/F/Sexual politics1/ 14NS/3/DNMO+3/2/084/13731/14/What forei
gners really think of us1/ 14QP/3/DNN3I+2/2/083/6261/1K/Own up to pounds 36bn eu
ro bill, Tories tell Brown19/Benedict Brogan Political Correspondent14QQ/3/DNN3I
+2/2/083/9631/1T/Hague euro tactics raise leadership doubt Election AnalysisC/An
thony King14QR/3/DNN3I+2/2/093/5041/1Q/Democrats and Republicans come to the aid
 of the partiesQ/Toby Harnden in Washington14QT/3/DNN3I+2/2/093/2711/13/US-style
 campaign upsets Lib DemsE/David Millward14R0/3/DNN3I+2/2/103/2891/1B/Rights Act
 'breached by system of voting'T/Joshua Rozenberg Legal Editor14R1/3/DNN3I+2/2/1
03/2221/1H/Mowlam tuition fee row puts Labour on defensive18/Andrew Sparrow Poli
tical Correspondent14R2/3/DNN3I+2/2/103/6001/1G/Competition hotting up among par
ty youth wingsA/Erin Baker14R5/3/DNN3I+2/2/083/1921/1C/Portillo's challenge on f
ate of NI ceilingF/Benedict Brogan14R6/3/DNN3I+2/2/103/4711/1E/Vaz helped billio
naire in extradition battleE/Andrew Sparrow14R7/3/DNN3I+2/2/102/541/10/Lottery c
ash to aid poor areas1/ 1503/3/DNN6O+2/2/043/4541/17/pounds 36bn costing may be 
inaccurate16/Sarah Womack Political Correspondent1504/3/DNN6O+2/2/043/7391/18/Jo
spin has something to upset everyoneN/Patrick Bishop in Paris1505/3/DNN6O+2/2/04
3/6581/1N/The French plan Ideas confirm worst fears of sceptics15/Ambrose Evans-
Pritchard in Brussels1507/3/DNN6O+2/2/053/6701/1L/Blair shows hand before reshuf
fle Election NotebookB/Andrew Marr1509/3/DNN6O+2/2/073/3361/1N/Labour pledges po
unds 150m lottery cash to poor areas16/Sarah Womack Political Correspondent150A/
3/DNN6O+2/2/073/7481/4E/Tory big guns shy away from a Cornish maverick Constitue
ncy Spotlight Falmouth Portillo and Hague refuse to support anti-EU campaignerC/
Sean O'Neill150C/3/DNN6O+2/2/234/10901/7E/Forget the Tories: what about Labour's
 splits on Europe? Stephen Pollard says that, if Tony Blair calls a referendum, 
he will have trouble selling the euro even to his Cabinet, let alone the party a
nd the electorate at largeF/Stephen Pollard150E/3/DNN6O+2/2/243/2491/S/Alastair'
s election briefingG/Armando Iannucci150H/3/DNN6O+2/2/243/5431/O/An election abo
ut Europe1/ 153E/3/DNNA+3/2/064/10711/6G/Question that will decide fate of the p
ound If Labour wins the election, Tony Blair will probably hold a referendum on 
euro membership next year. Will the campaign be fair? Philip Johnston reportsF/P
hilip Johnston153G/3/DNNA+3/2/063/5741/1C/Brown sidesteps Tory devaluation chall
enge11/George Jones and Andrew Sparrow153H/3/DNNA+3/2/063/4321/1A/Tories challen
ged over low-earning women16/Sarah Womack Political Correspondent153I/3/DNNA+3/2
/063/2891/13/Lib Dems accuse Labour on elderlyC/Sarah Womack153T/3/DNNA+3/2/264/
10591/77/What Jimmy taught me about the importance of the pound. In 1997 Sir Jam
es Goldsmith extracted from party leaders a promise of a referendum on a single 
currency. Annabel Goldsmith, his widow, is keeping up the campaignH/Annabel Gold
smith1540/3/DNNA+3/2/273/5981/M/The character question1/ 1541/3/DNNA+3/2/273/986
1/2A/Eight reasons why Tony Blair has got it in for me The Wednesday column9/Tom
 Utley156M/3/DNND6+2/2/023/6361/1S/Like old times - another pro-euro Mr Heath Ca
mpaign sketchD/Frank Johnson156N/3/DNND6+2/2/083/6281/1F/Hague faces party backl
ash over euro campaignG/Rachel Sylvester156Q/3/DNND6+2/2/083/7221/26/Fatalism ma
y pave way for 'yes' vote in single currency referendumC/Anthony King156T/3/DNND
6+2/2/093/4501/1R/Blair seeks zero tolerance for attacks on public servants19/Be
nedict Brogan Political Correspondent1570/3/DNND6+2/2/104/10671/28/Party leaders
 try to march in tune with the growing army of the aged16/Sarah Womack Political
 Correspondent1576/3/DNND6+2/2/113/5071/1D/Postal voting system may be liable to
 abuseD/P J Bonthrone1577/3/DNND6+2/2/263/6601/1I/Bluff Ken Clarke revealed in a
ll his boorishnessA/David Hare1578/3/DNND6+2/2/264/10621/6C/Let me see patients,
 not forms and management directives. In May 1997 Dr Gillian Braunold welcomed L
abour's new broom in the National Health Service. Now, like most GPs, she is at 
her wits endJ/Dr Gillian Braunold157A/3/DNND6+2/2/273/2481/S/Alastair's election
 briefingG/Armando Iannucci15A3/3/DNNGC+2/2/023/6661/1S/Trouble with the schools
 in Middle England Campaign sketchD/Frank Johnson15A4/3/DNNGC+2/2/083/5271/1E/Bl
air put on defensive over NI 'stealth tax'T/George Jones Political Editor15A7/3/
DNNGC+2/2/082/831/O/Secondary school bursars1/ 15A9/3/DNNGC+2/2/093/7111/17/What
 the parties promise on educationC/Andy McSmith15AD/3/DNNGC+2/2/093/5131/2F/Half
-baked, backward thinking and hostile Education, Analysis by John Clare1/ 15AE/3
/DNNGC+2/2/103/8261/2E/Portillo's nemesis faces lone force of Conservatism Const
ituency spotlightC/Sean O'Neill15AG/3/DNNGC+2/2/113/8291/4K/Babes on the Bus who
 keep the campaign journalists at bay Benedict Brogan reports on the all-female 
team who run Blair's election coach tourF/Benedict Brogan15AI/3/DNNGC+2/2/263/99
81/6A/Tony Blair is committed to the extinction of Britain Margaret Thatcher war
ns of the perils ahead if Labour is returned with a large majority: nothing less
 than democracy hangs in the balanceH/Margaret Thatcher15DE/3/DNNQ+3/2/063/9971/
21/Don't blame Hague if the Conservatives flop Election AnalysisC/Anthony King15
DG/3/DNNQ+3/2/063/3531/11/Ancram's passion for the futureC/Andy McSmith15DH/3/DN
NQ+3/2/063/5381/1D/Labour of love keeps Foot on campaign trail1C/Andy McSmith Ch
ief Political Correspondent15DI/3/DNNQ+3/2/074/10411/3R/The whirly bird Tory who
 leaves Page Three Jordan in the shade Alice Thomson flies around Britain with A
nn WiddecombeD/Alice Thomson15DJ/3/DNNQ+3/2/083/7181/33/Labour's sick man who is
 still striding towards victory Constituency Spotlight Leicester EastC/Sean O'Ne
ill15DK/3/DNNQ+3/2/083/3681/1O/Blair is close to political perfection, says Mand
elsonN/Patrick Bishop in Paris15DL/3/DNNQ+3/2/083/3281/14/Archbishop warns again
st landslide17/Victoria Combe Religion Correspondent15DN/3/DNNQ+3/2/093/3121/15/
Blair 'not happy as Prime Minister'T/George Jones Political Editor15DO/3/DNNQ+3/
2/093/5381/1G/First-time voters urged to make idealism count19/Benedict Brogan P
olitical Correspondent15DP/3/DNNQ+3/2/093/3461/11/Labour 'ruining military ethos
'T/George Jones Political Editor15DS/3/DNNQ+3/2/213/6491/T/The party for all the
 talents1/ 15E0/3/DNNQ+3/2/063/2201/1J/Portillo warns of pension plan 'stealth t
ax' riskC/George Jones15GL/3/DNNT6+2/2/063/7561/1C/Confident Blair casts Lib Dem
 allies asideT/George Jones Political Editor15GO/3/DNNT6+2/2/063/6611/12/Apathy 
is now the Tories' friendD/FRANK JOHNSON15GQ/3/DNNT6+2/2/073/7341/14/Postal ball
ots 'are open to fraud'1C/Andy McSmith Chief Political Correspondent15H1/3/DNNT6
+2/2/083/3591/14/Times tells readers to vote Labour9/Matt Born15H2/3/DNNT6+2/2/0
93/2671/16/'Too few staff' to train new doctorsD/Nicole Martin15H3/3/DNNT6+2/2/0
93/3411/1M/Breast cancer patient driven to seek help in GermanyE/Sandra Laville1
5H4/3/DNNT6+2/2/093/6451/1S/Trimble warns electorate not to undo Good Friday Agr
eement16/David Sharrock Ireland Correspondent15H5/3/DNNT6+2/2/093/1961/13/Kenned
y targets Labour dissidentsE/David Millward15H9/3/DNNT6+2/2/253/4401/S/The limit
s of mail franchise1/ 15HB/3/DNNT6+2/2/253/2401/S/Alistair's election briefingG/
Armando Iannucci15K6/3/DNO2C+2/2/083/2331/13/Grounded press photographers snap19
/Benedict Brogan Political Correspondent15K8/3/DNO2C+2/2/103/4021/1C/Sinn Fein i
s accused of massive vote fraud16/David Sharrock Ireland Correspondent15K9/3/DNO
2C+2/2/083/7171/23/Conservative 'bubble' campaign fails to impress in key margin
alG/Rachel Sylvester15KA/3/DNO2C+2/2/093/8861/1I/Man made to measure for the sma
rt set in ChelseaD/Alice Thomson15KB/3/DNO2C+2/2/093/3201/19/Portillo is prepare
d to share any blameT/George Jones Political Editor15KE/3/DNO2C+2/2/103/4301/17/
We'll tax and spend, promises KennedyE/David Millward15KF/3/DNO2C+2/2/103/3891/1
G/Brown scores victory on public spending levels10/David Haworth and Andy McSmit
h15KG/3/DNO2C+2/2/103/1231/11/ITV puts 'bloopers' before news11/Tom Leonard Medi
a Correspondent15KH/3/DNO2C+2/2/103/4831/1D/Tories on a winner . . . in the loca
l polls15/Philip Johnston Home Affairs Editor15KI/3/DNO2C+2/2/113/7341/3F/Chocoh
olic with the willpower to stay on-message P J Bonthrone fails in his attempt to
 bribe a Blair BabeD/P J BONTHRONE15KJ/3/DNO2C+2/2/113/4851/2O/The immovable obj
ect versus the irresistible force Constituency spotlight - Southall8/Amit Roy15K
L/3/DNO2C+2/2/224/10781/7L/Blair's centre-Left coalition could be split by the e
uro Michael Barone says the Tories should take heart from the collapse of Lyndon
 Johnson's administration, which saw the Democrats out of power for a generation
 By Michael Barone1/ 15KN/3/DNO2C+2/2/233/2471/S/Alastair's election briefingG/A
rmando Iannucci15ND/3/DNO5I+2/2/023/6911/1B/Polling day is welcome release for v
otersD/FRANK JOHNSON15NG/3/DNO5I+2/2/083/5821/2C/Four potential leadership rival
s join forces to rally the party faithfulT/George Jones Political Editor15NH/3/D
NO5I+2/2/083/3911/2B/Scotland Strange campaign that lacked 'Scottish feel', By A
lan Cochrane1/ 15NI/3/DNO5I+2/2/083/3661/1T/Wales After 1997. Things can only ge
t better for the ToriesC/Sean O'Neill15NJ/3/DNO5I+2/2/083/3631/2K/Northern Irela
nd Good Friday Agreement hinges on four results, By David Sharrock1/ 15NM/3/DNO5
I+2/2/103/7271/23/Warhorses primed for a hi-tech battle to win stay-awake viewer
s9/Matt Born15NO/3/DNO5I+2/2/103/2741/1J/Blair: a tour of polling stations in co
nstituency19/Benedict Brogan Political Correspondent15NQ/3/DNO5I+2/2/114/11351/3
3/Bridge too far in battle to topple the leaders Constituency Spotlight Sedgefie
ld and RichmondC/NEIL TWEEDIE15NR/3/DNO5I+2/2/113/2091/1I/It is vital to vote, s
ays suffragette descendantD/P J Bonthrone15NS/3/DNO5I+2/2/113/2731/1D/Speech ban
 in Oldham amid fears of violence1C/Andy McSmith Chief Political Correspondent15
NT/3/DNO5I+2/2/243/6711/1M/In the end, Tories are left playing Annoy Tony BlairA
/DAVID HARE15O0/3/DNO5I+2/2/243/5551/7O/Polling day casts its spell The MP for A
shford from 1950 to 1974 recalls standing for Parliament for the first time, and
 an Oxford undergraduate, 67 years his junior, explains his sense of excitement 
at voting for the first time today9/JON BOONE15O3/3/DNO5I+2/2/253/9671/5D/Thatch
er and Clarke would be at home in the Pub Party Andrew Gimson finds the saloon b
ar united in hatred of oppressive taxation, but honestly doubtful on the euroD/A
ndrew Gimson1EGL/4/DNL2O+2/2/163/8301/2M/ELECTION 2001: POLITICS IS A DIRTY BUSI
NESS. THE NEWSPAPERS WILL MAKE SURE OF THATH/David Aaronovitch1EGM/4/DNL2O+2/2/0
34/11161/3L/LEADING ARTICLE: CONVENTIONAL WISDOM SAYS THE ELECTION WILL BE A LAN
DSLIDE. BUT THERE ARE VITAL ISSUES AT STAKE1/ 1EGQ/4/DNL2O+2/2/023/5441/34/ELECT
ION 2001: BLAIR ANNOUNCES POLL AT SCHOOL THAT WAS NOT GOOD ENOUGH FOR MINISTER'S
 CHILDRENE/Richard Garner1EGR/4/DNL2O+2/2/023/5031/1B/IRA GIVEN ULTIMATUM ON WEA
PONS BY TRIMBLE18/David Mckittirck Ireland Correspondent1EGS/4/DNL2O+2/2/023/421
1/27/HUNTING BILL AMONG SEVEN STATUTES ABANDONED IN DEAL WITH TORY WHIPS15/Ben R
ussell Political Correspondent1EH1/4/DNL2O+2/2/133/6111/31/ELECTION 2001: CONSER
VATIVES - A DEAD PARROT? TORIES BELIEVE A NO-NONSENSE CAMPAIGN CAN FLYA/Paul Wau
gh1EH3/4/DNL2O+2/2/144/18981/22/ELECTION 2001: THREE REASONS WHY HAGUE SHOULD NO
T GIVE UP HOPEC/John Curtice1EH4/4/DNL2O+2/2/144/11571/T/ELECTION 2001: SEATS TO
 WATCHC/John Curtice1EH8/4/DNL2O+2/2/023/4631/48/MONITOR: THE INTERNATIONAL PRES
S COMMENTS ON TONY BLAIR'S CHANCES IN THE FORTHCOMING GENERAL ELECTION; ALL THE 
NEWS OF THE WORLD1/ 1EK1/4/DNL6+3/2/083/4841/3I/PARLIAMENT: THE SKETCH - PM'S MA
STERCLASS OF HUNGER, HUMILITY AND RECONCILING THE IRRECONCILABLE; THE SKETCHA/Si
mon Carr1EK3/4/DNL6+3/2/023/2661/1R/MILLBANK LINES UP A SAFE SEAT FOR TORY DEFEC
TOR TO LABOUR14/Paul Waugh Deputy Political Editor1EK6/4/DNL6+3/2/053/4921/1F/EL
ECTION 2001: HOW THE ELECTION TEAMS COMPARE1/ 1EK7/4/DNL6+3/2/053/3331/2F/ELECTI
ON 2001: SPEECH - BLAIR 'WILL NOT RAISE TAX RATE FOR HIGHEST EARNERS'16/Nigel Mo
rris Political Correspondent1EK8/4/DNL6+3/2/063/8521/7C/ELECTION 2001: PLEDGES -
 BROWN FORCED ON TO THE BACKFOOT AS HE REFUSES TO RULE OUT TAX INCREASES; PLEDGE
S; LABOUR UNVEILS ITS NEW KEY PLEDGES AS INDEPENDENT ECONOMISTS QUESTION THE SUC
CESS OF PREVIOUS 'UNAMBITIOUS' TARGETST/Andrew Grice Political Editor1EKD/4/DNL6
+3/2/034/12091/1Q/JOIN A TV DEBATE, MR BLAIR, OR STOP MOANING ABOUT APATHYG/Dona
ld Macintyre1EKG/4/DNL6+3/2/073/6071/1P/MARGINALS: ANTI-EURO JOURNALIST TAKES ON
 A 'BLAIR BABE'A/Chris Gray1ENC/4/DNL96+2/2/083/5971/3I/PARLIAMENT & POLITICS - 
THE SKETCH: YOU WAKE UP AND SOMETHING PRECIOUS IS LOST. WE'VE ALL DONE THAT, WIL
LIAMA/Simon Carr1END/4/DNL96+2/2/043/8401/2I/ELECTION 2001 - TAXATION: SPENDING 
BATTLE IS SUCKED INTO THE TAX 'BLACK HOLES'T/Andrew Grice Political Editor1ENG/4
/DNL96+2/2/053/3021/78/TORIES PLEDGE TAX CUTS AND GREATER CHOICE. WILLIAM HAGUE 
YESTERDAY CLAIMED THE CONSERVATIVE MANIFESTO WAS THE MOST AMBITIOUS FOR A GENERA
TION. HERE IS ANALYSIS FROM THE INDEPENDENT'S SPECIALIST WRITERS: ECONOMY & TAXE
SF/Philip Thornton1ENI/4/DNL96+2/2/053/2801/6T/TORIES PLEDGE TAX CUTS AND GREATE
R CHOICE. WILLIAM HAGUE YESTERDAY CLAIMED THE CONSERVATIVE MANIFESTO WAS THE MOS
T AMBITIOUS FOR A GENERATION. HERE IS ANALYSIS FROM THE INDEPENDENT'S SPECIALIST
 WRITERS: EUROPE1E/Donald Macintyre Chief Political Commentator1ENM/4/DNL96+2/2/
053/2561/7B/TORIES PLEDGE TAX CUTS AND GREATER CHOICE. WILLIAM HAGUE YESTERDAY C
LAIMED THE CONSERVATIVE MANIFESTO WAS THE MOST AMBITIOUS FOR A GENERATION. HERE 
IS ANALYSIS FROM THE INDEPENDENT'S SPECIALIST WRITERS: CRIME & PUNISHMENTA/Paul 
Waugh1ENN/4/DNL96+2/2/053/1431/75/TORIES PLEDGE TAX CUTS AND GREATER CHOICE. WIL
LIAM HAGUE YESTERDAY CLAIMED THE CONSERVATIVE MANIFESTO WAS THE MOST AMBITIOUS F
OR A GENERATION. HERE IS ANALYSIS FROM THE INDEPENDENT'S SPECIALIST WRITERS: ART
S & MEDIA11/Louise Jury Media Correspondent1ENO/4/DNL96+2/2/053/2101/70/TORIES P
LEDGE TAX CUTS AND GREATER CHOICE. WILLIAM HAGUE YESTERDAY CLAIMED THE CONSERVAT
IVE MANIFESTO WAS THE MOST AMBITIOUS FOR A GENERATION. HERE IS ANALYSIS FROM THE
 INDEPENDENT'S SPECIALIST WRITERS: WELFARE1E/Lorna Duckworth Social Affairs Corr
espondent1ENR/4/DNL96+2/2/053/2191/7J/TORIES PLEDGE TAX CUTS AND GREATER CHOICE.
 WILLIAM HAGUE YESTERDAY CLAIMED THE CONSERVATIVE MANIFESTO WAS THE MOST AMBITIO
US FOR A GENERATION. HERE IS ANALYSIS FROM THE INDEPENDENT'S SPECIALIST WRITERS:
 CENTRAL & LOCAL GOVERNMENT15/Ben Russell Political Correspondent1ENS/4/DNL96+2/
2/073/6291/30/ELECTION 2001 - CAMPAIGN TOUR: MIDDLE ENGLAND BARELY STIRS AS BLAI
R'S BATTLE BUS GLIDES IN16/Nigel Morris Political Correspondent1EO1/4/DNL96+2/2/
033/7461/2S/LEADING ARTICLE: FIRST OUT OF THE TRAPS - BUT THE TORIES' MANIFESTO 
HAS SOME FATAL FLAWS1/ 1EO3/4/DNL96+2/2/044/10631/27/THE INDIA-RUBBER MAN OF MOD
ERN POLITICS CONFOUNDS HIS CRITICS AGAIND/Michael Brown1EO4/4/DNL96+2/2/064/1123
1/6K/ELECTION 2001- VOTERS' PANEL: FOUNDED ON COAL, TAKEN FOR GRANTED; 'THE INDE
PENDENT' HAS SELECTED FIVE SEATS AS BAROMETERS OF PUBLIC REACTION TO THE CAMPAIG
N. TODAY, WE GAUGE OPINION IN ST HELENS SOUTH1C/Ian Herbert North Of England Cor
respondent1EO5/4/DNL96+2/2/063/1671/2D/ELECTION 2001 - HEALTH: CONSULTANT WAITIN
G LISTS HAVE RISEN BY TWO-THIRDS1B/Marie Woolf Chief Political Correspondent1EO6
/4/DNL96+2/2/073/3861/2I/ELECTION 2001 - SHORTLIST: KEY ADVISER TO BE PARACHUTED
 INTO SAFE LABOUR SEATV1B/Marie Woolf Chief Political Correspondent1EQL/4/DNLIO+
2/2/103/5211/27/ELECTION 2001: VOICES FROM ENFIELD SOUTHGATE: 1,433 LABOUR MAJOR
ITY1/ 1EQM/4/DNLIO+2/2/073/1701/1J/ELECTION 2001: BLAIR: MY STRENGTHS AND WEAKNE
SSES1/ 1EQP/4/DNLIO+2/2/093/2291/2C/ELECTION 2001: BLAIR WANTS TO REFORM BASIS O
F WELFARE SYSTEM; EMPLOYMENTC/Andrew Grice1EQS/4/DNLIO+2/2/073/4651/2E/ELECTION 
2001: LABOUR MUSTERS ADVISERS TO REPLACE MANDELSON; MILLBANK TEAMB/Marie Woolf1E
R0/4/DNLIO+2/2/083/5431/25/ELECTION 2001: WOODWARD PARACHUTES INTO SAFE ST HELEN
S; SELECTIONB/Ian Herbert1ER3/4/DNLIO+2/2/093/4931/25/ELECTION 2001: WHAT GOOD S
TART? THE TORIES ARE STILL NOT BELIEVEDC/John Curtice1ER4/4/DNLIO+2/2/103/5761/1
R/ELECTION 2001: LITTLE HOPE FOR HAGUE IF TWIGG CAN STAY OND/Matthew Beard1ER7/4
/DNLIO+2/2/044/11551/26/LABOUR'S ELECTION CAMPAIGN NEEDS TO EXPRESS ITS VISION A
ND BELIEFSF/Peter Mandelson1F01/4/DNLM+3/2/073/8721/3D/ELECTION 2001: PRESENTATI
ON - BLAIR SHOWS HIS IRRITATION OVER CLAIMS THAT CAMPAIGN IS DOMINATED BY SPINT/
Nigel Morris And Andrew Grice1F02/4/DNLM+3/2/033/1991/1H/LEADING ARTICLE: ELECTI
ON 2001 - ELECTION SPICE1/ 1F09/4/DNLM+3/2/023/6551/31/ELECTION 2001: ELECTION S
KETCH - PROMISES, SECRETS AND LIES. IT'S ALL IN A DAY ON THE STUMPA/Simon Carr1F
0B/4/DNLM+3/2/064/12161/35/ELECTION 2001: BUSINESS - BROWN PROMISES POUNDS 150M 
LOAN FUND TO FOSTER 'SPIRIT OF ENTERPRISE'15/Ben Russell Political Correspondent
1F0C/4/DNLM+3/2/083/4941/2I/ELECTION 2001: EDUCATION - LIB DEMS PLEDGE TO FIND P
OUNDS 3BN MORE FOR SCHOOLS1B/Marie Woolf Chief Political Correspondent1F0D/4/DNL
M+3/2/083/4281/2H/ELECTION 2001: WALES - WELSH NATIONALISTS CALL FOR TAX AND LEG
ISLATIVE POWERS15/Ben Russell Political Correspondent1F0E/4/DNLM+3/2/093/7491/2L
/ELECTION 2001: CONSERVATIVES - HAGUE KNOCKED OFF COURSE BY POUNDS 20BN CUTS CLA
IM14/Paul Waugh Deputy Political Editor1F0F/4/DNLM+3/2/094/11061/7P/ELECTION 200
1: THE CANDIDATE - WOODWARD PLAYS THE PIED PIPER TO GAIN SUPPORT; TODAY, WE ASK 
PEOPLE IN ST HELENS SOUTH FOR THEIR VIEWS ON THE SELECTION OF SHAUN WOODWARD, A 
FORMER TORY, AS LABOUR CANDIDATE IN THE MERSEYSIDE CONSTITUENCY1C/Ian Herbert No
rth Of England Correspondent1F0H/4/DNLM+3/2/034/11981/52/ELECTION 2001: JUST WHA
T DOES LABOUR HAVE TO BE SO DEFENSIVE ABOUT?; 'BLAIR TOLD THE CABINET THAT THEY 
COULD NOT FIGHT THE ELECTION ON COMPETENCE ALONE'G/Donald Macintyre1F0I/4/DNLM+3
/2/044/10941/5D/ELECTION 2001: MY MISSION IS TO FREE THE BRITISH PEOPLE AND IMPR
OVE PUBLIC SERVICES; 'IF PEOPLE ASK IN THIS ELECTION, "WHAT'S THE BIG IDEA?", WE
'LL HAVE AN ANSWER'F/Charles Kennedy1F3D/4/DNLP6+2/2/063/4711/2H/ELECTION 2001: 
WHERE BUSH ADVERTISEMENTS LED, HAGUE HAS FOLLOWED; CAMPAIGNINGC/John Rentoul1F3F
/4/DNLP6+2/2/083/2571/2R/ELECTION 2001: TABLOID IDEA DESIGNED TO MAKE HEADLINES;
 PRESENTATION: LIB DEM MANIFESTOB/Marie Woolf1F3J/4/DNLP6+2/2/023/6631/2K/ELECTI
ON 2001: FREEDOM. JUSTICE. HONESTY. AND FLOBBALOB FINANCE; ELECTION SKETCHA/Simo
n Carr1F3K/4/DNLP6+2/2/074/10571/2G/ELECTION 2001: LIVINGSTONE RISKS OUTCRY BY B
ACKING LIB DEMS; TACTICAL VOTING1B/Marie Woolf Chief Political Correspondent1F3L
/4/DNLP6+2/2/083/5541/2E/ELECTION 2001: LIB DEMS PLEDGE TO RAISE TAX FOR PUBLIC 
SERVICES; MANIFESTO1B/Marie Woolf Chief Political Correspondent1F3R/4/DNLP6+2/2/
044/10581/5T/ELECTION 2001: WHAT SORT OF 'RADICALISM' CAN WE EXPECT FROM THE LAB
OUR MANIFESTO?; 'IT WILL BE INTERESTING TO SEE IF THE WORD "SOCIALISM" HAS FINAL
LY DISAPPEARED FROM THE LEXICON'B/Mark Seddon1F3S/4/DNLP6+2/2/063/6501/2T/ELECTI
ON 2001: CONSERVATIVES FACE DOUBLE SPLIT ON EUROPE AS MPS DEFY PARTY LINE; FACTI
ONSP/Andrew Grice & Paul Waugh1F6M/4/DNLSC+2/2/034/12111/1H/SO NOW WE KNOW WHAT 
MR BLAIR MEANS BY 'RADICAL'G/Donald Macintyre1F6P/4/DNLSC+2/2/093/9391/38/ELECTI
ON 2001: ON THE STUMP - DEPRIVATION, NOT RACE, IS KEY ISSUE ACROSS OLDHAM'S EAST
-WEST DIVIDEC/Paul Vallely1F72/4/DNLSC+2/2/063/1371/17/ELECTION 2001: 18 MONTHS'
 HARD LABOUR1/ 1F74/4/DNLSC+2/2/073/3031/5S/ELECTION 2001: 'A BALANCED APPROACH 
TO GET THE JOB DONE' - TAX AND THE ECONOMY; LABOUR'S MANIFESTO, UNVEILED YESTERD
AY, PUTS THE EMPHASIS SQUARELY ON REVITALISING PUBLIC SERVICESB/Diane Coyle1F75/
4/DNLSC+2/2/073/2811/5R/ELECTION 2001: 'A BALANCED APPROACH TO GET THE JOB DONE'
 - COUNTRYSIDE AND ENVIRONMENT; LABOUR'S MANIFESTO, UNVEILED YESTERDAY, PUTS THE
 EMPHASIS SQUARELY ON REVITALISING PUBLIC1B/Marie Woolf Chief Political Correspo
ndent1F76/4/DNLSC+2/2/073/2891/5I/ELECTION 2001: 'A BALANCED APPROACH TO GET THE
 JOB DONE' - EDUCATION; LABOUR'S MANIFESTO, UNVEILED YESTERDAY, PUTS THE EMPHASI
S SQUARELY ON REVITALISING PUBLIC SERVICES11/Richard Garner Education Editor1F79
/4/DNLSC+2/2/073/2751/5H/ELECTION 2001: 'A BALANCED APPROACH TO GET THE JOB DONE
' - FAMILIES; LABOUR'S MANIFESTO, UNVEILED YESTERDAY, PUTS THE EMPHASIS SQUARELY
 ON REVITALISING PUBLIC SERVICES1E/Lorna Duckworth Social Affairs Correspondent1
F7B/4/DNLSC+2/2/073/2171/60/ELECTION 2001: 'A BALANCED APPROACH TO GET THE JOB D
ONE' - CONSTITUTIONAL REFORM; LABOUR'S MANIFESTO, UNVEILED YESTERDAY, PUTS THE E
MPHASIS SQUARELY ON REVITALISING PUBLIC SERVICEST/Andrew Grice Political Editor1
F7E/4/DNLSC+2/2/073/2651/5J/ELECTION 2001: 'A BALANCED APPROACH TO GET THE JOB D
ONE' - PENSIONERS; LABOUR'S MANIFESTO, UNVEILED YESTERDAY, PUTS THE EMPHASIS SQU
ARELY ON REVITALISING PUBLIC SERVICESF/Lorna Duckworth1F7F/4/DNLSC+2/2/083/3681/
2I/ELECTION 2001: POLICING - POLICE FEDERATION SHAKES STRAW WITH THE WI TREATMEN
TB/Ian Burrell1F7J/4/DNLSC+2/2/023/3991/46/ELECTION 2001: VIEWS FROM AROUND THE 
WORLD: YOUR POLITICIANS ALL SEEM SO STRANGE; PAOLO FILO DELLA TORRE LA REPUBBLIC
A (ITALY)M/Paolo Filo Della Torre1F7K/4/DNLSC+2/2/034/10121/2Q/LEADING ARTICLE: 
TOO MANY WORDS, TOO LITTLE CONVICTION AND TOO MUCH JUST LEFT TO TRUST1/ 1F7L/4/D
NLSC+2/2/033/6331/1A/YOUR GENERAL ELECTION QUESTIONS ANSWEREDD/Miles Kington1F7M
/4/DNLSC+2/2/093/4911/33/ELECTION 2001: HEALTH SERVICE - LIB DEMS WILL NOT STAND
 AGAINST 'SAVE OUR HOSPITAL' CANDIDATE1B/Marie Woolf Chief Political Corresponde
nt1FA1/4/DNM1I+2/2/103/1341/2F/ELECTION 2001: URI GELLER, MY VOTE - 'AT A PUSH, 
I THINK I WOULD VOTE TORY'A/Uri Geller1FA2/4/DNM1I+2/2/093/6221/2E/ELECTION 2001
: PARTY PLEDGES - GREENS LAUNCH MANIFESTO WITH A WIDER AGENDA1B/Marie Woolf Chie
f Political Correspondent1FA5/4/DNM1I+2/2/063/3301/3D/ELECTION 2001: LAW AND ORD
ER - STRAW CRITICISED FOR SUGGESTING POLICE WHO HECKLED HIM HAD BEEN DRINKING15/
Ben Russell Political Correspondent1FA6/4/DNM1I+2/2/064/11251/2H/ELECTION 2001: 
AFTERMATH - LABOUR DISCOVERS PRESCOTT PUNCH NO LAUGHING MATTER1B/Andrew Grice, P
aul Waugh And Nigel Morris1FA7/4/DNM1I+2/2/023/6591/2M/ELECTION 2001: ENTER THE 
HAGUES, THE WEDDING CAKE BRIDE AND GROOM; ELECTION SKETCHA/Simon Carr1FA8/4/DNM1
I+2/2/063/4061/6Q/ELECTION 2001: VOTERS' PANEL: OCHIL, 4,652 LABOUR MAJORITY; JO
HN PRESCOTT JUSTIFIED HIS BRAWL WITH A DEMONSTRATOR AFTER HE WAS HIT BY AN EGG A
S SELF-DEFENCE, BUT OPINION IS DIVIDED OVER HIS VIOLENT REACTION1/ 1FAA/4/DNM1I+
2/2/073/4381/33/ELECTION 2001: THE PROTESTER - EGG-THROWER ANGERED BY A HARD WIN
TER AND AN ANTI- HUNTING JIBES/Ian Herbert And Kim Sengupta1FAB/4/DNM1I+2/2/083/
4761/2C/ELECTION 2001: ST HELENS - SON OF MINER QUITS LABOUR TO TAKE ON WOODWARD
15/Ben Russell Political Correspondent1FAC/4/DNM1I+2/2/083/8161/2B/ELECTION 2001
: PROTEST - PM PLEDGES INQUIRY INTO CANCER SUFFERER'S WAITB/Cahal Milmo1FAG/4/DN
M1I+2/2/103/9921/2E/ELECTION 2001: ON THE STUMP - THREE-WAY BATTLE IN TOWN SCARR
ED BY ATROCITY18/David Mckittrick Ireland Correspondent1FAI/4/DNM1I+2/2/033/6101
/2R/LEADING ARTICLE: THAT IS THE WRONG WAY TO GET IN TOUCH WITH THE ELECTORATE, 
MR PRESCOTT1/ 1FAJ/4/DNM1I+2/2/033/5911/4S/EGGSTRA, EGGSTRA! FIST-IN-MOUTH CRISI
S LATEST!; 'ELECTIONS ARE ALL ABOUT WHAT'S IN IT FOR ME. GLOBAL DESTRUCTION IS N
OT AS IMPORTANT AS MORE POLICE'D/Miles Kington1FAK/4/DNM1I+2/2/044/10771/53/THER
E IS A SIMPLE WAY TO DEFEAT THE HATED PARACHUTE BRIGADE; 'WE ARE WITNESSING THE 
DEATH OF THE ABILITY OF LOCAL PARTIES TO SELECT THEIR OWN CANDIDATES'D/Michael B
rown1FAL/4/DNM1I+2/2/043/6321/1K/PUNCH SOMEONE - IT'S AN EASY BADGE OF AUTHENTIC
ITYF/Terence Blacker1FDB/4/DNMB6+2/2/093/4341/2L/ELECTION 2001: ANALYSIS - FISTI
CUFFS FAIL TO STIR ELECTORATE FROM COLLECTIVE YAWNC/John Curtice1FDD/4/DNMB6+2/2
/064/11641/49/ELECTION 2001: GREEN ISSUES - FEAR OF LOSING THE FLOATING VOTER DE
LAYED CRUCIAL DECISIONS THAT COULD SERIOUSLY AFFECT ENVIRONMENT15/Michael Mccart
hy Environment Editor1FDF/4/DNMB6+2/2/073/1751/22/ELECTION 2001: EUROPE - TORY U
RGES VOTERS TO SHUN THE SCEPTICST/Andrew Grice Political Editor1FDG/4/DNMB6+2/2/
073/4931/2A/ELECTION 2001: LAW AND ORDER - STRAW PLANS CURBS ON CHATROOM PREDATO
RSC/Nigel Morris1FDM/4/DNMB6+2/2/084/10971/2K/ELECTION 2001: SCOTLAND - SHERIDAN
'S STAR QUALITY: MARXISM WITH A TAN AND A WINKG/Donald Macintyre1FGL/4/DNMEC+2/2
/093/5021/73/ELECTION 2001: VOTERS' PANEL: MID DORSET AND NORTH POOLE, 681 TORY 
MAJORITY; CONSTITUENTS IN THIS MARGINAL LIBERAL DEMOCRAT TARGET SEAT ASSESS THE 
PARTIES' POSITIONS ON THE ISSUES OF ASYLUM-SEEKERS AND IMMIGRATION1/ 1FGM/4/DNME
C+2/2/083/2781/2Q/ELECTION 2001: TRANSPORT - LIB DEMS PLAN TO CUT FARES AND REIN
 IN RAILTRACK; TRANSPORT1B/Marie Woolf Chief Political Correspondent1FGN/4/DNMEC
+2/2/063/3241/3P/ELECTION 2001: NATIONAL INSURANCE - 'SAVINGS SCHEME' THAT BECAM
E A TAX ON MIDDLE-INCOME EARNERS; NATIONAL INSURANCEJ/Katherine Griffiths1FGO/4/
DNMEC+2/2/063/4221/4F/ELECTION 2001: SUPPORTERS - FORMER MINISTERS, DONORS AND E
VEN A CANDIDATE IN TORY COMMERCE LIST AMONG TORY BUSINESS BACKERS; SUPPORTERSP/B
en Russell & Mike Pflanz1FGS/4/DNMEC+2/2/023/6261/3B/ELECTION 2001: ELECTION SKE
TCH - VAZ HAS AN AWFUL LOT OF HIDE, BUT WHERE'S HIS HAIR?; ELECTION SKETCHA/Simo
n Carr1FH2/4/DNMEC+2/2/073/5101/3J/ELECTION 2001: FRINGE PARTIES - THE LOONIES A
REN'T SCREAMING ANY MORE, JUST HOWLING HOPEFULLY; FRINGE PARTIESB/Cahal Milmo1FH
4/4/DNMEC+2/2/083/4621/3S/ELECTION 2001: MEDIA SUPPORT - 'THE TIMES' TO ENDORSE 
LABOUR FOR THE FIRST TIME IN ITS 216-YEAR HISTORY; MEDIA SUPPORTT/Andrew Grice P
olitical Editor1FH7/4/DNMEC+2/2/093/1601/37/ELECTION 2001: MY VOTE ANDY KERSHAW 
BROADCASTER - 'BLAIR IS THE OTHER SIDE OF THE SAME TORY COIN'C/Andy Kershaw1FH8/
4/DNMEC+2/2/023/4141/2O/ELECTION 2001: 'SPIN DOCTOR' IS IMPOSSIBLE TO TRANSLATE;
 VIEWS FROM AROUND THE WORLD17/Philippe Le Corre La Tribune (france)1FH9/4/DNMEC
+2/2/034/12041/1P/SPEAK UP, MR KENNEDY: LET'S HEAR THE LIBERAL CONSCIENCEG/Donal
d Macintyre1FK1/4/DNMHI+2/2/034/11841/45/NEW LABOUR, THE NATURAL HOME OF UNNECES
SARY PANIC; 'THE TAUNTING OF THE STRONG BY THE WEAK MAKES FOR IRRESISTIBLY GOOD 
TELLY'C/Anne Mcelvoy1FK2/4/DNMHI+2/2/063/3341/2A/ELECTION 2001: EUROPE - THATCHE
R POUNDS AWAY AT BLAIR OVER EURO 'PLOT'C/Nigel Morris1FK3/4/DNMHI+2/2/064/12911/
3P/ELECTION 2001: LABOUR STRATEGY - IN 1997 LABOUR RAN A RUTHLESSLY EFFICIENT CA
MPAIGN. THIS TIME THEY ARE OFF MESSAGEC/Andrew Grice1FKA/4/DNMHI+2/2/073/3011/29
/ELECTION 2001: FRINGE PARTY - REDGRAVE SWITCHES FROM LIB DEMS TO MARXB/Mike Pfl
anz1FKD/4/DNMHI+2/2/093/5051/2J/ELECTION 2001: NOMINATIONS - FURY OVER FALL IN W
OMEN SELECTED TO FIGHT ELECTIONB/Marie Woolf1FKE/4/DNMHI+2/2/093/3681/2D/ELECTIO
N 2001: FUNDING - CONSERVATIVE WAR CHEST GETS POUNDS 600,000 BOOSTB/Marie Woolf1
FKG/4/DNMHI+2/2/023/4091/2I/ELECTION 2001 - VIEWS FROM AROUND THE WORLD: SLUGGIN
G VOTERS? THAT'S A NEW ONE1D/Ray Moseley Chicago Tribune (united States)1FKJ/4/D
NMHI+2/2/093/4141/2C/ELECTION 2001: VOTERS' PANEL: BIRMINGHAM EDGBASTON 4,842 LA
BOUR MAJORITY1/ 1FNB/4/DNMKO+2/2/103/5311/25/ELECTION 2001: EDUCATION - EXPERTS 
GIVE THEIR PERSONAL MANIFESTOS1/ 1FNC/4/DNMKO+2/2/054/12191/10/WHERE HAVE ALL TH
E WOMEN GONE?E/Natasha Walter1FND/4/DNMKO+2/2/093/1631/25/ELECTION 2001: MY VOTE
 -'LABOUR HAS BEEN VERY COMPETENT AND ABLE'L/Ben Pimlott Historian1FNE/4/DNMKO+2
/2/093/2351/26/ELECTION 2001: CONSTITUTION - CHARTER 88 UNVEILS 'PINOCCHIO' BLAI
R18/Ian Burrell Home Affairs Correspondent1FNI/4/DNMKO+2/2/023/6371/31/ELECTION 
2001: ELECTION SKETCH - LET'S GET THIS QUITE CLEAR: I NEVER, EVER WENT TO THE DO
MEA/Simon Carr1FNK/4/DNMKO+2/2/063/5941/2M/ELECTION 2001: ANALYSIS - THE 'SECRET
 PLAN' THAT WASN'T SECRET - OR MUCH OF A PLANQ/Stephen Castle In Brussels1FNM/4/
DNMKO+2/2/063/3461/2B/ELECTION 2001: MANIFESTOS - 'SPENDING PROMISES WILL HAVE L
ITTLE EFFECT'15/Ben Russell Political Correspondent1FNN/4/DNMKO+2/2/074/25311/4D
/ELECTION 2001: INTERVIEW: TONY BLAIR - 'THE CAMPAIGN HAS REVOLVED TO A QUITE RI
DICULOUS DEGREE AROUND PERSONALITY RATHER THAN POLICY'13/Donald Macintyre And An
drew Grice1FNO/4/DNMKO+2/2/083/6551/23/ELECTION 2001: CANDIDATES - MINISTERS HAV
E TO FIGHT THE FRINGES1B/Marie Woolf Chief Political Correspondent1FNP/4/DNMKO+2
/2/093/9271/2E/ELECTION 2001: ON THE STUMP - GAY EX-TORY FIGHTS TO HOLD ON TO TH
E RHONDDAE/Barrie Clement1FNS/4/DNMKO+2/2/033/6111/2R/LEADING ARTICLE: LET US HO
PE THE PHONEY WAR IS OVER AND THE BATTLE FOR EUROPE HAS BEGUN1/ 1FNT/4/DNMKO+2/2
/023/4161/2D/ELECTION 2001: VIEWS FROM AROUND THE WORLD - LIGHTEN UP AND HAVE SO
ME FUN11/Nevsal Elevli Milliyet (turkey)1FQO/4/DNMO+3/2/063/1461/16/ELECTION 200
1: A NEW KIND OF POLLING1/ 1FQQ/4/DNMO+3/2/073/7911/2N/ELECTION 2001: HIGHER EDU
CATION - BLAIR BLUNDERS INTO DISPUTE AT STRIKE-HIT COLLEGE15/Ben Russell Politic
al Correspondent1FR0/4/DNMO+3/2/084/12121/2R/ELECTION 2001: ON THE STUMP - CONFI
NED TO RUSHCLIFFE, KEN CLARKE IS KEEPING HIS COUNSELG/Donald Macintyre1FR1/4/DNM
O+3/2/083/4471/2P/ELECTION 2001: EUROPE - MODERN PATRIOTISM MEANS BEING AT THE H
EART OF THE EU, SAYS PMT/Andrew Grice Political Editor1FR2/4/DNMO+3/2/083/2251/2
5/ELECTION 2001: CRIME - JAILED FARMER: POLICE REDUCED TO 'STOOGES'14/Paul Waugh
 Deputy Political Editor1FR3/4/DNMO+3/2/083/3201/28/ELECTION 2001: AGRICULTURE -
 BROWN ATTACKED OVER NEW VIRUS OUTBREAKSA/Terri Judd1FR4/4/DNMO+3/2/093/7041/2D/
ELECTION 2001: SABOTAGE - PARTIES WAGE GUERILLA WAR OF ORGANISED HECKLING14/Paul
 Waugh Deputy Political Editor1FR6/4/DNMO+3/2/103/5711/2A/ELECTION 2001: GENDER 
- WOMEN'S GROUPS ANGRY AT 'SECOND DIVISION' ROLE1B/Marie Woolf Chief Political C
orrespondent1G02/4/DNN3I+2/2/023/6441/2K/ELECTION 2001: IT'S ALL KIND OF A SQUAR
ED CIRCLE THING, Y'KNOW?; ELECTION SKETCHA/Simon Carr1G03/4/DNN3I+2/2/033/3941/2
G/OLDHAM RIOTS: RACIST BEATING WAS TOO GOOD AN OPPORTUNITY FOR THE BNP TO MISSB/
Cahal Milmo1G04/4/DNN3I+2/2/063/4821/1K/ELECTION 2001: LABOUR FEARS THE HINT OF 
FEDERALISM11/John Lichfield And Andrew Grice1G05/4/DNN3I+2/2/063/2521/2S/ELECTIO
N 2001: KENNEDY URGES VOTERS NOT TO ALLOW ANOTHER 'UNHEALTHY' LANDSLIDE; STRATEG
YT/Andrew Grice Political Editor1G08/4/DNN3I+2/2/073/6451/29/ELECTION 2001: DESP
ERATE RIGHT TELLS US WE ARE UNWORTHY OF THE TORIESH/David Aaronovitch1G0A/4/DNN3
I+2/2/083/7471/2G/ELECTION 2001: VOTERS ARE SAYING THAT HEALTH AND EDUCATION MAT
TER; THE POLLSC/John Curtice1G0B/4/DNN3I+2/2/082/791/26/ELECTION 2001: 'LIB DEMS
 ARE HONEST ABOUT TAX AND EUROPE'; MY VOTE15/Vivienne Westwood, Fashion Designer
1G0C/4/DNN3I+2/2/093/9081/33/ELECTION 2001: SWEPT AWAY BY A CHARM OFFENSIVE ON M
Y RETURN TRIP TO CLEETHORPES; ON THE STUMPD/Michael Brown1G0E/4/DNN3I+2/2/023/60
61/2Q/VIEWS FROM AROUND THE WORLD: ELECCTION 2001; ON TOUR WITH THE LABOUR PARTY
 HIT FACTORY1A/Heidi Kingstone, The Star (south Africa)1G0F/4/DNN3I+2/2/034/1188
1/5H/ELECTION 2001: TEN DAYS LEFT TO SAVE MR BROWN'S POLITICAL CAREER; 'OVER THE
 PAST FORTNIGHT, THE CHANCELLOR HAS REVEALED HIMSELF TO BE LEADEN-FOOTED AND WOO
DEN-TONGUED'E/Bruce Anderson1G0H/4/DNN3I+2/2/043/6071/1E/THERE IS AN ALTERNATIVE
 APPROACH TO POLITICSE/Darren Johnson1G3C/4/DNN6O+2/2/094/10131/3C/ELECTION 2001
: ON THE STUMP - TORY SOLDIER IN LAST-DITCH CHALLENGE TO LABOUR IN DUMFRIES; ON 
THE STUMPE/Bruce Anderson1G3G/4/DNN6O+2/2/023/6531/33/ELECTION 2001: ELECTION SK
ETCH - POUNDS 36BN IS A LOT. BUT DON'T WORRY, IT'S A MADE-UP NUMBERA/Simon Carr1
G3H/4/DNN6O+2/2/063/5001/2C/ELECTION 2001: THE MEDIA - READ ALL ABOUT IT - THEN 
READ HOW IT'S UNTRUET/Andrew Grice Political Editor1G3I/4/DNN6O+2/2/064/12911/2Q
/ELECTION 2001: ANALYSIS - VERY FRENCH, VERY DULL BUT LITTLE TO FEAR IN THE JOSP
IN PLANN/John Lichfield In Paris1G3J/4/DNN6O+2/2/063/6571/36/ELECTION 2001: SING
LE CURRENCY - TORIES WANT 'POUND' IN THE REFERENDUM QUESTION; SINGLE CURRENCY1A/
Nigel Morris, Paul Waugh And Ben Russell1G3L/4/DNN6O+2/2/073/7871/3R/ELECTION 20
01: NORTHERN IRELAND - PAISLEY'S TERRIERS COULD BE TROUBLE FOR TRIMBLE AND THE A
GREEMENT; NORTHERN IRELAND18/David Mckittrick Ireland Correspondent1G3M/4/DNN6O+
2/2/073/2861/2J/ELECTION 2001: BUSINESS - LABOUR PLEDGES TO WOO MORE INWARD INVE
STORS; BUSINESS16/Nigel Morris Political Correspondent1G3O/4/DNN6O+2/2/072/691/2
L/ELECTION 2001: MY VOTE- AMY JENKINS: 'LABOUR. BECAUSE THEY ARE LESS EMBARRASSI
NG'1/ 1G3P/4/DNN6O+2/2/083/4871/22/ELECTION 2001: VOTERS' PANEL: EDGBASTON, LABO
UR MAJORITY 4,8421/ 1G3Q/4/DNN6O+2/2/083/3801/2R/ELECTION 2001: LIBERAL DEMOCRAT
S - KENNEDY PLEDGES TO CUT POLLUTANTS; LIBERAL DEMOCRATSB/Marie Woolf1G3R/4/DNN6
O+2/2/083/6251/36/ELECTION 2001: THE GREENS - STRUGGLING ON A SHOESTRING TO GET 
VOICES HEARD BY VOTERS; THE GREENS1B/Marie Woolf Chief Political Correspondent1G
41/4/DNN6O+2/2/034/11741/2B/ELECTION 2001: RIGGING THE REFERENDUM ISN'T AS EASY 
AS THE TORIES THINKG/Donald Macintyre1G43/4/DNN6O+2/2/044/10881/61/ELECTION 2001
: SORRY, MR BROWN, BUT A SCOT WILL NEVER BE PRIME MINISTER AGAIN; 'THE STATE TO 
WHICH THE PEOPLE OF ENGLAND BELONG IS CHANGING FAST, AND THEY NEVER HAVE BEEN CO
NSULTED'D/Tim Luckhurst1G6Q/4/DNNA+3/2/063/5051/31/ELECTION 2001: TORIES SAY TAX
 PLANS WOULD SAVE LOW-EARNING FAMILIES POUNDS 12 A WEEK; TAXES16/Nigel Morris Po
litical Correspondent1G6S/4/DNNA+3/2/074/10341/2H/ELECTION 2001: MAJOR HITS OUT 
AT 'LIES, SPIN AND HYPOCRISY'; COUNTER -ATTACKSS/Nigel Morris And Ben Russell1G6
T/4/DNNA+3/2/073/2821/22/ELECTION 2001: ATTACK ON BLAIR OVER MICROSOFT LAUNCH; B
USINESS14/Paul Waugh Deputy Political Editor1G70/4/DNNA+3/2/083/8891/2A/ELECTION
 2001: NATIONALISTS AIM TO CAP STUNNING ASSEMBLY RESULT; WALESE/Barrie Clement1G
72/4/DNNA+3/2/083/3541/27/ELECTION 2001: PRESCOTT ADMITS LACK OF FUNDING FOR POL
ICY; BUSINESS13/Paul Waugh Deputy Poltical Editor1G76/4/DNNA+3/2/023/6331/2P/VIE
WS FROM AROUND THE WORLD: ELECTION 2001; FORCING PEOPLE TO VOTE DIDN'T WORK FOR 
US1H/Graciela Iglesias-rogers, La Nacion (argentina)1G78/4/DNNA+3/2/034/12071/64
/ELECTION 2001: THE CHARISMATIC SECRETS OF THE MODERN 'IT' POLITICIAN; 'WE ACCEP
T MR BLAIR AT HIS OWN PROJECTION OF COMPETENCE AND SUCCESS, A PRE -EMPTIVE CLAIM
 THAT IS HIS GREAT ASSET'C/Anne Mcelvoy1G79/4/DNNA+3/2/033/7011/4A/NEW LABOUR. N
OW WITH EXTRA CHEESINESS; 'I STARED AT THE RED AND YELLOW OF THE LABOUR STICKERS
. SUDDENLY IT CAME TO ME. MCDONALD'S'D/Miles Kington1GA3/4/DNND6+2/2/063/7391/35
/ELECTION 2001: CRIMINAL JUSTICE REFORMS - BLAIR PLEDGES NEW POWERS TO PROTECT F
RONTLINE WORKERSR/Paul Waugh Political Editor1GA4/4/DNND6+2/2/063/4631/2C/ELECTI
ON 2001: INDEPENDENTS - JORDAN KEEPS HER NAKED AMBITIONS CONCEALED1C/Ian Herbert
 North Of England Correspondent1GA5/4/DNND6+2/2/063/3801/38/ELECTION 2001: EMPLO
YMENT - PARENTS OF YOUNG CHILDREN MAY GET RIGHT TO ASK FOR FLEXIBLE WORK HOURS1B
/Marie Woolf Chief Political Correspondent1GA8/4/DNND6+2/2/073/8971/2I/ELECTION 
2001: TORY LEADER - HAGUE STARTS TO SHOW STRAINS OF INEVITABLE DEFEATS/Andrew Gr
ice And Ben Russell1GA9/4/DNND6+2/2/073/4331/2F/ELECTION 2001: AGENDA - PORTILLO
 MOVES TO FREE TORIES FROM THATCHER'S SPELL16/Nigel Morris Political Corresponde
nt1GAA/4/DNND6+2/2/073/5641/33/ELECTION 2001: EUROPE - PRO-EURO GROUP FEARS VOTI
NG RULES WILL BENEFIT THE 'ANTI' CAMPAIGNERSC/Andrew Grice1GAC/4/DNND6+2/2/083/8
231/2A/ELECTION 2001: POLLS - SCOTTISH TORIES FACE A SECOND SHATTERING DEFEATA/M
ary Braid1GAE/4/DNND6+2/2/083/6141/29/ELECTION 2001: VOTERS' PANEL: ST HELENS SO
UTH, 23,739 LABOUR MAJORITY1/ 1GAG/4/DNND6+2/2/093/1231/2J/ELECTION 2001: MY VOT
E - KATHY LETTE: 'LABOUR: PASSIONATE ABOUT THEIR POLICIES'B/Kathy Lette1GAI/4/DN
ND6+2/2/103/3791/2O/ELECTION 2001: PENSIONERS - TORIES PROMISE TAX CUTS TO WIN B
ACK 'GREY VOTE' PROMISES16/Nigel Morris Political Correspondent1GAM/4/DNND6+2/2/
054/12151/18/SEVEN DAYS TO SAVE THIS GRIMY ELECTIOND/Michael Dobbs1GDF/4/DNNGC+2
/2/063/4861/32/ELECTION 2001: EDUCATION - UNDERFUNDING HAS CREATED 'THIRD WORLD'
 PUBLIC SERVICES, SAY HEADS11/Richard Garner Education Editor1GDG/4/DNNGC+2/2/06
3/2701/2J/ELECTION 2001: BENEFITS - TORIES PLAN TO ABOLISH FAMILY TAX CREDIT, SA
YS LABOUR16/Nigel Morris Political Correspondent1GDI/4/DNNGC+2/2/073/1301/2N/ELE
CTION 2001: MY VOTE - BARRY NORMAN: 'LIB DEM: DEMOCRACY WOULDN'T BE A BAD THING'
C/Barry Norman1GDK/4/DNNGC+2/2/083/5811/28/ELECTION 2001: MEDIA - WHY SILENT VAZ
 IS HOT, BUT SHORT IS STILL NOT17/David Lister Media And Culture Editor1GDM/4/DN
NGC+2/2/093/8131/3R/ELECTION 2001: LEADERS' QUIZ - BLAIR IS STUMPED BY TV COOLNE
SS TEST WHILE TRENDY HAGUE MUGGLES THROUGH; LEADERS' QUIZQ/Paul Waugh And Ben Ru
ssell1GDQ/4/DNNGC+2/2/034/11981/1R/THE DEATH OF THE TORY PARTY WOULD BE A LOSS F
OR ALL OF USD/Michael Brown1GDR/4/DNNGC+2/2/043/6361/1D/ONLY WOMEN KNOW THE BALD
 SECRET OF VIRILITYF/Terence Blacker1GGO/4/DNNQ+3/2/063/5701/2P/ELECTION 2001: C
LAIMS OF POSTAL BALLOT FRAUD TO BE INVESTIGATED; ELECTORAL COMMISSION14/Paul Wau
gh Deputy Political Editor1GGP/4/DNNQ+3/2/063/2981/2H/ELECTION 2001: LIB DEMS FE
AR LOSS OF THEIR THREE SEATS HELD BY WOMEN; TACTICS1B/Marie Woolf Chief Politica
l Correspondent1GGR/4/DNNQ+3/2/063/1721/22/ELECTION 2001: HAGUE CHALLENGED OVER 
COMMITMENT TO NHS; HEALTHA/Paul Waugh1GGT/4/DNNQ+3/2/083/9141/3G/ELECTION 2001: 
LABOUR UNDER THREAT FROM PAVEMENT POLITICS IN THE POLL BLAIR TRIED TO BURY; LOCA
L ELECTIONSS/Ian Herbert And Kim Sengupta1GH4/4/DNNQ+3/2/023/6281/33/ELECTION 20
01: VIEWS FROM AROUND THE WORLD; RIDICULOUS ROSETTES AND THE MOTHER OF PARLIAMEN
TS18/Tom Levine, Berliner Zeitung (germany)1GH5/4/DNNQ+3/2/033/6241/2N/LEADING A
RTICLE: THE ANSWER TO FEARS OF A LANDSLIDE LIES IN REFORM OF OUR DEMOCRACY1/ 1GH
7/4/DNNQ+3/2/044/11321/2B/YOU MAY CALL THIS ELECTION BORING, BUT TO AMERICAN EYE
S IT'S IMPRESSIVEB/James Rubin1GK5/4/DNNT6+2/2/063/5841/2A/ELECTION 2001: TORY W
OMEN ACCUSE HAGUE OF IGNORING ISSUES; FEMALE VOTE1B/Marie Woolf Chief Political 
Correspondent1GK6/4/DNNT6+2/2/063/3391/2F/ELECTION 2001: SCOTTISH TORIES MAY BRE
AK AWAY IF NO SEATS ARE WON; SCOTLANDD/Tim Luckhurst1GKA/4/DNNT6+2/2/073/9231/3T
/ELECTION 2001: HUGGY BEAR SAYS: 'WORD ON THE STREET IS BELL.' IT LOOKS AS IF TH
E PEOPLE OF BRENTWOOD AGREE; INDEPENDENTC/John Sweeney1GKB/4/DNNT6+2/2/084/10031
/3H/ELECTION 2001: ANOTHER IMPRESSIVE VICTORY BECKONS FOR BLAIR, BUT THIS TIME T
HINGS REALLY HAVE TO GET BETTERC/John Curtice1GKD/4/DNNT6+2/2/083/4521/34/ELECTI
ON 2001: ELECTORAL COMMISSION WARNS OF FRAUD CLAIMS OVER POSTAL VOTING; LEGAL CH
ALLENGES16/Nigel Morris Political Correspondent1GKE/4/DNNT6+2/2/083/5001/26/ELEC
TION 2001: LADBROKES PAYS OUT ON DEAD CERT LABOUR WIN; BETTINGF/Stephen Pollard1
GKF/4/DNNT6+2/2/083/4431/2F/ELECTION 2001: MAFF DENIES HAGUE'S CLAIM OF POST-ELE
CTION CULL; AGRICULTURE15/Ben Russell Political Correspondent1GKI/4/DNNT6+2/2/09
3/5221/2P/ELECTION 2001: I WON'T CLOBBER THE RICHEST WITH HIGHER TAXES, BLAIR TE
LLS PAXMAN; TAX1B/Marie Woolf Chief Political Correspondent1GND/4/DNO2C+2/2/063/
9581/2N/ELECTION 2001: BLAIR: TIME FOR A CLEAN BREAK FROM THATCHER'S LEGACY; KEY
NOTE SPEECH14/Paul Waugh Deputy Political Editor1GNE/4/DNO2C+2/2/063/4871/2E/ELE
CTION 2001: SMITH PROMISES EARLY ACTION TO SCRAP SECTION 28; GAY RIGHTST/Andrew 
Grice Political Editor1GNF/4/DNO2C+2/2/063/5221/2F/ELECTION 2001: PARTIES TO BOM
BARB VOTERS AS THE COUNTDOWN BEGINS; CAMPAIGNS16/Nigel Morris Political Correspo
ndent1GNH/4/DNO2C+2/2/073/5371/2F/ELECTION 2001: HAGUE ATTACKS PM OVER SCHOOLING
 OF HIS CHILDREN; FINAL RALLYS/Ben Russell And Nigel Morris1GNL/4/DNO2C+2/2/083/
4181/8A/ELECTION 2001: VOTERS' PANEL: BIRMINGHAM EDGBASTON, 4,842 LABOUR MAJORIT
Y; WITH THE TORIES STILL TRAILING IN OPINION POLLS, VOTERS IN MIDDLE- CLASS EDGB
ASTON, WHICH CHANGED HANDS IN 1997, GIVE THEIR OPINIONS ON THE PROSPECT OF ANOTH
ER LANDSLIDE FOR L1/ 1GQM/4/DNO5I+2/2/023/5841/14/BLAIR TO CUT TREASURY'S POWER 
BASEC/Andrew Grice1GQP/4/DNO5I+2/2/143/9401/2I/ELECTION 2001: LIBERAL DEMOCRATS 
- KENNEDY HAPPY HE HAS GOT HIS MESSAGE ACROSSB/Marie Woolf1GQQ/4/DNO5I+2/2/153/9
151/2D/ELECTION 2001: TORIES - TORY LEADERS-IN-WAITING SET OUT THEIR CREDENTIALS
S/Nigel Morris And Ben Russell1GQS/4/DNO5I+2/2/164/27581/2L/ELECTION 2001: YOUR 
MINUTE-BY-MINUTE GUIDE TO HOW THE BATTLE WILL BE WON AND LOST1/ 1GQT/4/DNO5I+2/2
/163/5371/34/ELECTION 2001: THE SWINGOMETER - CAN WILLIAM HAGUE SWING IT? HIS TA
SK LOOKS ALL BUT IMPOSSIBLEC/Sean O'grady1GR0/4/DNO5I+2/2/173/6901/2D/ELECTION 2
001: TELEVISION - PUNDITS READY FOR THEIR VERSION OF 'SURVIVOR'B/Louise Jury1GR2
/4/DNO5I+2/2/183/3731/2A/ELECTION 2001: VOTERS' PANEL: ENFIELD SOUTHGATE, 1,433 
LABOUR MAJORITY1/ 1GR3/4/DNO5I+2/2/193/7451/33/ELECTION 2001: MEDIA - THE TORY P
RESS HASN'T GONE AWAY - IT'S JUST WAITING FOR THE REFERENDUMH/David Aaronovitch1
GR5/4/DNO5I+2/2/193/7791/1R/ELECTION 2001: MONITOR - FINAL VERDICTS OF THE EDITO
RIALSJ/Compiled By Ben Chu1GRB/4/DNO5I+2/2/053/8331/5E/WE MUST END THE SUFFERING
 OF ALL THOSE POOR LABOUR ADDICTS; 'IN 2037, PEOPLE WILL SAY; "BLAIR'S CAUTIOUS 
BECAUSE HE'S WAITING TO BE RADICAL IN THE VITAL 11TH TERM"'A/Mark Steel1GRC/4/DN
O5I+2/2/054/12211/52/THE CHANGING ART OF GOVERNMENT; 'POLITICS IS STILL PAROCHIA
L. WE BUY OUR CARS FROM ANYWHERE IN THE WORLD BUT WE HAVE TO BUY OUR POLITICIANS
 FROM BRITAINC/Hamish Mcrae1PK3/5/DNL2O+2/2/083/4601/14/COMMONS WILL BE THE ELEC
TION LOSER16/Trevor Kavanagh Sun political editor1PK5/5/DNL2O+2/2/083/6111/E/BLA
IR:I WANT 31E/George Pascoe-Watson Deputy Political Editor1PNB/5/DNL6+3/2/063/51
61/I/ROUND ONE TO HAGUE1E/George Pascoe-Watson Deputy Political Editor1PNE/5/DNL
6+3/2/083/6021/13/WE SHARE SUN'S VISION FOR BRITAIN19/William Hague Conservative
 Party Leader1PNH/5/DNL6+3/2/073/1101/Q/PORTILLO GIVES IT HIS BEST1/ 1PQM/5/DNL9
6+2/2/083/6561/19/LABOUR: THE PARTY OF ECONOMIC STABILITYP/Tony Blair prime mini
ster1PQP/5/DNL96+2/2/083/7511/12/HAGUE: I'D CUT TAX BY POUNDS 8BN12/Trevor Kavan
agh political editor1PQQ/5/DNL96+2/2/093/1121/S/PM WON'T 'PUSH US INTO EURO'1/ 1
Q01/5/DNLIO+2/2/093/2331/11/POUNDS 1BN-A-WEEK TAX HIKE FURY1/ 1Q02/5/DNLIO+2/2/0
92/561/M/GERI STARS IN TELLY AD1/ 1Q03/5/DNLIO+2/2/082/901/T/'STITCH-UP' FOR TOR
Y DEFECTOR1/ 1Q08/5/DNLIO+2/2/093/1041/R/HAGUE'S DAD SAYS HE'LL LOSE9/Nic Cecil1
Q3E/5/DNLM+3/2/023/1311/12/MATRONS TO FIRE SLOPPY NHS FIRMSK/George Pascoe-watso
n1Q3G/5/DNLM+3/2/022/911/L/SLEAZE BUST-UP FOR PM1/ 1Q3I/5/DNLM+3/2/022/911/M/TOR
IES' BOOKLET BINNEDD/David Wooding1Q6L/5/DNLP6+2/2/023/1171/K/PM: I'LL DO A MAGG
IE1/ 1Q6M/5/DNLP6+2/2/073/2641/R/STAR WHO BEAT HUGE OBSTACLE16/Trevor Kavanagh S
un Political Editor1Q6N/5/DNLP6+2/2/064/15901/O/THIS CHARMING, WITTY MAN11/Sue E
vison Chief Feature Writer1Q6Q/5/DNLP6+2/2/023/1211/M/OK TO SIGN EU PETITION1/ 1
Q6R/5/DNLP6+2/2/023/1221/O/TORIES TOLD: NO TAX TALK1/ 1Q6S/5/DNLP6+2/2/023/2421/
L/TONY GRABS GORD GLORYF/Trevor Kavanagh1Q70/5/DNLP6+2/2/063/6241/14/BLUNKETT MI
SSION IS TO SMASH CRIME13/Trevor Kavanagh, Political Editor1Q72/5/DNLP6+2/2/083/
1791/L/BLUNKETT'S BIG CHANCE1/ 1Q73/5/DNLP6+2/2/083/5831/1A/HAGUE HAS TO GET TOR
Y TAX STORY STRAIGHT12/Trevor Kavanagh Political Editor1QA2/5/DNLSC+2/2/094/1268
1/I/BLAIR'S REVOLUTION14/Trevor Kavanagh , Political Editor1QA3/5/DNLSC+2/2/093/
2301/A/COMMENTARY16/Trevor Kavanagh Sun Political Editor1QA5/5/DNLSC+2/2/023/126
1/17/LABOUR'S JOY AS DOLE HITS 26-YEAR LOW1E/George Pascoe-watson Deputy Politic
al Editor1QA8/5/DNLSC+2/2/092/721/13/'NO SNAP POLL ON POUNDS ' VOWS PM1/ 1QDC/5/
DNM1I+2/2/113/9581/1B/YOU'RE A BIG MAN, BUT YOU'RE OUT OF ORDERI/Richard Littlej
ohn1QDF/5/DNM1I+2/2/022/771/14/LABOUR STRETCHES LEAD IN THE POLLS1/ 1QDH/5/DNM1I
+2/2/022/821/16/FUEL RISE TRIGGERS NEW CRISIS THREAT1/ 1QDK/5/DNM1I+2/2/063/4191
/H/BIG FIGHT VERDICTD/Oliver Harvey1QDM/5/DNM1I+2/2/082/401/D/BETTER HALVES1/ 1Q
DO/5/DNM1I+2/2/083/1761/9/SPIN FREE1/ 1QGL/5/DNMB6+2/2/083/7111/17/IT'S UNCOSTED
 UNWORKABLE UNAFFORDABLEA/Tony Blair1QK2/5/DNMEC+2/2/083/1091/A/OLD GRUMPS1/ 1QK
6/5/DNMEC+2/2/064/11951/1R/20 THINGS TO TURN YOU OFF VOTING FOR WOULD-BE MP WOOD
WARDD/PHILIP MARTIN1QK7/5/DNMEC+2/2/083/7041/15/TORIES WARN OF 50P IN THE POUND 
TAX13/Trevor Kavanagh, Political Editor1QNB/5/DNMHI+2/2/083/5881/M/TORIES FACE E
XTINCTION1F/George Pascoe-Watson, Deputy Political Editor1QNC/5/DNMHI+2/2/092/93
1/12/BLAIR CLEARS NEWSMEN ON BUST-UPS1/ 1QNE/5/DNMHI+2/2/023/1781/S/PM BOOKS SON
G STAR CHARLOTTED/Dominic Mohan1QNG/5/DNMHI+2/2/093/4791/1N/ROUT ON JUNE 7 WOULD
 MEAN A HAMMER BLOW FOR DEMOCRACYK/George Pascoe-Watson1QQM/5/DNMKO+2/2/083/1871
/A/HIGH PRICE1/ 1QQO/5/DNMKO+2/2/083/2731/1B/CHANCELLOR ADMITS OLD LABOUR GOT IT
 WRONGF/Trevor Kavanagh1QQQ/5/DNMKO+2/2/083/4961/P/NO TO EURO VOTE NEXT TERM12/T
revor Kavanagh Political Editor1QQR/5/DNMKO+2/2/093/2671/11/POUNDS 70M VOW TO GI
FTED PUPILS11/David Wooding, Whitehall Editor1R03/5/DNMO+3/2/033/1431/L/'TEARAWA
Y' KIDS STORM1F/George Pascoe-Watson, Deputy political editor1R06/5/DNMO+3/2/083
/3101/15/HAGUE WILL QUIT QUICKLY IF TROUNCED1/ 1R6L/5/DNN6O+2/2/083/2821/C/EURO 
SUICIDE1/ 1R6M/5/DNN6O+2/2/023/1471/1G/MOTORISTS WARNED OF POUNDS 4 GALLON AFTER
 POLL1/ 1R6N/5/DNN6O+2/2/023/1021/I/TORY FURY AT BLAME1/ 1R6O/5/DNN6O+2/2/064/10
601/J/DEATH OF OUR NATION1F/George Pascoe-Watson, Deputy Political Editor1RA5/5/
DNNA+3/2/073/3481/R/HELP OUR SICK GIRL, PM TOLDC/Chris Riches1RA8/5/DNNA+3/2/083
/2461/D/NO QUICK VOTE1/ 1RA9/5/DNNA+3/2/213/4301/19/LAW & ORDER TORY IS REALLY D
RUGS EX-CON10/Tracey Kandohla and Tom Worden1RDC/5/DNND6+2/2/023/1571/J/HAGUE JA
B AT PREZZA1/ 1RDE/5/DNND6+2/2/022/811/14/NOTHING CAN DENT LABOUR'S BIG LEAD1/ 1
RDF/5/DNND6+2/2/083/7861/M/WHY I'M VOTING LIB DEME/Grant Rollings1RDG/5/DNND6+2/
2/083/1521/D/ONE WEEK LEFT1/ 1RDI/5/DNND6+2/2/123/5081/Q/THINGS CAN ONLY GET BUT
LER12/Charles Yates and Martel Maxwell1RGO/5/DNNGC+2/2/083/1651/9/TOUGH JOB1/ 1R
GR/5/DNNGC+2/2/093/1031/J/CAMPBELL CASH PROBE1/ 1RGT/5/DNNGC+2/2/093/1381/J/HAGU
E IN POLL ALERT11/David Wooding, Whitehall Editor1RH1/5/DNNGC+2/2/113/8621/Q/FRA
NKIE GOES TO HARTLEPOOLI/Richard Littlejohn1RH2/5/DNNGC+2/2/113/5351/15/HEY, HEY
 BILLY...HERE COMES RICHARDI/Richard Littlejohn1RK2/5/DNNQ+3/2/063/7851/N/JACK'S
 ON BOARD WITH USC/Mark Bowness1RK4/5/DNNQ+3/2/083/7471/22/KENNEDY'S ROLE IN THE
 ELECTION IS THAT OF BLAIR'S USEFUL IDIOTI/Richard Littlejohn1RK5/5/DNNQ+3/2/093
/2661/1C/SLEAZE-ROW VAZ TO GET THE BULLET ON FRIDAYK/George Pascoe-Watson1RK6/5/
DNNQ+3/2/092/941/K/TONY GETS THE NEEDLE1/ 1RNC/5/DNNT6+2/2/063/4401/L/WE HUNT IN
VAZIBLE MANC/Mark Bowness1RNE/5/DNNT6+2/2/083/2971/J/A PIVOTAL INTERVIEW1/ 1RNF/
5/DNNT6+2/2/082/821/A/HOLD TIGHT1/ 1RNH/5/DNNT6+2/2/093/1511/10/HAGUE TV VID BID
 TO STAY CHIEFK/George Pascoe-Watson1RNI/5/DNNT6+2/2/093/5161/D/IT'S A BLAIR!1F/
George Pascoe-Watson, Deputy Political Editor1RNK/5/DNNT6+2/2/093/1751/R/IT'S FF
ION THE CARDS FOR MEB/Michael Lea1RQP/5/DNO2C+2/2/062/551/Q/I'M STANDING FOR THE
 GIRLS1/ 1RQS/5/DNO2C+2/2/093/6051/D/MORE VAZ LIESB/Michael Lea1RQT/5/DNO2C+2/2/
093/1711/15/POLL CUTS LABOUR'S LEAD TO JUST 11%13/Trevor Kavanagh, Political Edi
tor1RR0/5/DNO2C+2/2/082/401/7/OH GORD1/ 1S09/5/DNO5I+2/2/072/661/I/20-1 FOR LAND
SLIDE1/ 1S0A/5/DNO5I+2/2/083/9341/19/IF YOU DON'T WANT A LABOUR LANDSLIDE...I/Ri
chard Littlejohn1S0B/5/DNO5I+2/2/093/7761/1B/SORRY ISN'T ENOUGH.. BLAIR MUST DO 
BETTER12/Trevor Kavanagh Political Editor1S0C/5/DNO5I+2/2/093/1591/F/TV COVERAGE
 WARR/Emily Smith, TV News Editor26NB/6/DNL2O+2/2/033/1951/T/ELECTION 2001: WIN'
S ON CARDSB/James Hardy26ND/6/DNL2O+2/2/024/12061/2D/ELECTION 2001: INTERVIEW: B
LAIR'S PLEDGE TO MIRROR READERS: TIME TO DO IIB/James Hardy26NF/6/DNL2O+2/2/073/
4251/2A/ELECTION 2001: HE'S OAPLESS; PENSIONER CATH HIJACKS HAGUE'S BIG LAUNCH14
/Tom Newton Dunn And David Pilditch26NG/6/DNL2O+2/2/073/1671/1I/ELECTION 2001: C
HEF ROASTS TORY CHIEF; EXCLUSIVE12/Paul Gilfeather Whitehall Editor26NH/6/DNL2O+
2/2/072/901/14/ELECTION 2001: CAMPBELL QUITS POSTF/Oonagh Blackman26NI/6/DNL2O+2
/2/072/861/16/ELECTION 2001: BABY, WHAT A CHEEK...B/Bob Roberts26NM/6/DNL2O+2/2/
043/7531/19/ELECTION 2001: APATHY IS THE REAL ENEMYE/Paul Routledge26QL/6/DNL6+3
/2/043/6661/1S/ELECTION 2001: CARD LABOUR; 5 PLEDGES FOR THE NEXT 5 YEARS1E/Jame
s Hardy, Paul Gilfeather And Bob Roberts26QN/6/DNL6+3/2/022/701/2B/ELECTION 2001
: INTRODUCING A NEW TORY ADVERTISING CAMPAIGN.. VOTE TESCOH/Lorraine Davidson26Q
O/6/DNL6+3/2/023/3551/2N/ELECTION 2001: KICK IN THE HINDUJAS; EXCLUSIVE: EXPOSED
: 2-YR-OLD TORY LETTER SMEARF/Oonagh Blackman26QQ/6/DNL6+3/2/022/651/14/ELECTION
 2001: HAGUE IN ALARM CALLF/Paul Gilfeather26QS/6/DNL6+3/2/043/4411/1K/ELECTION 
2001: SPEECH PUT THE FINAL NAIL IN COFFINE/Paul Routledge26R2/6/DNL6+3/2/053/183
1/16/ELECTION 2001: GORDON'S GOLDEN GOALS12/Paul Gilfeather Whitehall Editor26R3
/6/DNL6+3/2/022/781/17/ELECTION 2001: REID TICKS OFF TRIMBLEF/Oonagh Blackman270
3/6/DNL96+2/2/023/3601/2K/ELECTION 2001: THE LOWEST OF THE LOAN; BANK BOOSTS LAB
OUR WITH INTEREST RATE CUT11/Clinton Manning Business Editor2704/6/DNL96+2/2/023
/1351/3B/ELECTION 2001: SHERBET, LOLLIPOPS, BLACK JACKS, BRIE AND AVOCADO SANDWI
CHES.. IT'S ALL ON BLAIR'S BUSB/Bob Roberts2706/6/DNL96+2/2/022/501/18/ELECTION 
2001: HEATH SLAMS HAGUE AGAIN1/ 270A/6/DNL96+2/2/043/2461/1K/ELECTION 2001: SACK
ED RIVAL SLAMS MANDY; EXCLUSIVEF/Oonagh Blackman270B/6/DNL96+2/2/043/1011/14/ELE
CTION 2001: MELTDOWN FOR TORIESF/Oonagh Blackman270F/6/DNL96+2/2/063/3241/2K/PAU
L ROUTLEDGE'S COLUMN: HAGUE BRIBES WON'T FUEL US; CUT WOULD COST POUNDS 2.2BNE/P
aul Routledge270G/6/DNL96+2/2/062/681/19/PAUL ROUTLEDGE'S COLUMN: HEAD IN CLOUDS
E/Paul Routledge270H/6/DNL96+2/2/063/2851/1D/PAUL ROUTLEDGE'S COLUMN: BIG BENN I
S TIMELYE/Paul Routledge273B/6/DNLIO+2/2/073/3281/1M/ELECTION 2001: GERI BLAIR; 
SHE'S IN LABOUR BROADCASTT/James Hardy, Political Editor273G/6/DNLIO+2/2/023/189
1/33/ELECTION 2001: IT'LL BE A MIRACLE IF HAGUE WINS THE ELECTION ..SAYS HAGUE'S
 FATHER! - VERDICTE/Paul Routledge276L/6/DNLM+3/2/063/1191/13/VOICE OF THE MIRRO
R: HOME SERVICE1/ 276M/6/DNLM+3/2/043/6091/31/ELECTION 2001: THE BIRD BRAINS; TO
RIES IMPLODE ON TAX AS POUNDS 8BN CUTS BECOME POUNDS 20BN1A/Oonagh Blackman, Dep
uty Political Editor276O/6/DNLM+3/2/042/541/16/ELECTION 2001: OH MY GOD, SHE'S B
ACK1/ 276P/6/DNLM+3/2/053/1131/Q/ELECTION 2001: UP THE REDSB/James Hardy276T/6/D
NLM+3/2/052/521/15/ELECTION 2001: PM DENIES USING SPIN1/ 27A4/6/DNLP6+2/2/023/22
71/2D/ELECTION 2001: RAPE SLUR; FURY AS ELECTION VIDEO 'BLAMES' CRIME ON LABOUR1
2/Paul Gilfeather Whitehall Editor27A5/6/DNLP6+2/2/022/611/1B/ELECTION 2001: TOR
Y'S AIRGUN CASE DROPPED1/ 27A7/6/DNLP6+2/2/023/1061/16/ELECTION 2001: BOOK AN OP
 ON THE NHSB/Jill Palmer27DB/6/DNLSC+2/2/073/1381/1D/ELECTION 2001: BLAIR: NO RU
SH FOR EURO VOTEB/James Hardy27DD/6/DNLSC+2/2/063/2141/1N/VOICE OF THE MIRROR: W
HY LABOUR MUST SORT OUT THE NHS1/ 27DE/6/DNLSC+2/2/062/671/14/VOICE OF THE MIRRO
R: BALLOT BOXING1/ 27DK/6/DNLSC+2/2/072/771/18/ELECTION 2001: NURSERY TO BE FREE
 AT 31/ 27GL/6/DNM1I+2/2/ 43/6311/47/ELECTION 2001: HE SHOULD HAVE USED HIS RIGH
T; SPECIAL PREZZA TRIBUTE EDITION: EXCLUSIVE WE GET VERDICT OF PREZZA'S BOXING C
OACHA/Don Mackay27GN/6/DNM1I+2/2/023/8651/51/ELECTION 2001: HE WOULD HAVE BEEN L
ESS OF A MAN IF HE HAD NOT REACTED IN THE WAY HE DID; SPECIAL PREZZA TRIBUTE EDI
TION: PRESCOTT'S MUM BACKS HIS PUNCH1N/Lucy Rock, Don Mackay, David Pilditch And
 James Hardy27GS/6/DNM1I+2/2/053/3261/17/ELECTION 2001: EVANS HUNTS DOWN HARESP/
Paul Byrne And Jan Disley27H1/6/DNM1I+2/2/063/2071/20/PAUL ROUTLEDGE'S COLUMN: L
ETWIN LETS TORY CAT OUT OF THE BAGE/Paul Routledge27H2/6/DNM1I+2/2/062/411/29/PA
UL ROUTLEDGE'S COLUMN: MANDELSON FLOUNCES OUT OF BBC NEWSNIGHT SHOWE/Paul Routle
dge27H3/6/DNM1I+2/2/073/3291/2D/ELECTION 2001: STRAW: HECKLERS WERE BOOZED UP; '
CRASS INSULT' ANGERS COPS19/Oonagh Blackman Deputy Political Editor27H6/6/DNM1I+
2/2/072/571/1H/ELECTION 2001: SSTOP PPRESS: FFION HHAS SSPOKEN1/ 27H7/6/DNM1I+2/
2/123/3711/12/TAKE SPLAT; HITS WITH THE VOTERS1/ 27H8/6/DNM1I+2/2/063/1861/1E/PA
UL ROUTLEDGE'S COLUMN: KEEP OUT OF IT, KENE/Paul Routledge27H9/6/DNM1I+2/2/063/2
611/1M/VOICE OF THE MIRROR: A THUMPING SUCCESS FOR PRESCOTT1/ 27K1/6/DNMB6+2/2/0
23/3131/2N/ELECTION 2001: TORIES PLUNGED INTO CIVIL WAR; PARTY BOSSES ARGUE OVER
 POLL STRATEGY19/Oonagh Blackman Deputy Political Editor27K2/6/DNMB6+2/2/053/186
1/17/ELECTION 2001: TORY PREZZA SMEAR KO'DA/Paul Byrne27K4/6/DNMB6+2/2/023/1501/
18/ELECTION 2001: POUNDS 20BN CUTS DENIEDF/Oonagh Blackman27K5/6/DNMB6+2/2/023/1
961/1N/ELECTION 2001: LABOUR SET OUT 'PORTILLO' FIRST BUDGETF/Oonagh Blackman27K
8/6/DNMB6+2/2/043/1151/1G/ELECTION 2001: WHY BLAIR FAN GERI'S NOT VOTINGA/Paul B
yrne27KA/6/DNMB6+2/2/053/5421/2Q/ELECTION 2001: FIVE YEARS FOR LURING KIDS ONLIN
E; STRAW CRACKDOWN ON CHATROOM PERVERTS12/Paul Gilfeather Whitehall Editor27KB/6
/DNMB6+2/2/063/1961/21/VOICE OF THE MIRROR: NET PERVERTS MUST TOP THE CRIME HIT 
LIST1/ 27KC/6/DNMB6+2/2/063/1071/16/VOICE OF THE MIRROR: SAME OLD TORY..1/ 27NB/
6/DNMEC+2/2/022/441/1B/ELECTION 2001: BROWN ANGER AT 'PACT' TALK1/ 27NC/6/DNMEC+
2/2/023/3561/2R/ELECTION 2001: WEALTH SERVICE; NHS GETS POUNDS 100M FOR CHILD CA
RE TO BRING BACK NURSESS/James Hardy Political Editor27NE/6/DNMEC+2/2/022/771/19
/ELECTION 2001: GROWING PAINS FOR RIVALS1/ 27QN/6/DNMHI+2/2/022/911/R/ELECTION 2
001: BLUNKETT ROWB/James Hardy27QO/6/DNMHI+2/2/022/891/S/ELECTION 2001: U-TURN O
N TAX13/Paul Gilfeather, Whitehall Editor27QQ/6/DNMHI+2/2/063/1821/1T/ELECTION 2
001: VOICE OF THE MIRROR: MAGGIE KILLS TORY HOPES1/ 27QR/6/DNMHI+2/2/023/2891/20
/ELECTION 2001: THE MUMMY RETURNS; MAGGIE RUINS TORY EURO VOW19/Oonagh Blackman 
Deputy Political Editor2801/6/DNMKO+2/2/043/9911/2P/TORIES ARE A BUNCH OF LOSERS
 WITHOUT THATCHER; SIR ALAN SUGAR ON HIS SWITCH TO LABOUR1/ 2802/6/DNMKO+2/2/022
/551/18/ELECTION 2001: TORIES FACE VICTORY BAR1/ 2803/6/DNMKO+2/2/022/531/15/ELE
CTION 2001: YOUNG WILL SNUB VOTE1/ 2805/6/DNMKO+2/2/023/3281/M/ELECTION 2001: VE
RDICT1C/Paul Routledge Chief Political Commentator2807/6/DNMKO+2/2/053/6331/46/W
ATCH YOUR BACK, WILLIE; AS ELECTION DISASTER LOOMS, HAGUE'S MOST VALUED CONFIDAN
TE TELLS HIM 'I DON'T TRUST PORTILLO AN INCH'13/Paul Gilfeather, Whitehall Edito
r2808/6/DNMKO+2/2/063/2601/1O/VOICE OF THE MIRROR: HAGUE AND HIS BIGOTS ARE HIS-
TORY1/ 283D/6/DNMO+3/2/023/4671/2B/ELECTION 2001: MY 17-HOUR DAY TO MAKE SURE TO
NY STAYS IN DOWNING STREET11/James Hardy And Oonagh Blackman283F/6/DNMO+3/2/063/
2031/1Q/VOICE OF THE MIRROR: MAKE CHILD POVERTY THE RALLYING CRY1/ 283G/6/DNMO+3
/2/063/4341/2B/ROUTLEDGE : WHO LET BLAIR BULLY-DOGS OUT?; THEY MUST STOP SAVAGIN
G GORDE/Paul Routledge283J/6/DNMO+3/2/073/1551/1E/ELECTION 2001: PM WANTS BYERS 
FOR SCHOOL JOBB/Bob Roberts283L/6/DNMO+3/2/023/1551/1D/ELECTION 2001: 'WEATHER M
IX' ON POLLING DAY1/ 286M/6/DNN3I+2/2/024/35951/70/ELECTION 2001: MAY 28TH 2006:
 A HORROR TORY: BRITAIN IS DYING; AND HAGUE'S IN HIDING; ECONOMY IN RUINS AND KI
CKED OUT OF EU JOBLESS AT 3 MILLION, INTEREST RATES AT 15% CIVIL WAR IN IRELAND,
 SHUNNED BY THE WORLD27/Brian Reade, Mirror Man Jailed For Daring To Poke Fun At
 The Tories286N/6/DNN3I+2/2/023/4611/30/ELECTION 2001: MAY 28TH 2006: A HORROR T
ORY: ROUTLEDGE - HE'S OFF MESSAGE AND IN DETENTIONE/Paul Routledge286Q/6/DNN3I+2
/2/053/3631/32/ELECTION 2001: MAY 28TH 2006: A HORROR TORY: HEALTH - URGENT OPS 
ONLY AS NURSES QUIT; HEALTHB/Jill Palmer286T/6/DNN3I+2/2/042/541/2G/ELECTION 200
1: MAY 28TH 2006: A HORROR TORY: FURY OF PARENTS AT PLACES CHAOS1/ 2870/6/DNN3I+
2/2/063/2671/2O/ELECTION 2001: MAY 28TH 2006: A HORROR TORY: HOUSING - FAMILIES 
SUFFER AS LOANS SOART/Stephen White And Bob Roberts2873/6/DNN3I+2/2/073/4151/2E/
ELECTION 2001: MAY 28TH 2006: A HORROR TORY: JAMES HARDY, POLITICAL EDITORB/Jame
s Hardy2874/6/DNN3I+2/2/173/2861/2J/ELECTION 2001: WILLIAM, YOU ARE THE WEAKEST 
LINK; HAGUE TARGETED IN POLL RUN-UPT/James Hardy, Political Editor28A3/6/DNN6O+2
/2/023/3671/37/ELECTION 2001: POLL AXED; TORIES HEAD FOR MELTDOWN AS THEY LAG BE
HIND ON EVERY MAJOR POLICY ISSUE12/Paul Gilfeather Whitehall Editor28A4/6/DNN6O+
2/2/023/2131/11/JOSPIN: WE BACK BLAIR ON EUROPED/Graham Brough28A6/6/DNN6O+2/2/0
63/1841/13/VOICE OF THE MIRROR: EUROPELESS..1/ 28A7/6/DNN6O+2/2/062/571/14/VOICE
 OF THE MIRROR: HOUSE PARTIES1/ 28DC/6/DNNA+3/2/023/1131/17/ELECTION 2001: MAGGI
E HANDBAGS TV MANE/Steve Mccomish28DD/6/DNNA+3/2/023/1251/1K/ELECTION 2001: TORY
 NO 2 ADMITS BLAIR WILL WALK IT13/Paul Gilfeather, Whitehall Editor28DE/6/DNNA+3
/2/022/491/17/ELECTION 2001: LABOUR POLL LEAD GROWS1/ 28DJ/6/DNNA+3/2/042/601/17
/ELECTION 2001: MAJOR RAPS SPIN 'LIES'C/Gavin Cordon28DK/6/DNNA+3/2/042/581/15/E
LECTION 2001: TAX BREAK HELPS JOBSB/Bob Roberts28DM/6/DNNA+3/2/063/3001/1S/VOICE
 OF THE MIRROR: LET'S LISTEN TO THIS GENT ON THE EURO1/ 28GL/6/DNND6+2/2/023/205
1/2A/ELECTION 2001: YOBS WAR; JAIL FOR THUGS WHO ATTACK NURSES AND TEACHERS15/Bo
b Roberts Political Correspondent28GM/6/DNND6+2/2/022/831/10/ELECTION 2001: HAGU
E POLL FLOP1/ 28GN/6/DNND6+2/2/022/791/1B/ELECTION 2001: TORY BETS BLAIR; EXCLUS
IVEF/Paul Gilfeather28GR/6/DNND6+2/2/063/6871/4C/ELECTION 2001: (BIG) L IB DEM C
ORNER VOTES GALORE? NO, JUST A CLASSY PUSSY; PAUL ROUTLEDGE IS SHAKEN, NOT STIRR
ED BY CHARLES KENNEDYE/Paul Routledge28K2/6/DNNGC+2/2/023/4571/36/ELECTION 2001:
 EU FAKES; EXCLUSIVE: TORY LEADER SLAMMED FOR HIDING EURO -SCEPTIC MPS FROM VOTE
RS19/Oonagh Blackman Deputy Political Editor28K6/6/DNNGC+2/2/022/701/1A/ELECTION
 2001: SCHOOL IDEA 'SECOND RATE'H/Dorothy Lepkowska28K9/6/DNNGC+2/2/063/2341/1O/
VOICE OF THE MIRROR: THE BELL IS TOLLING FOR EU, HAGUE1/ 28KA/6/DNNGC+2/2/063/10
61/12/VOICE OF THE MIRROR: CONS SORTED1/ 28KE/6/DNNGC+2/2/062/491/17/PAUL ROUTLE
DGE COLUMN: BLAIR'S BOTTOME/Paul Routledge28KF/6/DNNGC+2/2/062/571/20/PAUL ROUTL
EDGE COLUMN: MARGARET THATCHER - CARDBOARD CUT-OUTE/Paul Routledge28KG/6/DNNGC+2
/2/063/2171/26/PAUL ROUTLEDGE COLUMN: NO PLANS TO TAX OR MEANS-TEST CHILD BENEFI
TE/Paul Routledge28KH/6/DNNGC+2/2/062/571/1L/PAUL ROUTLEDGE COLUMN: SILLY BILLY 
IS NO SMART ALECE/Paul Routledge28NB/6/DNNQ+3/2/023/4151/2R/ELECTION 2001: BLAME
 ME; HAGUE MAY STEP DOWN IF LABOUR ROMP TO SECOND LANDSLIDE VICTORY12/Paul Gilfe
ather Whitehall Editor28ND/6/DNNQ+3/2/023/1421/13/ELECTION 2001: WAR ON POLL APA
THYS/James Hardy Political Editor28NE/6/DNNQ+3/2/022/651/18/ELECTION 2001: STARS
 SIGN UP FOR BLAIRB/James Hardy28NI/6/DNNQ+3/2/063/2211/1N/VOICE OF THE MIRROR: 
DESPERATE TORY TRICKS WON'T WORK1/ 28NJ/6/DNNQ+3/2/064/14971/4R/ELECTION 2001: G
IVE US DIGNITY .. WHY SHOULD MY LIFE STOP BECAUSE I HAVE RETIRED?; ELECTION COUN
TDOWN: TONY PARSONS ON THE PLIGHT OF OUR PENSIONERSC/Tony Parsons28QN/6/DNNT6+2/
2/022/631/17/ELECTION 2001: EX-MP QUITS FOR LABOUR1/ 28QP/6/DNNT6+2/2/022/841/Q/
ELECTION 2001: FT BACKS PM1/ 28R0/6/DNNT6+2/2/062/911/15/VOICE OF THE MIRROR: TH
E BUSINESS..1/ 28R1/6/DNNT6+2/2/064/13861/61/ELECTION 2001: 1976 - WE HAD PRIDE,
 HOPE AND JOBS AT THE END; 2001 - WE NEED CASH TO GIVE KIDS A REAL CHANCE; BRIAN
 READE RETURNS TO HIS OLD SCHOOL TO SEE WHAT'S CHANGED IN 25 YEARSB/Brian Reade2
904/6/DNO2C+2/2/042/831/1I/ELECTION 2001: HAGUE ASYLUM JAIL 'LIKE HITLER'S'F/Pau
l Gilfeather2905/6/DNO2C+2/2/043/1051/1C/ELECTION 2001: BROWN VICTORY OVER SPEND
INGF/Oonagh Blackman2907/6/DNO2C+2/2/043/2421/18/ELECTION 2001: NEW VAZ CLAIMS A
NGER PMB/Bob Roberts2908/6/DNO2C+2/2/042/561/12/ELECTION 2001: ONE PINT IN FRONT
1/ 290A/6/DNO2C+2/2/053/3091/18/ELECTION 2001: TORY HQ PENSION BLUNDERQ/Gary Jon
es And James Hardy290B/6/DNO2C+2/2/063/2471/1R/VOICE OF THE MIRROR: IT ALL COMES
 DOWN TO A PAIR OF PANTS1/ 290C/6/DNO2C+2/2/062/891/1S/VOICE OF THE MIRROR: CAMB
ELL'S GOT HIS KNICKERS IN A TWIST1/ 293C/6/DNO5I+2/2/043/9731/45/ELECTION 2001: 
VOTE LABOUR, MAKE HISTORY - HOW TO BURY A TORY; TACTICAL VOTING WILL PUT FINAL N
AIL IN THE COFFIN FOR MR HAGUE1I/Jonathan Stones, James Hardy And Paul Gilfeathe
r293G/6/DNO5I+2/2/072/731/24/ELECTION 2001: VOTE LABOUR, MAKE HISTORY : HAGUE'S 
AIR NEAR MISSI/Alexandra Williams293H/6/DNO5I+2/2/062/791/28/ELECTION 2001: VOTE
 LABOUR, MAKE HISTORY : BIG THREE IN FINAL APPEAL1/ 293J/6/DNO5I+2/2/072/671/23/
ELECTION 2001: VOTE LABOUR, MAKE HISTORY : POLLS GIVE TONY LEADB/James Hardy293N
/6/DNO5I+2/2/083/8191/48/ELECTION 2001: VOTE LABOUR, MAKE HISTORY : IF THIS WAS 
A REAL LABOUR GOVERNMENT I AM AN ASTRONAUT BUT THEY'LL GET MY VOTE.. JUSTE/Paul 
Routledge293P/6/DNO5I+2/2/102/931/21/ELECTION 2001: VOTE LABOUR, MAKE HISTORY : 
THE SEATS OF POWERA/Ruki Sayid293S/6/DNO5I+2/2/112/751/20/ELECTION 2001: VOTE LA
BOUR, MAKE HISTORY: GET LOST, TORIES..B/Brian Reade293T/6/DNO5I+2/2/123/9201/2J/
ELECTION 2001: VOTE LABOUR, MAKE HISTORY : THE ULTIMATE 2001 ELECTION PARTY KITB
/Jane Ridley2HQL/7/DNL2O+2/2/023/4831/12/TRIMBLE THREAT TO QUIT OVER ARMSF/REBEC
CA PAVELEY2HQM/7/DNL2O+2/2/023/6491/1E/COOK PUTS EUROPE HIGH ON AGENDA FOR ELECT
IONA/JOHN DEANS2HQN/7/DNL2O+2/2/124/10871/4F/LEADING ARTICLE: AS WE FACE FOUR WE
EKS OF BEING UNENDURABLY PATRONISED BY OUR POLITICIANS, REMEMBER THE JOYOUS SONG
 OF THE THRUSH . . .D/JOHN MORTIMER2HQR/7/DNL2O+2/2/063/8911/14/STARTING GUN IS 
FIRED FOR ELECTIONC/DAVID HUGHES2HQT/7/DNL2O+2/2/073/1241/L/BBC'S PARTY BROADCAS
T1/ 2I01/7/DNL6+3/2/063/3401/15/Tories get a tonic from the doctorsD/Graeme Wils
on2I04/7/DNL6+3/2/062/901/P/Exit Heath still scowlingC/David Hughes2I0A/7/DNL6+3
/2/063/6591/2C/They were both pancaked by Hague, like a steam roller on two beac
h ballsD/Quentin Letts2I0B/7/DNL6+3/2/123/2551/H/A smell of sleaze1/ 2I06/7/DNL6
+3/2/083/5611/10/Grasping Gordon the tax dodgerD/Graeme Wilson2I0D/7/DNL6+3/2/09
3/2851/17/Uplifting lyrics and drooping eyelidsC/Bill Mouland2I3B/7/DNL96+2/2/12
3/5731/11/Have the Tories been too timid?1/ 2I3F/7/DNL96+2/2/064/15541/33/Hague:
My plan for Britain; Help for families,pensioners and savers-plus 27 pence off a
 gallonN/John Dean;Graeme Wilson2I3G/7/DNL96+2/2/083/1911/H/Defector backlashD/Q
uentin Letts2I3H/7/DNL96+2/2/083/1271/O/Dodging the tax questionD/Quentin Letts2
I3I/7/DNL96+2/2/073/7101/1G/That's just fine, but where are the BIG ideas?M/Edwa
rd Heathcoat Amory2I6L/7/DNLIO+2/2/043/1531/1L/FOOTNOTE; How Cherie toed the par
ty line in sandals1/ 2I6M/7/DNLIO+2/2/063/5541/18/Blair does not need minders sa
ys agentC/David Hughes2I6O/7/DNLIO+2/2/043/7171/1F/No vanity? Can we have that i
n writing, Tony?D/Quentin Letts2I6Q/7/DNLIO+2/2/053/6731/18/Faltering Brown and 
the march of MandyC/David Hughes2I6R/7/DNLIO+2/2/103/5851/12/Another ignoble use
 of the Lords1/ 2I6S/7/DNLIO+2/2/143/7741/R/Warming to the Apathy PartyG/Keith W
aterhouse2IA1/7/DNLM+3/2/053/3521/T/A tough message to tame Brown1/ 2IA2/7/DNLM+
3/2/073/7751/1L/We are the party of business now, claims chancellorC/Paul Eastha
m2IA4/7/DNLM+3/2/044/17521/32/Day the PM got the Humph; (1) Roasting on the radi
o reopens the sleaze row (2) 23 DAYS TO GOC/David Hughes2IA5/7/DNLM+3/2/053/7731
/1B/He struggled like a bluebottle on treacleD/Quentin Letts2IA7/7/DNLM+3/2/063/
4761/13/The turncoat's engineered victoryD/Graeme Wilson2IA8/7/DNLM+3/2/083/5241
/1F/Watchdogs are called in at Blair ally's unionC/Paul Eastham2IA9/7/DNLM+3/2/1
03/6151/1C/COMMENT; Here are the big issues, Mr Blair1/ 2IAA/7/DNLM+3/2/073/3251
/T/Geri, Labour's new party girl1/ 2IAB/7/DNLM+3/2/072/841/J/For whom Bell tolls
1/ 2IDC/7/DNLP6+2/2/083/4951/3D/America's anger over Star Wars; Defence chief te
lls Blair to get off the fence and back missile projectC/Paul Eastham2IDD/7/DNLP
6+2/2/123/3311/S/Trampling on a proud history1/ 2IDG/7/DNLP6+2/2/083/7551/1K/Pen
ny on income tax in Kennedy's 'honesty package'A/John Deans2IDO/7/DNLP6+2/2/253/
1641/T/Cull 'was election sacrifice'1/ 2IGL/7/DNLSC+2/2/033/2061/P/Labour meets 
the voters 11/ 2IGM/7/DNLSC+2/2/193/6571/15/Quentin Letts on the campaign trailD
/Quentin Letts2IGN/7/DNLSC+2/2/184/19041/50/Blair's private enterprise; 21 days 
to go A searing analysis of the Premier's waffly promises to take the dogma out 
of our second-rate public servicesC/David Hughes2IGO/7/DNLSC+2/2/024/10341/4M/Th
e day Two Jags Prescott blew a gasket; 21 days to go with a straight left from t
he Deputy Premier, the election campaign descends into farceP/David Hughes;Sarah
 Harris2IGQ/7/DNLSC+2/2/183/7781/2P/A manifesto? It reads more like Mills & Boon
; Edward Heathcoat Amory On the manifestoM/Edward Heathcoat Amory2IGR/7/DNLSC+2/
2/053/6221/2E/The woman for Britain who spoke up over the NHS; labour meets the 
voters 3C/Sarah Harris2IGS/7/DNLSC+2/2/043/7081/2B/The day Labour met real voter
s; Straw gets on the wrong side of the lawQ/Matthew Hickley;Ben Taylor2IK1/7/DNM
1I+2/2/124/10301/1B/Why Two Jags is heading for the scrapyardE/Bruce Anderson2IK
2/7/DNM1I+2/2/073/3051/19/The 'quiet man' who was hit in the faceD/Graham Keeley
2IK3/7/DNM1I+2/2/023/6601/37/Hague's asylum broadside to turn heat on Labour; Th
e simple truth is that the system is in piecesC/David Hughes2IK5/7/DNM1I+2/2/063
/2771/1C/'Thumper' and the strife on the ocean wave1/ 2IK6/7/DNM1I+2/2/083/9581/
7L/How the toff whose butler has a butler suffered a dire sense of humour failur
e; Quentin Letts on the campaign trail 20 days to goThe Mail surprises millionai
re Shaun Woodward as he tours the seat New Labour handed him for defectingD/Quen
tin Letts2IK8/7/DNM1I+2/2/093/3761/1H/We had no say in selection says local part
y manO/Graeme Wilson;Kate Hurry2IKA/7/DNM1I+2/2/103/2461/17/Warmer welcome for W
iddecombe the witF/Matthew Hickley2IKB/7/DNM1I+2/2/123/5981/15/The demeaning of 
democracy; COMMENT1/ 2IKC/7/DNM1I+2/2/143/6541/1B/counting the cost of bringing 
in the euroG/Andrew Alexander2IKD/7/DNM1I+2/2/073/7771/59/Prescott could face co
urt over fist fight; 20 days to go After those extraordinary scenes as the Deput
y PM squared up to a countryside protester, the reckoningC/David Hughes2INB/7/DN
MB6+2/2/053/1011/14/PM urged to ditch Vaz and Robinson1/ 2IND/7/DNMB6+2/2/053/20
41/13/Debate that the Chancellor missed1/ 2INE/7/DNMB6+2/2/053/2381/1N/Poll pile
s on the agony for Hague & Co; 17 days to Go1/ 2INF/7/DNMB6+2/2/043/4581/28/Boss
es hit back for Tories with a blast over red tape; 17 Days to GoG/Political Edit
or2INK/7/DNMB6+2/2/043/3401/1S/Lying low, Blair Babe who makes a racket 'once in
 a while'1/ 2INL/7/DNMB6+2/2/053/1481/16/Soft line on burglars; 17 Days to Go1/ 
2IQM/7/DNMEC+2/2/103/3891/12/The Chancellor's ominous silence1/ 2IQN/7/DNMEC+2/2
/164/27671/5K/Blair is destroying my legacy by stealth; EXCLUSIVE: In her only e
lection interview, Lady Thatcher delivers a devastating condemnation of New Labo
ur's four years in powerC/Simon Heffer2IQQ/7/DNMEC+2/2/063/5231/42/Labour accuse
s TV crews of inciting the protesters; 16 Days to Go: Broadcasters fume over 'sl
ur' in wake of Prescott punchC/David Hughes2IQR/7/DNMEC+2/2/063/8451/2A/The grea
t Vaz hunt; 16 Days to Go: Quentin Letts on the campaign trailD/Quentin Letts2IQ
S/7/DNMEC+2/2/063/1901/1R/A top job in NHS for Blair's barman friend; 16 Days to
 Go1/ 2J07/7/DNMHI+2/2/063/4401/N/'50pc income tax' storm1/ 2J3C/7/DNMKO+2/2/063
/2881/1N/The grim choice when the money runs out; 14 Day to Go1/ 2J3E/7/DNMKO+2/
2/043/2201/1A/What turncoat didn't tell; 14 Days to Go1/ 2J3F/7/DNMKO+2/2/043/21
01/1A/GCSEs at 11 for brightest; 14 Days to Go1/ 2J3H/7/DNMKO+2/2/073/7601/3E/Ke
nnedy scrubs up for the sickliest of stunts; Quentin Letts on the campaign trail
 on the campaign trailD/Quentin Letts2J3K/7/DNMKO+2/2/134/13471/1J/R.I.P. Farewe
ll to a uniquely British way of lifeM/Edward Heathcoat Amory2J6L/7/DNMO+3/2/063/
7821/1K/Down here, Europe is hated like an occupying powerD/Quentin Letts2J6M/7/
DNMO+3/2/063/6221/1J/How Labour bullies try to put the media in a spinE/Michael 
Clarke2J6N/7/DNMO+3/2/074/10351/1G/Bowing to Brussels is patriotic, insists Blai
rC/Paul Eastham2J6Q/7/DNMO+3/2/143/8481/1A/OH,WHAT A VERY RUM VERSION OF PATRIOT
ISMG/Andrew Alexander2JA2/7/DNN3I+2/2/023/5311/16/Cook lets slip the big euro qu
estionC/David Hughes2JA3/7/DNN3I+2/2/103/5851/13/Dishonest rush to scrap the pou
nd1/ 2JA4/7/DNN3I+2/2/163/6081/1B/Tell us the truth on taxes, says PortilloA/Joh
n Deans2JA5/7/DNN3I+2/2/173/5951/10/vaz is linked to wanted tycoonC/David Hughes
2JA6/7/DNN3I+2/2/173/5821/1E/'Politicians are allowed to talk to friends'D/Tom R
awstorne2JDB/7/DNN6O+2/2/134/11471/15/Only one man can save the pound nowE/Steph
en Glover2JDF/7/DNN6O+2/2/053/7691/16/Staggering price of one man's vanityJ/Mart
in Vander Weyer2JDG/7/DNN6O+2/2/043/7681/19/In a white suit, the man from Del Mo
nteD/Quentin Letts2JDJ/7/DNN6O+2/2/103/1741/F/The real issues1/ 2JGP/7/DNNA+3/2/
063/5601/1N/Prodi demands more power and a GBP 60billion Euro-taxF/Rebecca Pavel
ey2JGS/7/DNNA+3/2/103/5971/11/The black hole in this campaign1/ 2JK2/7/DNND6+2/2
/063/1631/38/Suited and booted . . . Cherie chooses the ideal outfit for those r
unning for office; 7 Days to Go1/ 2JK3/7/DNND6+2/2/073/2541/3Q/LibDems' pledge o
n free care for the elderly; 7 Days to Go: Kennedy calls for end to misery of fo
rced homes sell-off1/ 2JK5/7/DNND6+2/2/063/1011/S/Flexible hours; 7 Days to Go1/
 2JK8/7/DNND6+2/2/073/2541/1D/Better deal promise for pensions and petrol1/ 2JND
/7/DNNGC+2/2/064/11461/14/By any audit, the NHS has declinedM/Edward Heathcoat A
mory2JNE/7/DNNGC+2/2/073/5761/1K/I long to be a nurse but the colleges are all f
ull1/ 2JNG/7/DNNGC+2/2/083/7161/1Q/Like a butcher bawling pork belly prices at m
arket wivesD/Quentin Letts2JNI/7/DNNGC+2/2/123/5881/11/Embarking on a hollow 'cr
usade'1/ 2JNJ/7/DNNGC+2/2/124/10941/4T/My family are passionate about politics -
 and I am, too. So why is it, in my first election, that I do not want to vote f
or any of the party leaders?E/Kitty Dimbleby2JQN/7/DNNQ+3/2/043/7211/1O/Why I, a
s a GP, will not be giving my vote to Mr BlairI/Dr Trevor Stammers2JQP/7/DNNQ+3/
2/053/1551/H/The Aussie factor1/ 2JQQ/7/DNNQ+3/2/053/2361/P/What Labour would do
 next1/ 2K01/7/DNNT6+2/2/023/5551/1K/I won't soak the rich with new taxes, claim
s BlairA/John Deans2K04/7/DNNT6+2/2/063/2761/1R/Where there's a Will, there's a 
war aboard the battle bus1/ 2K05/7/DNNT6+2/2/063/1131/13/Mass cull 'is all set f
or Friday'1/ 2K08/7/DNNT6+2/2/103/2371/G/Test for the BBC1/ 2K09/7/DNNT6+2/2/102
/881/B/A class act1/ 2K0A/7/DNNT6+2/2/134/11231/1C/Why the state can't solve all
 our problemsE/Stephen Glover2K0B/7/DNNT6+2/2/164/23501/50/For the love of Ffion
; We've never before spent a whole month together. I adore her. I'm deeply in lo
ve with her. I'm having a big affair with my wifeG/Lynda Lee-Potter2K3B/7/DNO2C+
2/2/023/5451/13/Hague plea to 'join in our march'Q/David Hughes;Graeme Wilson2K3
C/7/DNO2C+2/2/063/6101/14/The doctoring of NHS waiting listsA/Jenny Hope2K3D/7/D
NO2C+2/2/063/4921/15/Tempers fray over new claims on VazQ/Paul Eastham;Graeme Wi
lson2K3E/7/DNO2C+2/2/063/3801/P/Union raises strike fears1/ 2K3F/7/DNO2C+2/2/063
/1221/T/use your vote,plead the stars1/ 2K3H/7/DNO2C+2/2/073/6551/1S/amid the ag
gro,Mr hague was beaming and relished the scrapD/Quentin Letts2K3K/7/DNO2C+2/2/1
04/20211/2E/blair the audit; He promised 'things can only get better' - but have
 they?M/Edward Heathcoat Amory2K6P/7/DNO5I+2/2/063/8461/49/Don't mention policie
s, pose. After four weeks in Blair's bubble and a final day with Hague, two star
 writers give their verdictsE/Robert Hardman2K6Q/7/DNO5I+2/2/123/5991/2F/Beware 
the perils of a landslide. At last, the shouting and the tumult dies1/ 2K6S/7/DN
O5I+2/2/134/11451/34/Get away from it all!; The Mail's guide to where you can es
cape another four years of Mr BlairH/James Bartholomew2K6T/7/DNO5I+2/2/073/8571/
4G/Last stand of a latter-day Hannibal. After four weeks in Blair's bubble and a
 final day with Hague, two star writers give their verdictsE/Robert Hardman2T01/
8/DNL2O+2/2/063/9491/15/PARTIES TAKE UP THEIR POSITIONS FOR17/ALISON LITTLE POLI
TICAL CORRESPONDENT2T02/8/DNL2O+2/2/023/2641/P/TRIMBLE THREATENS TO QUIT17/ALISO
N LITTLE POLITICAL CORRESPONDENT2T05/8/DNL2O+2/2/073/3431/18/BUSY CHERIE LEAVES 
THE SUPPORTING ROLE1/ 2T07/8/DNL2O+2/2/123/7931/1A/TARGETS THAT BLAIR MUST HIT I
N ROUND TWO12/PATRICK O'FLYNN POLITICAL EDITOR2T08/8/DNL2O+2/2/063/1221/18/THE P
ERSONALITIES WHO ARE SET TO LEAVE1/ 2T3B/8/DNL6+3/2/063/1711/M/KENNEDY OFF TO A 
FLYER1/ 2T3D/8/DNL6+3/2/123/7501/41/LEADER FFION'S IMAGE OF THE DUTIFUL LITTLE W
OMAN IS OUT OF STEP WITH THE TIMES; WHY CHERIE IS AN EXAMPLE TO WORKING WIVESB/L
AURA KIBBY2T3G/8/DNL6+3/2/123/2311/2C/LEADER COLUMN; HAGUE'S LACK OF CREDIBILITY
 WILL LOSE ELECTION FOR TORIES1/ 2T3H/8/DNL6+3/2/043/3491/1E/COMMONS SKETCH; MPS
 BID FAREWELL TO ALL THIS1/ 2T6L/8/DNL96+2/2/053/2311/L/BUSLOAD OF SWEETENERS1/ 
2T6M/8/DNL96+2/2/023/1361/T/POLICE HIT BY 'POOR' RECRUITS1/ 2T6N/8/DNL96+2/2/023
/5411/17/LABOUR FACE A FIGHT OVER NHS F IGURES17/ALISON LITTLE POLITICAL CORRESP
ONDENT2T6O/8/DNL96+2/2/043/8231/4F/AS TORIES LAUNCH MANIFESTO WITH 27P FUEL PROM
ISE LABOUR WARN OF HIGH PRICE THE NATION WOULD HAVE TO PAY; PETROL CUT FACES BLA
IR'S SCORN12/PATRICK O'FLYNN POLITICAL EDITOR2T6Q/8/DNL96+2/2/123/1891/1D/LEADER
 COLUMN; TESTING TIME FOR THE PARTIES1/ 2TA1/8/DNLIO+2/2/083/5871/2C/TORY RIGHT 
PICKS STRATEGY; HAGUE TO WARN OF SEVEN DAYS TO SAVE THE POUNDF/PATRICK O'FLYNN2T
A2/8/DNLIO+2/2/073/2161/T/NOW TONY IS GERI'S CUP OF TEA1/ 2TA3/8/DNLIO+2/2/083/1
241/H/FATHER'S PUT-DOWN1/ 2TA4/8/DNLIO+2/2/063/8621/4P/PREMIER PLANS TO LET PRIV
ATE COMPANIES RUN POOR STATE SECONDARIES AS HE MAKES EDUCATION A PRIORITY OF THE
 CAMPAIGN; BLAIR TARGETS FAILING SCHOOLS13/PATRICK O'FLYNN AND KIRSTY WALKER2TDB
/8/DNLM+3/2/033/4301/32/NEW PET JOINS GINGER ON LABOUR CAMPAIGN TRAIL; DOG-LOVER
 GERI PROVES A REAL POLITICAL ANIMAL10/DAVID SMITH AND MAURICE McLEOD2TDD/8/DNLM
+3/2/063/1561/1K/CRONIES ROW AFTER CAPTAINS OF INDUSTRY BACK LABOURA/ADRIAN LEE2
TDE/8/DNLM+3/2/063/3591/1B/FLASHY LIB-DEMS GET STRAIGHT TO THE POINT17/ALISON LI
TTLE POLITICAL CORRESPONDENT2TDF/8/DNLM+3/2/063/8561/5M/CONSERVATIVE ECONOMIC ST
RATEGY HIT BY CLAIMS OF MASSIVE SPENDING CUTS AS RIGHT-WINGERS SAY PORTILLO HAS 
NOT OFFERED ENOUGH; TORY RIFT OVER 'MISSING BILLIONS' IN TAX CUT VOW16/PATRICK O
'FLYNN AND PADRAIC FLANAGAN2TDG/8/DNLM+3/2/123/2671/26/LEADER COLUMN; WE NEED NH
S REFORMS NOW, NOT MORE ELECTION RHETORIC1/ 2TDI/8/DNLM+3/2/133/5751/28/LEADER; 
IT'S RAINING CELEBRITIES AS BLAIR TRIES OUT A NEW DOUBLE ACTD/Vanessa Feltz2TGM/
8/DNLP6+2/2/063/2721/13/POLL TAX MP RISKS LOSING HIS SEAT1/ 2TGO/8/DNLP6+2/2/073
/2911/L/BLAIR'S PATRIOT PARTYF/Patrick O'Flynn2TGQ/8/DNLP6+2/2/134/13641/88/LEAD
ER - YESTERDAY, THE DAILY MAIL CHALLENGED THE PRIME MINISTER TO ANSWER 12 ELECTI
ON QUESTIONS. HE DID BUT THE MAIL REFUSED TO CARRY HIS REPLIES. NOW, IN A SERVIC
E TO ITS READERS WHO BELIEVE IN FAIR DEBATE, THE EXPRESS IS PUBLISHING THOSE ANS
WERS1/ 2TGR/8/DNLP6+2/2/073/2911/1K/SPEARS SENDS GOOD LUCK NOTE AS SHE JOINS BAN
DWAGONA/JANE YOUNG2TK1/8/DNLSC+2/2/103/5041/31/TONY PLEDGES BETTER SCHOOLS, HOSP
ITALS AND POLICING AND NO TAX RISES IN A MANIFESTO FOR ALL1/ 2TK4/8/DNLSC+2/2/02
3/5721/1P/PRESCOTT LEFT WITH EGG ON HIS FACE AS HE THROWS A PUNCH10/KIRSTY WALKE
R AND RACHEL BAIRD2TNB/8/DNM1I+2/2/043/3651/12/GENTLE GIANT BEHIND EGG SCRAMBLEB
/TONY BROOKS2TNC/8/DNM1I+2/2/063/1631/K/A VOTER GOES BANANAS12/PADRAIC FLANAGAN 
& ALISON LITTLE2TND/8/DNM1I+2/2/184/10831/1C/WAS PRESCOTT RIGHT TO PUNCH EGG PRO
TESTER?1/ 2TNJ/8/DNM1I+2/2/053/4841/1A/YOUNG BOXER WAS A HIT WITH HIS CREWMATES1
2/PATRICK O'FLYNN POLITICAL EDITOR2TNK/8/DNM1I+2/2/123/2411/1N/IF WE DEMAND DIGN
ITY OUR POLITICIANS NEED PROTECTION?1/ 2TQL/8/DNMB6+2/2/123/2591/1S/LEADER COLUM
N; WHY THE TORY ODD BUNCH WON'T WOO THE VOTERS1/ 2TQM/8/DNMB6+2/2/123/8151/3K/LE
ADER WILLIAM HAGUE HAD BETTER FIND ANOTHER BANDWAGON BECAUSE. . .; KICKING ASYLU
M SEEKERS WILL NOT WIN VOTESD/JOHN KAMPFNER2TQN/8/DNMB6+2/2/043/6041/18/NURSES F
EAR A PAY-YOUR-WAY NHS BY 2010T/MICHAEL DAY AND KIRSTY WALKER3001/8/DNMEC+2/2/07
3/2711/11/FINANCIAL ADVICE FOR CHANCELLOR1/ 303B/8/DNMHI+2/2/023/4911/19/BLAIR I
N VOW NOT TO PUNISH HIGH EARNERS13/PATRICK O'FLYNN AND KIRSTY WALKER306L/8/DNMKO
+2/2/112/461/P/I'LL FIGHT FOR EUTHANASIA1/ 306N/8/DNMKO+2/2/084/16901/3C/'IT IS 
OBVIOUS, IF YOU WANT DECENT PUBLIC SERVICES YOU HAVE GOT TO FUND THEM. IT ISN'T 
ROCKET SCIENCE'14/CHRIS WILLIAMS AND PATRICK O'FLYNN306O/8/DNMKO+2/2/113/4461/3C
/PORTILLO ATTACKS OBRUSSELS TAX PLANO BUT REFUSES TO MAKE VAT PLEDGE; TORIES TRI
PPED UP ON EUROPE AGAIN17/ALISON LITTLE POLITICAL CORRESPONDENT306P/8/DNMKO+2/2/
113/1671/14/RORY GETS GBP 10,000 TO KEEP QUIET1/ 30A1/8/DNMO+3/2/113/7051/5R/HAG
UE STIRS ANGER WITH BROADCAST THAT PAINTS GRIM PICTURE OF PUPILS AS BLAIR RAISES
 THE ELECTION STAKES WITH A 'PATRIOTIC' SPEECH ON EUROPE; OUTRAGE AS TORIES 'INS
ULT ' CHILDREN16/PATRICK O'FLYNN AND PADRAIC FLANAGAN30A4/8/DNMO+3/2/123/2461/20
/LEADER COLUMN; SILENCE OF PRO-EUROPEAN TORIES SPEAKS VOLUMES1/ 30A5/8/DNMO+3/2/
123/8001/3J/LEADER - WOMEN MINISTERS MUST HAVE REAL SEATS OF POWER AT THE TOP TA
BLE; WHERE HAVE ALL THE BLAIR BABES GONE?D/JOHN KAMPFNER30DD/8/DNN3I+2/2/103/339
1/1N/PORTILLO QUESTIONS PARTY'S STRATEGY TO SAVE THE POUND12/PATRICK O'FLYNN POL
ITICAL EDITOR30DF/8/DNN3I+2/2/123/2581/24/LEADER COLUMN; GORDON BROWN MUST TAKE 
ON THESE GREEDY OIL GIANTS1/ 30DG/8/DNN3I+2/2/123/7721/46/LEADER TORIES FACE MEL
TDOWN AS BLITZ ON THE SINGLE CURRENCY PLAYS INTO BLAIR'S HANDS; HAGUE'S BLAST AG
AINST EURO WILL BACKFIRED/JOHN KAMPFNER30GL/8/DNN6O+2/2/122/561/1E/LEADER COLUMN
; IS IT ROCK BOTTOM FOR TORIES?1/ 30GM/8/DNN6O+2/2/083/1871/S/LEADERS REOPEN ASY
LUM DEBATEC/DAVID HUDSON30GN/8/DNN6O+2/2/102/671/L/THAT'S ENOUGH, CHERIE1/ 30GO/
8/DNN6O+2/2/102/561/M/KENNEDY KEEPS IT CLEAN1/ 30H1/8/DNN6O+2/2/123/1601/1C/LEAD
ER COLUMN; NHS FAILURE IS AN EMERGENCY1/ 30K5/8/DNNA+3/2/113/2101/P/MICROSOFT LI
NK SPARKS ROW17/KIRSTY WALKER POLITICAL CORRESPONDENT30K6/8/DNNA+3/2/123/2301/27
/LEADER COLUMN; TV SHOULD NOT BE AN ISSUE FOR YOUNG AT ELECTION TIME1/ 30NB/8/DN
ND6+2/2/023/5341/13/TORIES FACE MELTDOWN AT THE POLLS16/PATRICK O'FLYNN AND PADR
AIC FLANAGAN30ND/8/DNND6+2/2/103/1961/Q/PM, YOU'VE FAILED OUR GIRL1/ 30QM/8/DNNG
C+2/2/023/3811/1A/TORY TURMOIL AS HAGUE GAGS RIGHT-WINGERS12/PATRICK O'FLYNN POL
ITICAL EDITOR30QO/8/DNNGC+2/2/083/1771/15/FIVE YEARS TO SAVE NHS WARN DOCTORS1/ 
30QP/8/DNNGC+2/2/082/701/P/RED FACES OVER JOBS GAFFE1/ 30QR/8/DNNGC+2/2/093/4241
/1B/APATHY? WHAT ABOUT GERI'S 12.7M AUDIENCE?17/KIRSTY WALKER POLITICAL CORRESPO
NDENT30QT/8/DNNGC+2/2/093/1341/I/'THIRD WORLD' JIBE1/ 30R0/8/DNNGC+2/2/123/2801/
27/LEADER COLUMN; NO EXCUSES, IT'S TIME TO FIX OUR SCHOOLS AND THE NHS1/ 3101/8/
DNNQ+3/2/063/6101/6K/TORIES HAVE EVERY REASON TO FEEL BLUE AS EXPERTS CONTINUE T
O PREDICT A LANDSLIDE FOR LABOUR AND PUBLIC FIND WILLIAM AND HIS PARTY A TURN-OF
F; I'LL STEP DOWN IF WE HAVE A DISASTER AT POLLS, HINTS HAGUE12/PATRICK O'FLYNN 
POLITICAL EDITOR3103/8/DNNQ+3/2/063/2631/11/USE YOUR VOTE, STARS TELL YOUNG17/KI
RSTY WALKER POLITICAL CORRESPONDENT3104/8/DNNQ+3/2/073/3661/19/BIG NAMES IN DANG
ER FROM BALLOT TACTICS1/ 313C/8/DNNT6+2/2/063/8131/5N/BLAIR APPEALS TO 'DECENT P
ATRIOTIC' CONSERVATIVES TO SWAP SIDES AS HAGUE IS HIT BY ANOTHER DEFECTION AND P
OLLS SPELL DOOM FOR THE OPPOSITION; NOW TONY TARGETS THE TORY VOTER11/ALISON LIT
TLE AND KIRSTY WALKER313F/8/DNNT6+2/2/073/3891/1D/SOFT SOAP THAT AIMS TO CLEAN U
P ON THURSDAY1/ 313G/8/DNNT6+2/2/123/2811/26/LEADER COLUMN; TORY TACTICAL VOTING
 PLANS SHOW A PARTY IN DISARRAY1/ 316N/8/DNO2C+2/2/083/4301/1G/HAGUE'S FINAL BLI
TZ IN BID TO RING THE CHANGES16/PATRICK O'FLYNN AND PADRAIC FLANAGAN316O/8/DNO2C
+2/2/093/3081/10/PM FIGHTS BACK OVER VAZ ATTACK1/ 31A2/8/DNO5I+2/2/023/4971/11/V
OTERS WARM TO THE IDEA OF POLL12/PATRICK O'FLYNN POLITICAL EDITOR31A3/8/DNO5I+2/
2/083/6281/30/PARTY LEADERS ON LATE CAMPAIGNING FRENZY AS THEY PREPARE; FINAL DA
SH TO THE FINISHING LINE17/KIRSTY WALKER POLITICAL CORRESPONDENT31A6/8/DNO5I+2/2
/093/3441/1H/HAGUE HAS A LOT ON HIS PLATE AS SUCCESSORS LOOMG/PADRAIC FLANAGAN31
A7/8/DNO5I+2/2/113/6581/6F/BLAIR POISED TO BE LABOUR'S MOST SUCCESSFUL PM, WHILE
 HAGUE SEEMS DOOMED BY DISUNITY BUT KENNEDY WINS POINTS FOR CHARM; A LEADER ON T
HE BRINK OF HISTORY, A GALLANT FAILURE AND A SMALL RAY OF HOPE12/PATRICK O'FLYNN
 POLITICAL EDITOR31A8/8/DNO5I+2/2/103/2191/P/WHAT WILLIAM NEEDS TO WIN1/ 31A9/8/
DNO5I+2/2/113/2211/10/BROTHERS BATTLE FOR TV HONOURS1/ 31AA/8/DNO5I+2/2/113/4351
/15/FIVE FACES WORTH KEEPING A WATCH ON1/ 31AB/8/DNO5I+2/2/123/8301/3L/LEADER - 
TORIES DOOMED TO DEFEAT IN TODAY'S ELECTION AND THE NEXT ONE; A PARTY THAT HAS L
OST TOUCH WITH BRITAIN12/PATRICK O'FLYNN POLITICAL EDITORZZZZZZZZZZZZZZZZZZZZZZZ
