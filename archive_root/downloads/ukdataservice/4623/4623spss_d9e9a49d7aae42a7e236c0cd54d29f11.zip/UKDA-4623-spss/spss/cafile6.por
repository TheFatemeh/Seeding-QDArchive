�����@����@����@����@@@@@@@@@@@@@@@@@@@@ASCII SPSS PORT FILE                    
00000-0000-0000-0000--------------------!3#))0303300/240&),%00000000000000000000
0200002'220'&)3000#0000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrst
uvwxyz .<(+0&[]!$*);^-/|,%_>?`:#@'="000000~000000000000000000000{}\0000000000000
00000000000000000000000000000000000000000000000000000000SPSSPORTA8/200301316/122
147112/SPSS for MS WINDOWS Release 10.0411/5B/70/7/ARTDATE40/8/0/40/8/0/CC/Artic
le Date70/4/IDNO5/5/0/5/5/0/CS/Unique Identification Number70/5/PAPER5/1/0/5/1/0
/C9/Newspaper70/3/DAY5/1/0/5/1/0/CB/Day of Week70/8/PAPERTYP5/1/0/5/1/0/CE/Newsp
aper Type70/7/ARTSIZE5/4/0/5/4/0/CO/Article Size (No. Words)70/6/PAGENO5/2/0/5/2
/0/CB/Page Number70/6/AUTHOR5/2/0/5/2/0/CE/Type of Author70/8/STORYTYP5/2/0/5/2/
0/CA/Story Type70/7/SETTING5/1/0/5/1/0/CD/Story Setting70/8/TREATMNT5/1/0/5/1/0/
CF/Tone of Article70/5/CODER5/1/0/5/1/0/CD/Name of Coder70/8/THEME1ST5/3/0/5/3/0
/CA/Main Theme70/8/THEME2ND5/3/0/5/3/0/CC/Second Theme70/8/THEME3RD5/3/0/5/3/0/C
B/Third Theme70/8/ACTOR1ST5/4/0/5/4/0/CA/Main Actor70/8/ACTOR2ND5/4/0/5/4/0/CC/S
econd Actor70/8/ACTOR3RD5/4/0/5/4/0/CB/Third Actor70/8/ACTOR4TH5/4/0/5/4/0/CC/Fo
urth Actor70/8/JOURNEV15/1/0/5/1/0/C13/Journalist Evaluation - 1st Actor70/8/JOU
RNEV25/1/0/5/1/0/C13/Journalist Evaluation - 2nd Actor70/8/EVLTING15/4/0/5/4/0/C
K/1st Actor Evaluating70/8/EVLTION15/1/0/5/1/0/CE/1st Evaluation70/7/EVLTED15/4/
0/5/4/0/CJ/1st Actor Evaluated70/8/EVLTING25/4/0/5/4/0/CK/2nd Actor Evaluating70
/8/EVLTION25/1/0/5/1/0/CE/2nd Evaluation70/7/EVLTED25/4/0/5/4/0/CJ/2nd Actor Eva
luated70/7/TONE1ST5/1/0/5/1/0/CR/Favourability to Main Actor70/7/TONE2ND5/1/0/5/
1/0/CT/Favourability to Second Actor70/6/POLICY5/1/0/5/1/0/CI/Policy Information
70/8/PRSONLTY5/1/0/5/1/0/CN/Personality InformationD1/5/PAPER8/1/8/Guardian2/5/T
imes3/9/Telegraph4/B/Independent5/3/Sun6/6/Mirror7/4/Mail8/7/ExpressD1/3/DAY5/1/
6/Monday2/7/Tuesday3/9/Wednesday4/8/Thursday5/6/FridayD1/8/PAPERTYP2/1/7/Tabloid
2/A/BroadsheetD1/6/AUTHOR6/1/K/Political Journalist2/9/Columnist3/9/Not Given4/O
/Non Political Journalist5/F/Can't Determine39/5/OtherD1/8/STORYTYPA/1/D/Straigh
t News2/O/News Analysis/Background3/F/Feature/Profile4/G/Editorial/Leader5/F/Com
ment/Opinion6/9/Interview7/D/Signed Column8/6/Sketch9/1G/Picture Caption (Page 1
 Campaign stories only)39/5/OtherD1/7/SETTING5/1/9/Political2/8/Campaign3/5/Medi
a4/5/Other5/N/No Identifiable SettingD1/8/TREATMNT3/1/7/Serious2/C/Lighthearted3
/5/OtherD1/5/CODER5/1/N/Coder 1 Original Coding2/N/Coder 2 Original Coding3/18/C
oder 1 Intra-Coder Reliability Coding4/18/Coder 2 Intra-Coder Reliability Coding
5/13/Coder 1/2 Inter-Coder ReliabilityD1/8/THEME1ST3D/3B/E/Campaign Trail3C/H/Ca
mpaign Strategy3D/M/Announce Election Date3E/J/Controlled Campaign3F/K/Negative 
Campaigning3G/6/Sleaze3H/F/Gaffes/Scandals3I/H/Campaign Gimmicks3J/15/Political 
Distrust/Voter Alienation3K/C/Voter Apathy3L/F/Tactical Voting3M/D/Postal Voting
3N/E/Marginal Seats3O/F/Local Elections3P/H/Hecklers/Protests3Q/M/Risks of a Low
 Turnout3R/K/Risks of a Landslide3S/4/Spin3T/T/Candidate Selection Procedure40/G
/Electoral Reform41/G/Campaign Funding42/9/Women MPs43/R/Proportional Representa
tion44/F/Prescotts Punch45/L/Dull/Tedious Campaign46/9/Grey Vote47/B/Ethnic Vote
48/A/Young Vote49/B/Female Vote4A/K/Getting Out the Vote4B/I/Media Manipulation4
C/9/Defectors4D/M/Departing/Retiring MPs4E/4/PEBs4F/E/Election Fraud4G/E/Wives/P
artners6J/13/Election Campaign/Process - Other6L/J/Opinion Poll Result6M/O/Opini
on Poll Design etc.6N/G/Reaction to Poll6O/I/Outcome Prediction6P/I/Turnout Pred
iction6Q/Q/Media Coverage of Campaign6S/S/Party/Candidate Endorsements6T/B/Voter
 Panel70/L/Stats/Facts & Figures71/H/Summary of Events72/H/Spoof/joke column73/K
/Constituency Profile9T/S/Media Coverage/Polls - OtherA1/1A/Qualities - Professi
onal and/or PersonalA2/A/Aims/GoalsA3/I/Record/AchievementA4/T/Compare Qualities
/Aims/RecordA5/H/Manifesto: LabourA6/N/Manifesto: ConservativeA7/H/Manifesto: Li
bDemA8/O/Conflict Between PartiesA9/N/Conflict Within PartiesAA/10/Party/Leader/
Candidate ProfileAB/9/The LordsAC/J/Manifesto: BusinessAD/R/Blair/Brown Leadersh
ip PactAE/16/Post-Election Tory Leadership BattleAF/1G/Post-Election Cabinet/Whi
tehall ReorganisationD9/1A/Parties/Party Leaders/Candidates � OtherDB/A/NHS/Heal
thDC/9/EducationDD/H/Crime/Law & OrderDE/8/TaxationDF/H/Europe in GeneralDG/8/Th
e EuroDH/8/PensionsDI/7/EconomyDJ/9/TransportDK/A/EmploymentDL/B/EnvironmentDM/7
/WelfareDN/J/Farming/AgricultureDO/B/ImmigrationDP/I/Culture/Arts/SportDQ/G/Nort
hern IrelandDR/D/Racial IssuesDS/Q/Internet Crime/PornographyDT/12/National Insu
rance ContributionsE0/G/Local GovernmentE1/Q/Public Services in GeneralE2/13/Soc
ial Security inc Benefits, etcE3/10/Rural Affairs inc. Fox-HuntingE4/7/HousingE5
/K/Parliamentary ReformE6/M/Information/TechnologyE7/16/Private Sector Involveme
nt (PPP/PFI)E9/D/Petrol PricesEA/J/Policies in GeneralEB/F/Public SpendingEC/D/S
tealth TaxesED/8/BusinessEE/F/Scottish IssuesEF/K/Care for the ElderlyEG/7/Defen
ceEH/7/PovertyGJ/5/OtherD1/8/THEME2ND3D/3B/E/Campaign Trail3C/H/Campaign Strateg
y3D/M/Announce Election Date3E/J/Controlled Campaign3F/K/Negative Campaigning3G/
6/Sleaze3H/F/Gaffes/Scandals3I/H/Campaign Gimmicks3J/15/Political Distrust/Voter
 Alienation3K/C/Voter Apathy3L/F/Tactical Voting3M/D/Postal Voting3N/E/Marginal 
Seats3O/F/Local Elections3P/H/Hecklers/Protests3Q/M/Risks of a Low Turnout3R/K/R
isks of a Landslide3S/4/Spin3T/T/Candidate Selection Procedure40/G/Electoral Ref
orm41/G/Campaign Funding42/9/Women MPs43/R/Proportional Representation44/F/Presc
otts Punch45/L/Dull/Tedious Campaign46/9/Grey Vote47/B/Ethnic Vote48/A/Young Vot
e49/B/Female Vote4A/K/Getting Out the Vote4B/I/Media Manipulation4C/9/Defectors4
D/M/Departing/Retiring MPs4E/4/PEBs4F/E/Election Fraud4G/E/Wives/Partners6J/13/E
lection Campaign/Process - Other6L/J/Opinion Poll Result6M/O/Opinion Poll Design
 etc.6N/G/Reaction to Poll6O/I/Outcome Prediction6P/I/Turnout Prediction6Q/Q/Med
ia Coverage of Campaign6S/S/Party/Candidate Endorsements6T/B/Voter Panel70/L/Sta
ts/Facts & Figures71/H/Summary of Events72/H/Spoof/joke column73/K/Constituency 
Profile9T/S/Media Coverage/Polls - OtherA1/1A/Qualities - Professional and/or Pe
rsonalA2/A/Aims/GoalsA3/I/Record/AchievementA4/T/Compare Qualities/Aims/RecordA5
/H/Manifesto: LabourA6/N/Manifesto: ConservativeA7/H/Manifesto: LibDemA8/O/Confl
ict Between PartiesA9/N/Conflict Within PartiesAA/10/Party/Leader/Candidate Prof
ileAB/9/The LordsAC/J/Manifesto: BusinessAD/R/Blair/Brown Leadership PactAE/16/P
ost-Election Tory Leadership BattleAF/1G/Post-Election Cabinet/Whitehall Reorgan
isationD9/1A/Parties/Party Leaders/Candidates � OtherDB/A/NHS/HealthDC/9/Educati
onDD/H/Crime/Law & OrderDE/8/TaxationDF/H/Europe in GeneralDG/8/The EuroDH/8/Pen
sionsDI/7/EconomyDJ/9/TransportDK/A/EmploymentDL/B/EnvironmentDM/7/WelfareDN/J/F
arming/AgricultureDO/B/ImmigrationDP/I/Culture/Arts/SportDQ/G/Northern IrelandDR
/D/Racial IssuesDS/Q/Internet Crime/PornographyDT/12/National Insurance Contribu
tionsE0/G/Local GovernmentE1/Q/Public Services in GeneralE2/13/Social Security i
nc Benefits, etcE3/10/Rural Affairs inc. Fox-HuntingE4/7/HousingE5/K/Parliamenta
ry ReformE6/M/Information/TechnologyE7/16/Private Sector Involvement (PPP/PFI)E9
/D/Petrol PricesEA/J/Policies in GeneralEB/F/Public SpendingEC/D/Stealth TaxesED
/8/BusinessEE/F/Scottish IssuesEF/K/Care for the ElderlyEG/7/DefenceEH/7/Poverty
GJ/5/OtherD1/8/THEME3RD3D/3B/E/Campaign Trail3C/H/Campaign Strategy3D/M/Announce
 Election Date3E/J/Controlled Campaign3F/K/Negative Campaigning3G/6/Sleaze3H/F/G
affes/Scandals3I/H/Campaign Gimmicks3J/15/Political Distrust/Voter Alienation3K/
C/Voter Apathy3L/F/Tactical Voting3M/D/Postal Voting3N/E/Marginal Seats3O/F/Loca
l Elections3P/H/Hecklers/Protests3Q/M/Risks of a Low Turnout3R/K/Risks of a Land
slide3S/4/Spin3T/T/Candidate Selection Procedure40/G/Electoral Reform41/G/Campai
gn Funding42/9/Women MPs43/R/Proportional Representation44/F/Prescotts Punch45/L
/Dull/Tedious Campaign46/9/Grey Vote47/B/Ethnic Vote48/A/Young Vote49/B/Female V
ote4A/K/Getting Out the Vote4B/I/Media Manipulation4C/9/Defectors4D/M/Departing/
Retiring MPs4E/4/PEBs4F/E/Election Fraud4G/E/Wives/Partners6J/13/Election Campai
gn/Process - Other6L/J/Opinion Poll Result6M/O/Opinion Poll Design etc.6N/G/Reac
tion to Poll6O/I/Outcome Prediction6P/I/Turnout Prediction6Q/Q/Media Coverage of
 Campaign6S/S/Party/Candidate Endorsements6T/B/Voter Panel70/L/Stats/Facts & Fig
ures71/H/Summary of Events72/H/Spoof/joke column73/K/Constituency Profile9T/S/Me
dia Coverage/Polls - OtherA1/1A/Qualities - Professional and/or PersonalA2/A/Aim
s/GoalsA3/I/Record/AchievementA4/T/Compare Qualities/Aims/RecordA5/H/Manifesto: 
LabourA6/N/Manifesto: ConservativeA7/H/Manifesto: LibDemA8/O/Conflict Between Pa
rtiesA9/N/Conflict Within PartiesAA/10/Party/Leader/Candidate ProfileAB/9/The Lo
rdsAC/J/Manifesto: BusinessAD/R/Blair/Brown Leadership PactAE/16/Post-Election T
ory Leadership BattleAF/1G/Post-Election Cabinet/Whitehall ReorganisationD9/1A/P
arties/Party Leaders/Candidates � OtherDB/A/NHS/HealthDC/9/EducationDD/H/Crime/L
aw & OrderDE/8/TaxationDF/H/Europe in GeneralDG/8/The EuroDH/8/PensionsDI/7/Econ
omyDJ/9/TransportDK/A/EmploymentDL/B/EnvironmentDM/7/WelfareDN/J/Farming/Agricul
tureDO/B/ImmigrationDP/I/Culture/Arts/SportDQ/G/Northern IrelandDR/D/Racial Issu
esDS/Q/Internet Crime/PornographyDT/12/National Insurance ContributionsE0/G/Loca
l GovernmentE1/Q/Public Services in GeneralE2/13/Social Security inc Benefits, e
tcE3/10/Rural Affairs inc. Fox-HuntingE4/7/HousingE5/K/Parliamentary ReformE6/M/
Information/TechnologyE7/16/Private Sector Involvement (PPP/PFI)E9/D/Petrol Pric
esEA/J/Policies in GeneralEB/F/Public SpendingEC/D/Stealth TaxesED/8/BusinessEE/
F/Scottish IssuesEF/K/Care for the ElderlyEG/7/DefenceEH/7/PovertyGJ/5/OtherD1/8
/ACTOR1ST6I/3K/C/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Scott
ish Nationalist Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Party
3R/L/UK Independence Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/UU
P - Ulster Unionist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42/E
/The Government43/B/The Cabinet44/L/Government Department45/E/The Opposition46/R
/Parliament/MPs (in general)47/18/The European Union/European Commission48/8/Mil
lbank49/K/Electoral Commission4A/F/Scottish Labour4B/F/Scottish Tories6H/10/Othe
r Party - British Mainland6I/10/Other Party - Northern Ireland6J/H/Other Institu
tion70/A/Blair Tony71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry (SF)74
/G/Hume John (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble 
David (UUP)78/I/Nick Griffin (BNP)9T/K/Party Leader - OtherAA/J/LAB: Blunkett Da
vidAB/H/LAB: Brown GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: Pre
scott JohnAF/G/LAB: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/LA
B: Other Senior Labour PoliticianDK/11/LAB: Baroness Jay of PaddingtonDL/K/LAB: 
Becket MargaretDM/F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB: Campbell Ali
stairDP/L/LAB: Darling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/K/
LAB: Mandelson PeterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Reid
 JohnE3/H/LAB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Wood
ward ShaunE7/1A/LAB: Spokesperson or Unamed Party SourceE8/J/LAB: Party Official
E9/D/LAB: ActivistEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidate/
PeerGJ/P/LAB: Other inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2/I
/CON: Maude FrancisH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/L/CON: Portill
o MichaelH6/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other Senior Politic
ianKA/K/CON: Ainsworth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbuthnot JamesKD/
K/CON: Browning AngelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/CO
N: Heathcote Amory DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johnson BorisKJ/J/C
ON: Lansley AndrewKK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/J/CON: Platell
 AmandaKN/K/CON: Rifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: The Lord Henley
KQ/P/CON: The Lord StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Spokesperson or 
Unamed Party SourceKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/CON: Councillo
rL2/8/CON: MEPL3/J/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/CON: Other MP/C
andidate/PeerN9/P/CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campbel
l MenziesNM/F/LIB: Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers of Qu
arry BankNP/J/LIB: Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/S/
LIB: Other Senior PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable VincentR2/G/LIB
: Harver NickR3/J/LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore M
ichaelR6/F/LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: Sp
okesperson or Unamed Party SourceRA/J/LIB: Party OfficialRB/D/LIB: ActivistRC/F/
LIB: CouncillorRD/8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/LIB: Other inc
. Supporter10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10E/E/Hattersley R
oy10F/9/Heath Ted10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13/N
ellist Dave (Socialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party)1
0L/1G/Taylor Dr. Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/19
/Titford Jeffrey (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Indivi
dual13K/1B/David Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scotti
sh Parliament First Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13N/
1F/Rhodri Morgan (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Part
y)13P/13/Ian Paisley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/
Supporter/etc13R/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: MP/
Candidate/Spokesperson/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson/S
upporter/etc140/1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/M/Oth
er Party/Politician270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Bl
air273/I/LAB: Anthony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LI
B: Sarah Gurling277/P/CON: Nigel Hague (Father)29T/E/Other Relative3AA/Q/Agricul
ture Representative3AB/S/Business/City Representative3AC/1N/Business Organisatio
n eg. CBI, Institute of Directors3AD/D/Civil Servant3AE/M/Celebrity (state whom)
3AF/9/Economist3AG/19/European Leader/Politician (state whom)3AH/H/EU Representa
tive3AI/J/Farmer/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demonstra
tor3AL/15/Media Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/Securit
y3AO/E/Pressure Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollster/B
ookmaker3AS/A/Pensioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scientist
/Scientific Expert3B2/T/Social Service Representative3B3/13/Trade Union/Represen
tative/Member3B4/P/Unamed Source - Non-Party3B5/J/University Academic3B6/10/Vote
r/Citizen/Person in Street3B7/1K/World Leader/Politician (not European)(state wh
om)3B8/E/Geri Halliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/Th
ink Tank3D9/5/OtherD1/8/ACTOR2ND6I/3K/C/Labour Party3L/I/Conservative Party3M/D/
Lib Dem Party3N/Q/Scottish Nationalist Party3O/B/Plaid Cymru3P/B/Green Party3Q/M
/British National Party3R/L/UK Independence Party3S/1B/SDLP - Social Democratic 
and Labour Party3T/R/UUP - Ulster Unionist Party40/11/DUP - Democratic Unionist 
Party41/9/Sinn Fein42/E/The Government43/B/The Cabinet44/L/Government Department
45/E/The Opposition46/R/Parliament/MPs (in general)47/18/The European Union/Euro
pean Commission48/8/Millbank49/K/Electoral Commission4A/F/Scottish Labour4B/F/Sc
ottish Tories6H/10/Other Party - British Mainland6I/10/Other Party - Northern Ir
eland6J/H/Other Institution70/A/Blair Tony71/D/Hague William72/F/Kennedy Charles
73/G/Adams Gerry (SF)74/G/Hume John (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney 
John (SNP)77/J/Trimble David (UUP)78/I/Nick Griffin (BNP)9T/K/Party Leader - Oth
erAA/J/LAB: Blunkett DavidAB/H/LAB: Brown GordonAC/F/LAB: Cook RobinAD/H/LAB: Mi
lburn AlanAE/I/LAB: Prescott JohnAF/G/LAB: Smith ChrisAG/G/LAB: Short ClareAH/F/
LAB: Straw JackD9/15/LAB: Other Senior Labour PoliticianDK/11/LAB: Baroness Jay 
of PaddingtonDL/K/LAB: Becket MargaretDM/F/LAB: Brown NickDN/I/LAB: Byers Stephe
nDO/M/LAB: Campbell AlistairDP/L/LAB: Darling AlistairDQ/G/LAB: Irvine LordDR/I/
LAB: Liddell HelenDS/K/LAB: Mandelson PeterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh
 MargaretE2/E/LAB: Reid JohnE3/H/LAB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: 
Vaz KeithE6/J/LAB: Woodward ShaunE7/1A/LAB: Spokesperson or Unamed Party SourceE
8/J/LAB: Party OfficialE9/D/LAB: ActivistEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/L
AB: Other MP/Candidate/PeerGJ/P/LAB: Other inc. SupporterH0/D/CON: Fox LiamH1/J/
CON: Jenkin BernardH2/I/CON: Maude FrancisH3/G/CON: May TheresaH4/I/CON: Norman 
ArchieH5/L/CON: Portillo MichaelH6/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CO
N: Other Senior PoliticianKA/K/CON: Ainsworth PeterKB/J/CON: Ancram MichaelKC/K/
CON: Arbuthnot JamesKD/K/CON: Browning AngelaKE/M/CON: Duncan-Smith IainKF/J/CON
: Garnier EdwardKG/Q/CON: Heathcote Amory DavidKH/M/CON: Heseltine MichaelKI/I/C
ON: Johnson BorisKJ/J/CON: Lansley AndrewKK/I/CON: Letwin OliverKL/H/CON: McKay 
AndrewKM/J/CON: Platell AmandaKN/K/CON: Rifkind MalcolmKO/I/CON: Streeter GaryKP
/K/CON: The Lord HenleyKQ/P/CON: The Lord StrathclydeKR/I/CON: Willett DavidKS/1
A/CON: Spokesperson or Unamed Party SourceKT/J/CON: Party OfficialL0/D/CON: Acti
vistL1/F/CON: CouncillorL2/8/CON: MEPL3/J/CON: Clarke KennethL4/H/CON: Pickles E
ricN8/S/CON: Other MP/Candidate/PeerN9/P/CON: Other inc. SupporterNK/F/LIB: Beit
h AlanNL/L/LIB: Campbell MenziesNM/F/LIB: Foster DonNN/H/LIB: Hughes SimonNO/12/
LIB: Lord Rodgers of Quarry BankNP/J/LIB: Taylor MatthewNQ/G/LIB: Tonge JennyNR/
G/LIB: Wallace JimQJ/S/LIB: Other Senior PoliticianR0/G/LIB: Breed ColinR1/I/LIB
: Cable VincentR2/G/LIB: Harver NickR3/J/LIB: Livsey RichardR4/L/LIB: Maclennan 
RobertR5/I/LIB: Moore MichaelR6/F/LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: W
illis PhilR9/1A/LIB: Spokesperson or Unamed Party SourceRA/J/LIB: Party Official
RB/D/LIB: ActivistRC/F/LIB: CouncillorRD/8/LIB: MEPRE/S/LIB: Other MP/Candidate/
PeerTT/P/LIB: Other inc. Supporter10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn
 Tony10E/E/Hattersley Roy10F/9/Heath Ted10G/C/Kinnock Neil10H/F/Livingstone Ken1
0I/A/Major John10J/13/Nellist Dave (Socialist Alliance)10K/1A/Scargill Arthur (S
ocialist Labour Party)10L/1G/Taylor Dr. Richard (Kidderminster Independent)10M/G
/Thatcher Magaret10N/19/Titford Jeffrey (UK Independence Party)10O/G/Hinduja Bro
thers139/G/Other Individual13K/1B/David Ervine (Progressive Unionist Party)13L/1
K/Henry McLeish (Scottish Parliament First Minister)13M/1A/Gary McMichael (Ulste
r Democratic Party)13N/1F/Rhodri Morgan (Welsh Assembly First Minister)13O/S/Sea
n Neeson (Alliance Party)13P/13/Ian Paisley (Democratic Unionist)13Q/1E/SNP: MP/
Candidate/Spokesperson/Supporter/etc13R/1D/PC: MP/Candidate/Spokesperson/Support
er/etc13S/1G/Green: MP/Candidate/Spokesperson/Supporter/etc13T/1J/NI Party: MP/C
andidate/Spokesperson/Supporter/etc140/1M/Other Party: MP/Candidate/Spokesperson
/Supporter/etc16J/M/Other Party/Politician270/H/LAB: Cherie Blair271/F/LAB: Euan
 Blair272/E/LAB: Leo Blair273/I/LAB: Anthony Booth274/H/LAB: Lauren Booth275/G/C
ON: Ffion Hague276/I/LIB: Sarah Gurling277/P/CON: Nigel Hague (Father)29T/E/Othe
r Relative3AA/Q/Agriculture Representative3AB/S/Business/City Representative3AC/
1N/Business Organisation eg. CBI, Institute of Directors3AD/D/Civil Servant3AE/M
/Celebrity (state whom)3AF/9/Economist3AG/19/European Leader/Politician (state w
hom)3AH/H/EU Representative3AI/J/Farmer/Rural worker3AJ/M/Film/Documentary Maker
3AK/K/Heckler/Demonstrator3AL/15/Media Commentator/Journalist/Author3AM/9/The Me
dia3AN/F/Police/Security3AO/E/Pressure Group3AP/8/Prisoner3AQ/N/Professional Ind
ividual3AR/I/Pollster/Bookmaker3AS/A/Pensioners3AT/M/Religious Spokesperson3B0/7
/Royalty3B1/R/Scientist/Scientific Expert3B2/T/Social Service Representative3B3/
13/Trade Union/Representative/Member3B4/P/Unamed Source - Non-Party3B5/J/Univers
ity Academic3B6/10/Voter/Citizen/Person in Street3B7/1K/World Leader/Politician 
(not European)(state whom)3B8/E/Geri Halliwell3B9/P/Craig Evans - egg thrower3BA
/3/BBC3BB/3/ITV3BC/A/Think Tank3D9/5/OtherD1/8/ACTOR3RD6I/3K/C/Labour Party3L/I/
Conservative Party3M/D/Lib Dem Party3N/Q/Scottish Nationalist Party3O/B/Plaid Cy
mru3P/B/Green Party3Q/M/British National Party3R/L/UK Independence Party3S/1B/SD
LP - Social Democratic and Labour Party3T/R/UUP - Ulster Unionist Party40/11/DUP
 - Democratic Unionist Party41/9/Sinn Fein42/E/The Government43/B/The Cabinet44/
L/Government Department45/E/The Opposition46/R/Parliament/MPs (in general)47/18/
The European Union/European Commission48/8/Millbank49/K/Electoral Commission4A/F
/Scottish Labour4B/F/Scottish Tories6H/10/Other Party - British Mainland6I/10/Ot
her Party - Northern Ireland6J/H/Other Institution70/A/Blair Tony71/D/Hague Will
iam72/F/Kennedy Charles73/G/Adams Gerry (SF)74/G/Hume John (SDLP)75/K/Jones Ieua
n Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble David (UUP)78/I/Nick Griffin (BNP)
9T/K/Party Leader - OtherAA/J/LAB: Blunkett DavidAB/H/LAB: Brown GordonAC/F/LAB:
 Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: Prescott JohnAF/G/LAB: Smith ChrisAG/
G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/LAB: Other Senior Labour PoliticianD
K/11/LAB: Baroness Jay of PaddingtonDL/K/LAB: Becket MargaretDM/F/LAB: Brown Nic
kDN/I/LAB: Byers StephenDO/M/LAB: Campbell AlistairDP/L/LAB: Darling AlistairDQ/
G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/K/LAB: Mandelson PeterE0/E/LAB: Mowl
am MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Reid JohnE3/H/LAB: Smith AndrewE4/F/LA
B: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Woodward ShaunE7/1A/LAB: Spokesperson 
or Unamed Party SourceE8/J/LAB: Party OfficialE9/D/LAB: ActivistEA/F/LAB: Counci
llorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidate/PeerGJ/P/LAB: Other inc. Supporter
H0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2/I/CON: Maude FrancisH3/G/CON: May T
heresaH4/I/CON: Norman ArchieH5/L/CON: Portillo MichaelH6/J/CON: Widdecombe AnnH
7/C/CON: Yeo TimJT/S/CON: Other Senior PoliticianKA/K/CON: Ainsworth PeterKB/J/C
ON: Ancram MichaelKC/K/CON: Arbuthnot JamesKD/K/CON: Browning AngelaKE/M/CON: Du
ncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/CON: Heathcote Amory DavidKH/M/CON: 
Heseltine MichaelKI/I/CON: Johnson BorisKJ/J/CON: Lansley AndrewKK/I/CON: Letwin
 OliverKL/H/CON: McKay AndrewKM/J/CON: Platell AmandaKN/K/CON: Rifkind MalcolmKO
/I/CON: Streeter GaryKP/K/CON: The Lord HenleyKQ/P/CON: The Lord StrathclydeKR/I
/CON: Willett DavidKS/1A/CON: Spokesperson or Unamed Party SourceKT/J/CON: Party
 OfficialL0/D/CON: ActivistL1/F/CON: CouncillorL2/8/CON: MEPL3/J/CON: Clarke Ken
nethL4/H/CON: Pickles EricN8/S/CON: Other MP/Candidate/PeerN9/P/CON: Other inc. 
SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campbell MenziesNM/F/LIB: Foster DonNN/H/
LIB: Hughes SimonNO/12/LIB: Lord Rodgers of Quarry BankNP/J/LIB: Taylor MatthewN
Q/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/S/LIB: Other Senior PoliticianR0/G/L
IB: Breed ColinR1/I/LIB: Cable VincentR2/G/LIB: Harver NickR3/J/LIB: Livsey Rich
ardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore MichaelR6/F/LIB: Tyler PaulR7/F/LIB
: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: Spokesperson or Unamed Party SourceR
A/J/LIB: Party OfficialRB/D/LIB: ActivistRC/F/LIB: CouncillorRD/8/LIB: MEPRE/S/L
IB: Other MP/Candidate/PeerTT/P/LIB: Other inc. Supporter10A/D/Ashdown Paddy10B/
B/Bell Martin10C/9/Benn Tony10E/E/Hattersley Roy10F/9/Heath Ted10G/C/Kinnock Nei
l10H/F/Livingstone Ken10I/A/Major John10J/13/Nellist Dave (Socialist Alliance)10
K/1A/Scargill Arthur (Socialist Labour Party)10L/1G/Taylor Dr. Richard (Kiddermi
nster Independent)10M/G/Thatcher Magaret10N/19/Titford Jeffrey (UK Independence 
Party)10O/G/Hinduja Brothers139/G/Other Individual13K/1B/David Ervine (Progressi
ve Unionist Party)13L/1K/Henry McLeish (Scottish Parliament First Minister)13M/1
A/Gary McMichael (Ulster Democratic Party)13N/1F/Rhodri Morgan (Welsh Assembly F
irst Minister)13O/S/Sean Neeson (Alliance Party)13P/13/Ian Paisley (Democratic U
nionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Supporter/etc13R/1D/PC: MP/Candida
te/Spokesperson/Supporter/etc13S/1G/Green: MP/Candidate/Spokesperson/Supporter/e
tc13T/1J/NI Party: MP/Candidate/Spokesperson/Supporter/etc140/1M/Other Party: MP
/Candidate/Spokesperson/Supporter/etc16J/M/Other Party/Politician270/H/LAB: Cher
ie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair273/I/LAB: Anthony Booth274/H/L
AB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: Sarah Gurling277/P/CON: Nigel H
ague (Father)29T/E/Other Relative3AA/Q/Agriculture Representative3AB/S/Business/
City Representative3AC/1N/Business Organisation eg. CBI, Institute of Directors3
AD/D/Civil Servant3AE/M/Celebrity (state whom)3AF/9/Economist3AG/19/European Lea
der/Politician (state whom)3AH/H/EU Representative3AI/J/Farmer/Rural worker3AJ/M
/Film/Documentary Maker3AK/K/Heckler/Demonstrator3AL/15/Media Commentator/Journa
list/Author3AM/9/The Media3AN/F/Police/Security3AO/E/Pressure Group3AP/8/Prisone
r3AQ/N/Professional Individual3AR/I/Pollster/Bookmaker3AS/A/Pensioners3AT/M/Reli
gious Spokesperson3B0/7/Royalty3B1/R/Scientist/Scientific Expert3B2/T/Social Ser
vice Representative3B3/13/Trade Union/Representative/Member3B4/P/Unamed Source -
 Non-Party3B5/J/University Academic3B6/10/Voter/Citizen/Person in Street3B7/1K/W
orld Leader/Politician (not European)(state whom)3B8/E/Geri Halliwell3B9/P/Craig
 Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/Think Tank3D9/5/OtherD1/8/ACTOR4TH6I
/3K/C/Labour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Scottish Nationa
list Party3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Party3R/L/UK Ind
ependence Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/UUP - Ulster 
Unionist Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42/E/The Govern
ment43/B/The Cabinet44/L/Government Department45/E/The Opposition46/R/Parliament
/MPs (in general)47/18/The European Union/European Commission48/8/Millbank49/K/E
lectoral Commission4A/F/Scottish Labour4B/F/Scottish Tories6H/10/Other Party - B
ritish Mainland6I/10/Other Party - Northern Ireland6J/H/Other Institution70/A/Bl
air Tony71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry (SF)74/G/Hume Joh
n (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble David (UUP)
78/I/Nick Griffin (BNP)9T/K/Party Leader - OtherAA/J/LAB: Blunkett DavidAB/H/LAB
: Brown GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: Prescott JohnA
F/G/LAB: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/LAB: Other Se
nior Labour PoliticianDK/11/LAB: Baroness Jay of PaddingtonDL/K/LAB: Becket Marg
aretDM/F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB: Campbell AlistairDP/L/L
AB: Darling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/K/LAB: Mandel
son PeterE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Reid JohnE3/H/L
AB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Woodward ShaunE
7/1A/LAB: Spokesperson or Unamed Party SourceE8/J/LAB: Party OfficialE9/D/LAB: A
ctivistEA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidate/PeerGJ/P/LA
B: Other inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2/I/CON: Maude
 FrancisH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/L/CON: Portillo MichaelH6
/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other Senior PoliticianKA/K/CON
: Ainsworth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbuthnot JamesKD/K/CON: Brow
ning AngelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/CON: Heathcot
e Amory DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johnson BorisKJ/J/CON: Lansley
 AndrewKK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/J/CON: Platell AmandaKN/K
/CON: Rifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: The Lord HenleyKQ/P/CON: T
he Lord StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Spokesperson or Unamed Part
y SourceKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/CON: CouncillorL2/8/CON: 
MEPL3/J/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/CON: Other MP/Candidate/Pe
erN9/P/CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campbell MenziesNM
/F/LIB: Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers of Quarry BankNP
/J/LIB: Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/S/LIB: Other 
Senior PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable VincentR2/G/LIB: Harver Ni
ckR3/J/LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore MichaelR6/F/
LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: Spokesperson 
or Unamed Party SourceRA/J/LIB: Party OfficialRB/D/LIB: ActivistRC/F/LIB: Counci
llorRD/8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/LIB: Other inc. Supporter
10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/Benn Tony10E/E/Hattersley Roy10F/9/Hea
th Ted10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13/Nellist Dave
 (Socialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party)10L/1G/Taylo
r Dr. Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/19/Titford Je
ffrey (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Individual13K/1B/
David Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scottish Parliame
nt First Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13N/1F/Rhodri M
organ (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Party)13P/13/Ia
n Paisley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Supporter/e
tc13R/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: MP/Candidate/S
pokesperson/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson/Supporter/et
c140/1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/M/Other Party/Po
litician270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair273/I/LA
B: Anthony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: Sarah Gu
rling277/P/CON: Nigel Hague (Father)29T/E/Other Relative3AA/Q/Agriculture Repres
entative3AB/S/Business/City Representative3AC/1N/Business Organisation eg. CBI, 
Institute of Directors3AD/D/Civil Servant3AE/M/Celebrity (state whom)3AF/9/Econo
mist3AG/19/European Leader/Politician (state whom)3AH/H/EU Representative3AI/J/F
armer/Rural worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demonstrator3AL/15/M
edia Commentator/Journalist/Author3AM/9/The Media3AN/F/Police/Security3AO/E/Pres
sure Group3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollster/Bookmaker3AS
/A/Pensioners3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scientist/Scientific
 Expert3B2/T/Social Service Representative3B3/13/Trade Union/Representative/Memb
er3B4/P/Unamed Source - Non-Party3B5/J/University Academic3B6/10/Voter/Citizen/P
erson in Street3B7/1K/World Leader/Politician (not European)(state whom)3B8/E/Ge
ri Halliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/Think Tank3D9
/5/OtherD1/8/JOURNEV15/0/F/Can't Determine1/A/Crticising2/A/Mixed/Both3/A/Suppor
ting4/7/NeutralD1/8/JOURNEV25/0/F/Can't Determine1/A/Crticising2/A/Mixed/Both3/A
/Supporting4/7/NeutralD1/8/EVLTING16J/3K/C/Labour Party3L/I/Conservative Party3M
/D/Lib Dem Party3N/Q/Scottish Nationalist Party3O/B/Plaid Cymru3P/B/Green Party3
Q/M/British National Party3R/L/UK Independence Party3S/1B/SDLP - Social Democrat
ic and Labour Party3T/R/UUP - Ulster Unionist Party40/11/DUP - Democratic Unioni
st Party41/9/Sinn Fein42/E/The Government43/B/The Cabinet44/L/Government Departm
ent45/E/The Opposition46/R/Parliament/MPs (in general)47/18/The European Union/E
uropean Commission48/8/Millbank49/K/Electoral Commission4A/F/Scottish Labour4B/F
/Scottish Tories6H/10/Other Party - British Mainland6I/10/Other Party - Northern
 Ireland6J/H/Other Institution70/A/Blair Tony71/D/Hague William72/F/Kennedy Char
les73/G/Adams Gerry (SF)74/G/Hume John (SDLP)75/K/Jones Ieuan Wyn (PC)76/I/Swinn
ey John (SNP)77/J/Trimble David (UUP)78/I/Nick Griffin (BNP)9T/K/Party Leader - 
OtherAA/J/LAB: Blunkett DavidAB/H/LAB: Brown GordonAC/F/LAB: Cook RobinAD/H/LAB:
 Milburn AlanAE/I/LAB: Prescott JohnAF/G/LAB: Smith ChrisAG/G/LAB: Short ClareAH
/F/LAB: Straw JackD9/15/LAB: Other Senior Labour PoliticianDK/11/LAB: Baroness J
ay of PaddingtonDL/K/LAB: Becket MargaretDM/F/LAB: Brown NickDN/I/LAB: Byers Ste
phenDO/M/LAB: Campbell AlistairDP/L/LAB: Darling AlistairDQ/G/LAB: Irvine LordDR
/I/LAB: Liddell HelenDS/K/LAB: Mandelson PeterE0/E/LAB: Mowlam MoE1/M/LAB: McDon
agh MargaretE2/E/LAB: Reid JohnE3/H/LAB: Smith AndrewE4/F/LAB: Taylor AnnE5/E/LA
B: Vaz KeithE6/J/LAB: Woodward ShaunE7/1A/LAB: Spokesperson or Unamed Party Sour
ceE8/J/LAB: Party OfficialE9/D/LAB: ActivistEA/F/LAB: CouncillorEB/8/LAB: MEPGI/
S/LAB: Other MP/Candidate/PeerGJ/P/LAB: Other inc. SupporterH0/D/CON: Fox LiamH1
/J/CON: Jenkin BernardH2/I/CON: Maude FrancisH3/G/CON: May TheresaH4/I/CON: Norm
an ArchieH5/L/CON: Portillo MichaelH6/J/CON: Widdecombe AnnH7/C/CON: Yeo TimJT/S
/CON: Other Senior PoliticianKA/K/CON: Ainsworth PeterKB/J/CON: Ancram MichaelKC
/K/CON: Arbuthnot JamesKD/K/CON: Browning AngelaKE/M/CON: Duncan-Smith IainKF/J/
CON: Garnier EdwardKG/Q/CON: Heathcote Amory DavidKH/M/CON: Heseltine MichaelKI/
I/CON: Johnson BorisKJ/J/CON: Lansley AndrewKK/I/CON: Letwin OliverKL/H/CON: McK
ay AndrewKM/J/CON: Platell AmandaKN/K/CON: Rifkind MalcolmKO/I/CON: Streeter Gar
yKP/K/CON: The Lord HenleyKQ/P/CON: The Lord StrathclydeKR/I/CON: Willett DavidK
S/1A/CON: Spokesperson or Unamed Party SourceKT/J/CON: Party OfficialL0/D/CON: A
ctivistL1/F/CON: CouncillorL2/8/CON: MEPL3/J/CON: Clarke KennethL4/H/CON: Pickle
s EricN8/S/CON: Other MP/Candidate/PeerN9/P/CON: Other inc. SupporterNK/F/LIB: B
eith AlanNL/L/LIB: Campbell MenziesNM/F/LIB: Foster DonNN/H/LIB: Hughes SimonNO/
12/LIB: Lord Rodgers of Quarry BankNP/J/LIB: Taylor MatthewNQ/G/LIB: Tonge Jenny
NR/G/LIB: Wallace JimQJ/S/LIB: Other Senior PoliticianR0/G/LIB: Breed ColinR1/I/
LIB: Cable VincentR2/G/LIB: Harver NickR3/J/LIB: Livsey RichardR4/L/LIB: Maclenn
an RobertR5/I/LIB: Moore MichaelR6/F/LIB: Tyler PaulR7/F/LIB: Webb SteveR8/G/LIB
: Willis PhilR9/1A/LIB: Spokesperson or Unamed Party SourceRA/J/LIB: Party Offic
ialRB/D/LIB: ActivistRC/F/LIB: CouncillorRD/8/LIB: MEPRE/S/LIB: Other MP/Candida
te/PeerTT/P/LIB: Other inc. Supporter10A/D/Ashdown Paddy10B/B/Bell Martin10C/9/B
enn Tony10D/I/Griffin Nick (BNP)10E/E/Hattersley Roy10F/9/Heath Ted10G/C/Kinnock
 Neil10H/F/Livingstone Ken10I/A/Major John10J/13/Nellist Dave (Socialist Allianc
e)10K/1A/Scargill Arthur (Socialist Labour Party)10L/1G/Taylor Dr. Richard (Kidd
erminster Independent)10M/G/Thatcher Magaret10N/19/Titford Jeffrey (UK Independe
nce Party)10O/G/Hinduja Brothers139/G/Other Individual13K/1B/David Ervine (Progr
essive Unionist Party)13L/1K/Henry McLeish (Scottish Parliament First Minister)1
3M/1A/Gary McMichael (Ulster Democratic Party)13N/1F/Rhodri Morgan (Welsh Assemb
ly First Minister)13O/S/Sean Neeson (Alliance Party)13P/13/Ian Paisley (Democrat
ic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Supporter/etc13R/1D/PC: MP/Can
didate/Spokesperson/Supporter/etc13S/1G/Green: MP/Candidate/Spokesperson/Support
er/etc13T/1J/NI Party: MP/Candidate/Spokesperson/Supporter/etc140/1M/Other Party
: MP/Candidate/Spokesperson/Supporter/etc16J/M/Other Party/Politician270/H/LAB: 
Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair273/I/LAB: Anthony Booth274
/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: Sarah Gurling277/P/CON: Nig
el Hague (Father)29T/E/Other Relative3AA/Q/Agriculture Representative3AB/S/Busin
ess/City Representative3AC/1N/Business Organisation eg. CBI, Institute of Direct
ors3AD/D/Civil Servant3AE/9/Celebrity3AF/9/Economist3AG/Q/European Leader/Politi
cian3AH/H/EU Representative3AI/J/Farmer/Rural worker3AJ/M/Film/Documentary Maker
3AK/K/Heckler/Demonstrator3AL/15/Media Commentator/Journalist/Author3AM/9/The Me
dia3AN/F/Police/Security3AO/E/Pressure Group3AP/8/Prisoner3AQ/N/Professional Ind
ividual3AR/I/Pollster/Bookmaker3AS/A/Pensioners3AT/M/Religious Spokesperson3B0/7
/Royalty3B1/R/Scientist/Scientific Expert3B2/T/Social Service Representative3B3/
13/Trade Union/Representative/Member3B4/P/Unamed Source - Non-Party3B5/J/Univers
ity Academic3B6/10/Voter/Citizen/Person in Street3B7/18/World Leader/Politician 
(not European)3B8/E/Geri Halliwell3B9/P/Craig Evans - egg thrower3BA/3/BBC3BB/3/
ITV3BC/A/Think Tank3D9/5/OtherD1/8/EVLTION15/0/F/Can't Determine1/A/Crticising2/
A/Mixed/Both3/A/Supporting4/7/NeutralD1/7/EVLTED16J/3K/C/Labour Party3L/I/Conser
vative Party3M/D/Lib Dem Party3N/Q/Scottish Nationalist Party3O/B/Plaid Cymru3P/
B/Green Party3Q/M/British National Party3R/L/UK Independence Party3S/1B/SDLP - S
ocial Democratic and Labour Party3T/R/UUP - Ulster Unionist Party40/11/DUP - Dem
ocratic Unionist Party41/9/Sinn Fein42/E/The Government43/B/The Cabinet44/L/Gove
rnment Department45/E/The Opposition46/R/Parliament/MPs (in general)47/18/The Eu
ropean Union/European Commission48/8/Millbank49/K/Electoral Commission4A/F/Scott
ish Labour4B/F/Scottish Tories6H/10/Other Party - British Mainland6I/10/Other Pa
rty - Northern Ireland6J/H/Other Institution70/A/Blair Tony71/D/Hague William72/
F/Kennedy Charles73/G/Adams Gerry (SF)74/G/Hume John (SDLP)75/K/Jones Ieuan Wyn 
(PC)76/I/Swinney John (SNP)77/J/Trimble David (UUP)78/I/Nick Griffin (BNP)9T/K/P
arty Leader - OtherAA/J/LAB: Blunkett DavidAB/H/LAB: Brown GordonAC/F/LAB: Cook 
RobinAD/H/LAB: Milburn AlanAE/I/LAB: Prescott JohnAF/G/LAB: Smith ChrisAG/G/LAB:
 Short ClareAH/F/LAB: Straw JackD9/15/LAB: Other Senior Labour PoliticianDK/11/L
AB: Baroness Jay of PaddingtonDL/K/LAB: Becket MargaretDM/F/LAB: Brown NickDN/I/
LAB: Byers StephenDO/M/LAB: Campbell AlistairDP/L/LAB: Darling AlistairDQ/G/LAB:
 Irvine LordDR/I/LAB: Liddell HelenDS/K/LAB: Mandelson PeterE0/E/LAB: Mowlam MoE
1/M/LAB: McDonagh MargaretE2/E/LAB: Reid JohnE3/H/LAB: Smith AndrewE4/F/LAB: Tay
lor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Woodward ShaunE7/1A/LAB: Spokesperson or Una
med Party SourceE8/J/LAB: Party OfficialE9/D/LAB: ActivistEA/F/LAB: CouncillorEB
/8/LAB: MEPGI/S/LAB: Other MP/Candidate/PeerGJ/P/LAB: Other inc. SupporterH0/D/C
ON: Fox LiamH1/J/CON: Jenkin BernardH2/I/CON: Maude FrancisH3/G/CON: May Theresa
H4/I/CON: Norman ArchieH5/L/CON: Portillo MichaelH6/J/CON: Widdecombe AnnH7/C/CO
N: Yeo TimJT/S/CON: Other Senior PoliticianKA/K/CON: Ainsworth PeterKB/J/CON: An
cram MichaelKC/K/CON: Arbuthnot JamesKD/K/CON: Browning AngelaKE/M/CON: Duncan-S
mith IainKF/J/CON: Garnier EdwardKG/Q/CON: Heathcote Amory DavidKH/M/CON: Heselt
ine MichaelKI/I/CON: Johnson BorisKJ/J/CON: Lansley AndrewKK/I/CON: Letwin Olive
rKL/H/CON: McKay AndrewKM/J/CON: Platell AmandaKN/K/CON: Rifkind MalcolmKO/I/CON
: Streeter GaryKP/K/CON: The Lord HenleyKQ/P/CON: The Lord StrathclydeKR/I/CON: 
Willett DavidKS/1A/CON: Spokesperson or Unamed Party SourceKT/J/CON: Party Offic
ialL0/D/CON: ActivistL1/F/CON: CouncillorL2/8/CON: MEPL3/J/CON: Clarke KennethL4
/H/CON: Pickles EricN8/S/CON: Other MP/Candidate/PeerN9/P/CON: Other inc. Suppor
terNK/F/LIB: Beith AlanNL/L/LIB: Campbell MenziesNM/F/LIB: Foster DonNN/H/LIB: H
ughes SimonNO/12/LIB: Lord Rodgers of Quarry BankNP/J/LIB: Taylor MatthewNQ/G/LI
B: Tonge JennyNR/G/LIB: Wallace JimQJ/S/LIB: Other Senior PoliticianR0/G/LIB: Br
eed ColinR1/I/LIB: Cable VincentR2/G/LIB: Harver NickR3/J/LIB: Livsey RichardR4/
L/LIB: Maclennan RobertR5/I/LIB: Moore MichaelR6/F/LIB: Tyler PaulR7/F/LIB: Webb
 SteveR8/G/LIB: Willis PhilR9/1A/LIB: Spokesperson or Unamed Party SourceRA/J/LI
B: Party OfficialRB/D/LIB: ActivistRC/F/LIB: CouncillorRD/8/LIB: MEPRE/S/LIB: Ot
her MP/Candidate/PeerTT/P/LIB: Other inc. Supporter10A/D/Ashdown Paddy10B/B/Bell
 Martin10C/9/Benn Tony10D/I/Griffin Nick (BNP)10E/E/Hattersley Roy10F/9/Heath Te
d10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13/Nellist Dave (Soc
ialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party)10L/1G/Taylor Dr.
 Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/19/Titford Jeffrey
 (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Individual13K/1B/David
 Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scottish Parliament Fi
rst Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13N/1F/Rhodri Morgan
 (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Party)13P/13/Ian Pai
sley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Supporter/etc13R
/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: MP/Candidate/Spokes
person/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson/Supporter/etc140/
1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/M/Other Party/Politic
ian270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair273/I/LAB: An
thony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: Sarah Gurling
277/P/CON: Nigel Hague (Father)29T/E/Other Relative3AA/Q/Agriculture Representat
ive3AB/S/Business/City Representative3AC/1N/Business Organisation eg. CBI, Insti
tute of Directors3AD/D/Civil Servant3AE/9/Celebrity3AF/9/Economist3AG/Q/European
 Leader/Politician3AH/H/EU Representative3AI/J/Farmer/Rural worker3AJ/M/Film/Doc
umentary Maker3AK/K/Heckler/Demonstrator3AL/15/Media Commentator/Journalist/Auth
or3AM/9/The Media3AN/F/Police/Security3AO/E/Pressure Group3AP/8/Prisoner3AQ/N/Pr
ofessional Individual3AR/I/Pollster/Bookmaker3AS/A/Pensioners3AT/M/Religious Spo
kesperson3B0/7/Royalty3B1/R/Scientist/Scientific Expert3B2/T/Social Service Repr
esentative3B3/13/Trade Union/Representative/Member3B4/P/Unamed Source - Non-Part
y3B5/J/University Academic3B6/10/Voter/Citizen/Person in Street3B7/18/World Lead
er/Politician (not European)3B8/E/Geri Halliwell3B9/P/Craig Evans - egg thrower3
BA/3/BBC3BB/3/ITV3BC/A/Think Tank3D9/5/OtherD1/8/EVLTING26J/3K/C/Labour Party3L/
I/Conservative Party3M/D/Lib Dem Party3N/Q/Scottish Nationalist Party3O/B/Plaid 
Cymru3P/B/Green Party3Q/M/British National Party3R/L/UK Independence Party3S/1B/
SDLP - Social Democratic and Labour Party3T/R/UUP - Ulster Unionist Party40/11/D
UP - Democratic Unionist Party41/9/Sinn Fein42/E/The Government43/B/The Cabinet4
4/L/Government Department45/E/The Opposition46/R/Parliament/MPs (in general)47/1
8/The European Union/European Commission48/8/Millbank49/K/Electoral Commission4A
/F/Scottish Labour4B/F/Scottish Tories6H/10/Other Party - British Mainland6I/10/
Other Party - Northern Ireland6J/H/Other Institution70/A/Blair Tony71/D/Hague Wi
lliam72/F/Kennedy Charles73/G/Adams Gerry (SF)74/G/Hume John (SDLP)75/K/Jones Ie
uan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble David (UUP)78/I/Nick Griffin (BN
P)9T/K/Party Leader - OtherAA/J/LAB: Blunkett DavidAB/H/LAB: Brown GordonAC/F/LA
B: Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: Prescott JohnAF/G/LAB: Smith ChrisA
G/G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/LAB: Other Senior Labour Politicia
nDK/11/LAB: Baroness Jay of PaddingtonDL/K/LAB: Becket MargaretDM/F/LAB: Brown N
ickDN/I/LAB: Byers StephenDO/M/LAB: Campbell AlistairDP/L/LAB: Darling AlistairD
Q/G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/K/LAB: Mandelson PeterE0/E/LAB: Mo
wlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Reid JohnE3/H/LAB: Smith AndrewE4/F/
LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Woodward ShaunE7/1A/LAB: Spokesperso
n or Unamed Party SourceE8/J/LAB: Party OfficialE9/D/LAB: ActivistEA/F/LAB: Coun
cillorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidate/PeerGJ/P/LAB: Other inc. Support
erH0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2/I/CON: Maude FrancisH3/G/CON: May
 TheresaH4/I/CON: Norman ArchieH5/L/CON: Portillo MichaelH6/J/CON: Widdecombe An
nH7/C/CON: Yeo TimJT/S/CON: Other Senior PoliticianKA/K/CON: Ainsworth PeterKB/J
/CON: Ancram MichaelKC/K/CON: Arbuthnot JamesKD/K/CON: Browning AngelaKE/M/CON: 
Duncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/CON: Heathcote Amory DavidKH/M/CON
: Heseltine MichaelKI/I/CON: Johnson BorisKJ/J/CON: Lansley AndrewKK/I/CON: Letw
in OliverKL/H/CON: McKay AndrewKM/J/CON: Platell AmandaKN/K/CON: Rifkind Malcolm
KO/I/CON: Streeter GaryKP/K/CON: The Lord HenleyKQ/P/CON: The Lord StrathclydeKR
/I/CON: Willett DavidKS/1A/CON: Spokesperson or Unamed Party SourceKT/J/CON: Par
ty OfficialL0/D/CON: ActivistL1/F/CON: CouncillorL2/8/CON: MEPL3/J/CON: Clarke K
ennethL4/H/CON: Pickles EricN8/S/CON: Other MP/Candidate/PeerN9/P/CON: Other inc
. SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campbell MenziesNM/F/LIB: Foster DonNN/
H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers of Quarry BankNP/J/LIB: Taylor Matthe
wNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/S/LIB: Other Senior PoliticianR0/G
/LIB: Breed ColinR1/I/LIB: Cable VincentR2/G/LIB: Harver NickR3/J/LIB: Livsey Ri
chardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore MichaelR6/F/LIB: Tyler PaulR7/F/L
IB: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: Spokesperson or Unamed Party Sourc
eRA/J/LIB: Party OfficialRB/D/LIB: ActivistRC/F/LIB: CouncillorRD/8/LIB: MEPRE/S
/LIB: Other MP/Candidate/PeerTT/P/LIB: Other inc. Supporter10A/D/Ashdown Paddy10
B/B/Bell Martin10C/9/Benn Tony10D/I/Griffin Nick (BNP)10E/E/Hattersley Roy10F/9/
Heath Ted10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10J/13/Nellist D
ave (Socialist Alliance)10K/1A/Scargill Arthur (Socialist Labour Party)10L/1G/Ta
ylor Dr. Richard (Kidderminster Independent)10M/G/Thatcher Magaret10N/19/Titford
 Jeffrey (UK Independence Party)10O/G/Hinduja Brothers139/G/Other Individual13K/
1B/David Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (Scottish Parli
ament First Minister)13M/1A/Gary McMichael (Ulster Democratic Party)13N/1F/Rhodr
i Morgan (Welsh Assembly First Minister)13O/S/Sean Neeson (Alliance Party)13P/13
/Ian Paisley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesperson/Supporte
r/etc13R/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Green: MP/Candidat
e/Spokesperson/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokesperson/Supporter
/etc140/1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J/M/Other Party
/Politician270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: Leo Blair273/I
/LAB: Anthony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague276/I/LIB: Sarah
 Gurling277/P/CON: Nigel Hague (Father)29T/E/Other Relative3AA/Q/Agriculture Rep
resentative3AB/S/Business/City Representative3AC/1N/Business Organisation eg. CB
I, Institute of Directors3AD/D/Civil Servant3AE/9/Celebrity3AF/9/Economist3AG/Q/
European Leader/Politician3AH/H/EU Representative3AI/J/Farmer/Rural worker3AJ/M/
Film/Documentary Maker3AK/K/Heckler/Demonstrator3AL/15/Media Commentator/Journal
ist/Author3AM/9/The Media3AN/F/Police/Security3AO/E/Pressure Group3AP/8/Prisoner
3AQ/N/Professional Individual3AR/I/Pollster/Bookmaker3AS/A/Pensioners3AT/M/Relig
ious Spokesperson3B0/7/Royalty3B1/R/Scientist/Scientific Expert3B2/T/Social Serv
ice Representative3B3/13/Trade Union/Representative/Member3B4/P/Unamed Source - 
Non-Party3B5/J/University Academic3B6/10/Voter/Citizen/Person in Street3B7/18/Wo
rld Leader/Politician (not European)3B8/E/Geri Halliwell3B9/P/Craig Evans - egg 
thrower3BA/3/BBC3BB/3/ITV3BC/A/Think Tank3D9/5/OtherD1/8/EVLTION25/0/F/Can't Det
ermine1/A/Crticising2/A/Mixed/Both3/A/Supporting4/7/NeutralD1/7/EVLTED26J/3K/C/L
abour Party3L/I/Conservative Party3M/D/Lib Dem Party3N/Q/Scottish Nationalist Pa
rty3O/B/Plaid Cymru3P/B/Green Party3Q/M/British National Party3R/L/UK Independen
ce Party3S/1B/SDLP - Social Democratic and Labour Party3T/R/UUP - Ulster Unionis
t Party40/11/DUP - Democratic Unionist Party41/9/Sinn Fein42/E/The Government43/
B/The Cabinet44/L/Government Department45/E/The Opposition46/R/Parliament/MPs (i
n general)47/18/The European Union/European Commission48/8/Millbank49/K/Electora
l Commission4A/F/Scottish Labour4B/F/Scottish Tories6H/10/Other Party - British 
Mainland6I/10/Other Party - Northern Ireland6J/H/Other Institution70/A/Blair Ton
y71/D/Hague William72/F/Kennedy Charles73/G/Adams Gerry (SF)74/G/Hume John (SDLP
)75/K/Jones Ieuan Wyn (PC)76/I/Swinney John (SNP)77/J/Trimble David (UUP)78/I/Ni
ck Griffin (BNP)9T/K/Party Leader - OtherAA/J/LAB: Blunkett DavidAB/H/LAB: Brown
 GordonAC/F/LAB: Cook RobinAD/H/LAB: Milburn AlanAE/I/LAB: Prescott JohnAF/G/LAB
: Smith ChrisAG/G/LAB: Short ClareAH/F/LAB: Straw JackD9/15/LAB: Other Senior La
bour PoliticianDK/11/LAB: Baroness Jay of PaddingtonDL/K/LAB: Becket MargaretDM/
F/LAB: Brown NickDN/I/LAB: Byers StephenDO/M/LAB: Campbell AlistairDP/L/LAB: Dar
ling AlistairDQ/G/LAB: Irvine LordDR/I/LAB: Liddell HelenDS/K/LAB: Mandelson Pet
erE0/E/LAB: Mowlam MoE1/M/LAB: McDonagh MargaretE2/E/LAB: Reid JohnE3/H/LAB: Smi
th AndrewE4/F/LAB: Taylor AnnE5/E/LAB: Vaz KeithE6/J/LAB: Woodward ShaunE7/1A/LA
B: Spokesperson or Unamed Party SourceE8/J/LAB: Party OfficialE9/D/LAB: Activist
EA/F/LAB: CouncillorEB/8/LAB: MEPGI/S/LAB: Other MP/Candidate/PeerGJ/P/LAB: Othe
r inc. SupporterH0/D/CON: Fox LiamH1/J/CON: Jenkin BernardH2/I/CON: Maude Franci
sH3/G/CON: May TheresaH4/I/CON: Norman ArchieH5/L/CON: Portillo MichaelH6/J/CON:
 Widdecombe AnnH7/C/CON: Yeo TimJT/S/CON: Other Senior PoliticianKA/K/CON: Ainsw
orth PeterKB/J/CON: Ancram MichaelKC/K/CON: Arbuthnot JamesKD/K/CON: Browning An
gelaKE/M/CON: Duncan-Smith IainKF/J/CON: Garnier EdwardKG/Q/CON: Heathcote Amory
 DavidKH/M/CON: Heseltine MichaelKI/I/CON: Johnson BorisKJ/J/CON: Lansley Andrew
KK/I/CON: Letwin OliverKL/H/CON: McKay AndrewKM/J/CON: Platell AmandaKN/K/CON: R
ifkind MalcolmKO/I/CON: Streeter GaryKP/K/CON: The Lord HenleyKQ/P/CON: The Lord
 StrathclydeKR/I/CON: Willett DavidKS/1A/CON: Spokesperson or Unamed Party Sourc
eKT/J/CON: Party OfficialL0/D/CON: ActivistL1/F/CON: CouncillorL2/8/CON: MEPL3/J
/CON: Clarke KennethL4/H/CON: Pickles EricN8/S/CON: Other MP/Candidate/PeerN9/P/
CON: Other inc. SupporterNK/F/LIB: Beith AlanNL/L/LIB: Campbell MenziesNM/F/LIB:
 Foster DonNN/H/LIB: Hughes SimonNO/12/LIB: Lord Rodgers of Quarry BankNP/J/LIB:
 Taylor MatthewNQ/G/LIB: Tonge JennyNR/G/LIB: Wallace JimQJ/S/LIB: Other Senior 
PoliticianR0/G/LIB: Breed ColinR1/I/LIB: Cable VincentR2/G/LIB: Harver NickR3/J/
LIB: Livsey RichardR4/L/LIB: Maclennan RobertR5/I/LIB: Moore MichaelR6/F/LIB: Ty
ler PaulR7/F/LIB: Webb SteveR8/G/LIB: Willis PhilR9/1A/LIB: Spokesperson or Unam
ed Party SourceRA/J/LIB: Party OfficialRB/D/LIB: ActivistRC/F/LIB: CouncillorRD/
8/LIB: MEPRE/S/LIB: Other MP/Candidate/PeerTT/P/LIB: Other inc. Supporter10A/D/A
shdown Paddy10B/B/Bell Martin10C/9/Benn Tony10D/I/Griffin Nick (BNP)10E/E/Hatter
sley Roy10F/9/Heath Ted10G/C/Kinnock Neil10H/F/Livingstone Ken10I/A/Major John10
J/13/Nellist Dave (Socialist Alliance)10K/1A/Scargill Arthur (Socialist Labour P
arty)10L/1G/Taylor Dr. Richard (Kidderminster Independent)10M/G/Thatcher Magaret
10N/19/Titford Jeffrey (UK Independence Party)10O/G/Hinduja Brothers139/G/Other 
Individual13K/1B/David Ervine (Progressive Unionist Party)13L/1K/Henry McLeish (
Scottish Parliament First Minister)13M/1A/Gary McMichael (Ulster Democratic Part
y)13N/1F/Rhodri Morgan (Welsh Assembly First Minister)13O/S/Sean Neeson (Allianc
e Party)13P/13/Ian Paisley (Democratic Unionist)13Q/1E/SNP: MP/Candidate/Spokesp
erson/Supporter/etc13R/1D/PC: MP/Candidate/Spokesperson/Supporter/etc13S/1G/Gree
n: MP/Candidate/Spokesperson/Supporter/etc13T/1J/NI Party: MP/Candidate/Spokespe
rson/Supporter/etc140/1M/Other Party: MP/Candidate/Spokesperson/Supporter/etc16J
/M/Other Party/Politician270/H/LAB: Cherie Blair271/F/LAB: Euan Blair272/E/LAB: 
Leo Blair273/I/LAB: Anthony Booth274/H/LAB: Lauren Booth275/G/CON: Ffion Hague27
6/I/LIB: Sarah Gurling277/P/CON: Nigel Hague (Father)29T/E/Other Relative3AA/Q/A
griculture Representative3AB/S/Business/City Representative3AC/1N/Business Organ
isation eg. CBI, Institute of Directors3AD/D/Civil Servant3AE/9/Celebrity3AF/9/E
conomist3AG/Q/European Leader/Politician3AH/H/EU Representative3AI/J/Farmer/Rura
l worker3AJ/M/Film/Documentary Maker3AK/K/Heckler/Demonstrator3AL/15/Media Comme
ntator/Journalist/Author3AM/9/The Media3AN/F/Police/Security3AO/E/Pressure Group
3AP/8/Prisoner3AQ/N/Professional Individual3AR/I/Pollster/Bookmaker3AS/A/Pension
ers3AT/M/Religious Spokesperson3B0/7/Royalty3B1/R/Scientist/Scientific Expert3B2
/T/Social Service Representative3B3/13/Trade Union/Representative/Member3B4/P/Un
amed Source - Non-Party3B5/J/University Academic3B6/10/Voter/Citizen/Person in S
treet3B7/18/World Leader/Politician (not European)3B8/E/Geri Halliwell3B9/P/Crai
g Evans - egg thrower3BA/3/BBC3BB/3/ITV3BC/A/Think Tank3D9/5/OtherD1/7/TONE1ST5/
0/F/Can't Determine1/8/Negative2/A/Mixed/Both3/8/Positive4/7/NeutralD1/7/TONE2ND
5/0/F/Can't Determine1/8/Negative2/A/Mixed/Both3/8/Positive4/7/NeutralD1/6/POLIC
Y4/0/4/None1/3/Low2/6/Medium3/4/HighD1/8/PRSONLTY4/0/4/None1/3/Low2/6/Medium3/4/
HighFDNL96+2/BDE/1/5/2/GP/6/1/1/3/1/1/3H/*.*.E5/29T/6J/*.4/4/6J/1/E5/6J/1/29T/1/
1/0/0/DNL96+2/BDE/1/5/2/GP/6/1/1/3/1/3/3G/3H/*.E5/29T/6J/*.4/4/6J/1/E5/*.*.*.1/1
/0/0/DNLP6+2/BOA/1/3/2/BT/J/1/1/3/1/1/6J/DH/*.273/70/277/71/4/4/273/1/70/277/1/7
1/4/4/1/0/DNLP6+2/BOA/1/3/2/BT/J/1/1/3/1/3/6J/DH/*.273/70/71/29T/4/4/273/1/70/29
T/1/71/4/4/0/0/DNMB6+2/C43/1/1/2/S5/J/1/5/3/1/1/6Q/*.*.3BA/3AL/70/*.1/1/*.*.*.*.
*.*.1/1/0/0/DNMB6+2/C43/1/1/2/S5/J/4/5/3/1/3/6Q/*.*.3BA/3AL/*.*.1/1/*.*.*.*.*.*.
1/1/0/0/DNMEC+2/C79/1/2/2/1N1/J/1/6/3/1/1/A1/A2/D9/71/*.*.*.2/*.*.*.*.*.*.*.2/*.
1/2/DNMEC+2/C79/1/2/2/1N1/J/1/6/3/1/3/A1/A2/AA/71/*.*.*.2/*.*.*.*.*.*.*.2/*.1/2/
DNMKO+2/CE6/1/4/2/RH/P/1/5/3/2/1/72/45/*.3K/70/*.*.2/2/*.*.*.*.*.*.2/2/0/0/DNMKO
+2/CE6/1/4/2/RH/P/1/5/3/2/3/72/45/*.70/3K/*.*.4/4/*.*.*.*.*.*.4/4/0/0/DNMO+3/CGO
/1/5/2/MB/F/1/1/3/1/1/AF/GJ/A2/AA/3D9/3K/E7/4/4/3D9/1/3K/E7/1/3K/4/4/1/0/DNMO+3/
CGO/1/5/2/MB/F/1/1/3/1/3/GJ/AF/*.AA/3K/3D9/*.4/4/3D9/1/3K/*.*.*.4/4/1/1/DNN6O+2/
CNM/1/2/2/1CO/E/5/2/3/1/1/E7/E1/*.3K/3BC/*.*.4/4/*.*.*.*.*.*.4/4/2/0/DNN6O+2/CNM
/1/2/2/1CO/E/5/2/3/1/3/E7/E1/*.3K/3BC/70/*.4/4/*.*.*.*.*.*.4/4/2/0/DNNA+3/CRF/1/
3/2/RG/M/2/5/3/1/1/DG/3C/6J/71/70/*.*.1/1/*.*.*.*.*.*.1/1/1/0/DNNA+3/CRF/1/3/2/R
G/M/2/5/3/1/3/DG/*.*.71/70/3K/3L/1/1/*.*.*.*.*.*.1/1/1/0/DNND6+2/D0D/1/4/2/JC/J/
1/1/2/1/1/46/DH/EF/3M/3L/3K/KR/4/4/KR/1/3K/*.*.*.4/4/2/0/DNND6+2/D0D/1/4/2/JC/J/
1/1/2/1/3/46/EF/DH/3M/3L/3K/*.4/4/3L/1/3K/*.*.*.4/4/2/0/DNNGC+2/D40/1/5/2/C5/K/5
/5/3/1/1/GJ/*.*.3K/3L/3M/*.1/1/*.*.*.*.*.*.1/1/1/0/DNNGC+2/D40/1/5/2/C5/K/5/2/3/
1/3/GJ/*.*.3K/3L/3M/*.1/1/*.*.*.*.*.*.1/1/1/0/DNNT6+2/DA8/1/2/2/F3/E/1/1/2/1/1/3
R/A2/*.71/3K/*.*.4/4/71/1/3K/*.*.*.4/4/1/0/DNNT6+2/DA8/1/2/2/F3/E/1/1/2/1/3/3R/A
2/*.71/3K/*.*.4/4/71/1/3K/*.*.*.4/4/2/0/DNO2C+2/DE6/1/3/2/D1/J/1/1/3/1/1/6J/*.*.
3K/GJ/3L/*.1/4/GJ/1/3K/*.*.*.1/4/0/0/DNO2C+2/DE6/1/3/2/D1/J/1/1/3/1/3/6J/*.*.3K/
70/GJ/*.1/1/GJ/1/3K/*.*.*.1/1/0/0/DNO5I+2/DH2/1/4/2/QS/K/2/5/3/1/1/6Q/3C/*.70/3A
M/3B6/*.3/2/*.*.*.*.*.*.3/2/0/0/DNO5I+2/DH2/1/4/2/QS/K/2/5/3/1/3/6Q/3C/*.70/3B6/
3AM/*.3/1/*.*.*.*.*.*.3/1/0/0/DNL6+3/MDL/2/4/2/8B/B/5/1/2/1/1/3B/A1/3C/13S/3P/*.
*.3/4/*.*.*.*.*.*.3/4/0/0/DNL6+3/MDL/2/4/2/8B/B/5/1/2/1/3/3B/3C/*.3P/13S/13S/13S
/4/4/*.*.*.*.*.*.4/4/0/0/DNLM+3/MNI/2/2/2/IA/1/1/1/2/1/1/GJ/A2/*.DK/70/6J/*.4/4/
*.*.*.*.*.*.4/4/1/0/DNLM+3/MNI/2/2/2/IA/1/1/1/2/1/3/GJ/A2/*.DK/70/6J/*.4/4/*.*.*
.*.*.*.4/4/2/0/DNLP6+2/MQO/2/3/2/MH/1/1/1/2/1/3/E1/A5/A2/70/3K/*.*.4/4/*.*.*.*.*
.*.4/4/3/0/DNLP6+2/MQO/2/3/2/MH/1/1/1/2/1/3/E1/A5/A2/70/3K/*.*.4/4/*.*.*.*.*.*.4
/4/3/0/DNLP6+2/MR0/2/3/2/2II/D/3/39/2/1/1/A7/A2/EA/3M/*.*.*.4/*.*.*.*.*.*.*.4/*.
3/0/DNLP6+2/MR0/2/3/2/2II/D/3/1/3/1/3/A7/A2/EA/3M/*.*.*.4/*.*.*.*.*.*.*.4/*.3/0/
DNM1I+2/N3P/2/5/2/H0/C/5/1/3/1/1/AA/73/A1/N8/71/N9/RE/4/4/N8/2/71/3B6/2/71/4/4/0
/1/DNM1I+2/N3P/2/5/2/H0/C/5/1/3/1/3/AA/A1/73/N8/71/3B6/*.4/4/N8/2/71/3B6/1/71/4/
2/0/0/DNMEC+2/NA4/2/2/2/Q4/1/1/1/2/2/1/3E/3B/*.AB/3B6/*.*.1/4/*.*.*.*.*.*.1/4/0/
1/DNMEC+2/NA4/2/2/2/Q4/1/4/1/2/2/3/3B/6J/*.AB/3B6/*.*.1/4/*.*.*.*.*.*.1/4/0/1/DN
MEC+2/NAH/2/2/2/4O/D/1/1/2/1/1/DO/3B/3P/3D9/71/70/*.4/4/3D9/1/71/3D9/3/70/4/1/1/
0/DNMEC+2/NAH/2/2/2/4O/D/1/1/2/1/3/DO/3P/3B/3D9/71/70/*.4/4/3D9/1/71/3D9/3/70/4/
1/0/0/DNN6O+2/NQP/2/2/2/HR/2/1/1/1/1/1/DF/6J/*.3AG/*.*.*.4/*.*.*.*.*.*.*.4/*.2/0
/DNN6O+2/NQP/2/2/2/HR/2/1/1/4/1/3/DF/6J/*.3AG/*.*.*.4/*.*.*.*.*.*.*.4/*.2/0/DNND
6+2/O3F/2/4/2/D8/D/5/2/3/1/1/3L/*.*.3K/3M/3L/70/4/1/*.*.*.*.*.*.4/1/0/0/DNND6+2/
O3F/2/4/2/D8/D/5/2/3/1/3/3L/*.*.3K/3M/3L/70/4/1/*.*.*.*.*.*.4/1/0/0/DNNT6+2/ODJ/
2/2/2/7N/9/1/1/2/1/1/43/A2/*.70/3K/72/3M/4/1/72/1/70/*.*.*.4/1/1/0/DNNT6+2/ODJ/2
/2/2/7N/9/1/1/2/1/3/43/A2/*.70/3K/72/*.4/4/72/1/70/*.*.*.4/1/1/0/DNL96+2/13KC/3/
5/2/KA/D/1/1/1/1/1/DH/46/DE/AB/H5/3L/3K/4/4/H5/1/AB/AB/1/3L/4/4/1/0/DNL96+2/13KC
/3/5/2/KA/D/1/1/1/1/3/46/DH/DE/AB/H5/3K/3L/4/4/H5/1/3K/AB/1/3L/4/4/1/0/DNLIO+2/1
3NH/3/1/2/KC/1/4/1/3/1/1/DD/*.*.3AN/AH/3L/3K/4/4/3AN/1/3K/*.*.*.4/4/1/0/DNLIO+2/
13NH/3/1/2/KC/1/4/1/3/1/3/DD/*.*.3AN/3D9/AH/3L/4/4/*.*.*.*.*.*.4/4/1/0/DNMB6+2/1
4A7/3/1/2/T2/1/1/1/3/1/1/ED/6S/*.3AB/3K/3L/*.4/1/3AB/1/3K/3AB/3/3L/4/1/1/0/DNMB6
+2/14A7/3/1/2/T2/1/1/1/3/1/3/ED/6S/*.3K/3L/N8/GI/1/4/N8/3/3K/N8/1/3L/1/4/1/0/DNN
3I+2/14QP/3/1/2/KQ/8/1/1/2/1/1/DG/*.*.AB/3L/71/3AB/4/4/3L/1/AB/3AB/1/3L/4/4/1/0/
DNN3I+2/14QP/3/1/2/KQ/8/1/1/2/1/3/DG/*.*.AB/71/3K/3AB/4/4/3K/1/AB/3AB/1/3K/4/4/1
/0/DNN6O+2/1504/3/2/2/OJ/4/4/1/4/1/1/DF/*.*.3AG/*.*.*.4/*.*.*.*.*.*.*.4/*.2/0/DN
N6O+2/1504/3/2/2/OJ/4/4/1/4/1/3/DF/*.*.3AG/*.*.*.4/*.*.*.*.*.*.*.4/*.2/0/DNNGC+2
/15AG/3/5/2/RJ/B/1/2/3/1/1/6J/3C/*.GJ/48/70/*.3/4/GJ/1/48/*.*.*.3/4/0/1/DNNGC+2/
15AG/3/5/2/RJ/B/1/2/3/1/3/3C/6J/*.GJ/E8/70/*.2/4/GJ/1/E8/*.*.*.2/4/0/1/DNO2C+2/1
5KG/3/3/2/43/A/4/1/3/1/1/6Q/*.*.3BB/3BA/3AM/*.4/4/3BA/1/3BB/3AM/1/3BB/1/4/0/0/DN
O2C+2/15KG/3/3/2/43/A/4/1/3/1/3/6Q/9T/*.3BB/3AL/3BA/*.4/4/3AL/1/3BB/*.*.*.1/4/0/
0/DNL6+3/1EKD/4/4/2/1A9/3/1/5/3/1/1/3Q/3R/40/70/42/*.*.2/4/*.*.*.*.*.*.2/4/0/0/D
NL6+3/1EKD/4/4/2/1A9/3/1/2/3/1/3/3Q/3R/43/70/42/*.*.1/4/*.*.*.*.*.*.1/4/0/0/DNL9
6+2/1ENG/4/5/2/A2/5/5/5/3/1/1/A6/DI/DE/3L/*.*.*.2/*.*.*.*.*.*.*.2/*.3/0/DNL96+2/
1ENG/4/5/2/A2/5/5/5/3/1/3/A6/DI/DE/3L/*.*.*.2/*.*.*.*.*.*.*.2/*.3/0/DNL96+2/1ENN
/4/5/2/4N/5/4/5/3/1/1/A6/DP/*.3L/3AM/*.*.4/4/3AM/1/3L/*.*.*.4/4/3/0/DNL96+2/1ENN
/4/5/2/4N/5/4/5/3/1/3/A6/DP/*.3L/3AM/*.*.4/4/3AM/1/3L/*.*.*.4/4/3/0/DNLIO+2/1EQP
/4/1/2/7J/9/1/1/2/1/1/DK/DM/*.70/3K/3D9/*.4/4/*.*.*.*.*.*.4/4/2/0/DNLIO+2/1EQP/4
/1/2/7J/9/1/1/2/1/3/DK/DM/*.70/3D9/3K/*.4/4/*.*.*.*.*.*.4/4/2/0/DNLM+3/1F0B/4/2/
2/1AG/6/1/2/2/1/1/ED/6S/*.AB/3AB/H5/3K/4/1/H5/1/AB/*.*.*.4/1/3/0/DNLM+3/1F0B/4/2
/2/1AG/6/1/1/2/1/3/ED/6S/A2/AB/3AB/H5/3K/4/4/H5/1/AB/3AB/3/3K/4/4/2/0/DNLSC+2/1F
7M/4/4/2/GB/9/1/1/3/1/1/6J/3C/DB/3M/GI/10L/*.4/4/GI/1/3M/3M/3/10L/4/4/1/0/DNLSC+
2/1F7M/4/4/2/GB/9/1/1/3/1/3/6J/DB/*.3M/10L/E8/RE/4/4/E8/1/3M/3M/3/10L/4/4/1/0/DN
MO+3/1FQL/4/5/2/LR/1/1/1/3/1/1/E7/E1/6L/70/3K/3B3/71/2/1/3B3/1/3K/3B3/1/71/2/1/2
/0/DNMO+3/1FQL/4/5/2/LR/1/1/1/3/1/1/E7/6L/*.70/3B3/3K/*.2/4/3K/1/70/3B3/1/70/2/4
/2/0/DNMO+3/1FR2/4/5/2/7F/8/1/1/3/1/1/DD/*.*.3AI/3K/3L/*.4/4/3AI/1/3K/3AI/1/3L/4
/4/1/0/DNMO+3/1FR2/4/5/2/7F/8/1/1/3/1/3/DD/*.*.3AI/3K/3L/3AN/4/4/3AI/1/3K/3AI/1/
3L/4/4/1/0/DNNQ+3/1GGL/4/1/2/N2/1/1/1/2/1/1/3R/48/*.70/71/3K/3L/4/4/3K/1/71/3L/1
/70/4/4/0/1/DNNQ+3/1GGL/4/1/2/N2/1/1/1/2/1/3/3R/48/3B/70/71/3K/3L/4/4/3K/1/71/3L
/1/70/1/1/0/0/DNL6+3/1PNE/5/4/1/K2/8/39/39/2/1/1/A6/EA/A2/3L/3AM/42/*.3/3/*.*.*.
*.*.*.3/3/2/0/DNL6+3/1PNE/5/4/1/K2/8/39/39/2/1/3/A2/A6/EA/3L/42/3AM/*.3/1/*.*.*.
*.*.*.3/2/3/0/DNLP6+2/1Q6Q/5/3/1/41/2/3/1/3/1/1/DF/*.*.71/N9/*.*.4/4/*.*.*.*.*.*
.4/4/0/0/DNLP6+2/1Q6Q/7/3/1/41/2/3/1/3/1/3/DF/*.*.71/N8/*.*.4/4/*.*.*.*.*.*.4/4/
0/1/DNNA+3/1RA8/5/3/1/86/8/3/4/3/1/1/DG/DF/9T/70/3AG/*.*.1/1/*.*.*.*.*.*.1/1/1/0
/DNNA+3/1RA8/5/3/1/86/8/3/4/3/1/3/DG/DF/9T/70/3AG/*.*.1/1/*.*.*.*.*.*.1/1/1/0/DN
ND6+2/1RDI/5/4/1/GS/C/5/1/3/1/1/72/3T/*.3B6/E6/3D9/*.4/1/3B6/3/3D9/*.*.*.1/4/0/0
/DNND6+2/1RDI/5/4/1/GS/C/5/1/3/1/3/72/3T/*.3B6/E6/3D9/*.4/1/3B6/3/3D9/*.*.*.3/1/
0/0/DNL6+3/26QQ/6/4/1/25/2/1/1/3/1/1/3C/6J/*.71/E8/E7/*.1/4/E8/1/71/E7/1/71/1/4/
0/1/DNL6+3/26QQ/6/4/1/25/2/1/1/3/1/3/3C/6J/*.71/E8/E7/*.1/4/E8/1/71/E7/1/71/1/4/
0/1/DNL96+2/270B/6/5/1/3B/4/1/1/3/1/1/6J/A9/6J/71/JT/3L/*.4/4/JT/1/71/*.*.*.1/4/
0/0/DNL96+2/270B/6/5/1/3B/4/1/1/3/1/3/6J/A9/*.71/JT/3L/*.4/4/JT/1/71/*.*.*.1/4/0
/0/DNL96+2/270F/6/5/1/AO/6/1/5/3/1/1/DE/E9/A1/71/3L/*.*.1/1/*.*.*.*.*.*.1/1/1/1/
DNL96+2/270F/6/5/1/AO/6/1/5/3/1/3/DE/E9/A1/3L/71/*.*.1/1/*.*.*.*.*.*.1/1/1/1/DNL
IO+2/273F/6/1/1/60/1/1/1/3/1/1/6O/6L/*.277/71/3AR/*.4/1/3AR/1/71/277/1/71/4/1/0/
0/DNLIO+2/273F/6/1/1/60/1/1/1/3/1/3/6O/6L/*.277/71/3AR/*.4/1/3AR/1/71/277/1/71/4
/1/1/0/DNMHI+2/27QO/6/3/1/2T/2/1/1/2/1/1/DE/EB/3H/KK/3K/3L/*.1/4/3K/1/KK/*.*.*.1
/4/1/0/DNMHI+2/27QO/6/3/1/2T/2/1/1/2/1/3/DE/EB/3H/KK/3K/3L/*.1/4/3K/1/KK/*.*.*.1
/4/1/0/DNL96+2/2I3E/7/5/1/S4/1/1/1/3/1/1/3G/*.*.E5/29T/10O/GI/1/1/GI/1/E5/GI/1/2
9T/1/1/0/0/DNL96+2/2I3E/7/5/1/S4/1/1/1/3/1/3/3G/*.*.E5/29T/E5/10O/1/1/GI/1/E5/GI
/1/29T/1/1/0/0/DNLP6+2/2IDG/7/3/1/P5/8/5/1/2/1/1/A7/DE/EA/72/3M/70/71/4/4/72/1/7
0/72/1/71/4/4/3/0/DNLP6+2/2IDG/7/3/1/P5/8/5/1/2/1/3/A7/DE/EA/3M/72/70/71/4/4/72/
1/70/72/1/71/4/4/3/0/DNMEC+2/2IQQ/7/2/1/HD/6/1/1/3/1/1/6Q/3P/*.E1/3K/3AM/*.4/4/E
1/1/3AM/3AM/1/3K/1/1/0/0/DNMEC+2/2IQQ/7/2/1/HD/6/1/1/3/1/3/6Q/3P/*.3K/E1/3AM/3D9
/4/4/E1/1/3AM/3AM/1/3K/1/1/0/0/DNND6+2/2JK8/7/4/1/8E/7/3/1/3/1/1/DH/*.*.KR/3L/3A
S/*.4/4/KR/3/3AS/*.*.*.4/4/1/0/DNND6+2/2JK8/7/4/1/8E/7/3/1/3/1/3/DH/*.*.KR/3AS/3
L/*.4/4/KR/3/3AS/*.*.*.4/4/2/0/DNO2C+2/2K3B/7/3/1/I5/2/1/1/2/1/1/6J/4A/6L/71/70/
*.*.4/4/71/1/70/70/1/71/4/1/0/0/DNO2C+2/2K3B/7/3/1/I5/2/1/1/2/1/3/6J/4A/6L/71/70
/*.*.4/4/71/1/70/70/1/71/4/1/0/0/DNO5I+2/2K6L/7/4/1/MR/1/1/1/3/1/1/6L/4A/*.70/71
/72/*.4/4/70/1/71/71/1/70/1/3/1/1/DNO5I+2/2K6L/7/4/1/MR/1/1/1/3/1/3/6L/4A/*.70/7
1/72/*.4/4/70/1/71/71/1/70/1/2/1/1/DNL96+2/2T6M/8/5/1/4G/2/3/1/3/1/1/DD/*.*.3AN/
3K/3L/*.4/4/*.*.*.*.*.*.4/4/1/0/DNL96+2/2T6M/8/5/1/4G/2/3/1/3/1/3/DD/*.*.3AN/3K/
3L/*.4/4/*.*.*.*.*.*.4/4/1/0/DNNA+3/30K6/8/3/1/7K/C/3/4/3/1/1/48/3J/*.3D9/46/*.*
.1/1/*.*.*.*.*.*.1/1/0/0/DNNA+3/30K6/8/3/1/7K/C/3/4/3/1/3/48/3J/*.3D9/46/*.*.2/2
/*.*.*.*.*.*.2/2/0/0/DNO5I+2/31A1/8/4/1/NR/1/3/4/3/1/1/6S/A3/*.70/71/3K/3L/3/1/*
.*.*.*.*.*.3/1/1/0/DNO5I+2/31A1/8/4/1/NR/1/3/4/3/1/3/6S/A3/*.70/71/3K/3L/3/1/*.*
.*.*.*.*.3/1/1/0/DNLSC+2/BR9/1/4/2/LC/H/4/1/3/1/2/A5/DI/EA/3K/*.*.*.2/*.*.*.*.*.
*.*.2/*.3/0/DNLSC+2/BR9/1/4/2/LC/H/4/1/3/1/5/A5/DI/EA/3K/*.*.*.2/*.*.*.*.*.*.*.2
/*.3/0/DNMHI+2/CA1/1/3/2/196/L/2/2/3/1/2/6J/A1/*.10B/L4/3D9/*.2/2/*.*.*.*.*.*.2/
2/0/0/DNMHI+2/CA1/1/3/2/196/L/5/1/3/1/5/6J/A1/A2/10B/L4/3D9/*.4/4/*.*.*.*.*.*.4/
4/0/0/DNN3I+2/CK7/1/1/2/44/6/1/1/3/1/2/49/6L/*.3B6/3K/GI/*.4/4/*.*.*.*.*.*.4/4/0
/0/DNN3I+2/CK7/1/1/2/44/6/1/1/3/1/5/49/6L/*.3B6/3K/GI/*.4/4/*.*.*.*.*.*.4/4/0/0/
DNNA+3/CRD/1/3/2/17C/L/2/5/3/1/2/A1/*.*.70/AG/*.*.3/4/AG/3/70/*.*.*.3/4/1/1/DNNA
+3/CRD/1/3/2/17C/L/2/5/3/1/5/A1/A3/*.70/3K/*.*.3/3/*.*.*.*.*.*.3/3/1/1/DNND6+2/D
07/1/4/2/AM/G/1/1/2/1/2/DK/*.*.AB/AE/*.*.4/4/*.*.*.*.*.*.4/4/2/0/DNND6+2/D07/1/4
/2/AM/G/1/1/2/1/5/DK/GJ/*.AB/AE/*.*.4/4/*.*.*.*.*.*.4/4/2/0/DNNGC+2/D3O/1/5/2/AL
/I/1/1/2/1/2/E2/*.*.AE/KR/3K/3L/4/4/*.*.*.*.*.*.4/4/2/0/DNNGC+2/D3O/1/5/2/AL/I/1
/1/3/1/5/E2/EC/*.AB/KR/3L/3K/4/4/*.*.*.*.*.*.4/4/2/0/DNL96+2/MGQ/2/5/2/PO/1/1/2/
2/1/2/A6/DH/*.3L/3K/AB/DP/4/4/*.*.*.*.*.*.4/4/1/0/DNL96+2/MGQ/2/5/2/PO/1/1/1/2/1
/5/A6/DH/A9/3L/3K/AB/H5/4/4/3L/1/3K/*.*.*.4/4/2/0/DNLM+3/MNC/2/2/2/HP/D/5/1/2/1/
2/3B/*.*.DS/H6/N8/*.2/1/*.*.*.*.*.*.2/1/0/1/DNLM+3/MNC/2/2/2/HP/D/5/1/2/1/5/3B/*
.*.DS/H6/*.*.2/1/*.*.*.*.*.*.2/1/0/0/DNLP6+2/MQL/2/3/2/53/1/1/1/2/1/2/3C/DG/*.72
/N9/3K/*.4/4/72/1/3K/*.*.*.4/4/1/0/DNLP6+2/MQL/2/3/2/53/1/1/1/2/1/5/3C/DG/*.72/N
9/3K/3L/4/4/72/1/3K/*.*.*.4/4/1/0/DNLP6+2/MR1/2/3/2/8P/D/5/1/3/1/2/A7/EA/*.3M/*.
*.*.2/*.*.*.*.*.*.*.2/*.2/0/DNLP6+2/MR1/2/3/2/8P/D/5/1/3/1/5/A7/EA/*.3M/*.*.*.4/
*.*.*.*.*.*.*.4/*.1/0/DNO5I+2/OKD/2/4/2/DN/E/1/1/3/1/2/6L/EA/*.3B6/71/72/70/4/4/
*.*.*.*.*.*.4/1/1/0/DNO5I+2/OKD/2/4/2/DN/E/1/1/3/1/5/6L/EA/*.3L/70/71/72/4/4/*.*
.*.*.*.*.4/4/0/0/DNL96+2/13K2/3/5/2/F0/7/1/1/3/1/2/3T/*.*.GI/E6/70/*.4/4/*.*.*.*
.*.*.4/4/0/0/DNL96+2/13K2/3/5/2/F0/7/1/1/3/1/5/3T/*.*.GI/3K/E6/*.4/4/*.*.*.*.*.*
.4/4/0/0/DNLP6+2/1401/3/3/2/CE/9/1/1/3/1/2/6J/A9/*.3D9/3L/6J/71/4/4/3D9/1/3L/*.*
.*.4/4/1/0/DNLP6+2/1401/3/3/2/CE/9/1/1/3/1/5/DF/A9/*.3D9/3L/71/6J/4/4/3AB/1/3L/*
.*.*.4/4/1/0/DNM1I+2/146S/3/5/2/MR/2/1/8/2/1/2/3B/44/*.71/AE/70/275/2/3/*.*.*.*.
*.*.2/3/0/0/DNM1I+2/146S/3/5/2/MR/2/1/8/3/1/5/3B/44/*.71/AE/70/275/2/3/*.*.*.*.*
.*.2/3/0/0/DNMKO+2/14KD/3/4/2/CS/A/1/1/3/1/2/6J/DF/*.139/3R/3D9/3K/4/4/139/1/3R/
*.*.*.4/4/0/0/DNMKO+2/14KD/3/4/2/CS/A/1/1/3/1/5/6J/DF/*.139/3R/3AB/*.4/4/139/1/3
R/*.*.*.4/4/0/0/DNN6O+2/150E/3/2/2/89/O/2/39/3/2/2/3C/72/*.70/72/DO/*.1/1/*.*.*.
*.*.*.1/1/0/0/DNN6O+2/150E/3/2/2/89/O/2/39/3/2/5/3C/72/*.70/72/DO/*.1/1/*.*.*.*.
*.*.1/1/0/1/DNNGC+2/15AE/3/5/2/RG/A/5/2/3/1/2/6J/*.*.GI/H5/N8/3B6/4/4/N8/1/GI/*.
*.*.3/1/1/0/DNNGC+2/15AE/3/5/2/RG/A/5/2/3/1/5/6J/3C/*.GI/H5/3B6/N8/4/4/N8/1/GI/3
AQ/4/GI/4/4/1/0/DNL2O+2/1EGL/4/3/2/RK/G/5/2/1/1/2/6Q/45/*.3AM/3K/3L/*.1/4/*.*.*.
*.*.*.1/4/0/0/DNL2O+2/1EGL/4/3/2/RK/G/5/5/3/1/5/6Q/45/3K/3AM/3K/3L/3M/1/4/*.*.*.
*.*.*.1/4/0/0/DNMHI+2/1FK2/4/3/2/B4/6/1/1/2/1/2/DG/3B/*.10M/70/71/3K/4/4/10M/1/7
0/10M/1/3K/4/4/1/0/DNMHI+2/1FK2/4/3/2/B4/6/1/1/2/1/5/DG/3B/*.10M/70/71/*.4/4/10M
/1/70/*.*.*.4/4/1/0/DNN6O+2/1G41/4/2/2/194/3/1/5/3/1/2/DG/*.*.3K/3L/AC/H2/4/2/*.
*.*.*.*.*.4/1/2/0/DNN6O+2/1G41/4/2/2/194/3/1/5/3/1/5/DG/*.*.3K/3L/AC/H2/4/2/*.*.
*.*.*.*.4/2/2/0/DNND6+2/1GAE/4/4/2/KE/8/3/39/3/1/2/6T/6J/*.3B6/70/3K/3L/4/2/3B6/
2/3K/3B6/2/3L/4/2/0/0/DNND6+2/1GAE/4/4/2/KE/8/3/39/3/1/5/6T/3F/*.3B6/70/3K/3L/4/
2/3B6/2/70/*.*.*.4/2/0/0/DNNGC+2/1GDG/4/5/2/90/6/1/1/2/1/2/DE/*.*.3K/3L/AB/E3/4/
4/E3/1/3L/*.*.*.4/1/2/0/DNNGC+2/1GDG/4/5/2/90/6/1/1/3/1/5/DE/*.*.3K/3L/AB/E3/4/4
/E3/1/3K/*.*.*.4/1/1/0/DNNQ+3/1GGP/4/1/2/9S/6/1/1/3/1/2/6J/3L/*.3M/72/3K/3L/4/4/
*.*.*.*.*.*.1/1/0/0/DNNQ+3/1GGP/4/1/2/9S/6/1/1/3/1/5/6J/3L/*.3M/72/3L/3K/4/4/*.*
.*.*.*.*.4/4/0/0/DNNT6+2/1GKF/4/2/2/EN/8/1/1/3/1/2/DN/*.*.71/42/44/3B3/4/4/42/1/
71/*.*.*.4/4/0/0/DNNT6+2/1GKF/4/2/2/EN/8/1/1/3/1/5/DN/3C/*.71/3K/44/3B3/4/4/3K/1
/71/*.*.*.4/4/0/0/DNLIO+2/1Q01/5/1/1/7N/9/3/1/2/1/2/DE/EC/*.3AC/70/3AL/*.4/2/*.*
.*.*.*.*.4/2/1/0/DNLIO+2/1Q01/5/1/1/7N/9/3/1/2/1/5/DE/EC/*.3AC/70/3AL/*.4/4/*.*.
*.*.*.*.4/4/1/0/DNLM+3/1Q3E/5/2/1/4B/2/1/1/3/1/2/DB/A5/*.3AQ/70/3D9/*.4/4/*.*.*.
*.*.*.4/4/1/0/DNLM+3/1Q3E/5/2/1/4B/2/1/1/2/1/5/DB/A5/*.70/3AQ/*.*.4/4/*.*.*.*.*.
*.4/4/1/0/DNMB6+2/1QGL/5/1/1/NL/8/39/5/2/1/2/A2/DB/DC/71/3L/*.*.1/1/*.*.*.*.*.*.
1/1/3/0/DNMB6+2/1QGL/5/1/1/NL/8/39/5/2/1/5/A2/A3/EA/3L/71/*.*.1/1/*.*.*.*.*.*.1/
1/2/0/DNMKO+2/1QQL/5/4/1/75/1/1/1/2/1/2/3B/6Q/*.3B6/70/*.*.4/3/3B6/3/70/*.*.*.4/
3/0/1/DNMKO+2/1QQL/5/4/1/75/1/1/1/2/1/5/3B/6S/*.3B6/70/*.*.4/3/3B6/3/70/*.*.*.4/
3/0/1/DNMKO+2/1QQM/5/4/1/67/8/3/4/3/1/2/DG/DF/*.70/AB/*.*.4/4/*.*.*.*.*.*.4/4/1/
0/DNMKO+2/1QQM/5/4/1/67/8/3/4/3/1/5/DG/DF/*.70/3K/AB/*.4/4/*.*.*.*.*.*.4/4/1/0/D
NL6+3/26QL/6/4/1/M6/4/1/1/2/1/2/3I/EA/*.70/AB/DP/3L/4/4/*.*.*.*.*.*.4/4/2/0/DNL6
+3/26QL/6/4/1/M6/4/1/1/2/1/5/3I/EA/*.70/AB/DP/3L/4/4/*.*.*.*.*.*.4/4/3/0/DNLP6+2
/27A5/6/3/1/21/2/3/1/3/1/2/6J/*.*.N8/*.*.*.4/*.*.*.*.*.*.*.4/*.0/0/DNLP6+2/27A5/
6/3/1/21/2/3/1/3/1/5/6J/*.*.N8/*.*.*.4/*.*.*.*.*.*.*.4/*.0/0/DNO2C+2/2907/6/3/1/
82/4/5/1/2/1/2/3G/*.*.70/E5/71/H2/4/4/71/1/70/*.*.*.1/1/0/0/DNO2C+2/2907/6/3/1/8
2/4/5/1/3/1/5/3G/*.*.70/E5/71/H2/4/4/71/1/70/H2/1/E5/1/1/0/0/DNLIO+2/2I6L/7/1/1/
53/4/3/1/2/2/2/72/3B/*.270/*.*.*.4/*.*.*.*.*.*.*.4/*.0/0/DNLIO+2/2I6L/7/1/1/53/4
/3/1/3/1/5/6J/3B/*.270/*.*.*.4/*.*.*.*.*.*.*.4/*.0/0/DNNGC+2/30QT/8/5/1/4E/9/3/1
/3/1/2/E1/*.*.3B3/3K/3L/*.4/4/3B3/1/3K/3B3/1/3L/4/1/1/0/DNNGC+2/30QT/8/5/1/4E/9/
3/1/3/1/5/E1/*.*.3B3/3K/3L/*.4/4/3B3/1/3K/3B3/1/3L/4/1/0/0/DNO5I+2/31A7/8/4/1/LS
/B/1/2/3/1/2/D9/*.*.70/AB/71/72/2/2/*.*.*.*.*.*.2/2/0/2/DNO5I+2/31A7/8/4/1/LS/B/
1/2/3/1/5/A1/A3/*.70/71/72/*.3/1/*.*.*.*.*.*.3/1/0/1/DNO5I+2/31AB/8/4/1/RK/C/1/4
/3/1/2/A1/*.*.70/3L/10M/71/3/1/*.*.*.*.*.*.3/1/1/1/DNO5I+2/31AB/8/4/1/RK/C/1/4/3
/1/5/A1/*.*.3L/3K/71/*.1/4/*.*.*.*.*.*.1/4/0/1/DNL96+2/BDC/1/5/2/K0/J/3/4/3/1/2/
A6/EA/*.71/3K/H5/*.2/2/*.*.*.*.*.*.2/2/2/0/DNL96+2/BDC/1/5/2/K0/J/3/4/3/1/4/A6/E
A/*.71/3K/H5/*.2/4/*.*.*.*.*.*.2/4/2/0/DNLM+3/BK2/1/2/2/RK/1/1/1/3/1/2/DE/3H/A9/
3K/71/KK/H5/4/1/3K/1/71/*.*.*.4/1/1/0/DNLM+3/BK2/1/2/2/RK/1/1/1/3/1/4/DE/3H/*.3K
/71/KK/H5/4/4/3K/1/71/*.*.*.4/1/1/0/DNN6O+2/CNP/1/2/2/F9/F/4/2/3/1/2/DO/E4/*.GJ/
70/3D9/*.4/4/*.*.*.*.*.*.4/4/1/0/DNN6O+2/CNP/1/2/2/F9/F/4/1/3/1/4/DO/E4/*.GJ/70/
*.*.4/4/*.*.*.*.*.*.4/4/1/0/DNO5I+2/DH0/1/4/2/E7/H/1/1/3/1/2/6L/*.*.3K/3L/3M/*.4
/4/*.*.*.*.*.*.3/1/0/0/DNO5I+2/DH0/1/4/2/E7/H/1/1/3/1/4/6L/3R/*.3K/3L/*.*.4/4/*.
*.*.*.*.*.3/4/0/0/DNL6+3/MDM/2/4/2/D8/B/5/1/3/1/2/6Q/*.*.3AM/71/*.*.4/2/*.*.*.*.
*.*.4/2/0/1/DNL6+3/MDM/2/4/2/D8/B/5/1/3/1/4/6Q/*.*.71/3AM/*.*.4/4/3AM/1/71/*.*.*
.2/4/0/0/DNL96+2/MGL/2/5/2/62/B/3/1/2/1/2/A6/DI/*.H5/3K/*.*.4/4/*.*.*.*.*.*.4/4/
2/0/DNL96+2/MGL/2/5/2/62/B/3/1/2/1/4/A6/DI/*.H5/3K/*.*.4/4/*.*.*.*.*.*.4/4/2/0/D
NND6+2/O3S/2/4/2/DR/H/1/1/2/1/2/DG/DE/*.70/71/*.*.4/4/*.*.*.*.*.*.4/4/2/0/DNND6+
2/O3S/2/4/2/DR/H/1/1/3/1/4/DG/*.*.70/71/*.*.4/4/*.*.*.*.*.*.4/4/1/0/DNLP6+2/1404
/3/3/2/LQ/8/5/2/3/1/2/6J/EA/*.3K/GI/70/*.4/4/*.*.*.*.*.*.4/4/2/0/DNLP6+2/1404/3/
3/2/LQ/8/5/2/3/1/4/A5/EA/*.3K/*.*.*.4/*.*.*.*.*.*.*.4/*.3/0/DNMO+3/14NE/3/5/2/A7
/6/5/1/3/1/2/47/6L/*.71/3AB/3B6/3K/4/4/3AB/1/71/3AB/1/3K/1/4/1/0/DNMO+3/14NE/3/5
/2/A7/6/5/1/3/1/4/DR/6L/*.71/3AB/*.*.4/4/3AB/2/71/*.*.*.2/4/0/0/DNL2O+2/1EGM/4/3
/2/176/3/3/4/3/1/2/3R/EA/A3/70/71/72/*.2/2/*.*.*.*.*.*.2/2/1/1/DNL2O+2/1EGM/4/3/
2/176/3/3/4/3/1/4/A3/EA/3R/70/71/72/*.2/2/*.*.*.*.*.*.2/2/1/1/DNLM+3/1F02/4/2/2/
6J/3/3/4/3/1/2/3I/3C/6S/3B8/3K/3L/3M/4/4/*.*.*.*.*.*.4/4/0/0/DNLM+3/1F02/4/2/2/6
J/3/3/4/3/1/4/3I/3C/6S/3B8/3K/*.*.4/4/*.*.*.*.*.*.4/4/0/0/DNLSC+2/1F6M/4/4/2/1AB
/3/1/5/3/1/2/A5/6J/EA/70/*.*.*.2/*.*.*.*.*.*.*.2/*.2/0/DNLSC+2/1F6M/4/4/2/1AB/3/
5/1/3/1/4/A5/*.*.70/*.*.*.2/*.*.*.*.*.*.*.2/*.2/0/DNNT6+2/1GKD/4/2/2/F2/8/1/1/3/
1/2/3M/*.*.49/70/*.*.4/4/*.*.*.*.*.*.4/4/0/0/DNNT6+2/1GKD/4/2/2/F2/8/1/1/3/1/4/3
M/*.*.49/70/*.*.4/4/*.*.*.*.*.*.4/4/0/0/DNMB6+2/1QGO/5/1/1/9J/1/1/1/3/1/2/DE/*.*
.70/71/H5/KK/4/4/70/1/71/*.*.*.3/1/1/0/DNMB6+2/1QGO/5/1/1/9J/1/1/1/3/1/4/DE/*.*.
70/71/H5/*.4/4/70/1/71/*.*.*.4/1/1/0/DNMEC+2/27NB/6/2/1/1K/2/3/1/3/1/2/AD/*.*.70
/AB/*.*.4/1/*.*.*.*.*.*.4/1/0/0/DNMEC+2/27NB/6/2/1/1K/2/3/1/3/1/4/AD/*.*.AB/70/*
.*.4/4/*.*.*.*.*.*.1/4/0/0/DNO5I+2/293P/6/4/1/33/A/5/1/3/2/2/72/*.*.70/3AL/*.*.4
/4/*.*.*.*.*.*.3/4/0/0/DNO5I+2/293P/6/4/1/33/A/5/1/3/2/4/72/*.*.70/3AL/*.*.4/4/*
.*.*.*.*.*.4/4/0/0/DNL6+3/2I01/7/4/1/BA/6/5/1/3/1/2/6L/DB/*.70/3AQ/H0/*.4/4/3AQ/
1/70/H0/1/70/1/4/1/0/DNL6+3/2I01/7/4/1/BA/6/5/1/3/1/4/6L/DB/*.3AQ/70/H0/*.4/1/3A
Q/1/3K/H0/1/70/4/1/1/0/DNN6O+2/2JDG/7/2/1/PI/4/1/1/2/1/2/A1/*.*.10B/L4/3B6/*.2/4
/*.*.*.*.*.*.2/4/0/0/DNN6O+2/2JDG/7/2/1/PI/4/5/1/3/1/4/A1/*.*.10B/L4/3B6/*.2/4/3
B6/2/10B/*.*.*.2/4/0/0/DNNGC+2/30R0/8/5/1/9A/C/3/4/3/1/2/A3/DB/DC/70/3AQ/3K/3L/2
/4/3AQ/1/3K/*.*.*.2/4/1/0/DNNGC+2/30R0/8/5/1/9A/C/3/4/4/1/4/A3/DB/DC/3K/3AQ/*.*.
2/4/3AQ/1/3K/*.*.*.2/4/1/0/ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
